import { RESPONSE_CODE } from "../completion/util/consants"

export type ChatFuncParams = {
	prompt: string
	appId: string
	token?: string
	options?: {
		isCache: boolean
	}
}

export type ChatResponseCodeType = typeof RESPONSE_CODE.SUCCESS | typeof RESPONSE_CODE.RESPONSE_ERROR

export type ChatResponseType = {
	value: string
	code: ChatResponseCodeType
}
