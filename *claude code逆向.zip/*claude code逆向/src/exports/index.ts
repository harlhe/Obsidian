import * as vscode from "vscode"
import { Controller } from "@core/controller"
import { ClineAPI } from "./cline"
import { getGlobalState } from "@core/storage/state"

import { ChatFuncParams, ChatResponseType } from "./type"
import { checkResult } from "../util/decorators"
import { LOG_KEYS } from "../completion/util/consants"
import { eventManager } from "../util/eventEmitter"
import { event } from "../util/constants"
import { RESPONSE_CODE } from "../completion/util/consants"

export function createClineAPI(outputChannel: vscode.OutputChannel, sidebarController: Controller): ClineAPI {
	const api: ClineAPI = {
		setCustomInstructions: async (value: string) => {
			await sidebarController.updateCustomInstructions(value)
			outputChannel.appendLine("Custom instructions set")
		},

		getCustomInstructions: async () => {
			return (await getGlobalState(sidebarController.context, "customInstructions")) as string | undefined
		},

		startNewTask: async (task?: string, images?: string[]) => {
			outputChannel.appendLine("Starting new task")
			await sidebarController.clearTask()
			await sidebarController.postStateToWebview()
			await sidebarController.postMessageToWebview({
				type: "action",
				action: "chatButtonClicked",
			})
			await sidebarController.postMessageToWebview({
				type: "invoke",
				invoke: "sendMessage",
				text: task,
				images: images,
			})
			outputChannel.appendLine(
				`Task started with message: ${task ? `"${task}"` : "undefined"} and ${images?.length || 0} image(s)`,
			)
		},

		sendMessage: async (message?: string, images?: string[]) => {
			outputChannel.appendLine(
				`Sending message: ${message ? `"${message}"` : "undefined"} with ${images?.length || 0} image(s)`,
			)
			await sidebarController.postMessageToWebview({
				type: "invoke",
				invoke: "sendMessage",
				text: message,
				images: images,
			})
		},

		pressPrimaryButton: async () => {
			outputChannel.appendLine("Pressing primary button")
			await sidebarController.postMessageToWebview({
				type: "invoke",
				invoke: "primaryButtonClick",
			})
		},

		pressSecondaryButton: async () => {
			outputChannel.appendLine("Pressing secondary button")
			await sidebarController.postMessageToWebview({
				type: "invoke",
				invoke: "secondaryButtonClick",
			})
		},
	}

	return api
}

const chat = ({ prompt, appId, options }: ChatFuncParams): Promise<ChatResponseType> => {
	checkResult(LOG_KEYS.exportChat, { prompt, appId, options })
	vscode.commands.executeCommand("zteChatGPT.chat", { prompt, appId, options })
	return new Promise((resolve, reject) => {
		try {
			eventManager.on(event.CHAT_RESPONSE, ({ value, code }: ChatResponseType) => {
				resolve({
					value,
					code,
				})
			})
		} catch (e) {
			reject({
				value: e,
				code: RESPONSE_CODE,
			})
		}
	})
}

export { chat }
