import { INDEX_API_URL } from "@/util/constants"
import Authentication from "@/util/authentication"
import { IndexManager } from "@/codebase"

/**
 * @param {string} query 查询内容
 * @returns {Promise<any>} 检索结果
 */
export async function queryCodebase(query: string): Promise<string> {
	const url = `${INDEX_API_URL}/CodeBaseIndex/retrieve`
	const userInfo = Authentication.getAuthenticationInfo()
	const body = {
		projectPathHash: IndexManager.projectSha256,
		user_name: userInfo.userId,
		query,
	}
	const controller = new AbortController()
	const timeout = 20000 // 10秒超时
	const timeoutId = setTimeout(() => controller.abort(), timeout)

	try {
		const response = await fetch(url, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify(body),
			signal: controller.signal,
		})
		clearTimeout(timeoutId)
		if (!response.ok) {
			throw new Error(`HTTP error! status: ${response.status}`)
		}
		const result = await response.json()
		console.log("queryCodebase result:", result.context_text || "")
		const formatResult = (result.context_text || "") + "\n" + result.repomap
		return Promise.resolve(formatResult)
	} catch (error) {
		clearTimeout(timeoutId)
		console.error("queryCodebase error:", error)
		throw error
	}
}
