import { AGENT_REPORT_URL } from "../util/constants"

// AI服务API接口定义
export interface AiServiceRequest {
	user_id: string // 必填参数
	ai_code: string // 必填参数
	function?: string // 可选参数
	scene?: string // 可选参数
	need_parse?: boolean // 可选参数，默认true
	repo?: string // 可选参数
	file_path?: string // 可选参数
}

export interface AiServiceResponse {
	// 根据实际API响应结构定义，这里给出通用结构
	success: boolean
	data?: any
	message?: string
	code?: number
}

/**
 * AI服务POST请求
 * @param params 请求参数
 * @returns Promise<AiServiceResponse>
 */
export async function postAiReport(params: AiServiceRequest): Promise<AiServiceResponse> {
	// 验证必填参数
	if (!params.user_id) {
		throw new Error("user_id is required")
	}
	if (!params.ai_code) {
		throw new Error("ai_code is required")
	}

	// 构建请求体，设置默认值
	const requestBody: AiServiceRequest = {
		user_id: params.user_id,
		ai_code: params.ai_code,
		need_parse: false,
	}

	try {
		const response = await fetch(`${AGENT_REPORT_URL}`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Accept: "application/json",
			},
			body: JSON.stringify(requestBody),
		})

		// 检查响应状态
		if (!response.ok) {
			throw new Error(`HTTP error! status: ${response.status}, statusText: ${response.statusText}`)
		}

		// 解析响应数据
		const data: AiServiceResponse = await response.json()
		return data
	} catch (error) {
		console.error("AI Service API request failed:", error)

		// 重新抛出错误，包含更多上下文信息
		if (error instanceof Error) {
			throw new Error(`AI Service API request failed: ${error.message}`)
		} else {
			throw new Error("AI Service API request failed: Unknown error")
		}
	}
}

/**
 * 带有重试机制的AI服务请求
 * @param params 请求参数
 * @param maxRetries 最大重试次数，默认3次
 * @param retryDelay 重试间隔时间（毫秒），默认1000ms
 * @returns Promise<AiServiceResponse>
 */
export async function postAiServiceWithRetry(
	params: AiServiceRequest,
	maxRetries: number = 3,
	retryDelay: number = 1000,
): Promise<AiServiceResponse> {
	let lastError: Error

	for (let attempt = 1; attempt <= maxRetries; attempt++) {
		try {
			return await postAiReport(params)
		} catch (error) {
			lastError = error instanceof Error ? error : new Error("Unknown error")

			if (attempt === maxRetries) {
				break
			}

			console.warn(`AI Service API request attempt ${attempt} failed, retrying in ${retryDelay}ms...`, lastError.message)

			// 等待重试间隔
			await new Promise((resolve) => setTimeout(resolve, retryDelay))
		}
	}

	throw new Error(`AI Service API request failed after ${maxRetries} attempts. Last error: ${lastError!.message}`)
}

export const aiServiceApi = {
	post: postAiReport,
	postWithRetry: postAiServiceWithRetry,
}
