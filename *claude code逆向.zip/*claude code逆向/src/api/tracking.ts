import { TrackTypeV2, TraceTypeV2 } from "../types/index"
import * as vscode from "vscode"
import { constructRequestUrl } from "../util"
import { getPackageVersion } from "../util/getPackageVersion"
import { urlPath } from "../util/constants"
import { UserInfoType } from "../types/index"
import { RequestHeaderType, TraceType } from "../completion/types"
const { v4: uuidv4 } = require("uuid")

export const trackingV2 = async function (trackingParam: TrackTypeV2) {
	try {
		const body: any = {
			chatId: trackingParam?.chatUuid,
			docId: trackingParam?.originDocId,
			completionType: trackingParam?.completionType,
			acceptType: trackingParam?.acceptType,
			partialAcceptCode: trackingParam?.content,
		}
		const userInfo: UserInfoType = await vscode.commands.executeCommand("zteChatGPT.getUserInfo")
		const headers: any = {
			"Content-Type": "application/json",
			"X-Emp-No": userInfo.userId,
			"X-Auth-Value": userInfo.token,
			"X-Plugin-Type": "VSCODE",
			"X-Plugin-UserAgent": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-UserAgent"] : "",
			"X-Plugin-Version": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-Version"] : "",
			"X-Plugin-Platform": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-Platform"] : "",
			"X-Plugin-Repo": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-Repo"] : "",
			"X-Plugin-Branch": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-Branch"] : "",
			"X-Plugin-FilePath": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-FilePath"] : "",
			"X-Plugin-ContentType": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-ContentType"] : "",
			"X-Tenant-Code": trackingParam?.extendProps ? trackingParam?.extendProps["X-Tenant-Code"] : "",
			"X-Plugin-Delay": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-Delay"] : "",
		}
		const response = await fetch(constructRequestUrl(urlPath.metric), {
			method: "POST",
			headers,
			body: JSON.stringify(body),
		})
		const resText = await response.text()
		console.log(resText)
	} catch (error: any) {
		return Promise.reject(error)
	}
}

export type TracingClassType = {
	setTracingParams: (traceType: TraceTypeV2) => void
	run: () => Promise<void>
	tracingId: string
	initTracingParams: () => void
}

export class RequestHead {
	protected tracingHeader: RequestHeaderType

	constructor() {
		this.tracingHeader = {
			"Content-Type": "application/json",
			"X-Emp-No": "",
			"X-Auth-Value": "",
		}
		this.initializeHeaders()
	}

	protected initializeHeaders() {
		return new Promise<void>((resolve, reject) => {
			try {
				vscode.commands.executeCommand("zteChatGPT.getUserInfo").then((value: unknown) => {
					const userInfo = <UserInfoType>value
					this.tracingHeader["X-Auth-Value"] = userInfo.token
					this.tracingHeader["X-Emp-No"] = userInfo.userId
					resolve()
				})
			} catch (error) {
				reject(error)
			}
		})
	}
}

export class Tracing extends RequestHead implements TracingClassType {
	private tracingBody: TraceType
	public tracingId: string

	constructor() {
		super()
		this.tracingId = ""
		this.tracingBody = {
			resourceSpans: [
				{
					resource: {
						attributes: [
							{
								key: "service.name",
								value: {
									stringValue: "前端",
								},
							},
						],
					},
					scopeSpans: [
						{
							spans: [
								{
									traceId: this.tracingId,
									spanId: "",
									name: "",
									startTimeUnixNano: "",
									endTimeUnixNano: "",
									kind: 2,
									attributes: [
										{
											key: "ide",
											value: {
												stringValue: "vscode",
											},
										},
									],
								},
							],
						},
					],
				},
			],
		}
	}

	public async initTracingParams() {
		await this.initializeHeaders()
		this.tracingBody.resourceSpans[0].scopeSpans[0].spans = []
	}

	public setTracingParams(traceType: TraceTypeV2) {
		const { name, startTimeUnixNano, endTimeUnixNano } = traceType
		const span = {
			traceId: this.tracingId,
			spanId: this.genSpanId(),
			name,
			startTimeUnixNano,
			endTimeUnixNano,
			kind: 2,
			attributes: [
				{
					key: "ide",
					value: {
						stringValue: "vscode",
						pluginVersion: getPackageVersion(),
					},
				},
			],
		}
		this.tracingBody.resourceSpans[0].scopeSpans[0].spans.push(span)
	}

	private genSpanId() {
		return uuidv4().replace(/-/g, "").slice(0, 16)
	}

	public async run(): Promise<void> {
		try {
			const response = await fetch(constructRequestUrl(urlPath.trace), {
				method: "POST",
				headers: <any>this.tracingHeader,
				body: JSON.stringify(this.tracingBody),
			})
			const resText = await response.text()
			console.log(resText)
		} catch (error: any) {
			return Promise.reject(error)
		}
	}
}

export const resInterception = async function (trackingParam: TrackTypeV2) {
	try {
		const body: any = {
			chatId: trackingParam?.chatUuid,
			docId: trackingParam?.originDocId,
		}
		const userInfo: UserInfoType = await vscode.commands.executeCommand("zteChatGPT.getUserInfo")
		const headers: any = {
			"Content-Type": "application/json",
			"X-Emp-No": userInfo.userId,
			"X-Auth-Value": userInfo.token,
			"X-Plugin-Type": "VSCODE",
			"X-Plugin-UserAgent": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-UserAgent"] : "",
			"X-Plugin-Version": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-Version"] : "",
			"X-Plugin-Platform": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-Platform"] : "",
			"X-Plugin-Repo": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-Repo"] : "",
			"X-Plugin-Branch": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-Branch"] : "",
			"X-Plugin-FilePath": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-FilePath"] : "",
			"X-Plugin-ContentType": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-ContentType"] : "",
			"X-Tenant-Code": trackingParam?.extendProps ? trackingParam?.extendProps["X-Tenant-Code"] : "",
			"X-Plugin-Delay": trackingParam?.extendProps ? trackingParam?.extendProps["X-Plugin-Delay"] : "",
		}
		const response = await fetch(constructRequestUrl(urlPath.interception), {
			method: "POST",
			headers,
			body: JSON.stringify(body),
		})
		const resText = await response.text()
		console.log(resText)
	} catch (error: any) {
		return Promise.reject(error)
	}
}

export const preemptiveInterception = async function (trackingParam: TrackTypeV2, reason: string) {
	try {
		const body: any = {
			contentType: trackingParam?.extendProps?.["X-Plugin-ContentType"] ?? "",
			actionType: trackingParam?.actionType ?? "",
			bizApp: "icode",
			userAgent: trackingParam?.extendProps?.["X-Plugin-UserAgent"] ?? "",
			extendProps: {
				"icode-ai-plugin-version": trackingParam?.extendProps?.["X-Plugin-Version"] ?? "",
				"icode-ai-plugin-platform": trackingParam?.extendProps?.["X-Plugin-Platform"] ?? "",
				"icode-ai-plugin-completion-intercept-reason": reason,
				"icode-ai-plugin-type": "VSCODE",
			},
		}
		const userInfo: UserInfoType = await vscode.commands.executeCommand("zteChatGPT.getUserInfo")
		const headers: any = {
			"Content-Type": "application/json",
			"X-Emp-No": userInfo.userId,
			"X-Auth-Value": userInfo.token,
		}
		const response = await fetch(constructRequestUrl(urlPath.preemptive), {
			method: "POST",
			headers,
			body: JSON.stringify(body),
		})
		const resText = await response.text()
		console.log(resText)
	} catch (error: any) {
		return Promise.reject(error)
	}
}

export const feedback = async function () {
	try {
		const userInfo: UserInfoType = await vscode.commands.executeCommand("zteChatGPT.getUserInfo")
		const headers: any = {
			"Content-Type": "application/json",
			"X-Emp-No": userInfo.userId,
			"X-Auth-Value": userInfo.token,
		}
		const response = await fetch(constructRequestUrl(urlPath.feedback), {
			method: "GET",
			headers,
		})
		const text = await response.text()
		let resJson: any = {}
		try {
			resJson = JSON.parse(text)
		} catch (e) {
			console.log("response is not valid JSON")
		}
		// 正确获取 tempUrl
		const tempUrl = resJson?.bo?.tempUrl
		return tempUrl || ""
	} catch (e: any) {
		console.log("feedback is error:", e)
		return ""
	}
}
