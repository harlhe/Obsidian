import * as vscode from "vscode"
import { EVENT_NAME } from "./util/constants"
import nls from "./nls"

export default class AppWebviewProvider {
	private webUrl: string
	public panel: vscode.WebviewPanel | null
	private theme: number
	private lang: string
	static instance: any

	constructor(appUrl: string, theme: number, lang: string) {
		if (!AppWebviewProvider.instance) {
			AppWebviewProvider.instance = this
		}
		this.webUrl = appUrl
		this.panel = null
		this.theme = theme
		this.lang = lang
		return AppWebviewProvider.instance
	}

	public createAppWebviewProvider() {
		this.panel = vscode.window.createWebviewPanel("AppManagement", nls.t("icode.extension.title"), vscode.ViewColumn.One, {
			enableScripts: true,
		})
		this.panel.webview.html = this.getWebviewContent()

		this.panel.onDidDispose(() => {
			this.panel = null
		})
		this.initReceiveMessage()
		return this.panel
	}

	public getAppViewTheme(eventName: string, data?: { [key: string]: any }) {
		this.panel &&
			this.panel.webview.postMessage(
				JSON.stringify({
					type: eventName,
					data,
				}),
			)
	}

	public getAppLang(lang: string) {
		this.panel &&
			this.panel.webview.postMessage(
				JSON.stringify({
					type: EVENT_NAME.LANG,
					data: {
						value: lang,
					},
				}),
			)
	}

	public initReceiveMessage() {
		this.panel &&
			this.panel.webview.onDidReceiveMessage((data) => {
				switch (data.type) {
					case "queryCurrentTheme":
						this.getAppViewTheme(EVENT_NAME.SEND_THEME, { kind: this.theme })
						break
					case "queryLang":
						this.getAppLang(this.lang)
						break
				}
			})
	}

	public getWebviewContent() {
		return `<!DOCTYPE html>
      <html lang="en" style='height: 100%'>
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${nls.t("icode.extension.title")}</title>
      </head>
			<script>
				const vscode = acquireVsCodeApi();
				window.onload = function() {
					vscode.postMessage({
						type: 'queryCurrentTheme'
					})
          		vscode.postMessage({
						type: 'queryLang'
					})
				}
				function sentMessageToChatIframe(messageObj) {
          		const origin="*"
					document
						.getElementById("app-webview")
						.contentWindow.postMessage(JSON.stringify(messageObj), origin);
				}
				window.addEventListener("message", (e) => {
					if (!e.data) {
						return;
					}
					let formatMsg;
					try {
						formatMsg = JSON.parse(e.data);
						console.log(formatMsg);
					} catch (error) {
						console.error(error);
					} 
					if (!formatMsg) {
						return;
					}
					const type = formatMsg.type;
					switch (type) {
						case "SEND_THEME":
							console.log(formatMsg)
							sentMessageToChatIframe(formatMsg);
							break;
						case "LANG":
							sentMessageToChatIframe(formatMsg);
							break;
						default:
							break;
								}
							})
			</script>
      <body style='height: 100%; overflow: hidden; padding: unset'>
          <iframe id='app-webview' style='height: 100%; border: unset; width: 100%;' src="${this.webUrl}/application"></iframe>
      </body>
      </html>`
	}
}
