import { CompletionType, VariableInfo } from "../completion/types"

export type ModelType = "gpt-35-turbo" | "gpt-3.5-turbo" | "zte" | "starcoder-v1"

export type ChatGPTViewProviderType = {
	model: ModelType
}

export type SendChatGptMessageType = {
	chatUuid?: string
	question: string
	userId: string
	token: string
	onProgress?: (param: { text: string; chatUuid: string }) => void
	errorHandler?: (e: string) => void
	mode?: "stream" | "ask"
	doneResponse?: () => void
	model: ModelType
	type: "explain" | "optimize" | "findbug" | "genUT" | "genUTShortCut" | "chat"
	initFeedback?: (docId: string) => void
	abortRequestControllerCallback?: (abortController: any) => void
	reciveFeedbackId?: (docId: string) => void
	notSaveChatUuid?: boolean
}

export type RequestHeadType = {
	"X-Auth-Value": string
	"X-Emp-No": string
	"X-Lang-Id": "zh_CN"
	"Content-Type": "application/json"
}

export type RequestBodyType = {
	chatUuid: string
	keep: boolean
	text: string
	stream: boolean
	model: ModelType
}

export type ResponseType = {
	code: {
		code: string
	}
}

export type LogType = "trace" | "info" | "debug" | "warn" | "error"

export type FeedbackType = "approve" | "cancelApprove" | "disapprove" | "cancelDisapprove"

export type QuickPickListType = "zte" | "ms" | "all"

export type TrackingType = "chat" | "explain" | "optimize" | "findbug" | "generate" | "copy" | "replace" | "genUT"

export type TestFrameType = "auto" | "gtest" | "cunit" | "cppunit"

export type MockToolType = "" | "mockcpp" | "gmock"

export type netWorkType = "externalNetwork" | "testEnv" | "innerNetwork"

export type UserInfoType = {
	token: string
	userId: string
	tenant?: string
}

export interface TrackTypeV2 {
	userId: string
	token: string
	actionType: string
	model: string
	chatUuid?: string
	originDocId?: string
	content?: string
	username: string
	contentLength?: number
	docIdContent?: string
	docIdContentLength?: number
	bizApp?: "icode"
	ip?: string
	completionType: string
	ipAddress?: string
	acceptType?: string
	extendProps?: {
		"X-Plugin-Version"?: string
		"X-Plugin-UserAgent": string
		"X-Plugin-Platform"?: string
		"X-Plugin-Repo"?: string
		"X-Plugin-Branch"?: string
		"X-Plugin-FilePath"?: string
		"X-Plugin-ContentType"?: string
		"icode-ai-plugin-completion-prompt"?: string
		"X-Tenant-Code"?: string
		"X-Plugin-Delay"?: number
	}
	department?: string
}

export interface TraceTypeV2 {
	name: string
	startTimeUnixNano: string
	endTimeUnixNano: string
}

export interface PromptConfig {
	stream: boolean
	function: string
	dependencyPackage: string[]
	globalVariable: VariableInfo[]
	localVariable: string[]
	dataStructure: string[]
	macroDefinition: string[]
	enumeration: string[]
	classDefinition: string[]
	dependencyFunction: string[]
	similarCode: string[]
	associatedCode: string[]
	technologyStack: string
	absoluteFilePath: string
	filePath: string
	curFunction: string
	language: string
	completionType: CompletionType
	testFrame: TestFrameType
	mockTool: MockToolType
	similarCodeTypeUser: string
	similarCodeTypeActual: string
}

/**
 * 相似代码片段打分
 */
export interface SnippetScore {
	snippet: string
	languageId: string
	name: string | null | undefined
	score: number
	startLine: number
	endLine: number
}

/**
 * 代码片段枚举
 */
export enum SnippetSelectionOption {
	// eslint-disable-next-line no-unused-vars
	BestMatch,
	// eslint-disable-next-line no-unused-vars
	TopK,
}

/**
 * 记录文件会话
 */
export interface FileInteractionSessionItem {
	// 文件的上次访问时间
	lastVisited: number
	// 打开的文件名称
	name: string | null | undefined
	// 语言类型
	languageId: string
}

/**
 * 相邻打开文件信息
 */
export interface NeighborFileItem {
	// 文件的上次访问时间
	lastVisited: number
	// 打开的文件名称
	name: string | null | undefined
	// 语言类型
	languageId: string
	source: string
	uri: string
}

/**
 * 文件片段 窗口 token 集合
 */
export interface FileSnippetToken {
	tokenSet: Set<string>
	startLine: number
	endLine: number
}

export interface Response<T = any> {
	bo: T
	code: {
		code: string
		msg: string
		msgId: string
	}
}

export interface CompletionCode {
	id: string
	accType: string
	path: string
	content: string
	prompt: string
	startLine: number
	endLine: number
	createdAt: Date
}

export type SimilarCodeData = {
	code: string
	score: number
	project: string
	source: string
	vector_score?: string
	keyword_score?: string
}
