import "./polyfills"
import * as vscode from "vscode"
import ChatGPTViewProvider from "./chatgptViewProvider"
import { EVENT_NAME, Guidance_Url } from "./util/constants"
import { CompletionProvider } from "./completion/index"
import { FileInteractionCache } from "./completion/prompt/file-interaction"
import * as path from "path"
import { registUserInfo } from "./util/index"
import { UserInfoType } from "./types/index"
import { commands } from "vscode"
import { EXTENSION_NAME, ZTE_AI_ASSISTANT_COMMAND_NAME } from "./completion/util/consants"
import { ParserTrees } from "./util/parserTrees"
import { NeighborFileSnippet } from "./completion/prompt/neighbor-file-snippet"
import { defineKeybindingCommand } from "./util/keybinding"
import { ChatFuncParams } from "./exports/type"
import { chat } from "./exports/index"
import { ClineExtension } from "./clineInit"
import { checkResult } from "./util/decorators"
import nls from "./nls/index"
import { getFormattedMemoryUsage } from "./util/memoryCheck"
import { FileNameCache } from "./completion/prompt/file-name"
import { fileDataCache } from "./completion/cache/cache"
import { FileCommonInfo } from "./completion/common/file-common-info"
import { CodeParser } from "./completion/handler/code-parser"
import { DirectoryCacheService } from "./completion/service/directoryCacheService"
import Authentication from "./util/authentication"
import { activateCodeBase, CodeBase } from "./codebase"
import { eventManager } from "./util/eventEmitter"
import { feedback } from "./api/tracking"

const { v4: uuidv4 } = require("uuid")
const dotenv = require("dotenv")
let memoryCheckTimer: NodeJS.Timeout
let clineExtensionInstance: ClineExtension // Added instance variable
let codeBaseInstance: CodeBase | null = null // CodeBase instance
let isCodeBaseActivated = false // 标记 CodeBase 是否已激活

function checkVersion() {
	try {
		const version = vscode.version
		const majorVersion = parseInt(version.split(".")[0], 10)
		const minorVersion = parseInt(version.split(".")[1], 10)

		if (majorVersion < 1 || (majorVersion === 1 && minorVersion < 90)) {
			vscode.window.showWarningMessage(nls.t("icode.completion.versionHint"))
		}
	} catch (e) {
		console.error("Error checking version:", e)
	}
}

export async function activate(context: vscode.ExtensionContext) {
	// Instantiate the Authentication class with vscodeContext
	Authentication.initialize(context)

	// 监听用户登录成功事件，用于在首次登录后激活 CodeBase
	eventManager.on("userLoginSuccess", async (loginData: { userId: string; token: string }) => {
		console.log(`用户 ${loginData.userId} 首次登录成功，准备激活 CodeBase`)
		await activateCodeBaseAfterLogin(context, statusBar)
	})

	checkVersion()
	if (process.env.NODE_ENV === "development") {
		const envPath = path.join(__dirname, "..", ".env.development")
		dotenv.config({ path: envPath })
	}

	// 获取 "ZTE AI ASSITANT" 扩展的配置信息
	const randomString = uuidv4() // 用于uac登录
	context.globalState.update("userKey", randomString)

	// 代码补全
	const statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right)
	const fileInteractionCache = new FileInteractionCache()
	const gptProvider = new ChatGPTViewProvider(context.extensionUri, context)
	let hangingEventName = "" // 视图未激活挂起的事件名称
	let hangingShortCutEventOption: Record<string, unknown> = {} // 视图未激活挂起的参数
	const shortCutEventHandler = (eventName: string, shortCutEventOption?: Record<string, unknown>) => {
		vscode.commands.executeCommand("zteAIAssitant.toggleSidebar").then(async () => {
			setTimeout(() => vscode.commands.executeCommand("ZTE-AI-Assistant.SidebarProvider.focus"), 300)

			if (!gptProvider.isWebReady) {
				hangingEventName = eventName
				shortCutEventOption && (hangingShortCutEventOption = shortCutEventOption)
				return
			}
			if (eventName === "completionByComment") {
				gptProvider.generateCodeByComment()
			} else if (eventName === "genUt") {
				gptProvider.genUt()
			} else if (eventName === "completion") {
				gptProvider.completion()
			} else if (eventName === "analyze") {
				gptProvider.codeAnalyze()
			} else if (eventName === "EXPLAIN") {
				gptProvider.codeExplain()
			} else if (eventName === "OPTIMIZE") {
				gptProvider.codeOptimize()
			} else if (eventName === "chat") {
				const { prompt, appId, options } = <any>shortCutEventOption
				gptProvider.chat({ prompt, options, appId })
			} else {
				gptProvider.search(eventName)
			}
		})
	}

	let completionProvider: any
	let neighborFileSnippet: NeighborFileSnippet = new NeighborFileSnippet()
	// 获取当前文件夹的文件名缓存在内存中
	const fileNameCache: FileNameCache = new FileNameCache(neighborFileSnippet)
	completionProvider = new CompletionProvider(
		statusBar,
		fileInteractionCache,
		context,
		neighborFileSnippet,
		gptProvider,
		fileNameCache,
	)

	const directoryCacheService = DirectoryCacheService.getInstance(context)
	directoryCacheService.initialize()

	gptProvider.setWebReadyCallback((isWebReady) => {
		if (isWebReady && hangingEventName) {
			shortCutEventHandler(hangingEventName, hangingShortCutEventOption)
		}
	})

	const webviewProvider = vscode.window.registerWebviewViewProvider(ChatGPTViewProvider.viewType, gptProvider, {
		webviewOptions: { retainContextWhenHidden: true },
	})

	const statusBarEnable = vscode.commands.registerCommand("zteChatGPT.enable", () => {
		statusBar.show()
	})

	const statusBarDisable = vscode.commands.registerCommand("zteChatGPT.disable", () => {
		statusBar.hide()
	})

	const commentCompletion = vscode.commands.registerCommand("zteChatGPT.commentCompletion", () => {
		shortCutEventHandler("completionByComment")
	})

	const codeOptimize = vscode.commands.registerCommand("zteChatGPT.optimizeCode", () => {
		shortCutEventHandler(EVENT_NAME.OPTIMIZE)
	})

	const findBug = vscode.commands.registerCommand("zteChatGPT.findbug", () => {
		shortCutEventHandler(EVENT_NAME.FINDBUG)
	})

	const codeExplain = vscode.commands.registerCommand("zteChatGPT.explainCode", () => {
		shortCutEventHandler(EVENT_NAME.EXPLAIN)
	})

	const genUTShortCut = vscode.commands.registerCommand("zteChatGPT.genUTShortCut", () => {
		shortCutEventHandler("genUt")
	})

	const completion = vscode.commands.registerCommand("zteChatGPT.completion", () => {
		shortCutEventHandler("completion")
	})

	const analyze = vscode.commands.registerCommand("zteChatGPT.analyze", () => {
		shortCutEventHandler("analyze")
	})

	const decreaseView = vscode.commands.registerCommand("zteChatGPT.decreaseView", () => {
		vscode.commands.executeCommand("workbench.action.increaseViewSize")
	})

	const increaseView = vscode.commands.registerCommand("zteChatGPT.increaseView", () => {
		vscode.commands.executeCommand("workbench.action.decreaseViewSize")
	})

	const forceInlineCompletion = vscode.commands.registerCommand("zteChatGPT.forceInlineCompletion", () => {
		if (CompletionProvider.isForce) return
		CompletionProvider.isForce = true
		vscode.commands.executeCommand("editor.action.inlineSuggest.hide")
		vscode.commands.executeCommand("editor.action.inlineSuggest.trigger")
	})

	// const { getUserInfo, setUserInfo } = registUserInfo(context);
	const regUserInfo = registUserInfo(context)
	const userInfo = vscode.commands.registerCommand("zteChatGPT.getUserInfo", () => {
		return regUserInfo.getUserInfo()
	})
	const setUserInfoHandler = vscode.commands.registerCommand("zteChatGPT.setUserInfo", (info: UserInfoType) => {
		regUserInfo.setUserInfo(info)
	})
	const shortCutEventHandlerCaller = vscode.commands.registerCommand(
		"zteChatGPT.chat",
		({ prompt, options, appId }: ChatFuncParams) => {
			shortCutEventHandler("chat", { prompt, options, appId })
		},
	)

	// 获取当前打开的标签页路径
	function parseVisibleText() {
		let visibleUri: { fsPath: string; absoluteFile: string }[] = []
		const tabGroups = vscode.window.tabGroups
		tabGroups.all.forEach((tabGroup, index) => {
			tabGroup.tabs.map((tab) => {
				const input = tab.input as { uri: vscode.Uri }
				if (input && input.uri !== undefined) {
					visibleUri.push({ fsPath: input.uri.fsPath, absoluteFile: input.uri.path })
				}
			})
		})
		try {
			ParserTrees.set(visibleUri)
		} catch (err) {
			checkResult("parseVisibleTextError", err, "error")
		}
	}

	parseVisibleText()

	// 当有补全文本的时候拦截esc键
	const cancelCompletion = vscode.commands.registerCommand("zteAiAssistant.cancelCompletion", () => {
		if (completionProvider) {
			vscode.commands.executeCommand("editor.action.inlineSuggest.hide")
			completionProvider.setMetric({ accType: "cancel" })
			completionProvider.resetCacheResponse()
		}
	})

	const showNextInlineSuggestion = vscode.commands.registerCommand("zteAiAssistant.showNextCompletion", () => {
		if (completionProvider) {
			completionProvider.setMetric({ toggle: 1, accType: "" })
			vscode.commands.executeCommand("editor.action.inlineSuggest.showNext")
		}
	})

	const showPreviousInlineSuggestion = vscode.commands.registerCommand("zteAiAssistant.showPreviousCompletion", () => {
		if (completionProvider) {
			completionProvider.setMetric({ toggle: 1, accType: "" })
			vscode.commands.executeCommand("editor.action.inlineSuggest.showPrevious")
		}
	})

	// 主题切换时，发送主题给web
	vscode.window.onDidChangeActiveColorTheme((theme) => {
		gptProvider.sendTheme(theme.kind)
	})

	// 监听窗口焦点变化事件
	vscode.window.onDidChangeWindowState((windowState) => {
		if (Authentication.isExternalLogin || Authentication.isStopUdsTimer) {
			return
		}
		if (windowState.focused) {
			Authentication.udsLogin()
			//重启定时器
			Authentication.restartTimer()
		} else {
			Authentication.stopTimer()
		}
	})

	const acceptInlineSuggestion = vscode.commands.registerCommand("zteAiAssistant.acceptInlineSuggestion", async (args) => {
		try {
			// 如果建议窗口可见，先接受建议窗口的内容
			if (vscode.window.activeTextEditor) {
				await vscode.commands.executeCommand("acceptSelectedSuggestion")
			}
			// 执行内联建议（幽灵文本）的提交操作
			await vscode.commands.executeCommand("editor.action.inlineSuggest.commit")
		} catch (error) {
			console.error("Command error:", error)
		}
	})
	const openPrompt = vscode.commands.registerCommand("ZTE-AI-Assistant.promptButtonClicked", async () => {
		gptProvider.openPrompt()
	})

	const openExtenisonWeb = vscode.commands.registerCommand("ZTE-AI-Assistant.extensionsButtonClicked", async () => {
		gptProvider.openExtenison()
	})

	const setLogout = vscode.commands.registerCommand("ZTE-AI-Assistant.logoutButtonClicked", async () => {
		gptProvider.doLogout()
	})

	const helpButtonClicked = vscode.commands.registerCommand("ZTE-AI-Assistant.helpButtonClicked", async (webview: any) => {
		await vscode.env.openExternal(vscode.Uri.parse(Guidance_Url))
	})

	const feedbackButtonClicked = vscode.commands.registerCommand(
		"ZTE-AI-Assistant.feedbackButtonClicked",
		async (webview: any) => {
			const url = await feedback()
			await vscode.env.openExternal(vscode.Uri.parse(url))
		},
	)

	const triggerCheckCommand = vscode.commands.registerCommand("iCodeMate.codebase.addIndex", async () => {
		if (!codeBaseInstance) {
			vscode.window.showInformationMessage(nls.t("icode.codebase.notReady"))
			return
		}
		try {
			const result = await vscode.window.showQuickPick(
				[nls.t("icode.codebase.rebuildIndexConfirm"), nls.t("icode.codebase.rebuildIndexCancel")],
				{ placeHolder: nls.t("icode.codebase.rebuildIndexTooltip") },
			)

			if (result === nls.t("icode.codebase.rebuildIndexConfirm")) {
				await codeBaseInstance?.rebuildIndex()
				vscode.window.showInformationMessage(nls.t("icode.codebase.rebuildIndex"))
			}
		} catch (error) {
			vscode.window.showErrorMessage(nls.t("icode.codebase.rebuildIndexFailed") + `: ${error}`)
		}
	})

	// 手动触发删除索引
	const delIndexCommand = vscode.commands.registerCommand("iCodeMate.codebase.delIndex", async () => {
		if (!codeBaseInstance) {
			vscode.window.showInformationMessage(nls.t("icode.codebase.notReady"))
			return
		}
		try {
			const result = await vscode.window.showQuickPick(
				[nls.t("icode.codebase.rebuildIndexConfirm"), nls.t("icode.codebase.rebuildIndexCancel")],
				{ placeHolder: nls.t("icode.codebase.delIndexTooltip") },
			)

			if (result === nls.t("icode.codebase.rebuildIndexConfirm")) {
				await codeBaseInstance?.delIndex()
				vscode.window.showInformationMessage(nls.t("icode.codebase.delIndexSuccess"))
			}
		} catch (error) {
			vscode.window.showErrorMessage(nls.t("icode.codebase.delIndexFailed") + `: ${error}`)
		}
	})

	const textLengthMap: Map<string, number> = new Map()

	context.subscriptions.push(
		acceptInlineSuggestion,
		statusBarDisable,
		statusBarEnable,
		webviewProvider,
		commentCompletion,
		codeOptimize,
		codeExplain,
		findBug,
		genUTShortCut,
		completion,
		decreaseView,
		increaseView,
		analyze,
		vscode.languages.registerInlineCompletionItemProvider({ pattern: "**" }, completionProvider),
		userInfo,
		setUserInfoHandler,
		shortCutEventHandlerCaller,
		cancelCompletion,
		showNextInlineSuggestion,
		showPreviousInlineSuggestion,
		forceInlineCompletion,
		openPrompt,
		openExtenisonWeb,
		setLogout,
		helpButtonClicked,
		feedbackButtonClicked,
		triggerCheckCommand,
		delIndexCommand,

		commands.registerCommand(ZTE_AI_ASSISTANT_COMMAND_NAME.settings, () => {
			vscode.commands.executeCommand("workbench.action.openSettings", EXTENSION_NAME)
		}),
		commands.registerCommand(ZTE_AI_ASSISTANT_COMMAND_NAME.stopGeneration, () => {
			if (completionProvider && typeof completionProvider.abortCompletion === "function") {
				completionProvider.abortCompletion()
			} else {
				console.warn("completionProvider is not ready or abortCompletion method is missing")
			}
		}),
		vscode.workspace.onDidChangeConfiguration((event) => {
			if (!event.affectsConfiguration(EXTENSION_NAME)) return
			if (completionProvider && typeof completionProvider.updateConfig === "function") {
				completionProvider.updateConfig()
			} else {
				console.warn("completionProvider is not ready or updateConfig method is missing")
			}
		}),
		vscode.workspace.onDidOpenTextDocument((document) => {
			const textLength = document.lineCount
			const path = document.uri?.path
			if (path) {
				textLengthMap.set(path, textLength)
			}
			// 文件打开
			neighborFileSnippet.startSession(document)
			parseVisibleText()
		}),
		vscode.workspace.onDidCloseTextDocument((document) => {
			// 文件关闭
			neighborFileSnippet.endSession(document)
			parseVisibleText()
		}),
		vscode.window.onDidChangeActiveTextEditor((newEditor) => {
			if (newEditor) {
				try {
					textLengthMap.set(newEditor.document.uri.path, newEditor.document.lineCount)
					const fileCommonInfo = new FileCommonInfo(newEditor.document)
					fileCommonInfo.getNeighborFileInfo()
					ParserTrees.updateSingleFile(newEditor.document)
				} catch (err) {
					checkResult("parseVisibleTextError", err, "error")
				}
			}
		}),
		vscode.workspace.onDidChangeTextDocument((e) => {
			// 编辑文档后，文档变化事件，在批量编辑、替换的场景下会出现修改数组
			let editChange: vscode.TextDocumentContentChangeEvent | undefined = e.contentChanges[0]

			if (!editChange) {
				return
			}
			const document = e.document
			const path = document?.uri?.path
			if (e.contentChanges.length > 1) {
				let isExistContent = false
				let isNoExistContent = false
				let _tmpeditChange
				e.contentChanges.forEach((item) => {
					if (item.text) {
						isExistContent = true
						_tmpeditChange = item
					} else {
						isNoExistContent = true
					}
				})
				if (isExistContent && isNoExistContent) {
					editChange = _tmpeditChange
				}
			}
			if (!editChange) return
			if (path) {
				const originalTextLength = textLengthMap.get(path) || 0
				const newTextLength = document.lineCount
				const textLengthDifference = newTextLength - originalTextLength
				textLengthMap.set(path, newTextLength)

				const fileInfo = fileDataCache.get(document.uri.fsPath)
				let isAdjust = false
				// 处理行数变化
				if (Math.abs(textLengthDifference) === 1) {
					if (fileInfo && fileInfo.codeInfo) {
						const changeLine = editChange.range.start.line + 1
						if (textLengthDifference > 0 && editChange.text.includes("\n")) {
							CodeParser.adjustCodePoint(document, fileInfo.codeInfo, changeLine, "add")
						} else if (textLengthDifference < 0 && editChange.rangeLength > 0 && editChange.text === "") {
							CodeParser.adjustCodePoint(document, fileInfo.codeInfo, changeLine, "delete")
						}
						isAdjust = true
					}
				} else if (textLengthDifference === 0 && fileInfo?.codeInfo) {
					// 处理内容全是空格的变化
					const changeLine = editChange.range.start.line + 1
					if (editChange.text.trim() === "") {
						CodeParser.adjustCodePoint(document, fileInfo.codeInfo, changeLine, "modify")
						isAdjust = true
					}
				}

				// 更新文件信息
				if (isAdjust && fileInfo) {
					fileInfo.totalLine = newTextLength
					fileInfo.version = document.version
					fileInfo.content = document.getText()
				}
			}
			if (completionProvider) {
				completionProvider.dealEditChange(editChange)
			}
		}),
		vscode.commands.registerCommand(
			"zteAiAssistant.acceptNextLine",
			defineKeybindingCommand.bind(
				null,
				"ctrl+downArrow",
				vscode.commands.executeCommand.bind(null, "editor.action.inlineSuggest.acceptNextLine"),
			),
		),
		vscode.commands.registerCommand("zteAIAssitant.toggleSidebar", async () => {
			setTimeout(() => vscode.commands.executeCommand("ZTE-AI-Assistant.SidebarProvider.focus"), 300)
		}),
	)
	// statusBar.tooltip = nls.t("icode.extension.tooltip")
	statusBar.text = nls.t("icode.extension.title")
	statusBar.command = "zteAiAssistant.stopGeneration"
	statusBar.show()

	memoryCheckTimer = setInterval(() => getFormattedMemoryUsage("Copilot"), 60 * 360 * 1000)

	// Initialize Cline Extension
	clineExtensionInstance = new ClineExtension(context, gptProvider)
	const clineApi = clineExtensionInstance.initialize()

	return { chat, clineApi } // Modified return
}

/**
 * 在用户登录成功后激活 CodeBase
 */
async function activateCodeBaseAfterLogin(context: vscode.ExtensionContext, statusBar: vscode.StatusBarItem): Promise<void> {
	// 检查是否已经激活过
	if (isCodeBaseActivated || codeBaseInstance) {
		return
	}

	// 检查用户是否已登录
	const authInfo = Authentication.getAuthenticationInfo()
	if (!authInfo?.userId) {
		console.log("用户尚未登录，跳过 CodeBase 激活")
		return
	}

	try {
		// 立即设置标记，防止重复调用
		isCodeBaseActivated = true
		console.log("用户已登录，开始激活 CodeBase 模块...")
		// 执行异步操作
		codeBaseInstance = await activateCodeBase(context, statusBar)
		vscode.commands.executeCommand("setContext", "iCodeMate.codebase.isReady", true)

		console.log("CodeBase 模块已成功激活")
	} catch (error) {
		// 如果激活失败，重置标记
		isCodeBaseActivated = false
		codeBaseInstance = null
		console.error("CodeBase 模块激活失败:", error)
	}
}

export function deactivate() {
	clearInterval(memoryCheckTimer)
	if (clineExtensionInstance) {
		clineExtensionInstance.dispose()
	}
	if (codeBaseInstance) {
		codeBaseInstance.dispose()

		codeBaseInstance = null
		isCodeBaseActivated = false
		console.log("CodeBase 模块已销毁")
	}

	// 清理事件监听器
	eventManager.removeAllListeners("userLoginSuccess")
}
