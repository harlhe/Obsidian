import * as vscode from "vscode"
import * as fs from "fs"
import { EVENT_NAME, event } from "./util/constants"
import AppWebviewProvider from "./appWebviewProvider"
import { getGitInfo, getActiveEditorFilePath, getActiveFileLang } from "./util/index"
import { ChatFuncParams } from "./exports/type"
import { eventManager } from "./util/eventEmitter"
import { LOG_KEYS } from "./completion/util/consants"
import { checkResult } from "./util/decorators"
import { UserInfoType, netWorkType } from "./types/index"
import { OpenFilesTracker } from "./util/openFileTracker"
import { WEB_URL } from "./util/constants"
import Authentication from "./util/authentication"

const os = require("os")
const path = require("path")
import nls from "./nls/index"

type LoginType = {
	userId: string
	username: string
	department?: string
	token: string
	trackInfo?: any
}

type WebReadyCallback = (isReady: boolean) => void

export default class ChatGPTViewProvider implements vscode.WebviewViewProvider {
	public static readonly viewType = "zteAIAssitant.chatView"
	public _view?: vscode.WebviewView
	static userInfo: LoginType
	public vscodeContext: vscode.ExtensionContext
	public isWebReady: boolean
	private webReadyCallback: WebReadyCallback | undefined
	private appWebviewProvider: any
	private webUrl: string
	public expTime: number | undefined
	public isExternalLogin: boolean = false
	public netWorkType: netWorkType = "innerNetwork"
	private configurationChangeListener: vscode.Disposable | undefined
	private selectionChangeListener: vscode.Disposable | undefined
	public fileTracker: OpenFilesTracker
	public tabName: string | undefined
	public isCodeServerLogin: boolean = false
	constructor(
		private readonly _extensionUri: vscode.Uri,
		vscodeContext: vscode.ExtensionContext,
	) {
		this.vscodeContext = vscodeContext
		this.isWebReady = false
		this.webUrl = ""
		this.fileTracker = new OpenFilesTracker()

		this.configurationChangeListener = vscode.workspace.onDidChangeConfiguration((e) => {
			if (e.affectsConfiguration("icodemate")) {
				this.getVscodeConfig()
			}
		})

		this.selectionChangeListener = vscode.window.onDidChangeTextEditorSelection((e) => {
			const editor = e.textEditor
			// const selection = editor.selection;
			// const selectedText = editor.document.getText(selection);
			const fileName = path.basename(editor.document.fileName)
			const languageId = editor.document.languageId
			this.sendMessageToWebview(EVENT_NAME.SELECTION_CHANGE, {
				value: {
					selection: this.getSelection(),
					fileName: fileName,
					languageId,
				},
			})
		})
	}
	public resolveWebviewView(webviewView: vscode.WebviewView) {
		this._view = webviewView
		Authentication.view = webviewView

		webviewView.webview.options = {
			enableScripts: true,
			localResourceRoots: [this._extensionUri],
		}
		// webviewView.webview.html = this._getHtmlForWebview(webviewView.webview)

		webviewView.webview.onDidReceiveMessage(async (data) => {
			switch (data.type) {
				case "login":
					Authentication.isLogout = false
					const loginData = data && data.data ? data.data.data : {}
					Authentication.networkType = loginData.networkType
					Authentication.login(loginData)
					this.getTheme()
					break
				case "code-server-login":
					Authentication.codeServerLogin(data)
					this.getTheme()
					break
				case "REPLACE_CODE":
					this.handleReplaceText(data)
					break
				case "OPEN_WEBPAGE":
					const { value } = data.data
					vscode.env.openExternal(value)
					break
				case "OPEN_EXTERNAL_NETWORK_LOGIN":
					Authentication.openExternalNetworkLoginPage()
					break
				// 接收到web端发过来获取埋点数据的请求，将埋点
				case "TRACKING_INFO_REQUEST":
					const { contextId } = data.data
					const { branch, repoName } = getGitInfo()
					this.sendMessageToWebview(EVENT_NAME.TRACKING_INFO_RESPONSE, {
						contextId,
						activeFilePath: getActiveEditorFilePath(),
						activeFileLang: getActiveFileLang(),
						branch,
						repoName,
					})
					break
				case "CREATE_NEW_FILE":
					let doc = await vscode.workspace.openTextDocument()
					let editor = await vscode.window.showTextDocument(doc)
					await editor.edit((editBuilder) => {
						editBuilder.insert(new vscode.Position(0, 0), data.value)
					})
					break
				case "COMPARE_CODE":
					this.compareCode(data.value)
					break
				case "WEB_READY":
					if (!this.isWebReady && this.webReadyCallback) {
						this.webReadyCallback(true)
					}
					const userInfo: UserInfoType = await vscode.commands.executeCommand("zteChatGPT.getUserInfo")
					vscode.commands.executeCommand("zteChatGPT.setUserInfo", {
						tenant: (data && data.value) || "",
						token: userInfo.token,
						userId: userInfo.userId,
					})
					this.isWebReady = true
					this.sendMessageToWebview(EVENT_NAME.LANG, {
						value: vscode.env.language,
					})
					this.getVscodeConfig()
					break
				case "OPEN_APP_MANAGEMENT":
					this.openAppManagement()
					break
				case "UAC_USER_INFO":
					checkResult(LOG_KEYS.webUacInfo, data.data)
					Authentication.isLogout = false
					Authentication.isAuthFailed = false
					Authentication.saveAuthenticationInfo({
						userId: (data && data.data && data.data.userId) || "",
						token: (data && data.data && data.data.token) || "",
						tenant: (data && data.data && data.data.tenant) || "",
					})
					break
				case "CHAT_RESPONSE":
					eventManager.emit(event.CHAT_RESPONSE, {
						value: (data && data.value && data.value.value) || "",
						code: (data && data.value && data.value.code) || "",
					})
					break
				case "RESTART_TIMER":
					// 扫码返回处理
					Authentication.restartTimer()
					break
				case "STOP_UDS_TIMER":
					Authentication.isStopUdsTimer = true
					Authentication.stopTimer()
					break
				case "LOGOUT":
					Authentication.isLogout = true
					vscode.commands.executeCommand("zteChatGPT.setUserInfo", {
						userId: (data && data.data && data.data.userId) || "",
						token: (data && data.data && data.data.token) || "",
						tenant: (data && data.data && data.data.tenant) || "",
					})
					break
				case "FETCH_OPEN_FILE_INFO":
					const openFileInfo: Record<string, { fullPath: string; name: string; language: string }> = {}

					await this.fileTracker.loadOpenFiles()

					if (OpenFilesTracker.fileInfo) {
						Object.keys(OpenFilesTracker.fileInfo).forEach((path) => {
							if (OpenFilesTracker.fileInfo.hasOwnProperty(path)) {
								const { fullPath, name, language } = OpenFilesTracker.fileInfo[path]
								openFileInfo[path] = { fullPath, name, language }
							}
						})
					}

					const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || ""
					this.sendMessageToWebview(EVENT_NAME.OPEN_FILES_INFO, {
						value: openFileInfo,
						projectRoot: workspaceRoot,
					})
					break
				case "FETCH_SELECT_FILE_CONTENT":
					const filePath = (data && data.value && data.value.value) || ""
					await this.fileTracker.loadOpenFiles()
					const fileContent = fs.readFileSync(filePath, "utf-8") || ""
					this.sendMessageToWebview(EVENT_NAME.SELECT_FILE_CONTENT, {
						value: {
							content: fileContent,
							fullPath: filePath,
						},
					})
					break
				case "IS_FILE_EXIST":
					const curFilePath = (data && data.value && data.value.value) || ""
					if (!curFilePath) {
						return
					}
					this.sendMessageToWebview(EVENT_NAME.CHECK_FILE_EXIST, {
						value: fs.existsSync(curFilePath),
					})
					break
				case "TAB_CHANGED":
					await vscode.commands.executeCommand("setContext", "zteChatGPT.activeTab", data.value)
					break
				case "IS_AUTH_FAILED":
					Authentication.isAuthFailed = true
					break
			}
		})
	}

	private openAppManagement() {
		this.appWebviewProvider = new AppWebviewProvider(WEB_URL, vscode.window.activeColorTheme.kind, vscode.env.language)
		if (!this.appWebviewProvider.panel) {
			this.appWebviewProvider.createAppWebviewProvider()
		} else {
			this.appWebviewProvider.panel.reveal(
				vscode.window.activeTextEditor ? vscode.window.activeTextEditor.viewColumn : undefined,
			)
		}
	}

	private getTheme() {
		// 将当前的主题发送给web
		const currentTheme = vscode.window.activeColorTheme
		this.sendTheme(currentTheme.kind)
	}

	public setWebReadyCallback(callback: WebReadyCallback) {
		this.webReadyCallback = callback
	}

	// 代码比较
	private compareCode(generatedCode: string) {
		const editor = vscode.window.activeTextEditor
		if (!editor) {
			return
		}
		if (editor.document.isUntitled) {
			vscode.window.showWarningMessage(nls.t("icode.extension.diffWarning"))
			return
		}

		const selection = editor.selection
		let activeFileText = editor.document.getText()
		const filePath = editor.document.uri.fsPath
		const fileExtension = path.extname(filePath)
		const tempFolderPath = os.tmpdir()
		const activeFileName = path.basename(filePath)
		const randomString = new Date().getTime()
		const tempFileName = `${activeFileName}_aiAssitantTempFile_${randomString}${fileExtension}`
		const tempFilePath = path.join(tempFolderPath, tempFileName)
		let selectedText = editor.document.getText(selection)

		if (!selectedText) {
			// 选中文本为空插入到光标focus后
			const cursorPosition = editor.selection.active
			const cursorIndex = editor.document.offsetAt(cursorPosition)
			activeFileText = activeFileText.slice(0, cursorIndex) + generatedCode + activeFileText.slice(cursorIndex)
		} else {
			const index = activeFileText.indexOf(selectedText)
			if (index !== -1) {
				let before = activeFileText.substring(0, index)
				let after = activeFileText.substring(index + selectedText.length)
				activeFileText = before.concat(generatedCode, after)
			}
		}
		try {
			fs.writeFileSync(tempFilePath, activeFileText)
		} catch (e) {
			vscode.window.showErrorMessage(nls.t("icode.extension.diffFailure"))
			return
		}

		const diffTitle = "AI suggestion <--> your file"
		const diffProvider = {
			provideTextDocumentContent: () => {
				return fs.readFileSync(tempFilePath, "utf-8")
			},
		}

		const diffUri = vscode.Uri.parse(`diff://${diffTitle}`)
		vscode.workspace.registerTextDocumentContentProvider("diff", diffProvider)
		vscode.commands.executeCommand("vscode.diff", diffUri, vscode.Uri.file(filePath), diffTitle)

		const disposable = vscode.workspace.onDidCloseTextDocument((document) => {
			// 关闭diff窗口删除临时文件
			if (document.uri.toString().toLocaleLowerCase() === diffUri.toString().toLocaleLowerCase()) {
				fs.unlinkSync(tempFilePath)
				disposable.dispose()
			}
		})
	}

	// 补全代码
	public completion() {
		let editor: vscode.TextEditor | undefined = vscode.window.activeTextEditor
		if (!editor) {
			return
		}
		const languageId = editor.document.languageId
		this.sendMessageToWebview(EVENT_NAME.COMPLETION, {
			value: this.getSelection(),
			fileExtension: languageId,
		})
	}

	public chat({ prompt, options, appId }: ChatFuncParams) {
		this.sendMessageToWebview(EVENT_NAME.CHAT, {
			prompt,
			options: options,
			appId,
		})
	}

	private getSelection() {
		const selection = vscode.window.activeTextEditor?.selection
		const selectedText = vscode.window.activeTextEditor?.document.getText(selection)
		return selectedText
	}

	public search(type: string) {
		const text = this.getSelection()
		if (!text) {
			return
		}
		this.sendMessageToWebview(type, { value: this.getSelection() })
	}

	// 发送当前主题
	// kind为当前主题返回的值，1是浅色，2是深色
	public sendTheme(kind: number) {
		this.sendMessageToWebview(EVENT_NAME.SEND_THEME, { kind })
		if (this.appWebviewProvider) {
			this.appWebviewProvider.getAppViewTheme(EVENT_NAME.SEND_THEME, { kind })
			this.appWebviewProvider.getAppLang({
				value: vscode.env.language,
			})
		}
	}

	// 根据注释生成代码
	public generateCodeByComment() {
		let editor: vscode.TextEditor | undefined = vscode.window.activeTextEditor
		if (!editor) {
			return
		}
		const languageId = editor.document.languageId
		const cursorPosition = editor.selection.active
		const lineText = editor.document.lineAt(cursorPosition.line).text
		this.sendMessageToWebview(EVENT_NAME.GENERATE_BY_COMMENT, {
			value: this.getSelection() || lineText,
			fileExtension: languageId,
		})
	}

	private getVscodeConfig() {
		const vscodeSetting = vscode.workspace.getConfiguration("icodemate")
		this.sendMessageToWebview(EVENT_NAME.VSCODE_CONFIG, {
			value: {
				analysisCodePrompt: vscodeSetting["Analysis Code Prompt"],
				explainCodePrompt: vscodeSetting["Explain Code Prompt"],
				optimizeCodePrompt: vscodeSetting["Optimize Code Prompt"],
				unitTestPrompt: vscodeSetting["unitTestPrompt"],
			},
		})
	}

	public genUt() {
		const lang = vscode.window.activeTextEditor?.document.languageId || ""
		if (!lang) {
			return
		}
		const configration = vscode.workspace.getConfiguration("icodemate")
		const utConfig = configration.unitTestPrompt
		let prompt = ""
		for (let key in utConfig) {
			if (key === lang) {
				prompt = utConfig[key]
				break
			}
		}
		this.sendMessageToWebview(EVENT_NAME.GENUT, {
			value: `${this.getSelection()}\n${prompt}`,
		})
	}

	public handleCodeAction(eventType: string, configKey: string) {
		let editor: vscode.TextEditor | undefined = vscode.window.activeTextEditor
		if (!editor) {
			return
		}

		const config = vscode.workspace.getConfiguration("icodemate")
		const language = editor.document.languageId
		const selectedCode = this.getSelection()

		// 获取并替换 Prompt 变量
		let promptTemplate: string = config[configKey] || ""
		let formattedPrompt = promptTemplate
			.replace(/\${language}/g, language)
			.replace(/\${selectedCode}/g, selectedCode ? `\n\n ${selectedCode} \n\n` : "")

		this.sendMessageToWebview(eventType, {
			value: formattedPrompt,
		})
	}

	public codeAnalyze() {
		this.handleCodeAction(EVENT_NAME.ANALYZE, "Analysis Code Prompt")
	}

	public codeExplain() {
		this.handleCodeAction(EVENT_NAME.EXPLAIN, "Explain Code Prompt")
	}

	public codeOptimize() {
		this.handleCodeAction(EVENT_NAME.OPTIMIZE, "Optimize Code Prompt")
	}

	private handleReplaceText(data: any): void {
		this.replaceText(data)
	}

	public replaceText(data: any) {
		const editor = vscode.window.activeTextEditor
		if (editor) {
			editor.edit((editBuilder) => {
				editBuilder.replace(editor.selection, data.data.value)
			})
		}
	}

	public async openPrompt() {
		this.sendMessageToWebview(EVENT_NAME.OPEN_PROMPT, { isOpen: true })
	}

	public async openExtenison() {
		if (Authentication.isAuthFailed) {
			vscode.window.showErrorMessage(nls.t("icode.completion.authFailed"))
			return
		}
		this.sendMessageToWebview(EVENT_NAME.OPEN_EXTENISON)
	}

	public async doLogout() {
		this.sendMessageToWebview(EVENT_NAME.DO_LOGOUT)
	}

	public sendMessageToWebview(eventName: string, data?: { [key: string]: any }) {
		this._view &&
			this._view.webview.postMessage(
				JSON.stringify({
					type: eventName,
					data,
				}),
			)
	}

	public dispose() {
		if (this.configurationChangeListener) {
			this.configurationChangeListener.dispose()
		}
		Authentication.stopTimer()
		if (this.selectionChangeListener) {
			this.selectionChangeListener.dispose()
		}
	}
}
