import * as vscode from "vscode"

class ConfigurationService {
	private _onDidChangeConfiguration = new vscode.EventEmitter<vscode.ConfigurationChangeEvent>()
	public readonly onDidChangeConfiguration = this._onDidChangeConfiguration.event

	constructor() {
		vscode.workspace.onDidChangeConfiguration((e) => {
			this._onDidChangeConfiguration.fire(e)
		})
	}

	/**
	 * Retrieves a configuration value.
	 * @param section The configuration section (e.g., 'ZTE AI ASSISTANT.modelApiKey').
	 * @param defaultValue A default value to return if the section is not found.
	 * @returns The configuration value or the default value.
	 */
	public get<T>(section: string, defaultValue?: T): T | undefined {
		const value = vscode.workspace.getConfiguration().get<T>(section)
		if (value === undefined && defaultValue !== undefined) {
			return defaultValue
		}
		return value
	}

	/**
	 * Updates a configuration value.
	 * @param section The configuration section.
	 * @param value The new value.
	 * @param isGlobal Whether to update the global setting or workspace setting. Defaults to global.
	 * @returns A promise that resolves when the configuration is updated.
	 */
	public async update(section: string, value: any, isGlobal: boolean = true): Promise<void> {
		await vscode.workspace.getConfiguration().update(section, value, isGlobal)
	}
}

export const configurationService = new ConfigurationService()
