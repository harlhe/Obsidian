export default class ModelProvider {
	static modelKey: string
	static modelMap = {
		"nebulacoder-v6": {
			apiProvider: "openai",
			openAiApiKey: "0668001102",
			openAiBaseUrl: "http://nebulacoder.dev.zte.com.cn:40081/v1",
			openAiModelId: "nebulacoder-v6.0",
			contextWindow: 40_000,
		},
		"qwen3-32k": {
			apiProvider: "openai",
			openAiApiKey: "f1d9f9547ace4f2fbe06c38f9e771168",
			openAiBaseUrl: "https://maas-apigateway.dt.zte.com.cn/model/qwen3-235b-a22b/v1",
			openAiModelId: "Qwen3-235B-A22B",
			contextWindow: 20_000,
		},
		"deepseek-r1": {
			apiProvider: "deepseek",
			deepSeekBaseUrl: "https://maas-apigateway.dt.zte.com.cn/model/deepseek-r1-671b/v1",
			deepSeekApiKey: "f1d9f9547ace4f2fbe06c38f9e771168",
			contextWindow: 40_000,
		},
		"qwen3-128k": {
			apiProvider: "openai",
			openAiApiKey: "f1d9f9547ace4f2fbe06c38f9e771168",
			openAiBaseUrl: "https://maas-apigateway.dt.zte.com.cn/model/qwen3-235b-a22b-2507/v1",
			openAiModelId: "Qwen3-235B-A22B",
			contextWindow: 100_000,
		},
	}
}
