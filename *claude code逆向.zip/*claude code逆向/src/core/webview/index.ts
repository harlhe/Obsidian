import axios from "axios"
import * as vscode from "vscode"
import { getNonce } from "./getNonce"
import { getUri } from "./getUri"
import { getTheme } from "@integrations/theme/getTheme"
import { Controller } from "@core/controller/index"
import { findLast } from "@shared/array"
import ChatGPTViewProvider from "../../chatgptViewProvider"
import { WEB_URL } from "../../util/constants"
import { Uri } from "vscode"
export class WebviewProvider implements vscode.WebviewViewProvider {
	public static readonly sideBarId = "ZTE-AI-Assistant.SidebarProvider" // used in package.json as the view's id. This value cannot be changed due to how vscode caches views based on their id, and updating the id would break existing instances of the extension.
	public static readonly tabPanelId = "ZTE-AI-Assistant.TabPanelProvider"
	private static activeInstances: Set<WebviewProvider> = new Set()
	public view?: vscode.WebviewView | vscode.WebviewPanel
	private disposables: vscode.Disposable[] = []
	private gptProvider: ChatGPTViewProvider
	controller: Controller

	constructor(
		readonly context: vscode.ExtensionContext,
		gptProvider: ChatGPTViewProvider,
		private readonly outputChannel: vscode.OutputChannel,
	) {
		WebviewProvider.activeInstances.add(this)
		this.gptProvider = gptProvider
		this.controller = new Controller(context, outputChannel, (message) => this.view?.webview.postMessage(message))
	}

	async dispose() {
		if (this.view && "dispose" in this.view) {
			this.view.dispose()
		}
		while (this.disposables.length) {
			const x = this.disposables.pop()
			if (x) {
				x.dispose()
			}
		}
		await this.controller.dispose()
		WebviewProvider.activeInstances.delete(this)
	}

	public static getVisibleInstance(): WebviewProvider | undefined {
		return findLast(Array.from(this.activeInstances), (instance) => instance.view?.visible === true)
	}

	public static getAllInstances(): WebviewProvider[] {
		return Array.from(this.activeInstances)
	}

	public static getSidebarInstance() {
		return Array.from(this.activeInstances).find((instance) => instance.view && "onDidChangeVisibility" in instance.view)
	}

	public static getTabInstances(): WebviewProvider[] {
		return Array.from(this.activeInstances).filter((instance) => instance.view && "onDidChangeViewState" in instance.view)
	}

	async resolveWebviewView(webviewView: vscode.WebviewView | vscode.WebviewPanel) {
		this.view = webviewView
		const assetDir = vscode.Uri.joinPath(this.context.extensionUri, "assets")
		webviewView.webview.options = {
			// Allow scripts in the webview
			enableScripts: true,
			localResourceRoots: [this.context.extensionUri, assetDir],
		}
		const assetsBaseUri = webviewView.webview.asWebviewUri(assetDir)

		webviewView.webview.html =
			this.context.extensionMode === vscode.ExtensionMode.Development
				? await this.getHMRHtmlContent(webviewView.webview, assetsBaseUri)
				: this.getHtmlContent(webviewView.webview, assetsBaseUri)

		this.gptProvider.resolveWebviewView(webviewView as vscode.WebviewView)

		// Sets up an event listener to listen for messages passed from the webview view context
		// and executes code based on the message that is received
		this.setWebviewMessageListener(webviewView.webview)

		// Logs show up in bottom panel > Debug Console
		//console.log("registering listener")

		// Listen for when the panel becomes visible
		// https://github.com/microsoft/vscode-discussions/discussions/840
		if ("onDidChangeViewState" in webviewView) {
			// WebviewView and WebviewPanel have all the same properties except for this visibility listener
			// panel
			webviewView.onDidChangeViewState(
				() => {
					if (this.view?.visible) {
						this.controller.postMessageToWebview({
							type: "action",
							action: "didBecomeVisible",
						})
					}
				},
				null,
				this.disposables,
			)
		} else if ("onDidChangeVisibility" in webviewView) {
			// sidebar
			webviewView.onDidChangeVisibility(
				() => {
					if (this.view?.visible) {
						this.controller.postMessageToWebview({
							type: "action",
							action: "didBecomeVisible",
						})
					}
				},
				null,
				this.disposables,
			)
		}

		// Listen for when the view is disposed
		// This happens when the user closes the view or when the view is closed programmatically
		webviewView.onDidDispose(
			async () => {
				await this.dispose()
			},
			null,
			this.disposables,
		)

		// // if the extension is starting a new session, clear previous task state
		// this.clearTask()
		{
			// Listen for configuration changes
			vscode.workspace.onDidChangeConfiguration(
				async (e) => {
					if (e && e.affectsConfiguration("workbench.colorTheme")) {
						// Sends latest theme name to webview
						await this.controller.postMessageToWebview({
							type: "theme",
							text: JSON.stringify(await getTheme()),
						})
					}
					if (e && e.affectsConfiguration("cline.mcpMarketplace.enabled")) {
						// Update state when marketplace tab setting changes
						await this.controller.postStateToWebview()
					}
				},
				null,
				this.disposables,
			)

			// if the extension is starting a new session, clear previous task state
			this.controller.clearTask()

			this.outputChannel.appendLine("Webview view resolved")
		}
	}

	/**
	 * Defines and returns the HTML that should be rendered within the webview panel.
	 *
	 * @remarks This is also the place where references to the React webview build files
	 * are created and inserted into the webview HTML.
	 *
	 * @param webview A reference to the extension webview
	 * @param extensionUri The URI of the directory containing the extension
	 * @returns A template string literal containing the HTML that should be
	 * rendered within the webview panel
	 */
	private getHtmlContent(webview: vscode.Webview, assetsBaseUri: Uri): string {
		// Get the local path to main script run in the webview,
		// then convert it to a uri we can use in the webview.

		// The CSS file from the React build output
		const stylesUri = getUri(webview, this.context.extensionUri, ["webview-ui", "build", "assets", "index.css"])
		// The JS file from the React build output
		const scriptUri = getUri(webview, this.context.extensionUri, ["webview-ui", "build", "assets", "index.js"])

		const extensionUri = this.context.extensionUri
		const eventUri = webview.asWebviewUri(vscode.Uri.joinPath(extensionUri, "media", "scripts", "event.js"))
		const commonUri = webview.asWebviewUri(vscode.Uri.joinPath(extensionUri, "media", "scripts", "common.js"))
		// The codicon font from the React build output
		// https://github.com/microsoft/vscode-extension-samples/blob/main/webview-codicons-sample/src/extension.ts
		// we installed this package in the extension so that we can access it how its intended from the extension (the font file is likely bundled in vscode), and we just import the css fileinto our react app we don't have access to it
		// don't forget to add font-src ${webview.cspSource};
		const codiconsUri = getUri(webview, this.context.extensionUri, [
			"node_modules",
			"@vscode",
			"codicons",
			"dist",
			"codicon.css",
		])

		const katexCssUri = getUri(webview, this.context.extensionUri, [
			"webview-ui",
			"node_modules",
			"katex",
			"dist",
			"katex.min.css",
		])

		const nonce = getNonce()

		// Tip: Install the es6-string-html VS Code extension to enable code highlighting below
		return /*html*/ `
			<!DOCTYPE html>
			<html lang="en">
				<head>
					<meta charset="utf-8">
					<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
					<meta name="theme-color" content="#000000">
					<link rel="stylesheet" type="text/css" href="${stylesUri}">
					<link href="${codiconsUri}" rel="stylesheet" />
					<link href="${katexCssUri}" rel="stylesheet" />
					<!--<meta http-equiv="Content-Security-Policy" content="default-src 'none'; frame-src https://gerritdb.zte.com.cn; connect-src https://*.posthog.com https://*.firebaseauth.com https://*.firebaseio.com https://*.googleapis.com https://*.firebase.com; font-src ${webview.cspSource} data:; style-src ${webview.cspSource} 'unsafe-inline'; img-src ${webview.cspSource} https: data:; script-src 'nonce-${nonce}' 'unsafe-eval';">-->
					<title>Cline</title>
					<style>
						body { margin: 0; padding: 0; display: flex; flex-direction: column; height: 100vh; }
						.tab-container { display: flex; border-bottom: 1px solid var(--vscode-editorGroupHeader-tabsBorder); }
						.tab-button { padding: 8px 16px; cursor: pointer; background: none; border: none; color: var(--vscode-tab-inactiveForeground); border-bottom: 2px solid transparent; }
						.tab-button.active { color: var(--vscode-tab-activeForeground); border-bottom-color: var(--vscode-badge-foreground); }
						.tab-button:hover { background-color: var(--vscode-tab-hoverBackground); }
						.tab-content { display: none; flex-grow: 1; overflow: hidden; }
						.tab-content.active { display: block; }
						#chat-content iframe { width: 100%; height: 100%; border: none; }
						#agent-content { height: 100%; } /* Ensure agent content takes full height */
						#root { height: 100%; } /* Ensure root div takes full height */
					</style>
				</head>
				<body>
					<noscript>You need to enable JavaScript to run this app.</noscript>
					<div class="tab-container">
						<button class="tab-button active" id="tab-chat" onclick="showTab('chat')">Chat</button>
						<button class="tab-button" id="tab-agent" onclick="showTab('agent')">Agent</button>
					</div>
					<div id="chat-content" class="tab-content active">
						<iframe id="chat" src=${WEB_URL}/?type=vscode></iframe>
					</div>
					<div id="agent-content" class="tab-content">
						<div id="root"></div>
					</div>
					<script>
						window.assetBaseUrl = "${assetsBaseUri}";
					</script>
					<script nonce="${nonce}" src="${commonUri}"></script>
					<script type="module" nonce="${nonce}" src="${scriptUri}"></script>
					<script type="module" nonce="${nonce}" src="${eventUri}"></script>
				</body>
			</html>
		`
	}

	/**
	 * Connects to the local Vite dev server to allow HMR, with fallback to the bundled assets
	 *
	 * @param webview A reference to the extension webview
	 * @returns A template string literal containing the HTML that should be
	 * rendered within the webview panel
	 */
	private async getHMRHtmlContent(webview: vscode.Webview, assetsBaseUri: Uri): Promise<string> {
		const localPort = 25463
		const localServerUrl = `localhost:${localPort}`

		// Check if local dev server is running.
		try {
			await axios.get(`http://${localServerUrl}`)
		} catch (error) {
			vscode.window.showErrorMessage(
				"Agent: Local webview dev server is not running, HMR will not work. Please run 'npm run dev:webview' before launching the extension to enable HMR. Using bundled assets.",
			)

			return this.getHtmlContent(webview, assetsBaseUri)
		}

		const nonce = getNonce()
		const stylesUri = getUri(webview, this.context.extensionUri, ["webview-ui", "build", "assets", "index.css"])
		const codiconsUri = getUri(webview, this.context.extensionUri, [
			"node_modules",
			"@vscode",
			"codicons",
			"dist",
			"codicon.css",
		])

		// Get KaTeX resources
		const katexCssUri = getUri(webview, this.context.extensionUri, [
			"webview-ui",
			"node_modules",
			"katex",
			"dist",
			"katex.min.css",
		])

		const scriptEntrypoint = "src/main.tsx"
		const scriptUri = `http://${localServerUrl}/${scriptEntrypoint}`

		const reactRefresh = /*html*/ `
			<script nonce="${nonce}" type="module">
				import RefreshRuntime from "http://${localServerUrl}/@react-refresh"
				RefreshRuntime.injectIntoGlobalHook(window)
				window.$RefreshReg$ = () => {}
				window.$RefreshSig$ = () => (type) => type
				window.__vite_plugin_react_preamble_installed__ = true
			</script>
		`

		const csp = [
			"default-src 'none'",
			"frame-src https://gerritdb.zte.com.cn", // Allow iframe
			`font-src ${webview.cspSource} data:`,
			`style-src ${webview.cspSource} 'unsafe-inline' https://* http://${localServerUrl} http://0.0.0.0:${localPort}`,
			`img-src ${webview.cspSource} https: data:`,
			`script-src 'unsafe-eval' https://* http://${localServerUrl} http://0.0.0.0:${localPort} 'nonce-${nonce}'`,
			`connect-src https://* ws://${localServerUrl} ws://0.0.0.0:${localPort} http://${localServerUrl} http://0.0.0.0:${localPort}`,
		]

		const extensionUri = this.context.extensionUri
		const eventUri = webview.asWebviewUri(vscode.Uri.joinPath(extensionUri, "media", "scripts", "event.js"))
		const commonUri = webview.asWebviewUri(vscode.Uri.joinPath(extensionUri, "media", "scripts", "common.js"))

		return /*html*/ `
			<!DOCTYPE html>
			<html lang="en">
				<head>
					<meta charset="utf-8">
					<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
					<link rel="stylesheet" type="text/css" href="${stylesUri}">
					<link href="${codiconsUri}" rel="stylesheet" />
					<link href="${katexCssUri}" rel="stylesheet" />
					<title>Cline</title>
					<style nonce="${nonce}">
						/* Same styles as in getHtmlContent */
						body { margin: 0; padding: 0; display: flex; flex-direction: column; height: 100vh; }
						.tab-container { display: flex; border-bottom: 1px solid var(--vscode-editorGroupHeader-tabsBorder); }
						.tab-button { padding: 8px 16px; cursor: pointer; background: none; border: none; color: var(--vscode-tab-inactiveForeground); border-bottom: 2px solid transparent; }
						.tab-button.active { color: var(--vscode-tab-activeForeground); border-bottom-color: var(--vscode-badge-foreground); }
						.tab-button:hover { background-color: var(--vscode-tab-hoverBackground); }
						.tab-content { display: none; flex-grow: 1; overflow: hidden; }
						.tab-content.active { display: block; }
						#chat-content iframe { width: 100%; height: 100%; border: none; }
						#agent-content { height: 100%; }
						#root { height: 100%; }
					</style>
				</head>
				<body>
					<noscript>You need to enable JavaScript to run this app.</noscript>
					<div class="tab-container">
						<button class="tab-button active" id="tab-chat" onclick="showTab('chat')">Chat</button>
						<button class="tab-button" id="tab-agent" onclick="showTab('agent')">Agent</button>
					</div>
					<div id="chat-content" class="tab-content active">
						<iframe id="chat" src=${WEB_URL}/?type=vscode></iframe>
					</div>
					<div id="agent-content" class="tab-content">
						 <div id="root"></div>
					</div>
					<script>
						window.assetBaseUrl = "${assetsBaseUri}";
					</script>
					<script nonce="${nonce}" src="${commonUri}"></script>
					${reactRefresh}
					<script type="module" nonce="${nonce}" src="${scriptUri}"></script>
					<script nonce="${nonce}" src="${eventUri}"></script>
					</body>
			</html>
		`
	}
	/**
	 * Sets up an event listener to listen for messages passed from the webview context and
	 * executes code based on the message that is received.
	 *
	 * IMPORTANT: When passing methods as callbacks in JavaScript/TypeScript, the method's
	 * 'this' context can be lost. This happens because the method is passed as a
	 * standalone function reference, detached from its original object.
	 *
	 * The Problem:
	 * Doing: webview.onDidReceiveMessage(this.controller.handleWebviewMessage)
	 * Would cause 'this' inside handleWebviewMessage to be undefined or wrong,
	 * leading to "TypeError: this.setUserInfo is not a function"
	 *
	 * The Solution:
	 * We wrap the method call in an arrow function, which:
	 * 1. Preserves the lexical scope's 'this' binding
	 * 2. Ensures handleWebviewMessage is called as a method on the controller instance
	 * 3. Maintains access to all controller methods and properties
	 *
	 * Alternative solutions could use .bind() or making handleWebviewMessage an arrow
	 * function property, but this approach is clean and explicit.
	 *
	 * @param webview The webview instance to attach the message listener to
	 */
	private setWebviewMessageListener(webview: vscode.Webview) {
		webview.onDidReceiveMessage(
			(message) => {
				this.controller.handleWebviewMessage(message)
				// if (message.type === "iframeMessage") {
				// 	// 处理iframe消息
				// 	this.controller.handleIframeMessage(message.data)
				// } else {
				// 	this.controller.handleWebviewMessage(message)
				// }
			},
			null,
			this.disposables,
		)
	}
}
