import * as fs from "fs"
import * as path from "path"
import * as crypto from "crypto"
import * as os from "os"
import { FileInfo, ProjectIndex, IndexChange, IndexApiClient, ProgressInfo } from "./types"
import { MerkleTree } from "./merkleTree"
import { FileWatcher } from "./fileWatcher"
import { ProgressReporter, ProgressCalculator } from "./progressReporter"
import { DefaultIndexApiClient, MockIndexApiClient } from "./apiClient"
import Authentication from "../util/authentication"
import nls from "../nls/index"
import * as vscode from "vscode"

export class IndexManager {
	private fileWatcher: FileWatcher | null = null
	private progressReporter: ProgressReporter
	private progressCalculator: ProgressCalculator
	private apiClient: IndexApiClient

	private indexDir: string = ""
	static projectSha256: string = ""
	private projectIndexPath: string = ""
	private merkleTreePath: string = ""

	private currentIndex: ProjectIndex | null = null
	private isInitialized: boolean = false

	// 定时更新相关
	private updateTimer: NodeJS.Timeout | null = null
	private pendingChanges: Map<string, IndexChange> = new Map()
	private readonly UPDATE_INTERVAL = 10 * 60 * 1000 // 10分钟
	private lastUpdateTime: number = 0

	// 批量保存配置
	private readonly BATCH_SAVE_SIZE = 50 // 每50个文件保存一次
	private readonly SAVE_INTERVAL_MS = 30000 // 或者每30秒保存一次

	constructor(
		private projectPath: string,
		apiClient?: IndexApiClient,
		useMockApi: boolean = false,
		private statusBar?: vscode.StatusBarItem,
	) {
		this.progressReporter = new ProgressReporter(statusBar)
		this.progressCalculator = new ProgressCalculator()
		// 初始化 API 客户端
		this.apiClient = apiClient || (useMockApi ? new MockIndexApiClient() : new DefaultIndexApiClient())

		// 计算项目路径的 SHA256
		IndexManager.projectSha256 = crypto.createHash("sha256").update(this.projectPath).digest("hex")

		// 初始化路径
		this.initializePaths()
	}

	/**
	 * 初始化路径
	 */
	private initializePaths(): void {
		const homeDir = os.homedir()
		this.indexDir = path.join(homeDir, ".icodemate", "index")
		this.projectIndexPath = path.join(this.indexDir, IndexManager.projectSha256)
		this.merkleTreePath = path.join(this.projectIndexPath, "merkle-tree.json")
	}

	/**
	 * 初始化或加载索引（可复用）
	 */
	async initializeIndex(): Promise<void> {
		// 创建必要的目录
		await this.ensureDirectories()

		// 检查现有索引
		const hasExistingIndex = await this.checkExistingIndex()

		if (!hasExistingIndex) {
			// 没有现有索引，进行全量构建
			await this.buildFullIndex()
		} else {
			// 有现有索引，加载并进行增量检查
			await this.loadExistingIndex()
			await this.performIncrementalCheck()
		}
	}

	/**
	 * 初始化索引管理器
	 */
	async initialize(): Promise<void> {
		try {
			await this.initializeIndex()

			// 启动文件监控
			this.startFileWatching()

			// 启动定时更新
			this.startPeriodicUpdate()

			this.isInitialized = true
			console.log("索引管理器初始化完成")
		} catch (error) {
			console.error("索引管理器初始化失败:", error)
			throw error
		}
	}

	/**
	 * 确保必要的目录存在
	 */
	private async ensureDirectories(): Promise<void> {
		const directories = [path.dirname(this.indexDir), this.indexDir, this.projectIndexPath]

		for (const dir of directories) {
			if (!fs.existsSync(dir)) {
				fs.mkdirSync(dir, { recursive: true })
				console.log(`创建目录: ${dir}`)
			}
		}
	}

	/**
	 * 检查现有索引
	 */
	private async checkExistingIndex(): Promise<boolean> {
		return fs.existsSync(this.merkleTreePath)
	}

	/**
	 * 构建全量索引
	 */
	private async buildFullIndex(): Promise<void> {
		console.log("开始构建全量索引...")

		try {
			// 显示进度条
			this.progressReporter.startProgress(nls.t("icode.codebase.indexBuilding"))

			// 扫描所有文件
			const fileWatcher = new FileWatcher(this.projectPath)
			const allFiles = await fileWatcher.scanAllFiles()
			console.log(`扫描到 ${allFiles.length} 个文件`)

			if (allFiles.length === 0) {
				// 没有文本文件需要处理
				this.progressReporter.stopProgress()
				this.progressReporter.showCompletion(
					`${nls.t("icode.codebase.indexCompleted")}！共处理 0 个文本文件，成功 0 个，失败 0 个`,
				)
				return
			}

			this.progressCalculator.setTotalFiles(allFiles.length)

			// 初始化进度
			let processedFiles = 0
			let successFiles = 0
			let failedFiles = 0
			const indexedFiles: FileInfo[] = []

			this.updateBuildProgress(processedFiles, successFiles, failedFiles, allFiles.length)

			// 批量处理文件
			await this.processFilesInBatches(allFiles, indexedFiles, (processed, success, failed) => {
				processedFiles = processed
				successFiles = success
				failedFiles = failed
				this.updateBuildProgress(processedFiles, successFiles, failedFiles, allFiles.length)
			})

			this.progressReporter.stopProgress()
			this.progressReporter.showCompletion(
				`${nls.t("icode.codebase.indexCompleted")}！共处理 ${allFiles.length} 个文件，成功 ${successFiles} 个，失败 ${failedFiles} 个`,
			)

			// 触发repomap计算
			await this.apiClient.computeRepomap(
				Authentication.getAuthenticationInfo().userId || "",
				IndexManager.projectSha256,
				this.projectPath,
			)
		} catch (error) {
			this.progressReporter.stopProgress()
			this.progressReporter.showCompletion(`${nls.t("icode.codebase.indexFailed")}: ${error}`, true)
			throw error
		}
	}

	/**
	 * 异步索引单个文件
	 */
	private async indexSingleFileAsync(file: FileInfo, changeType: "add" | "modify"): Promise<boolean> {
		const filePath = path.join(this.projectPath, file.path)
		let fileContent = ""

		try {
			// 使用异步文件读取，避免阻塞事件循环
			fileContent = await fs.promises.readFile(filePath, "utf8")
		} catch (error) {
			console.warn(`读取文件内容失败: ${file.path}`, error)
			fileContent = ""
		}

		const userName = Authentication.getAuthenticationInfo().userId || ""

		const result = await this.apiClient.updateIndex(
			userName,
			IndexManager.projectSha256,
			file.path,
			fileContent,
			changeType,
			this.projectPath,
		)

		if (!result.success) {
			console.error(`${changeType === "add" ? "创建" : "更新"}文件索引失败: ${file.path}`, result.error)
			return false
		}
		return true
	}

	/**
	 * 批量处理文件
	 */
	private async processFilesInBatches(
		filesToProcess: FileInfo[],
		indexedFiles: FileInfo[],
		onProgress: (processed: number, success: number, failed: number) => void,
	): Promise<void> {
		let processedCount = 0
		let successCount = 0
		let failedCount = 0
		let lastSaveTime = Date.now()

		console.log(`开始批量处理 ${filesToProcess.length} 个文件，批量大小：${this.BATCH_SAVE_SIZE}`)

		for (const file of filesToProcess) {
			try {
				const success = await this.indexSingleFileAsync(file, "add")

				if (success) {
					successCount++
					indexedFiles.push(file)
				} else {
					failedCount++
				}
			} catch (error) {
				console.error(`处理文件失败: ${file.path}`, error)
				failedCount++
			}

			processedCount++
			onProgress(processedCount, successCount, failedCount)

			// 批量保存逻辑：每N个文件或每隔一定时间保存一次
			const shouldSave =
				successCount > 0 &&
				(successCount % this.BATCH_SAVE_SIZE === 0 ||
					Date.now() - lastSaveTime > this.SAVE_INTERVAL_MS ||
					processedCount === filesToProcess.length) // 最后一批

			if (shouldSave) {
				console.log(`触发批量保存：已处理 ${processedCount}/${filesToProcess.length} 个文件，成功 ${successCount} 个`)
				await this.saveProgressIncremental(indexedFiles)
				lastSaveTime = Date.now()
			}
		}

		// 确保最终状态被保存
		if (successCount > 0) {
			await this.saveProgressIncremental(indexedFiles)
			console.log(`批量处理完成：共处理 ${processedCount} 个文件，成功 ${successCount} 个，失败 ${failedCount} 个`)
		}
	}

	/**
	 * 更新构建进度
	 */
	private updateBuildProgress(processed: number, success: number, failed: number, total: number): void {
		const progress = this.progressCalculator.calculateProgress(
			"hashing",
			total > 0 ? (processed / total) * 100 : 100,
			processed,
			success,
			failed,
		)
		this.progressReporter.updateProgress(progress)
	}

	/**
	 * 增量保存进度
	 */
	private async saveProgressIncremental(indexedFiles: FileInfo[]): Promise<void> {
		const merkleTree = new MerkleTree(indexedFiles)
		this.currentIndex = {
			projectPath: this.projectPath,
			projectSha256: IndexManager.projectSha256,
			merkleRoot: merkleTree.getRootHash() || "",
			files: indexedFiles,
			lastUpdated: Date.now(),
		}
		await this.saveIndexData(merkleTree)
	}

	/**
	 * 更新增量进度
	 */
	private updateIncrementalProgress(processed: number, success: number, failed: number, total: number): void {
		if (total > 0) {
			const progress: ProgressInfo = {
				message: nls.t("icode.codebase.indexBuilding"),
				percentage: (processed / total) * 100,
				totalFiles: total,
				processedFiles: processed,
				successFiles: success,
				failedFiles: failed,
			}
			this.progressReporter.updateProgress(progress)
		}
	}

	/**
	 * 删除现有索引
	 */
	async deleteExistingIndex(): Promise<void> {
		try {
			const userName = Authentication.getAuthenticationInfo().userId || ""
			const result = await this.apiClient.deleteAllIndex(userName, IndexManager.projectSha256)
			if (!result.success) {
				console.error("删除代码库索引失败:", result.error)
			}
		} catch (error) {
			console.error("删除现有索引失败:", error)
		}
	}

	/**
	 * 加载现有索引（从简化的merkle-tree.json）
	 */
	private async loadExistingIndex(): Promise<void> {
		try {
			const treeData = fs.readFileSync(this.merkleTreePath, "utf8")
			const merkleTree = MerkleTree.deserialize(treeData)

			// 从MerkleTree重建ProjectIndex
			const files = merkleTree.getAllFileInfos()

			this.currentIndex = {
				projectPath: this.projectPath,
				projectSha256: IndexManager.projectSha256,
				merkleRoot: merkleTree.getRootHash() || "",
				files: files,
				lastUpdated: Date.now(), // 使用当前时间
			}

			console.log("加载现有索引完成，文件数量:", files.length)
		} catch (error) {
			console.error("加载现有索引失败:", error)
			throw error
		}
	}

	/**
	 * 执行增量检查（支持断点续传）
	 */
	private async performIncrementalCheck(): Promise<void> {
		if (!this.currentIndex) {
			return
		}

		console.log("开始增量检查...")

		try {
			// 扫描当前文件
			const fileWatcher = new FileWatcher(this.projectPath)
			const currentFiles = await fileWatcher.scanAllFiles()

			// 构建当前默克尔树
			const currentTree = new MerkleTree(currentFiles)

			// 加载保存的默克尔树
			const savedTreeData = fs.readFileSync(this.merkleTreePath, "utf8")
			const savedTree = MerkleTree.deserialize(savedTreeData)

			// 比较差异
			const changes = MerkleTree.compare(savedTree, currentTree)

			if (changes.added.length > 0 || changes.modified.length > 0 || changes.deleted.length > 0) {
				console.log(
					`发现变化: 新增 ${changes.added.length}, 修改 ${changes.modified.length}, 删除 ${changes.deleted.length}`,
				)

				// 应用变化（支持实时保存）
				await this.applyIncrementalChangesWithSave(currentFiles, changes)
			} else {
				console.log("没有发现文件变化")
			}
		} catch (error) {
			console.error("增量检查失败:", error)
		}
	}

	/**
	 * 应用增量变化（支持批量保存）
	 */
	private async applyIncrementalChangesWithSave(
		currentFiles: FileInfo[],
		changes: {
			added: string[]
			modified: string[]
			deleted: string[]
		},
	): Promise<void> {
		const totalChanges = changes.added.length + changes.modified.length + changes.deleted.length

		if (totalChanges > 0) {
			this.progressReporter.startProgress(nls.t("icode.codebase.indexBuilding"))
		}

		const fileMap = new Map(currentFiles.map((f) => [f.path, f]))
		let indexedFiles = [...(this.currentIndex?.files || [])]

		let processedChanges = 0
		let successChanges = 0
		let failedChanges = 0
		let lastSaveTime = Date.now()

		console.log(`开始增量更新：新增 ${changes.added.length}, 修改 ${changes.modified.length}, 删除 ${changes.deleted.length}`)

		// 批量处理所有变化
		const allChanges = [
			...changes.added.map((path) => ({ path, type: "added" as const })),
			...changes.modified.map((path) => ({ path, type: "modified" as const })),
			...changes.deleted.map((path) => ({ path, type: "deleted" as const })),
		]

		for (const change of allChanges) {
			let success = false

			try {
				if (change.type === "deleted") {
					success = await this.processDeletedFile(change.path, indexedFiles)
				} else {
					const file = fileMap.get(change.path)
					if (file) {
						success = await this.processChangedFile(file, change.type, indexedFiles)
					}
				}

				if (success) {
					successChanges++
				} else {
					failedChanges++
				}
			} catch (error) {
				console.error(`处理${change.type}文件失败: ${change.path}`, error)
				failedChanges++
			}

			processedChanges++
			this.updateIncrementalProgress(processedChanges, successChanges, failedChanges, totalChanges)

			// 批量保存逻辑：每N个变化或每隔一定时间保存一次
			const shouldSave =
				successChanges > 0 &&
				(processedChanges % this.BATCH_SAVE_SIZE === 0 ||
					Date.now() - lastSaveTime > this.SAVE_INTERVAL_MS ||
					processedChanges === totalChanges)

			if (shouldSave) {
				console.log(`增量更新批量保存：已处理 ${processedChanges}/${totalChanges} 个变化，成功 ${successChanges} 个`)
				await this.saveProgressIncremental(indexedFiles)
				lastSaveTime = Date.now()
			}
		}

		// 触发repomap计算
		await this.apiClient.computeRepomap(
			Authentication.getAuthenticationInfo().userId || "",
			IndexManager.projectSha256,
			this.projectPath,
		)

		if (totalChanges > 0) {
			this.progressReporter.showCompletion(
				`${nls.t("icode.codebase.incrementalUpdateCompleted")}！处理了 ${totalChanges} 个文件变化，成功 ${successChanges} 个，失败 ${failedChanges} 个`,
			)
		}
	}

	/**
	 * 处理变更文件（新增/修改）
	 */
	private async processChangedFile(
		file: FileInfo,
		changeType: "added" | "modified",
		indexedFiles: FileInfo[],
	): Promise<boolean> {
		const apiChangeType = changeType === "added" ? "add" : "modify"
		const success = await this.indexSingleFileAsync(file, apiChangeType)

		if (success) {
			if (changeType === "added") {
				indexedFiles.push(file)
			} else {
				// 修改文件：更新现有记录
				const index = indexedFiles.findIndex((f) => f.path === file.path)
				if (index >= 0) {
					indexedFiles[index] = file
				}
			}
		}

		return success
	}

	/**
	 * 处理删除文件
	 */
	private async processDeletedFile(filePath: string, indexedFiles: FileInfo[]): Promise<boolean> {
		try {
			const userName = Authentication.getAuthenticationInfo().userId || ""
			const result = await this.apiClient.updateIndex(
				userName,
				IndexManager.projectSha256,
				filePath,
				"",
				"delete",
				this.projectPath,
			)

			if (result.success) {
				// 从索引列表中移除
				const initialLength = indexedFiles.length
				const newFiles = indexedFiles.filter((f) => f.path !== filePath)

				// 直接修改原数组
				indexedFiles.length = 0
				indexedFiles.push(...newFiles)

				return initialLength > newFiles.length // 确实删除了文件
			} else {
				console.error(`删除文件索引失败: ${filePath}`, result.error)
				return false
			}
		} catch (error) {
			console.error(`处理删除文件失败: ${filePath}`, error)
			return false
		}
	}

	/**
	 * 保存索引数据（只保存增强的merkle-tree.json）
	 */
	private async saveIndexData(merkleTree: MerkleTree): Promise<void> {
		if (!this.currentIndex) {
			return
		}

		// 只保存增强的默克尔树（包含所有索引信息）
		fs.writeFileSync(this.merkleTreePath, merkleTree.serialize())

		console.log(`索引数据已保存到: ${this.merkleTreePath}`)
	}

	/**
	 * 启动文件监控
	 */
	private startFileWatching(): void {
		this.fileWatcher = new FileWatcher(this.projectPath)
		this.fileWatcher.startWatching((changes) => {
			this.collectFileChanges(changes)
		})
	}

	/**
	 * 启动定时更新
	 */
	private startPeriodicUpdate(): void {
		console.log(`启动定时索引更新，间隔：${this.UPDATE_INTERVAL / 1000 / 60} 分钟`)
		this.updateTimer = setInterval(async () => {
			await this.processPendingChanges()
		}, this.UPDATE_INTERVAL)

		// 记录启动时间
		this.lastUpdateTime = Date.now()
	}

	/**
	 * 收集文件变化（不立即处理）
	 */
	private collectFileChanges(changes: IndexChange[]): void {
		console.log(`收集到 ${changes.length} 个文件变化，等待定时处理`)

		for (const change of changes) {
			// 使用文件路径作为 key，后续的变化会覆盖之前的变化
			this.pendingChanges.set(change.filePath, change)
		}

		console.log(`当前待处理变化总数：${this.pendingChanges.size}`)
	}

	/**
	 * 处理所有待处理的文件变化
	 */
	private async processPendingChanges(): Promise<void> {
		console.log("=== 开始定时检查 ===")

		try {
			// 记录实时收集的变化数量（用于日志）
			const pendingCount = this.pendingChanges.size
			if (pendingCount > 0) {
				console.log(`发现 ${pendingCount} 个实时检测到的文件变化`)
			}

			// 清空实时变化队列（因为全量检查会覆盖这些变化）
			this.pendingChanges.clear()

			// 直接执行全量增量检查（会发现所有变化，包括实时收集的）
			console.log("执行全量增量检查...")
			await this.initializeIndex()

			// 更新最后更新时间
			this.lastUpdateTime = Date.now()
			console.log("=== 定时检查完成 ===")
		} catch (error) {
			console.error("定时检查失败:", error)
		}
	}

	/**
	 * 销毁索引管理器
	 */
	dispose(): void {
		if (this.fileWatcher) {
			this.fileWatcher.stopWatching()
			this.fileWatcher = null
		}

		// 清理定时器
		if (this.updateTimer) {
			clearInterval(this.updateTimer)
			this.updateTimer = null
		}

		// 清理剩余的待处理变化
		if (this.pendingChanges.size > 0) {
			console.log(`销毁时丢弃剩余的 ${this.pendingChanges.size} 个未处理文件变化`)
			// 注意：销毁时不处理剩余变化，避免异步操作延迟销毁
			// 下次启动时会通过全量检查发现这些变化
		}

		this.pendingChanges.clear()
		this.progressReporter.stopProgress()

		this.isInitialized = false
		console.log("索引管理器已销毁")
	}

	/**
	 * 获取项目索引信息
	 */
	getProjectIndex(): ProjectIndex | null {
		return this.currentIndex
	}

	/**
	 * 获取项目 SHA256
	 */
	getProjectSha256(): string {
		return IndexManager.projectSha256
	}

	/**
	 * 是否已初始化
	 */
	isReady(): boolean {
		return this.isInitialized
	}

	/**
	 * 手动触发增量检查
	 */
	async triggerIncrementalCheck(): Promise<void> {
		if (!this.isInitialized) {
			throw new Error("索引管理器未初始化")
		}

		await this.performIncrementalCheck()
	}

	/**
	 * 重建索引（彻底重建）
	 */
	async rebuildIndex(): Promise<void> {
		if (!this.isInitialized) {
			throw new Error("索引管理器未初始化")
		}

		console.log("开始完全重建索引...")
		try {
			// 1. 删除远端索引
			await this.deleteExistingIndex()
			// 2. 删除本地索引文件
			await this.deleteHashIndexFile()
			// 3. 从头开始全量构建
			await this.buildFullIndex()
			console.log("完全重建索引完成")
		} catch (error) {
			console.error("重建索引失败:", error)
			throw error
		}
	}

	/**
	 * 获取更新状态信息
	 */
	getUpdateStatus(): {
		isTimerActive: boolean
		pendingChangesCount: number
		lastUpdateTime: number
		nextUpdateIn: number
		updateInterval: number
	} {
		const now = Date.now()
		const nextUpdateIn = this.lastUpdateTime + this.UPDATE_INTERVAL - now

		return {
			isTimerActive: this.updateTimer !== null,
			pendingChangesCount: this.pendingChanges.size,
			lastUpdateTime: this.lastUpdateTime,
			nextUpdateIn: Math.max(0, nextUpdateIn),
			updateInterval: this.UPDATE_INTERVAL,
		}
	}

	//删除本地索引hash
	async deleteHashIndexFile(): Promise<void> {
		try {
			if (fs.existsSync(this.projectIndexPath)) {
				fs.rmSync(this.projectIndexPath, { recursive: true, force: true })
				console.log(`本地索引hash目录已删除: ${this.projectIndexPath}`)
			}
		} catch (error) {
			console.error("删除现有hash目录失败:", error)
		}
	}
}
