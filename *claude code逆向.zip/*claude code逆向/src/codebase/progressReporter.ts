import * as vscode from "vscode"
import { ProgressInfo } from "./types"
import nls from "../nls/index"

export class ProgressReporter {
	private progressToken: vscode.CancellationTokenSource | null = null
	private currentProgress: vscode.Progress<{ message?: string; increment?: number }> | null = null
	private statusBarItem: vscode.StatusBarItem | null = null
	private extensionStatusBar: vscode.StatusBarItem | null = null

	constructor(extensionStatusBar?: vscode.StatusBarItem) {
		this.extensionStatusBar = extensionStatusBar || null
	}

	/**
	 * 开始显示进度条（在状态栏）
	 */
	async startProgress(title: string): Promise<void> {
		if (this.statusBarItem) {
			this.stopProgress()
		}

		// 创建状态栏项目
		this.statusBarItem = vscode.window.createStatusBarItem(
			vscode.StatusBarAlignment.Right,
			100, // 优先级，数字越大越靠右
		)

		this.statusBarItem.text = `$(sync~spin) ${nls.t("icode.codebase.indexBuilding")} 0%`
		// this.statusBarItem.tooltip = nls.t("icode.codebase.progressTooltip")
		this.statusBarItem.show()

		console.log(`开始显示状态栏进度: ${title}`)
	}

	/**
	 * 更新进度（在状态栏显示）
	 */
	updateProgress(info: ProgressInfo): void {
		if (!this.statusBarItem) {
			return
		}

		let progressText = ""
		let detailText = ""

		// 根据进度百分比选择合适的图标
		const percentage = Math.round(info.percentage)
		let icon = "$(sync~spin)"

		if (percentage >= 100) {
			icon = "$(check)"
		} else if (percentage >= 75) {
			icon = "$(loading~spin)"
		} else if (percentage >= 50) {
			icon = "$(sync~spin)"
		} else {
			icon = "$(loading~spin)"
		}

		// 构建进度文本 - 统一显示国际化的"索引构建中"
		progressText = `${nls.t("icode.codebase.indexBuilding")} ${percentage}%`

		// 添加文件计数信息
		if (info.totalFiles && info.processedFiles !== undefined) {
			detailText = `${info.processedFiles}/${info.totalFiles} 文件`
			progressText += ` (${detailText})`
		}

		this.statusBarItem.text = progressText

		// 构建详细的tooltip信息
		let tooltipText = `${nls.t("icode.codebase.indexBuilding")}\n进度: ${percentage}%`
		if (detailText) {
			tooltipText += `\n${detailText}`
		}

		// 添加成功和失败文件统计
		if (info.successFiles !== undefined && info.failedFiles !== undefined) {
			tooltipText += `\n成功: ${info.successFiles} 个文件`
			tooltipText += `\n失败: ${info.failedFiles} 个文件`
		}

		// this.statusBarItem.tooltip = tooltipText
	}

	/**
	 * 停止进度条（清理状态栏）
	 */
	stopProgress(): void {
		if (this.progressToken) {
			this.progressToken.cancel()
			this.progressToken.dispose()
			this.progressToken = null
		}

		if (this.statusBarItem) {
			this.statusBarItem.dispose()
			this.statusBarItem = null
		}

		this.currentProgress = null
		console.log("已停止状态栏进度显示")
	}

	/**
	 * 显示完成消息（先在状态栏显示，然后延迟清理）
	 */
	showCompletion(message: string, isError: boolean = false): void {
		// 在状态栏显示完成状态
		if (this.statusBarItem) {
			const icon = isError ? "$(error)" : "$(check)"
			const status = isError ? nls.t("icode.codebase.indexFailed") : nls.t("icode.codebase.indexCompleted")
			this.statusBarItem.text = `${icon} ${status}`
			this.statusBarItem.tooltip = message

			// 3秒后清理状态栏
			setTimeout(() => {
				if (this.statusBarItem) {
					this.statusBarItem.dispose()
					this.statusBarItem = null
				}
			}, 3000)
		}

		// 更新 extension 的 statusBar tooltip
		if (this.extensionStatusBar && !isError) {
			// 从消息中提取统计信息 - 支持全量构建和增量更新两种格式
			const totalMatch = message.match(/(?:共处理|处理了)\s*(\d+)\s*个(?:文件|文件变化)/)
			const successMatch = message.match(/成功\s*(\d+)\s*个/)
			const failedMatch = message.match(/失败\s*(\d+)\s*个/)

			const successFiles = successMatch ? successMatch[1] : "0"
			const failedFiles = failedMatch ? failedMatch[1] : "0"

			// 更新 extension statusBar 的 tooltip
			let tooltip = `${nls.t("icode.codebase.indexCompleted")}！\n`

			// 只有在能够提取到总文件数时才显示相关信息
			if (totalMatch) {
				tooltip += `总共: ${totalMatch[1]} 个文件\n`
			}

			tooltip += `成功: ${successFiles} 个文件\n失败: ${failedFiles} 个文件`
			this.extensionStatusBar.tooltip = tooltip
		}

		// 可选：显示通知消息
		// const showMethod = isError ? vscode.window.showErrorMessage : vscode.window.showInformationMessage
		// showMethod(message)
	}

	/**
	 * 是否正在显示进度（检查状态栏项目）
	 */
	isActive(): boolean {
		return this.statusBarItem !== null
	}
}

export class ProgressCalculator {
	private totalSteps: number = 0
	private currentStep: number = 0
	private stepWeights: Map<string, number> = new Map()

	constructor() {
		// 设置各个步骤的权重 - 只保留hashing阶段
		this.stepWeights.set("hashing", 1.0) // 计算哈希/文件上传：100%
	}

	/**
	 * 设置总文件数
	 */
	setTotalFiles(count: number): void {
		this.totalSteps = count
		this.currentStep = 0
	}

	/**
	 * 计算指定步骤的进度百分比
	 */
	calculateProgress(
		stepName: string,
		stepProgress: number,
		processedFiles?: number,
		successFiles?: number,
		failedFiles?: number,
	): ProgressInfo {
		const stepWeight = this.stepWeights.get(stepName) || 0
		const baseProgress = this.getPreviousStepsProgress(stepName)
		const currentStepProgress = stepWeight * (stepProgress / 100)
		const totalProgress = Math.min(100, (baseProgress + currentStepProgress) * 100)

		return {
			message: this.getStepMessage(stepName),
			percentage: totalProgress,
			totalFiles: this.totalSteps,
			processedFiles,
			successFiles,
			failedFiles,
		}
	}

	/**
	 * 获取前面步骤的总进度
	 */
	private getPreviousStepsProgress(currentStep: string): number {
		const stepOrder = ["hashing"]
		const currentIndex = stepOrder.indexOf(currentStep)

		let progress = 0
		for (let i = 0; i < currentIndex; i++) {
			progress += this.stepWeights.get(stepOrder[i]) || 0
		}

		return progress
	}

	/**
	 * 获取步骤描述信息
	 */
	private getStepMessage(stepName: string): string {
		// 统一返回国际化的"索引构建中"，不区分具体步骤
		return nls.t("icode.codebase.indexBuilding")
	}

	/**
	 * 增量更新进度
	 */
	incrementStep(): void {
		this.currentStep++
	}

	/**
	 * 重置进度
	 */
	reset(): void {
		this.totalSteps = 0
		this.currentStep = 0
	}
}
