import * as vscode from "vscode"
import * as fs from "fs"
import * as path from "path"
import { FileInfo, IndexChange } from "./types"

export class FileWatcher {
	private watcher: vscode.FileSystemWatcher | null = null
	private checkInterval: NodeJS.Timeout | null = null
	private lastScanTime: number = 0
	private isActive: boolean = false

	private pendingChanges: Map<string, IndexChange> = new Map()
	private onChangesCallback: ((changes: IndexChange[]) => void) | null = null

	// 新增：白名单后缀
	private whiteList: string[] = [
		".py",
		".js",
		".ts",
		".java",
		".cpp",
		".c",
		".cc",
		".h",
		".hpp",
		".go",
		".rs",
		".jsx",
		".tsx",
		".html",
		".htm",
		".css",
		".php",
		".swift",
		".cs",
		".sh",
		".json",
		".md",
		".yml",
		".yaml",
		".xml",
		".vue",
		".mjs",
		".cjs",
		".kt",
		".rb",
		".pl",
		".sql",
		".ini",
		".conf",
		".bat",
		".cmd",
	]

	constructor(
		private projectPath: string,
		private ignorePatterns: string[] = [],
	) {
		// 设置默认忽略模式 - 更精确的匹配
		this.ignorePatterns = [
			// Node.js 相关
			"node_modules/**",
			"npm-debug.log*",
			"yarn-debug.log*",
			"yarn-error.log*",
			"package-lock.json",
			"yarn.lock",
			"pnpm-lock.yaml",

			// Git 相关
			".git/**",
			".gitignore",
			".gitattributes",

			// 构建输出目录
			"dist/**",
			"build/**",
			"out/**",
			"target/**",
			"bin/**",
			"obj/**",
			"lib/**",
			"libs/**",
			"release/**",
			"debug/**",
			"docker/**",

			// 操作系统文件
			".DS_Store",
			"Thumbs.db",
			"desktop.ini",
			"*.tmp",
			"*.temp",

			// 过滤所有 .log 文件
			"*.log",

			// 过滤常见非文本文件
			"*.png",
			"*.jpg",
			"*.jpeg",
			"*.gif",
			"*.bmp",
			"*.ico",
			"*.svg",
			"*.webp",
			"*.mp3",
			"*.wav",
			"*.mp4",
			"*.avi",
			"*.mov",
			"*.wmv",
			"*.flv",
			"*.mkv",
			"*.zip",
			"*.rar",
			"*.7z",
			"*.tar",
			"*.gz",
			"*.bz2",
			"*.xz",
			"*.exe",
			"*.dll",
			"*.so",
			"*.pdf",
			"*.doc",
			"*.docx",
			"*.ppt",
			"*.pptx",
			"*.xls",
			"*.xlsx",
			"*.apk",
			"*.dmg",
			"*.iso",
			"*.bin",
			"*.obj",
			"*.class",
			"*.jar",
			"*.psd",
			"*.ttf",
			"*.woff",
			"*.woff2",
			"*.eot",
			"*.swf",
			"*.dat",

			...ignorePatterns,
		]

		// 读取项目根目录下的 .icodemateignore 文件
		this.loadIgnoreFile()
	}

	/**
	 * 开始监控文件变化
	 */
	startWatching(onChanges: (changes: IndexChange[]) => void): void {
		if (this.isActive) {
			this.stopWatching()
		}

		this.onChangesCallback = onChanges
		this.isActive = true

		// 创建文件系统监控器
		this.createFileWatcher()

		// 注意：移除了定期检查，现在由 IndexManager 统一管理定时更新
		console.log(`开始监控项目文件变化: ${this.projectPath}（实时检测模式）`)
	}

	/**
	 * 停止监控
	 */
	stopWatching(): void {
		this.isActive = false

		if (this.watcher) {
			this.watcher.dispose()
			this.watcher = null
		}

		if (this.checkInterval) {
			clearInterval(this.checkInterval)
			this.checkInterval = null
		}

		this.pendingChanges.clear()
		console.log("已停止文件监控")
	}

	/**
	 * 创建文件系统监控器
	 */
	private createFileWatcher(): void {
		const pattern = new vscode.RelativePattern(this.projectPath, "**/*")
		this.watcher = vscode.workspace.createFileSystemWatcher(pattern)

		// 监听文件创建
		this.watcher.onDidCreate((uri) => {
			this.handleFileChange(uri.fsPath, "added")
		})

		// 监听文件修改
		this.watcher.onDidChange((uri) => {
			this.handleFileChange(uri.fsPath, "modified")
		})

		// 监听文件删除
		this.watcher.onDidDelete((uri) => {
			this.handleFileChange(uri.fsPath, "deleted")
		})
	}

	/**
	 * 处理文件变化事件
	 */
	private handleFileChange(filePath: string, changeType: "added" | "modified" | "deleted"): void {
		if (!this.isActive || this.shouldIgnoreFile(filePath)) {
			return
		}

		const relativePath = path.relative(this.projectPath, filePath)

		// 防抖处理：同一文件的多次变化在短时间内只处理一次
		const changeKey = relativePath

		if (changeType === "deleted") {
			this.pendingChanges.set(changeKey, {
				type: "deleted",
				filePath: relativePath,
			})
		} else {
			// 对于添加和修改，需要计算新的哈希值
			try {
				if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
					const content = fs.readFileSync(filePath)
					const newHash = require("crypto").createHash("sha256").update(content).digest("hex")

					this.pendingChanges.set(changeKey, {
						type: changeType,
						filePath: relativePath,
						newHash,
					})
				}
			} catch (error) {
				console.error(`计算文件哈希失败: ${filePath}`, error)
			}
		}

		// 延迟处理变化，避免同一文件的多次快速变化产生重复记录
		// 1秒延迟可以有效合并快速的文件变化（如保存时的多次写入）
		setTimeout(() => {
			this.flushPendingChanges()
		}, 1000)
	}

	/**
	 * 将积累的变化传递给 IndexManager 收集
	 * 注意：这里只是传递变化给 IndexManager 进行收集，
	 * 实际的 API 调用会在 10 分钟定时器中批量处理
	 */
	private flushPendingChanges(): void {
		if (this.pendingChanges.size === 0 || !this.onChangesCallback) {
			return
		}

		const changes = Array.from(this.pendingChanges.values())
		this.pendingChanges.clear()

		this.onChangesCallback(changes)
	}

	/**
	 * 扫描所有文件
	 */
	async scanAllFiles(): Promise<FileInfo[]> {
		const files: FileInfo[] = []
		await this.scanDirectory(this.projectPath, files)
		return files
	}

	/**
	 * 递归扫描目录
	 */
	private async scanDirectory(dirPath: string, files: FileInfo[]): Promise<void> {
		try {
			const entries = fs.readdirSync(dirPath, { withFileTypes: true })

			for (const entry of entries) {
				const fullPath = path.join(dirPath, entry.name)
				const relativePath = path.relative(this.projectPath, fullPath)

				if (this.shouldIgnoreFile(fullPath)) {
					continue
				}

				if (entry.isDirectory()) {
					await this.scanDirectory(fullPath, files)
				} else if (entry.isFile()) {
					try {
						const stats = fs.statSync(fullPath)
						const content = fs.readFileSync(fullPath)
						const hash = require("crypto").createHash("sha256").update(content).digest("hex")

						files.push({
							path: relativePath,
							hash,
							lastModified: stats.mtime.getTime(),
							size: stats.size,
						})
					} catch (error) {
						console.error(`读取文件失败: ${fullPath}`, error)
					}
				}
			}
		} catch (error) {
			console.error(`扫描目录失败: ${dirPath}`, error)
		}
	}

	/**
	 * 检查是否应该忽略文件
	 */
	private shouldIgnoreFile(filePath: string): boolean {
		const relativePath = path.relative(this.projectPath, filePath)

		// 1. 黑名单优先
		for (const pattern of this.ignorePatterns) {
			if (this.matchPattern(relativePath, pattern)) {
				return true
			}
		}

		// 仅对文件做白名单过滤
		try {
			const stat = fs.statSync(filePath)
			if (stat.isFile()) {
				const ext = path.extname(filePath).toLowerCase()
				if (!this.whiteList.includes(ext)) {
					return true
				}

				// 其它特殊忽略逻辑
				const ignoredExtensions = [".tmp", ".temp", ".lock", ".swp", ".swo"]
				if (ignoredExtensions.includes(ext)) {
					return true
				}

				const fileName = path.basename(filePath)
				if (fileName.startsWith(".") && fileName !== ".gitignore" && fileName !== ".npmrc") {
					return true
				}
			}
		} catch (e) {
			// statSync 失败时，保守忽略
			return true
		}

		return false
	}

	/**
	 * 改进的通配符匹配，支持子目录匹配
	 */
	private matchPattern(filePath: string, pattern: string): boolean {
		// 统一路径分隔符为 /
		const normalizedFilePath = filePath.replace(/\\/g, "/")
		const normalizedPattern = pattern.replace(/\\/g, "/")

		// 处理特殊情况
		if (normalizedPattern === "**") {
			return true // ** 匹配所有文件
		}

		// 如果是 **/xxx/** 这种模式，直接用 includes 判断
		const matchDirPattern = normalizedPattern.match(/^\*\*\/(.+)\/\*\*$/)
		if (matchDirPattern) {
			const dir = `/${matchDirPattern[1]}/`
			return normalizedFilePath.includes(dir)
		}

		// 其它情况用正则
		let regexPattern = normalizedPattern
			.replace(/\./g, "\\.") // 转义点号
			.replace(/\*\*/g, ".*") // ** 匹配任意字符包括路径分隔符
			.replace(/\*/g, "[^/]*") // * 匹配除路径分隔符外的任意字符
			.replace(/\?/g, "[^/]") // ? 匹配除路径分隔符外的单个字符
		regexPattern = "(^|/)" + regexPattern + "(\/|$)"
		const regex = new RegExp(regexPattern)
		return regex.test(normalizedFilePath)
	}

	/**
	 * 获取最后扫描时间
	 */
	getLastScanTime(): number {
		return this.lastScanTime
	}

	/**
	 * 是否正在监控
	 */
	isWatching(): boolean {
		return this.isActive
	}

	/**
	 * 添加忽略模式
	 */
	addIgnorePattern(pattern: string): void {
		if (!this.ignorePatterns.includes(pattern)) {
			this.ignorePatterns.push(pattern)
		}
	}

	/**
	 * 移除忽略模式
	 */
	removeIgnorePattern(pattern: string): void {
		const index = this.ignorePatterns.indexOf(pattern)
		if (index > -1) {
			this.ignorePatterns.splice(index, 1)
		}
	}

	/**
	 * 读取项目根目录下的 .icodemateignore 文件
	 */
	private loadIgnoreFile(): void {
		const ignoreFilePath = path.join(this.projectPath, ".icodemateignore")

		try {
			if (fs.existsSync(ignoreFilePath)) {
				const content = fs.readFileSync(ignoreFilePath, "utf-8")
				const lines = content.split("\n")

				for (const line of lines) {
					const trimmedLine = line.trim()

					// 跳过空行和注释行
					if (trimmedLine === "" || trimmedLine.startsWith("#")) {
						continue
					}

					// 添加到忽略模式列表
					if (!this.ignorePatterns.includes(trimmedLine)) {
						this.ignorePatterns.push(trimmedLine)
					}
				}

				console.log(
					`已加载 .icodemateignore 文件，包含 ${lines.filter((line) => line.trim() !== "" && !line.trim().startsWith("#")).length} 个忽略模式`,
				)
			}
		} catch (error) {
			console.error(`读取 .icodemateignore 文件失败:`, error)
		}
	}
}
