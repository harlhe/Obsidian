import * as vscode from "vscode"
import { IndexManager } from "./indexManager"
import { FileWatcher } from "./fileWatcher"
import { ProgressReporter } from "./progressReporter"
import { DefaultIndexApiClient, MockIndexApiClient } from "./apiClient"
import { MerkleTree } from "./merkleTree"
import * as types from "./types"
import nls from "../nls/index"

export { IndexManager, FileWatcher, ProgressReporter, DefaultIndexApiClient, MockIndexApiClient, MerkleTree, types }

/**
 * CodeBase 功能的主入口类
 */
export class CodeBase {
	private indexManager: IndexManager | null = null
	private isActive: boolean = false

	constructor(
		private context: vscode.ExtensionContext,
		private statusBar?: vscode.StatusBarItem,
	) {}

	/**
	 * 初始化 CodeBase 功能
	 */
	async initialize(): Promise<void> {
		try {
			const workspacePath = this.getCurrentWorkspacePath()

			if (!workspacePath) {
				console.log("无法获取工作区路径")
				return
			}

			console.log(`初始化 CodeBase，项目路径: ${workspacePath}`)

			// 创建索引管理器，传递 statusBar 实例
			this.indexManager = new IndexManager(workspacePath || "", undefined, false, this.statusBar)

			// 初始化索引
			await this.indexManager.initialize()

			this.isActive = true

			console.log("CodeBase 初始化完成")
		} catch (error) {
			const errorMessage = `CodeBase 初始化失败: ${error}`
			console.error(errorMessage)
			vscode.window.showErrorMessage(errorMessage)
			throw error
		}
	}

	/**
	 * 获取当前工作区路径
	 */
	private getCurrentWorkspacePath(): string | undefined {
		const workspaceFolders = vscode.workspace.workspaceFolders
		if (workspaceFolders && workspaceFolders.length > 0) {
			return workspaceFolders[0].uri.fsPath
		}
		return undefined
	}

	/**
	 * 手动触发增量检查
	 */
	async triggerIncrementalCheck(): Promise<void> {
		if (!this.indexManager) {
			throw new Error("索引管理器未初始化")
		}

		await this.indexManager.triggerIncrementalCheck()
	}

	/**
	 * 重建索引 增量
	 */
	async rebuildIndex(): Promise<void> {
		if (!this.indexManager) {
			throw new Error("索引管理器未初始化")
		}

		await this.indexManager.initializeIndex()
	}

	/**
	 * 获取项目索引信息
	 */
	getProjectIndex(): types.ProjectIndex | null {
		return this.indexManager?.getProjectIndex() || null
	}

	/**
	 * 获取项目 SHA256
	 */
	getProjectSha256(): string | null {
		return this.indexManager?.getProjectSha256() || null
	}

	/**
	 * 是否处于活动状态
	 */
	isActiveState(): boolean {
		return this.isActive && this.indexManager?.isReady() === true
	}

	/**
	 * 获取更新状态
	 */
	getUpdateStatus() {
		return this.indexManager?.getUpdateStatus?.()
	}

	/**
	 * 删除索引信息
	 */
	async delIndex() {
		await Promise.all([this.indexManager?.deleteExistingIndex(), this.indexManager?.deleteHashIndexFile()])
	}

	/**
	 * 销毁 CodeBase 功能
	 */
	dispose(): void {
		if (this.indexManager) {
			this.indexManager.dispose()
			this.indexManager = null
		}

		this.isActive = false
		console.log("CodeBase 已销毁")
	}
}

/**
 * 在 VSCode 扩展激活时调用的便捷函数
 */
export async function activateCodeBase(context: vscode.ExtensionContext, statusBar?: vscode.StatusBarItem): Promise<CodeBase> {
	try {
		const codeBase = new CodeBase(context, statusBar)
		await codeBase.initialize()

		// 注册销毁回调
		context.subscriptions.push({
			dispose: () => codeBase.dispose(),
		})

		// 注册命令
		// registerCommands(context, codeBase)

		return codeBase
	} catch (error) {
		console.error("CodeBase 激活失败:", error)
		throw error
	}
}

/**
 * 注册 VSCode 命令
 */
function registerCommands(context: vscode.ExtensionContext, codeBase: CodeBase): void {
	// 手动触发增量检查
	const triggerCheckCommand = vscode.commands.registerCommand("iCodeMate.codebase.addIndex", async () => {
		try {
			const result = await vscode.window.showQuickPick(
				[nls.t("icode.codebase.rebuildIndexConfirm"), nls.t("icode.codebase.rebuildIndexCancel")],
				{ placeHolder: nls.t("icode.codebase.rebuildIndexTooltip") },
			)

			if (result === nls.t("icode.codebase.rebuildIndexConfirm")) {
				await codeBase.rebuildIndex()
				vscode.window.showInformationMessage(nls.t("icode.codebase.rebuildIndex"))
			}
		} catch (error) {
			vscode.window.showErrorMessage(nls.t("icode.codebase.rebuildIndexFailed") + `: ${error}`)
		}
	})

	// 手动触发删除索引
	const delIndexCommand = vscode.commands.registerCommand("iCodeMate.codebase.delIndex", async () => {
		try {
			const result = await vscode.window.showQuickPick(
				[nls.t("icode.codebase.rebuildIndexConfirm"), nls.t("icode.codebase.rebuildIndexCancel")],
				{ placeHolder: nls.t("icode.codebase.delIndexTooltip") },
			)

			if (result === nls.t("icode.codebase.rebuildIndexConfirm")) {
				await codeBase.delIndex()
				vscode.window.showInformationMessage(nls.t("icode.codebase.delIndexSuccess"))
			}
		} catch (error) {
			vscode.window.showErrorMessage(nls.t("icode.codebase.delIndexFailed") + `: ${error}`)
		}
	})

	context.subscriptions.push(triggerCheckCommand, delIndexCommand)
}
