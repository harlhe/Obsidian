import { IndexApiClient, ApiResponse, DeleteAllIndexRequest, UpdateIndexRequest, ComputeRepomapRequest } from "./types"
import { INDEX_API_URL } from "../util/constants"

export class DefaultIndexApiClient implements IndexApiClient {
	private baseUrl: string
	private timeout: number = 30000 // 30秒超时

	constructor(baseUrl: string = INDEX_API_URL) {
		this.baseUrl = baseUrl
	}

	/**
	 * 删除所有索引
	 */
	async deleteAllIndex(userName: string, projectPathHash: string): Promise<ApiResponse> {
		try {
			const requestData: DeleteAllIndexRequest = {
				user_name: `${userName}`,
				projectPathHash: `${projectPathHash}`,
			}

			const response = await this.makeRequest("/CodeBaseIndex/deleteAllIndex", "POST", requestData)

			return {
				success: response.ok,
				data: response.ok ? await response.json() : null,
				error: response.ok ? undefined : `HTTP ${response.status}: ${response.statusText}`,
			}
		} catch (error) {
			return {
				success: false,
				error: error instanceof Error ? error.message : String(error),
			}
		}
	}

	/**
	 * 更新索引（包括新增、修改、删除）
	 */
	async updateIndex(
		userName: string,
		projectPathHash: string,
		filePath: string,
		text: string,
		type: "add" | "delete" | "modify",
		rootPath: string,
	): Promise<ApiResponse> {
		try {
			const requestData: UpdateIndexRequest = {
				user_name: `${userName}`,
				projectPathHash: `${projectPathHash}`,
				file_path: filePath,
				text,
				type,
				rootPath: rootPath,
			}
			const response = await this.makeRequest("/CodeBaseIndex/indexSingleFile", "POST", requestData)
			return {
				success: response.ok,
				data: response.ok ? await response.json() : null,
				error: response.ok ? undefined : `HTTP ${response.status}: ${response.statusText}`,
			}
		} catch (error) {
			return {
				success: false,
				error: error instanceof Error ? error.message : String(error),
			}
		}
	}

	/**
	 * 发起 HTTP 请求
	 */
	private async makeRequest(endpoint: string, method: string, data: any): Promise<Response> {
		const controller = new AbortController()
		const timeoutId = setTimeout(() => controller.abort(), this.timeout)

		try {
			const response = await fetch(`${this.baseUrl}${endpoint}`, {
				method,
				headers: {
					"Content-Type": "application/json",
					"X-Emp-No": data?.user_name,
				},
				body: JSON.stringify(data),
				signal: controller.signal,
			})

			clearTimeout(timeoutId)
			return response
		} catch (error) {
			clearTimeout(timeoutId)
			throw error
		}
	}

	/**
	 * 设置 API 基础 URL
	 */
	setBaseUrl(url: string): void {
		this.baseUrl = url
	}

	/**
	 * 设置请求超时时间
	 */
	setTimeout(timeout: number): void {
		this.timeout = timeout
	}

	/**
	 * 计算代码库映射
	 */
	async computeRepomap(userName: string, projectPathHash: string, rootPath: string): Promise<ApiResponse> {
		try {
			const requestData: ComputeRepomapRequest = {
				projectPathHash: `${projectPathHash}`,
				user_name: `${userName}`,
				rootPath: `${rootPath}`,
			}

			//console.log(`Making request to /CodeBaseIndex/computeRepomap with data: ${JSON.stringify(requestData)}`)
			const response = await this.makeRequest("/CodeBaseIndex/computeRepomap", "POST", requestData)

			return {
				success: response.ok,
				data: response.ok ? await response.json() : null,
				error: response.ok ? undefined : `HTTP ${response.status}: ${response.statusText}`,
			}
		} catch (error) {
			return {
				success: false,
				error: error instanceof Error ? error.message : String(error),
			}
		}
	}
}

/**
 * Mock API 客户端，用于测试
 */
export class MockIndexApiClient implements IndexApiClient {
	private delay: number = 100 // 模拟网络延迟

	constructor(delay: number = 100) {
		this.delay = delay
	}

	async deleteAllIndex(userName: string, projectPathHash: string): Promise<ApiResponse> {
		await this.simulateDelay()
		console.log(`Mock: Deleting all index for user ${userName}, project ${projectPathHash}`)
		return { success: true, data: { message: "All index deleted" } }
	}

	async updateIndex(
		userName: string,
		projectPathHash: string,
		filePath: string,
		text: string,
		type: "add" | "delete" | "modify",
		rootPath: string,
	): Promise<ApiResponse> {
		await this.simulateDelay()
		console.log(`Mock: ${type} index for user ${userName}, project ${projectPathHash}, file ${filePath}`)
		console.log(`Text length: ${text.length} characters`)
		return { success: true, data: { message: `Index ${type} completed` } }
	}
	async computeRepomap(userName: string, projectPathHash: string, rootPath: string): Promise<ApiResponse> {
		await this.simulateDelay()
		console.log(`Mock: Computing repomap for user ${userName}, project ${projectPathHash}`)
		return { success: true, data: { message: "Repomap computed successfully" } }
	}
	private async simulateDelay(): Promise<void> {
		return new Promise((resolve) => setTimeout(resolve, this.delay))
	}
}
