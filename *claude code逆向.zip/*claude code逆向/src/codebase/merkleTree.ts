import * as crypto from "crypto"
import { MerkleNode, FileInfo, SimplifiedMerkleTreeData } from "./types"

export class MerkleTree {
	private root: MerkleNode | null = null

	constructor(files: FileInfo[] = []) {
		if (files.length > 0) {
			this.buildTree(files)
		}
	}

	/**
	 * 构建默克尔树
	 */
	buildTree(files: FileInfo[]): void {
		if (files.length === 0) {
			this.root = null
			return
		}

		// 按文件路径排序，确保构建的树是确定性的
		const sortedFiles = files.sort((a, b) => a.path.localeCompare(b.path))

		// 创建叶子节点（包含完整文件信息）
		const leafNodes: MerkleNode[] = sortedFiles.map((file) => ({
			hash: file.hash,
			isLeaf: true,
			fileInfo: file, // 存储完整文件信息
		}))

		// 如果只有一个文件，直接返回
		if (leafNodes.length === 1) {
			this.root = leafNodes[0]
			return
		}

		this.root = this.buildTreeRecursive(leafNodes)
	}

	/**
	 * 递归构建树结构
	 */
	private buildTreeRecursive(nodes: MerkleNode[]): MerkleNode {
		if (nodes.length === 1) {
			return nodes[0]
		}

		const nextLevel: MerkleNode[] = []

		for (let i = 0; i < nodes.length; i += 2) {
			const left = nodes[i]
			const right = i + 1 < nodes.length ? nodes[i + 1] : left // 如果是奇数个节点，最后一个节点复制

			const combinedHash = this.combineHashes(left.hash, right.hash)
			const parentNode: MerkleNode = {
				hash: combinedHash,
				left,
				right: right !== left ? right : undefined,
				isLeaf: false,
			}

			nextLevel.push(parentNode)
		}

		return this.buildTreeRecursive(nextLevel)
	}

	/**
	 * 合并两个哈希值
	 */
	private combineHashes(hash1: string, hash2: string): string {
		const combined = hash1 + hash2
		return crypto.createHash("sha256").update(combined).digest("hex")
	}

	/**
	 * 获取根哈希
	 */
	getRootHash(): string | null {
		return this.root?.hash || null
	}

	/**
	 * 序列化树结构
	 */
	serialize(): string {
		const data: SimplifiedMerkleTreeData = {
			tree: this.root,
			rootHash: this.getRootHash() || undefined,
		}
		return JSON.stringify(data, null, 2)
	}

	/**
	 * 反序列化树结构
	 */
	static deserialize(data: string): MerkleTree {
		const tree = new MerkleTree()
		try {
			const parsed = JSON.parse(data) as SimplifiedMerkleTreeData
			tree.root = parsed.tree
		} catch (error) {
			console.error("Failed to deserialize merkle tree:", error)
			tree.root = null
		}
		return tree
	}

	/**
	 * 比较两个默克尔树，返回差异
	 */
	static compare(
		tree1: MerkleTree,
		tree2: MerkleTree,
	): {
		added: string[]
		modified: string[]
		deleted: string[]
	} {
		const files1 = tree1.getAllFiles()
		const files2 = tree2.getAllFiles()

		const map1 = new Map(files1.map((f) => [f.path, f.hash]))
		const map2 = new Map(files2.map((f) => [f.path, f.hash]))

		const added: string[] = []
		const modified: string[] = []
		const deleted: string[] = []

		// 检查新增和修改的文件
		for (const [path, hash] of map2) {
			if (!map1.has(path)) {
				added.push(path)
			} else if (map1.get(path) !== hash) {
				modified.push(path)
			}
		}

		// 检查删除的文件
		for (const path of map1.keys()) {
			if (!map2.has(path)) {
				deleted.push(path)
			}
		}

		return { added, modified, deleted }
	}

	/**
	 * 获取所有文件信息
	 */
	private getAllFiles(): { path: string; hash: string }[] {
		const files: { path: string; hash: string }[] = []
		this.collectFiles(this.root, files)
		return files
	}

	/**
	 * 递归收集所有叶子节点（文件）
	 */
	private collectFiles(node: MerkleNode | null | undefined, files: { path: string; hash: string }[]): void {
		if (!node) return

		if (node.isLeaf && node.fileInfo) {
			files.push({ path: node.fileInfo.path, hash: node.fileInfo.hash })
		} else {
			this.collectFiles(node.left, files)
			this.collectFiles(node.right, files)
		}
	}

	/**
	 * 获取所有文件信息（完整的FileInfo）
	 */
	getAllFileInfos(): FileInfo[] {
		const files: FileInfo[] = []
		this.collectFileInfos(this.root, files)
		return files
	}

	/**
	 * 递归收集所有叶子节点的完整文件信息
	 */
	private collectFileInfos(node: MerkleNode | null | undefined, files: FileInfo[]): void {
		if (!node) return

		if (node.isLeaf && node.fileInfo) {
			files.push(node.fileInfo)
		} else {
			this.collectFileInfos(node.left, files)
			this.collectFileInfos(node.right, files)
		}
	}

	/**
	 * 获取根节点（用于向后兼容）
	 */
	getRoot(): MerkleNode | null {
		return this.root
	}

	/**
	 * 计算文件哈希值
	 */
	static async calculateFileHash(filePath: string, content: Buffer): Promise<string> {
		return crypto.createHash("sha256").update(content).digest("hex")
	}
}
