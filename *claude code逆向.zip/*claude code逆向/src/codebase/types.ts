export interface FileInfo {
	path: string
	hash: string
	lastModified: number
	size: number
}

export interface MerkleNode {
	hash: string
	left?: MerkleNode
	right?: MerkleNode
	isLeaf: boolean
	fileInfo?: FileInfo
}

export interface ProjectIndex {
	projectPath: string
	projectSha256: string
	merkleRoot: string
	files: FileInfo[]
	lastUpdated: number
}

// 简化的MerkleTree存储结构（只包含树结构）
export interface SimplifiedMerkleTreeData {
	// 默克尔树结构
	tree: MerkleNode | null

	// 缓存的根哈希（性能优化）
	rootHash?: string
}

export interface IndexChange {
	type: "added" | "modified" | "deleted"
	filePath: string
	oldHash?: string
	newHash?: string
}

export interface ProgressInfo {
	message: string
	percentage: number
	totalFiles?: number
	processedFiles?: number
	successFiles?: number
	failedFiles?: number
}

export interface ApiResponse<T = any> {
	success: boolean
	data?: T
	error?: string
}

export interface UserInfo {
	userName: string
}

export interface UpdateIndexRequest {
	user_name: string
	projectPathHash: string
	file_path: string
	text: string
	type: "add" | "delete" | "modify"
	rootPath: string
}

export interface DeleteAllIndexRequest {
	user_name: string
	projectPathHash: string
}

export interface IndexApiClient {
	deleteAllIndex(userName: string, projectPathHash: string): Promise<ApiResponse>
	updateIndex(
		userName: string,
		projectPathHash: string,
		filePath: string,
		text: string,
		type: "add" | "delete" | "modify",
		rootPath: string,
	): Promise<ApiResponse>
	computeRepomap(userName: string, projectPathHash: string, rootPath: string): Promise<ApiResponse>
}

export interface ComputeRepomapRequest {
	projectPathHash: string
	user_name: string
	rootPath: string
}
