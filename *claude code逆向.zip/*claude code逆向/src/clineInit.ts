// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import { setTimeout as setTimeoutPromise } from "node:timers/promises"
import * as vscode from "vscode"
import pWaitFor from "p-wait-for"
import { Logger } from "./services/logging/Logger"
import { createClineAPI } from "./exports"
import "./utils/path" // necessary to have access to String.prototype.toPosix
import { DIFF_VIEW_URI_SCHEME } from "./integrations/editor/DiffViewProvider"
import assert from "node:assert"
import { telemetryService } from "./services/telemetry/TelemetryService"
import { WebviewProvider } from "./core/webview"
import { ErrorService } from "./services/error/ErrorService"
import { initializeTestMode, cleanupTestMode } from "./services/test/TestMode"
import ChatGPTViewProvider from "./chatgptViewProvider"
/*
Built using https://github.com/microsoft/vscode-webview-ui-toolkit

Inspired by
https://github.com/microsoft/vscode-webview-ui-toolkit-samples/tree/main/default/weather-webview
https://github.com/microsoft/vscode-webview-ui-toolkit-samples/tree/main/frameworks/hello-world-react-cra

*/

// TODO: Find a solution for automatically removing DEV related content from production builds.
//  This type of code is fine in production to keep. We just will want to remove it from production builds
//  to bring down built asset sizes.
//
// This is a workaround to reload the extension when the source code changes
// since vscode doesn't support hot reload for extensions
const { IS_DEV, DEV_WORKSPACE_FOLDER } = process.env

export class ClineExtension {
	private outputChannel: vscode.OutputChannel | undefined
	private context: vscode.ExtensionContext
	private sidebarWebview: WebviewProvider | undefined
	private gptProvider: ChatGPTViewProvider

	constructor(context: vscode.ExtensionContext, gptProvider: ChatGPTViewProvider) {
		this.context = context
		this.gptProvider = gptProvider
	}

	public initialize() {
		this.outputChannel = vscode.window.createOutputChannel("Cline")
		this.context.subscriptions.push(this.outputChannel)

		ErrorService.initialize()
		Logger.initialize(this.outputChannel)
		Logger.log("Cline extension activated")

		this.sidebarWebview = new WebviewProvider(this.context, this.gptProvider, this.outputChannel)

		// Initialize test mode and add disposables to context
		this.context.subscriptions.push(...initializeTestMode(this.context, this.sidebarWebview))

		vscode.commands.executeCommand("setContext", "cline.isDevMode", IS_DEV && IS_DEV === "true")

		this.context.subscriptions.push(
			vscode.window.registerWebviewViewProvider(WebviewProvider.sideBarId, this.sidebarWebview, {
				webviewOptions: { retainContextWhenHidden: true },
			}),
		)

		this.context.subscriptions.push(
			vscode.commands.registerCommand("ZTE-AI-Assistant.plusButtonClicked", async (webview: any) => {
				const openChat = async (instance?: WebviewProvider) => {
					await instance?.controller.clearTask()
					await instance?.controller.postStateToWebview()
					await instance?.controller.postMessageToWebview({
						type: "action",
						action: "customchatButtonClicked",
					})
				}
				const isSidebar = !webview
				if (isSidebar) {
					openChat(WebviewProvider.getSidebarInstance())
				} else {
					WebviewProvider.getTabInstances().forEach(openChat)
				}
			}),
		)

		this.context.subscriptions.push(
			vscode.commands.registerCommand("ZTE-AI-Assistant.mcpButtonClicked", (webview: any) => {
				const openMcp = (instance?: WebviewProvider) =>
					instance?.controller.postMessageToWebview({
						type: "action",
						action: "mcpButtonClicked",
					})
				const isSidebar = !webview
				if (isSidebar) {
					openMcp(WebviewProvider.getSidebarInstance())
				} else {
					WebviewProvider.getTabInstances().forEach(openMcp)
				}
			}),
		)

		const openClineInNewTab = async () => {
			Logger.log("Opening Cline in new tab")
			// (this example uses webviewProvider activation event which is necessary to deserialize cached webview, but since we use retainContextWhenHidden, we don't need to use that event)
			// https://github.com/microsoft/vscode-extension-samples/blob/main/webview-sample/src/extension.ts
			const tabWebview = new WebviewProvider(this.context, this.gptProvider, this.outputChannel!)
			//const column = vscode.window.activeTextEditor ? vscode.window.activeTextEditor.viewColumn : undefined
			const lastCol = Math.max(...vscode.window.visibleTextEditors.map((editor) => editor.viewColumn || 0))

			// Check if there are any visible text editors, otherwise open a new group to the right
			const hasVisibleEditors = vscode.window.visibleTextEditors.length > 0
			if (!hasVisibleEditors) {
				await vscode.commands.executeCommand("workbench.action.newGroupRight")
			}
			const targetCol = hasVisibleEditors ? Math.max(lastCol + 1, 1) : vscode.ViewColumn.Two

			const panel = vscode.window.createWebviewPanel(WebviewProvider.tabPanelId, "Cline", targetCol, {
				enableScripts: true,
				retainContextWhenHidden: true,
				localResourceRoots: [this.context.extensionUri],
			})
			// TODO: use better svg icon with light and dark variants (see https://stackoverflow.com/questions/58365687/vscode-extension-iconpath)

			panel.iconPath = {
				light: vscode.Uri.joinPath(this.context.extensionUri, "assets", "ai.png"),
				dark: vscode.Uri.joinPath(this.context.extensionUri, "assets", "ai.png"),
			}
			tabWebview.resolveWebviewView(panel)

			// Lock the editor group so clicking on files doesn't open them over the panel
			await setTimeoutPromise(100)
			await vscode.commands.executeCommand("workbench.action.lockEditorGroup")
		}

		this.context.subscriptions.push(
			vscode.commands.registerCommand("ZTE-AI-Assistant.popoutButtonClicked", openClineInNewTab),
		)
		this.context.subscriptions.push(vscode.commands.registerCommand("ZTE-AI-Assistant.openInNewTab", openClineInNewTab))

		this.context.subscriptions.push(
			vscode.commands.registerCommand("ZTE-AI-Assistant.settingsButtonClicked", (webview: any) => {
				WebviewProvider.getAllInstances().forEach((instance) => {
					const openSettings = async (instance?: WebviewProvider) => {
						instance?.controller.postMessageToWebview({
							type: "action",
							action: "settingsButtonClicked",
						})
					}
					const isSidebar = !webview
					if (isSidebar) {
						openSettings(WebviewProvider.getSidebarInstance())
					} else {
						WebviewProvider.getTabInstances().forEach(openSettings)
					}
				})
			}),
		)

		this.context.subscriptions.push(
			vscode.commands.registerCommand("ZTE-AI-Assistant.historyButtonClicked", (webview: any) => {
				WebviewProvider.getAllInstances().forEach((instance) => {
					const openHistory = async (instance?: WebviewProvider) => {
						instance?.controller.postMessageToWebview({
							type: "action",
							action: "customhistoryButtonClicked",
						})
					}
					const isSidebar = !webview
					if (isSidebar) {
						openHistory(WebviewProvider.getSidebarInstance())
					} else {
						WebviewProvider.getTabInstances().forEach(openHistory)
					}
				})
			}),
		)

		// this.context.subscriptions.push(
		// 	vscode.commands.registerCommand("ZTE-AI-Assistant.accountButtonClicked", (webview: any) => {
		// 		WebviewProvider.getAllInstances().forEach((instance) => {
		// 			const openAccount = async (instance?: WebviewProvider) => {
		// 				instance?.controller.postMessageToWebview({
		// 					type: "action",
		// 					action: "accountButtonClicked",
		// 				})
		// 			}
		// 			const isSidebar = !webview
		// 			if (isSidebar) {
		// 				openAccount(WebviewProvider.getSidebarInstance())
		// 			} else {
		// 				WebviewProvider.getTabInstances().forEach(openAccount)
		// 			}
		// 		})
		// 	}),
		// )

		/*
		We use the text document content provider API to show the left side for diff view by creating a virtual document for the original content. This makes it readonly so users know to edit the right side if they want to keep their changes.

		- This API allows you to create readonly documents in VSCode from arbitrary sources, and works by claiming an uri-scheme for which your provider then returns text contents. The scheme must be provided when registering a provider and cannot change afterwards.
		- Note how the provider doesn't create uris for virtual documents - its role is to provide contents given such an uri. In return, content providers are wired into the open document logic so that providers are always considered.
		https://code.visualstudio.com/api/extension-guides/virtual-documents
		*/
		const diffContentProvider = new (class implements vscode.TextDocumentContentProvider {
			provideTextDocumentContent(uri: vscode.Uri): string {
				return Buffer.from(uri.query, "base64").toString("utf-8")
			}
		})()
		this.context.subscriptions.push(
			vscode.workspace.registerTextDocumentContentProvider(DIFF_VIEW_URI_SCHEME, diffContentProvider),
		)

		// URI Handler
		const handleUri = async (uri: vscode.Uri) => {
			console.log("URI Handler called with:", {
				path: uri.path,
				query: uri.query,
				scheme: uri.scheme,
			})

			const path = uri.path
			const query = new URLSearchParams(uri.query.replace(/\+/g, "%2B"))
			const visibleWebview = WebviewProvider.getVisibleInstance()
			if (!visibleWebview) {
				return
			}
			switch (path) {
				case "/openrouter": {
					const code = query.get("code")
					if (code) {
						await visibleWebview?.controller.handleOpenRouterCallback(code)
					}
					break
				}
				case "/auth": {
					const token = query.get("token")
					const state = query.get("state")
					const apiKey = query.get("apiKey")
					
					console.log("Auth callback received:", {state: state,})

					// Validate state parameter
					if (!(await visibleWebview?.controller.validateAuthState(state))) {
						vscode.window.showErrorMessage("Invalid auth state")
						return
					}

					if (token && apiKey) {
						await visibleWebview?.controller.handleAuthCallback(token, apiKey)
					}
					break
				}
				default:
					break
			}
		}
		this.context.subscriptions.push(vscode.window.registerUriHandler({ handleUri }))

		// Register size testing commands in development mode
		if (IS_DEV && IS_DEV === "true") {
			// Use dynamic import to avoid loading the module in production
			import("./dev/commands/tasks")
				.then((module) => {
					const devTaskCommands = module.registerTaskCommands(this.context, this.sidebarWebview!.controller)
					this.context.subscriptions.push(...devTaskCommands)
					Logger.log("Cline dev task commands registered")
				})
				.catch((error) => {
					Logger.log("Failed to register dev task commands: " + error)
				})
		}

		this.context.subscriptions.push(
			vscode.commands.registerCommand(
				"ZTE-AI-Assistant.addToChat",
				async (range?: vscode.Range, diagnostics?: vscode.Diagnostic[]) => {
					const editor = vscode.window.activeTextEditor
					if (!editor) {
						return
					}

					// Use provided range if available, otherwise use current selection
					// (vscode command passes an argument in the first param by default, so we need to ensure it's a Range object)
					const textRange = range instanceof vscode.Range ? range : editor.selection
					const selectedText = editor.document.getText(textRange)

					if (!selectedText) {
						return
					}
					const visibleWebview = WebviewProvider.getVisibleInstance()
					if (visibleWebview) {
						visibleWebview.controller.postMessageToWebview({ type: "switchAgentTab" })
					}

					// Get the file path and language ID
					const filePath = editor.document.uri.fsPath
					const languageId = editor.document.languageId

					await visibleWebview?.controller.addSelectedCodeToChat(
						selectedText,
						filePath,
						languageId,
						Array.isArray(diagnostics) ? diagnostics : undefined,
					)
				},
			),
		)

		this.context.subscriptions.push(
			vscode.commands.registerCommand("ZTE-AI-Assistant.addTerminalOutputToChat", async () => {
				const terminal = vscode.window.activeTerminal
				if (!terminal) {
					return
				}

				// Save current clipboard content
				const tempCopyBuffer = await vscode.env.clipboard.readText()

				try {
					// Copy the *existing* terminal selection (without selecting all)
					await vscode.commands.executeCommand("workbench.action.terminal.copySelection")

					// Get copied content
					let terminalContents = (await vscode.env.clipboard.readText()).trim()

					// Restore original clipboard content
					await vscode.env.clipboard.writeText(tempCopyBuffer)

					if (!terminalContents) {
						// No terminal content was copied (either nothing selected or some error)
						return
					}

					// [Optional] Any additional logic to process multi-line content can remain here
					// For example:
					/*
					const lines = terminalContents.split("\n")
					const lastLine = lines.pop()?.trim()
					if (lastLine) {
						let i = lines.length - 1
						while (i >= 0 && !lines[i].trim().startsWith(lastLine)) {
							i--
						}
						terminalContents = lines.slice(Math.max(i, 0)).join("\n")
					}
					*/

					// Send to sidebar provider
					const visibleWebview = WebviewProvider.getVisibleInstance()
					await visibleWebview?.controller.addSelectedTerminalOutputToChat(terminalContents, terminal.name)
				} catch (error) {
					// Ensure clipboard is restored even if an error occurs
					await vscode.env.clipboard.writeText(tempCopyBuffer)
					console.error("Error getting terminal contents:", error)
					vscode.window.showErrorMessage("Failed to get terminal contents")
				}
			}),
		)

		// Register code action provider
		this.context.subscriptions.push(
			vscode.languages.registerCodeActionsProvider(
				"*",
				new (class implements vscode.CodeActionProvider {
					public static readonly providedCodeActionKinds = [vscode.CodeActionKind.QuickFix]

					provideCodeActions(
						document: vscode.TextDocument,
						range: vscode.Range,
						context: vscode.CodeActionContext,
					): vscode.CodeAction[] {
						// Expand range to include surrounding 3 lines
						const expandedRange = new vscode.Range(
							Math.max(0, range.start.line - 3),
							0,
							Math.min(document.lineCount - 1, range.end.line + 3),
							document.lineAt(Math.min(document.lineCount - 1, range.end.line + 3)).text.length,
						)

						const addAction = new vscode.CodeAction("Add to iCodeMate", vscode.CodeActionKind.QuickFix)
						addAction.command = {
							command: "ZTE-AI-Assistant.addToChat",
							title: "Add to iCodeMate",
							arguments: [expandedRange, context.diagnostics],
						}

						const fixAction = new vscode.CodeAction("Fix with iCodeMate", vscode.CodeActionKind.QuickFix)
						fixAction.command = {
							command: "ZTE-AI-Assistant.fixWithiCodeMate",
							title: "Fix with iCodeMate",
							arguments: [expandedRange, context.diagnostics],
						}

						// Only show actions when there are errors
						if (context.diagnostics.length > 0) {
							return [addAction, fixAction]
						} else {
							return []
						}
					}
				})(),
				{
					providedCodeActionKinds: [vscode.CodeActionKind.QuickFix],
				},
			),
		)

		// Register the command handler
		this.context.subscriptions.push(
			vscode.commands.registerCommand(
				"ZTE-AI-Assistant.fixWithiCodeMate",
				async (range: vscode.Range, diagnostics: vscode.Diagnostic[]) => {
					// Add this line to focus the chat input first
					await vscode.commands.executeCommand("ZTE-AI-Assistant.focusChatInput")
					// Wait for a webview instance to become visible after focusing
					await pWaitFor(() => !!WebviewProvider.getVisibleInstance())
					const editor = vscode.window.activeTextEditor
					if (!editor) {
						return
					}
					const visibleWebview = WebviewProvider.getVisibleInstance()
					if (visibleWebview) {
						visibleWebview.controller.postMessageToWebview({ type: "switchAgentTab" })
					}
					const selectedText = editor.document.getText(range)
					const filePath = editor.document.uri.fsPath
					const languageId = editor.document.languageId

					// Send to sidebar provider with diagnostics
					await visibleWebview?.controller.fixWithCline(selectedText, filePath, languageId, diagnostics)
				},
			),
		)

		// Register the focusChatInput command handler
		this.context.subscriptions.push(
			vscode.commands.registerCommand("ZTE-AI-Assistant.focusChatInput", () => {
				let visibleWebview = WebviewProvider.getVisibleInstance()
				if (!visibleWebview) {
					vscode.commands.executeCommand("ZTE-AI-Assistant.SidebarProvider.focus")
					visibleWebview = WebviewProvider.getSidebarInstance()
					// showing the extension will call didBecomeVisible which focuses it already
					// but it doesn't focus if a tab is selected which focusChatInput accounts for
				}

				visibleWebview?.controller.postMessageToWebview({
					type: "action",
					action: "focusChatInput",
				})
			}),
		)

		// Set up development mode file watcher
		if (IS_DEV && IS_DEV !== "false") {
			assert(DEV_WORKSPACE_FOLDER, "DEV_WORKSPACE_FOLDER must be set in development")
			const watcher = vscode.workspace.createFileSystemWatcher(new vscode.RelativePattern(DEV_WORKSPACE_FOLDER, "src/**/*"))

			watcher.onDidChange(({ scheme, path }) => {
				console.info(`${scheme} ${path} changed. Reloading VSCode...`)

				vscode.commands.executeCommand("workbench.action.reloadWindow")
			})
		}

		return createClineAPI(this.outputChannel!, this.sidebarWebview!.controller)
	}

	public dispose() {
		// Clean up test mode
		cleanupTestMode()

		telemetryService.shutdown()
		Logger.log("Cline extension deactivated")
		this.outputChannel?.dispose()
	}
}
