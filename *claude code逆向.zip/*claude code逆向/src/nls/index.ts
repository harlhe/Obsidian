import * as vscode from "vscode"
import en from "./lang/en"
import zh from "./lang/zh"

import { get } from "lodash"

const t = (key: string) => {
	const locale = vscode.env.language.toLowerCase() === "zh-cn" ? zh : en
	const message = get(locale, key)

	return message
}

const nls = {
	t,
}

export default nls
