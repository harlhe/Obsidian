import { extensions, window } from "vscode"
import * as vscode from "vscode"
import axios from "axios"
import { USER_INFO_KEY, API_URL } from "./constants"
import { UserInfoType } from "../types"

const os = require("os")

const getExternalNetworkTokenUrl = (): string => API_URL + "/gpt/api/oauth2/authResult?state="

export interface UserInfo {
	userId?: string | undefined
	username?: string | undefined
	token?: string | undefined
	gerritHttpPassword: string | undefined
	[propsName: string]: any
}

export function getUserInfo() {
	const uacExtension = extensions.getExtension("RAN-TAG.accounts")
	let userInfo
	try {
		if (uacExtension) {
			let importedApi = uacExtension.exports
			let uacUserInfo = importedApi.getUserInfo()
			if (
				uacUserInfo &&
				uacUserInfo.userId !== undefined &&
				uacUserInfo.userId !== "" &&
				uacUserInfo.gerritHttpPassword !== undefined &&
				uacUserInfo.gerritHttpPassword !== ""
			) {
				userInfo = uacUserInfo
			} else {
				window.showErrorMessage("未获取到认证信息，请先登录")
			}
		} else {
			window.showErrorMessage("请先安装登录验证（accounts）插件")
		}
	} catch {
		window.showErrorMessage("未获取到认证信息，请先登录")
	}
	return userInfo
}

export function printOutput(content: string) {
	const dateOb = new Date()
	let date = ("0" + dateOb.getDate()).slice(-2)
	let month = ("0" + (dateOb.getMonth() + 1)).slice(-2)
	return `[Info - ${dateOb.getFullYear()}-${month}-${date} ${dateOb.getHours()}:${dateOb.getMinutes()}:${dateOb.getSeconds()}] ${content}`
}
// 1.0 to 2.0 迁移
export function getBaseDirectory() {
	try {
		const workspaceFolders = vscode.workspace.workspaceFolders
		let baseDir = ""
		if (workspaceFolders) {
			baseDir = workspaceFolders[0].name
		}
		return baseDir
	} catch (e) {
		console.error(e)
	}
}
// 1.0 to 2.0 迁移
export function getGitInfo(): { branch: string; repoName: string } {
	try {
		const extension = vscode.extensions
		const gitExtension = extension.getExtension("vscode.git")
		let branch = ""
		let repoName = ""
		if (gitExtension?.isActive) {
			const gitExtensionExport = gitExtension?.exports
			const api = gitExtensionExport.getAPI(1)
			const repo = api.repositories[0]
			repoName = repo?.rootUri.path.split("/").pop()
			branch = repo?.state?.HEAD?.name
		}
		return {
			branch,
			repoName,
		}
	} catch (e) {
		console.error(e)
		return {
			branch: "",
			repoName: "",
		}
	}
}

// 1.0 to 2.0 迁移
export function getActiveEditorFilePath() {
	try {
		const activeTextEditor: vscode.TextEditor | undefined = vscode.window.activeTextEditor
		let baseDir = getBaseDirectory()

		let filePath = ""
		if (activeTextEditor && baseDir) {
			filePath = activeTextEditor.document.uri.fsPath
			const splitFilePathArray = filePath.split(baseDir)
			if (splitFilePathArray.length > 0) {
				filePath = `${baseDir}${splitFilePathArray[1]}`
			}
		}
		return encodeURIComponent(filePath)
	} catch (e) {
		console.error(e)
	}
}
// 1.0 to 2.0 迁移
export function getActiveFileLang() {
	return vscode.window.activeTextEditor?.document.languageId || ""
}

export function getPlatFormOS() {
	try {
		const platform = os.platform()
		const release = os.release()

		if (platform === "win32") {
			if (release.startsWith("10.0.1")) {
				return "Windows 10"
			} else if (release.startsWith("6.1")) {
				return "Windows 7"
			} else if (release.startsWith("10.0.2")) {
				return "Windows 11"
			}
		}
		return platform // 返回其他平台
	} catch (e) {
		console.error(e)
	}
}

export function getCookie(cookie: string, key: string) {
	let match = cookie.match(new RegExp(`(^|;|\\s)${key}=([^;]+)`))
	if (!match) {
		return ""
	}
	return decodeURIComponent(match[2])
}

export function getToken(cookie: string) {
	return getCookie(cookie, "PORTALSSOCookie") || getCookie(cookie, "ZTEDPGSSOCookie")
}

export function getUserId(cookie: string) {
	return getCookie(cookie, "PORTALSSOUser") || getCookie(cookie, "ZTEDPGSSOUser") || getCookie(cookie, "UCSSSOAccount")
}

// 页面loaded时，外网验证登录态
export async function getExternalNetworkTokenWhenLoadedPage(userKey: string) {
	try {
		const response = await fetch(getExternalNetworkTokenUrl() + userKey, {
			method: "GET",
		})

		if (!response.ok) {
			throw new Error(`HTTP error! status: ${response.status}`)
		}

		const data: any = await response.json()
		const { bo } = data
		if (bo) {
			const { uacToken, userId } = bo
			if (uacToken) {
				return {
					loginStatus: 1,
					userInfo: {
						token: uacToken,
						userId,
					},
				}
			}
		} else {
			return {
				loginStatus: 2,
				userInfo: {},
			}
		}
	} catch (e: any) {
		console.error(e.message)
		return {
			loginStatus: 2,
			userInfo: {},
		}
	}
}

export function getExternalNetworkToken(userKey: string): Promise<{
	loginStatus: number
	userInfo?: { token: string; userId: string }
}> {
	// 定义轮询间隔（毫秒）
	const pollingInterval = 3000 // 5秒
	let pollingIntervalId: NodeJS.Timeout | null = null

	// 发起网络请求的函数
	async function makeRequest(): Promise<{
		loginStatus: number
		userInfo?: { token: string; userId: string }
	}> {
		try {
			const { data } = await axios({
				url: getExternalNetworkTokenUrl() + userKey,
			})

			const { bo } = data
			if (bo) {
				const { uacToken, userId } = bo
				if (uacToken) {
					clearInterval(pollingIntervalId!)
					return {
						loginStatus: 3,
						userInfo: {
							token: uacToken,
							userId,
						},
					}
				}
			}
		} catch (error) {
			console.error("Error occurred while fetching token:", error)
		}

		// 开始轮询
		return new Promise<{
			loginStatus: number
			userInfo?: { token: string; userId: string }
		}>((resolve, reject) => {
			pollingIntervalId = setInterval(async () => {
				try {
					const { data } = await axios({
						url: getExternalNetworkTokenUrl() + userKey,
					})
					//console.log("uac data---------", data)
					const { bo } = data
					if (bo) {
						const { uacToken, userId } = bo
						if (uacToken) {
							clearInterval(pollingIntervalId!)
							resolve({
								loginStatus: 3,
								userInfo: {
									token: uacToken,
									userId,
								},
							})
						}
					}
				} catch (error) {
					console.error("Error occurred while fetching token during polling:", error)
				}
			}, pollingInterval)
		})
	}

	// 第一次立即发起请求
	return makeRequest()
}

export const getMacAddress = () => {
	const networkInterfaces = os.networkInterfaces()
	for (const interfaceName of Object.keys(networkInterfaces)) {
		// 排除 loopback 和虚拟网络接口
		if (interfaceName !== "lo" && !networkInterfaces[interfaceName][0].internal) {
			// 返回第一个非内部接口的 MAC 地址
			return networkInterfaces[interfaceName][0].mac.toUpperCase()
		}
	}
	// 如果找不到合适的 MAC 地址，返回 null 或者其他适当的值
	return null
}

export const registUserInfo = (context: vscode.ExtensionContext) => {
	return {
		getUserInfo() {
			let formatUserInfo: UserInfoType = {
				token: "",
				userId: "",
				tenant: "",
			}
			try {
				formatUserInfo = JSON.parse((context.globalState.get(USER_INFO_KEY) as string) || "{}")
			} catch (e) {
				console.log(e)
			}
			return formatUserInfo
		},
		setUserInfo(userInfo: UserInfoType) {
			context.globalState.update(USER_INFO_KEY, JSON.stringify(userInfo))
		},
	}
}

export const constructRequestUrl = (urlPath: string) => {
	return `${API_URL}${urlPath}`
}

export const compareTime = (start: number, end: number) => {
	const differenceInMilliseconds = Math.abs(start - end)

	const differenceInHours = differenceInMilliseconds / (1000 * 60 * 60)
	return differenceInHours > 8
}

export const formatTime = (timestamp: number) => {
	const date = new Date(timestamp)
	const hours = String(date.getHours()).padStart(2, "0")
	const minutes = String(date.getMinutes()).padStart(2, "0")
	const seconds = String(date.getSeconds()).padStart(2, "0")
	return `${hours}:${minutes}:${seconds}`
}
