import { UserInfoType as LoginType } from "../types/index"
import { udsPwdFree } from "./uac"
import { EVENT_NAME, API_URL, USER_INFO_KEY } from "./constants"
import { Logger } from "./logger"
import { getExternalNetworkTokenWhenLoadedPage, getPlatFormOS, getToken, getUserId, getExternalNetworkToken } from "./index"
import * as vscode from "vscode"
import nls from "../nls/index"
import { eventManager } from "./eventEmitter"

export default class Authentication {
	private static udsTimer: number | undefined | NodeJS.Timeout

	static isExternalLogin: boolean = false
	static isLogout: boolean = false
	static networkType = "innerNetwork"
	static userInfo: LoginType | null = null
	static isStopUdsTimer = false
	static view: vscode.WebviewView
	private static _isAuthFailed: boolean = false

	static get isAuthFailed(): boolean {
		return this._isAuthFailed
	}

	static set isAuthFailed(value: boolean) {
		if (this._isAuthFailed !== value) {
			this._isAuthFailed = value
			Authentication.sendMessageToWebview("IS_UAC_AUTH_FAILED", {
				isAuthFailed: value,
				networkType: Authentication.networkType,
			})
		}
		if (value) {
			Authentication.vscodeContext.globalState.update(
				USER_INFO_KEY,
				JSON.stringify({
					token: "",
					userId: "",
					tenant: "",
				}),
			)
		}
	}

	static vscodeContext: vscode.ExtensionContext

	static initialize(context: vscode.ExtensionContext): void {
		Authentication.vscodeContext = context
	}

	static async login(option?: { token: string }): Promise<void> {
		if (Authentication.networkType === "externalNetwork" || Authentication.networkType === "testEnv") {
			Authentication.isExternalLogin = true
			const userKey = Authentication.vscodeContext.globalState.get("userKey") as any
			Authentication.isLogout = false
			// Handle external network login
			Authentication.uacLogin(userKey)
		} else {
			Authentication.isExternalLogin = false
			try {
				if (Authentication.udsTimer) {
					clearInterval(Authentication.udsTimer)
				}
				if (Authentication.isLogout) return
				await Authentication.udsLogin()
				Authentication.restartTimer()
			} catch (e) {
				Authentication.isAuthFailed = true
				clearInterval(Authentication.udsTimer)
				Logger("error", e, "UDS login failed, switching to UAC login")
				if (option?.token) {
					// Handle UAC login with token
					Authentication.sendMessageToWebview(EVENT_NAME.UAC_LOGIN, { token: option.token })
				} else {
					Authentication.sendMessageToWebview(EVENT_NAME.UAC_LOGIN)
				}
			}
		}
	}

	static async udsLogin() {
		try {
			const result = (await udsPwdFree()) as LoginType
			Authentication.saveAuthenticationInfo(result)
			Authentication.sendMessageToWebview(EVENT_NAME.UDS_USER_INFO, result)
			Authentication.isLogout = false
			Authentication.isAuthFailed = false
			return Promise.resolve()
		} catch (e) {
			Logger("error", e, "UDS login failed")
			return Promise.reject()
		}
	}

	static async uacLogin(userKey: string): Promise<void> {
		const userInfo = Authentication.vscodeContext.globalState.get(USER_INFO_KEY) as any
		const hasLogin = userInfo.userId && userInfo.token
		Authentication.sendMessageToWebview(EVENT_NAME.EXTERNAL_NETWORK_LOGIN_STATUS, {
			loginStatus: hasLogin ? 3 : 4,
			userInfo: hasLogin ? userInfo : {},
		})
	}

	static codeServerLogin(data: { cookie?: string; userId?: string; token?: string }): void {
		const { cookie, userId, token } = data
		const userInfo = {
			token: token || "",
			userId: userId || "",
			tenant: "",
		}
		if (cookie) {
			userInfo.token = getToken(cookie)
			userInfo.userId = getUserId(cookie)
		}
		Authentication.sendMessageToWebview(EVENT_NAME.UDS_USER_INFO, userInfo)
		Authentication.sendMessageToWebview(EVENT_NAME.USER_AGENT_INFO, {
			ideVersion: `vscode ${vscode.version}`,
			os: getPlatFormOS(),
		})
		Authentication.saveAuthenticationInfo(userInfo)
	}

	static async openExternalNetworkLoginPage(): Promise<void> {
		const userKey = this.vscodeContext.globalState.get("userKey") as any

		try {
			const response = await fetch(`${API_URL}/gpt/api/oauth2/redirectUrl?state=${userKey}`)
			if (!response.ok) {
				throw new Error(`HTTP error! status: ${response.status}`)
			}

			const res: any = await response.json()
			if (res.bo) {
				// Use vscode.env.openExternal to open URLs
				await vscode.env.openExternal(vscode.Uri.parse(`${res.bo}&state=${userKey}`))
			} else {
				vscode.window.showWarningMessage(nls.t("icode.extension.loginError"))
			}
		} catch (e) {
			vscode.window.showWarningMessage(nls.t("icode.extension.fetchLoginUrlError"))
			Authentication.sendMessageToWebview(EVENT_NAME.EXTERNAL_NETWORK_LOGIN_STATUS, {
				loginStatus: 4,
				userInfo: {},
			})
			return
		}

		try {
			const res = await getExternalNetworkToken(userKey)
			Logger("info", res, "external UAC userInfo")
			const { loginStatus, userInfo } = res as any
			Authentication.sendMessageToWebview(EVENT_NAME.EXTERNAL_NETWORK_LOGIN_STATUS, {
				loginStatus,
				userInfo,
			})
			Authentication.saveAuthenticationInfo({
				token: userInfo.token,
				userId: userInfo.userId,
			})
			Authentication.isAuthFailed = false
		} catch (e: any) {
			console.error(e.message)
		}
	}

	static restartTimer(): void {
		if (Authentication.udsTimer) {
			clearInterval(Authentication.udsTimer)
		}
		Authentication.udsTimer = setInterval(
			async () => {
				await Authentication.udsLogin()
			},
			1000 * 60 * 30,
		)
	}

	static stopTimer(): void {
		if (Authentication.udsTimer) {
			clearInterval(Authentication.udsTimer)
		}
	}

	static getAuthenticationInfo(): LoginType {
		const userInfoStr = Authentication.vscodeContext.globalState.get(USER_INFO_KEY) as string
		Authentication.userInfo = userInfoStr ? JSON.parse(userInfoStr) : {}
		return Authentication.userInfo as LoginType
	}

	static saveAuthenticationInfo(info: LoginType): void {
		Authentication.userInfo = info

		Authentication.vscodeContext.globalState.update(USER_INFO_KEY, JSON.stringify(info))

		Authentication.sendMessageToWebview("AUTH_INFO", {
			userId: info.userId || "",
			token: info.token || "",
		})

		// 如果之前没有登录且现在有 userId，通过事件管理器发出登录成功事件
		if (info.userId) {
			eventManager.emit("userLoginSuccess", {
				userId: info.userId,
				token: info.token || "",
			})
		}
	}

	private static sendMessageToWebview(eventName: string, data?: { [key: string]: any }): void {
		Authentication.view.webview.postMessage(
			JSON.stringify({
				type: eventName,
				data,
			}),
		)
	}
}
