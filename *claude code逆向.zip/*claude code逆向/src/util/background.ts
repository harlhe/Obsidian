import * as vscode from "vscode"
import * as fs from "fs"
import * as path from "path"
import { RELATIVE_FILE, techStackList } from "./techStackList"
import { LoggerManager } from "./logger"

export interface BackgroundInfo {
	userSetTechStack: string
	repository: string
	branch: string
	remoteUrl: string
	languageId: string
	matchTechStack: string
	relativePath: string
	absolutRepoName: string
}

export interface BackgroundConf {
	activeEditor: vscode.TextEditor
	techStack: string
}

export class Background {
	private static activeEditor: vscode.TextEditor
	private static techStack: string
	private static languageId: string
	private static activePath: string
	private static matchTechStack: string
	private static branch: string
	private static repository: string
	private static remoteUrl: string
	private static relativePath: string
	private static absolutRepoName: string

	/**
	 * 设置技术栈的背景信息
	 * @param conf 当前编辑器和用户设置技术栈
	 */
	public static async set(conf: BackgroundConf, loggerManager: LoggerManager) {
		const { activeEditor, techStack } = conf
		Background.activeEditor = activeEditor
		Background.techStack = techStack
		Background.languageId = Background.activeEditor.document.languageId
		await Background.extractGitRepositoryInfo(undefined, loggerManager)
		Background.extractTechStack()
	}

	/**
	 * 获取当前编辑器的背景信息
	 * @returns 返回当前编辑器的背景信息，包括仓库名、远端地址、语言、用户设置技术栈和匹配的技术栈
	 */
	public static get(): BackgroundInfo {
		return {
			repository: Background.repository || "",
			branch: Background.branch || "",
			remoteUrl: Background.remoteUrl || "",
			languageId: Background.languageId || "",
			userSetTechStack: Background.techStack || "",
			matchTechStack: Background.matchTechStack || "",
			relativePath: Background.relativePath || "",
			absolutRepoName: Background.absolutRepoName || "",
		}
	}

	public static async extractGitRepositoryInfo(filePath: string | undefined, loggerManager: LoggerManager) {
		const startTime = Date.now()
		try {
			loggerManager.log("info", filePath, "currentFilepath")
			Background.activePath = filePath ? filePath : Background.activeEditor.document.uri.fsPath

			const gitExtension = vscode.extensions.getExtension("vscode.git")?.exports
			if (!gitExtension) {
				loggerManager.log("error", "Git extension not available", "extractGitRepositoryInfo")
				return
			}

			const api = gitExtension.getAPI(1)
			const repositories = api.repositories

			let repository = repositories.find((repo: any) =>
				Background.activePath.startsWith(path.normalize(repo.rootUri.fsPath)),
			)

			if (!repository) {
				repository = this.handleRepositoryNotFound(repositories, loggerManager)
			}

			if (repository) {
				try {
					Background.branch = repository.state.HEAD?.name || ""
					Background.remoteUrl = repository.state.remotes.length > 0 ? repository.state.remotes[0].fetchUrl : ""
					Background.repository = this.extractRelativeRepoName(Background.remoteUrl, repository.rootUri.fsPath)
					Background.absolutRepoName = this.extractAbsolutRepoName(Background.remoteUrl)
					Background.relativePath = this.getRelativePath(Background.activePath, repository.rootUri.fsPath)
				} catch (e: unknown) {
					loggerManager.log("error", e as object, "extractGitRepositoryInfoDetailERROR")
					Background.clearRepoInfo()
				}
			} else {
				loggerManager.log("warn", "No repository found at path", "extractGitRepositoryInfo")
				Background.clearRepoInfo()
			}
		} catch (e: unknown) {
			loggerManager.log("error", e as object, "extractGitRepositoryInfoERROR")
			Background.clearRepoInfo()
		} finally {
			const endTime = Date.now()
			const duration = endTime - startTime
			loggerManager.log("info", `Method completed in ${duration}ms`, "extractGitRepositoryInfo")
		}
	}

	private static handleRepositoryNotFound(repositories: any[], loggerManager: LoggerManager): any {
		loggerManager.log("warn", `No repository found directly. Searching for Git root.`, "extractGitRepositoryInfo")

		const gitRootPath = this.findGitRoot(Background.activePath)
		loggerManager.log("info", `Found Git root at: ${gitRootPath}`, "findGitRoot")

		if (gitRootPath) {
			let repository = repositories.find((repo: any) => gitRootPath === path.normalize(repo.rootUri.fsPath))

			if (!repository) {
				loggerManager.log("warn", `Git root path (${gitRootPath}) not found in repositories.`, "extractGitRepositoryInfo")

				repository = {
					rootUri: { fsPath: gitRootPath },
					state: {
						HEAD: { name: this.getBranchNameFromGit(gitRootPath) },
						remotes: this.getRemotesFromGit(gitRootPath),
					},
				}
				loggerManager.log(
					"info",
					`Manually created repository object: ${JSON.stringify(repository)}`,
					"extractGitRepositoryInfo",
				)
			}
			return repository
		}
		return null
	}

	/**
	 * 从 .git 根目录获取当前分支名称
	 */
	private static getBranchNameFromGit(gitRootPath: string): string {
		const headFile = path.join(gitRootPath, ".git", "HEAD")
		if (fs.existsSync(headFile)) {
			const content = fs.readFileSync(headFile, "utf8").trim()
			if (content.startsWith("ref: ")) {
				return content.split("/").pop() || ""
			}
		}
		return ""
	}

	/**
	 * 从 .git 根目录获取远程仓库信息
	 */
	private static getRemotesFromGit(gitRootPath: string): Array<{ fetchUrl: string }> {
		const configFile = path.join(gitRootPath, ".git", "config")
		const remotes: Array<{ fetchUrl: string }> = []
		if (fs.existsSync(configFile)) {
			const content = fs.readFileSync(configFile, "utf8")
			const remoteMatch = content.match(/\[remote ".*?"\][^[]*url = (.+)/g)
			if (remoteMatch) {
				remoteMatch.forEach((line) => {
					const url = line.split("=")[1].trim()
					remotes.push({ fetchUrl: url })
				})
			}
		}
		return remotes
	}

	/**
	 * 递归向上查找 .git 目录
	 * @param currentPath 当前路径
	 * @returns Git 根目录路径（如果找到），否则返回 null
	 */
	private static findGitRoot(currentPath: string): string | null {
		let dir = path.resolve(currentPath)
		while (dir !== path.parse(dir).root) {
			if (fs.existsSync(path.join(dir, ".git"))) {
				return dir
			}
			dir = path.dirname(dir)
		}
		return null
	}

	private static clearRepoInfo() {
		Background.repository = ""
		Background.remoteUrl = ""
		Background.branch = ""
		Background.absolutRepoName = ""
		Background.relativePath = ""
	}

	private static getRelativePath(fullPath: string, repoName: string): string {
		if (!repoName) {
			return ""
		}
		const index = fullPath.indexOf(repoName)
		if (index === -1) return fullPath
		const relativePath = fullPath.substring(index + repoName.length + 1)

		return path.posix.normalize(relativePath.replace(/\\/g, "/"))
	}

	private static extractRelativeRepoName(remotePath: string, repoPath: string): string {
		const filepathSplitter = process.platform === "win32" ? "\\" : "/"
		const repoParts = remotePath.split("/")
		const fileParts = repoPath.split(filepathSplitter)

		let commonParts = []
		while (repoParts.length && fileParts.length && repoParts[repoParts.length - 1] === fileParts[fileParts.length - 1]) {
			commonParts.unshift(repoParts.pop()!)
			fileParts.pop()
		}

		return commonParts.join("/")
	}

	private static extractAbsolutRepoName(remotePath: string): string {
		if (remotePath.startsWith("ssh")) {
			const regex = /\/\/[^@]+@[^:]+:[^/]+\/(.+)/
			const match = remotePath.match(regex)
			if (match) {
				return match[1]
			}
			return ""
		} else if (remotePath.startsWith("http")) {
			const index = remotePath.indexOf("/a/")
			if (index !== -1) {
				const result = remotePath.substring(index + 3)
				return result ?? ""
			}
			return ""
		} else {
			return ""
		}
	}

	private static extractTechStack() {
		for (let techStack of techStackList) {
			if (techStack.label.indexOf(Background.languageId) > -1) {
				if (techStack.relativeFile === RELATIVE_FILE.PACKAGE_JSON) {
					Background.matchTechStack = Background.extractTechStackFromPackageJson(techStack.includes)
					if (Background.matchTechStack) {
						return
					}
				}
			}
		}
	}

	private static extractTechStackFromPackageJson(techStackList: string[]): string {
		const packageCont = Background.readTechStackRelativeFile(RELATIVE_FILE.PACKAGE_JSON)
		const packageObj = packageCont ? JSON.parse(packageCont) : undefined
		if (packageObj?.dependencies || packageObj?.devDependencies) {
			const dependenciesObj = {
				...(packageObj.dependencies || {}),
				...(packageObj.devDependencies || {}),
			}
			const matchTechStack: string[] = techStackList.filter((techStack) => {
				return Object.keys(dependenciesObj).some((dependency) => dependency.indexOf(techStack) > -1)
			})
			return matchTechStack.length ? matchTechStack.join(" | ") : ""
		}
		return ""
	}

	private static readTechStackRelativeFile(fileName: string): string {
		let currDir = path.dirname(Background.activePath || "/")
		while (currDir !== "/") {
			const relativeFilePath = path.join(currDir, fileName)
			try {
				const content = fs.readFileSync(relativeFilePath, "utf-8")
				return content
			} catch {
				currDir = path.dirname(currDir)
			}
		}
		return ""
	}
}
