import { Logger } from "./logger"
import { LogType } from "../types/index"
import { serializeError } from "serialize-error"

export function checkResult(key: string, result: any, level?: LogType) {
	level = level ?? "info"

	if (result instanceof Error) {
		result = serializeError(result)
	}
	if (Array.isArray(result) || (typeof result === "object" && result !== null)) {
		level = Object.keys(result).length === 0 ? "warn" : level
		Logger(level, result, key)
	} else {
		Logger(level, result, key)
	}
}

/* Started by AICoder, pid:8e6ff3ba4du3ef0141ae0bb140f6c63812b19fe8 */
export function checkResultDecorators(key: string, level?: LogType, hasReturnValue?: boolean) {
	return function (target: any, propertyKey: string, descriptor: PropertyDescriptor) {
		const originalMethod = descriptor.value

		descriptor.value = function (...args: any[]) {
			try {
				const result = hasReturnValue === false ? `${propertyKey}执行正常` : originalMethod.apply(this, args)
				if (result instanceof Promise) {
					result.then((element) => {
						checkResult(key, element, level)
					})
				} else {
					checkResult(key, result, level)
				}
				return result
			} catch (error) {
				Logger("error", <string | object | undefined>error, key)
				throw error
			}
		}
		return descriptor
	}
}
/* Ended by AICoder, pid:8e6ff3ba4du3ef0141ae0bb140f6c63812b19fe8 */
