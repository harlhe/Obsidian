import crypto from "crypto"

export function calculateSHA256(input: string): string {
	// 创建 SHA-256 哈希算法实例
	const sha256 = crypto.createHash("sha256")

	// 更新哈希算法,传入要哈希的数据
	sha256.update(input)

	// 完成哈希计算并获取结果
	return sha256.digest("hex")
}
