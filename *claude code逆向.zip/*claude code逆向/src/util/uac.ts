import nls from "../nls"
import axios from "axios"
import promisePoller from "promise-poller"

async function getUdsToken(port: number) {
	return new Promise((resolve, reject) => {
		axios
			.get("https://127.0.0.1:" + port + "/requestToken?callback=vscodegptdata", {
				headers: {
					Host: "127.0.0.1:" + port,
					Referer: "https://uac.zte.com.cn/",
				},
				proxy: false,
			})
			.then((response) => {
				const body = response.data
				if (body && typeof body === "string" && body.length > 2) {
					const result = JSON.parse(body.substring(14, body.length - 1))
					resolve(result)
				} else {
					reject(new Error("Invalid response body"))
				}
			})
			.catch((error) => {
				reject(error)
			})
	})
}

async function tryGetUdsToken(ports: number[], retries = 3) {
	for (let i = 0; i < ports.length * retries; i++) {
		const port = ports[i % ports.length]
		try {
			const data = await getUdsToken(port)
			return data
		} catch (err) {
			console.log(err)
		}
	}
	console.log(nls.t("icode.extension.fetchUdsTokenError"))
	throw new Error(nls.t("icode.extension.fetchUdsTokenError"))
}

export function udsPwdFree() {
	// eslint-disable-next-line no-async-promise-executor
	return new Promise(async function (resolve, reject) {
		try {
			const result: any = await tryGetUdsToken([19996, 5865, 29273])
			const userId = result?.ZTEDPGSSOUser || result?.PORTALSSOUser
			const token = result?.ZTEDPGSSOCookie || result?.PORTALSSOCookie
			// const userInfo = await queryUserInfo(userId, token, result?.udsVersion);
			resolve({ token, userId })
		} catch (error) {
			console.log(error)
			reject(error)
		}
	})
}

function run(_dataStr: string) {
	return new Promise((resolve, reject) => {
		fetch("https://uac.zte.com.cn/uacqr/auth/qrcode/verify.serv", {
			method: "POST",
			body: _dataStr,
		}).then(async (res: any) => {
			const response = await res.text()
			let formatResponse
			try {
				formatResponse = JSON.parse(response)
			} catch (e) {
				console.info(e)
			}
			if (
				formatResponse &&
				formatResponse.code &&
				formatResponse.code.code === "0000" &&
				formatResponse.bo.code === "0000"
			) {
				resolve({ userId: formatResponse.other.account, token: formatResponse.other.token })
			} else if (
				formatResponse &&
				formatResponse.code &&
				formatResponse.code.code === "0000" &&
				formatResponse.bo.code !== "4002"
			) {
				reject(formatResponse)
			} else {
				reject(formatResponse)
			}
		})
	})
}

export async function pollUac(dataStr: string) {
	try {
		const result = await promisePoller({
			taskFn: () => run(dataStr),
			interval: 800,
			retries: 300,
			masterTimeout: 120000, // 2min stop polling
		})
		console.log(result)
		return result
	} catch (error) {
		return { error }
	}
}
