import { getPlatFormOS } from "../util/index"
import { getPackageVersion } from "../util/getPackageVersion"
import * as vscode from "vscode"

export class MetricProvider {
	private static instance: MetricProvider

	private userId: string
	private completionType: string
	private token: string
	private actionType: string
	private model: string
	private originDocId: string
	private bizApp?: "icode" | undefined
	private username: string
	private content: string
	private contentLength: number
	private chatUuid: string
	private acceptType?: string
	private extendProps: {
		"X-Plugin-UserAgent": string
		"X-Plugin-Version"?: string | undefined
		"X-Plugin-Platform"?: string | undefined
		"X-Plugin-Repo"?: string | undefined
		"X-Plugin-Branch"?: string | undefined
		"X-Plugin-FilePath"?: string | undefined
		"X-Plugin-ContentType"?: string
		"icode-ai-plugin-completion-prompt"?: string | undefined
		"icode-ai-plugin-completion-toggle"?: number
		"X-Tenant-Code"?: string
		"X-Plugin-Delay"?: number
	}

	constructor() {
		this.userId = ""
		this.token = ""
		this.model = ""
		this.actionType = ""
		this.originDocId = ""
		this.username = ""
		this.content = ""
		this.contentLength = 0
		this.chatUuid = ""
		this.acceptType = ""
		this.completionType = "InlineCompletion"
		this.extendProps = {
			"X-Plugin-UserAgent": `vscode ${vscode.version}`,
			"X-Plugin-Version": `v${getPackageVersion()}`,
			"X-Plugin-Platform": getPlatFormOS(),
			"X-Plugin-Repo": "",
			"X-Plugin-Branch": "",
			"X-Plugin-FilePath": "",
			"X-Plugin-ContentType": "",
			"icode-ai-plugin-completion-prompt": "",
			"icode-ai-plugin-completion-toggle": 0,
			"X-Plugin-Delay": 0,
			"X-Tenant-Code": "",
		}
		this.bizApp = "icode"
	}

	public static getInstance(): MetricProvider {
		if (!MetricProvider.instance) {
			MetricProvider.instance = new MetricProvider()
		}
		return MetricProvider.instance
	}

	public setUserInfo(userId: string, token: string, tenant: string) {
		this.userId = userId
		this.token = token
		this.username = userId
		this.extendProps["X-Tenant-Code"] = tenant
		return this
	}

	public setRepoInfo(remoteFilePath: string, repo: string, branch: string) {
		this.extendProps["X-Plugin-FilePath"] = encodeURIComponent(remoteFilePath)
		this.extendProps["X-Plugin-Repo"] = repo
		this.extendProps["X-Plugin-Branch"] = branch
	}

	public setMetricParams({
		actionType,
		docId,
		content,
		chatUuid,
		prompt,
		accType,
		contentType,
		toggle,
		delay,
	}: {
		actionType: string
		docId: string
		content: string
		chatUuid: string
		prompt: string
		accType: string
		contentType: string
		toggle?: number
		delay?: number
	}) {
		this.actionType = actionType
		this.originDocId = docId
		this.content = content
		this.chatUuid = chatUuid
		this.extendProps["X-Plugin-ContentType"] = contentType
		this.contentLength = content.split("\n").length
		this.extendProps["icode-ai-plugin-completion-prompt"] = prompt
		this.acceptType = accType
		this.completionType = prompt ? JSON.parse(prompt).completionType : ""
		toggle && (this.extendProps["icode-ai-plugin-completion-toggle"] = toggle)
		delay && (this.extendProps["X-Plugin-Delay"] = delay)
		return this.getAll()
	}

	public getAll() {
		return {
			userId: this.userId,
			token: this.token,
			model: this.model,
			actionType: this.actionType,
			originDocId: this.originDocId,
			username: this.username,
			content: this.content,
			contentLength: this.contentLength,
			bizApp: this.bizApp,
			chatUuid: this.chatUuid,
			acceptType: this.acceptType,
			completionType: this.completionType,
			extendProps: {
				"X-Plugin-UserAgent": this.extendProps?.["X-Plugin-UserAgent"],
				"X-Plugin-Version": this.extendProps?.["X-Plugin-Version"],
				"X-Plugin-Platform": this.extendProps?.["X-Plugin-Platform"],
				"X-Plugin-Repo": this.extendProps?.["X-Plugin-Repo"],
				"X-Plugin-Branch": this.extendProps?.["X-Plugin-Branch"],
				"X-Plugin-FilePath": this.extendProps?.["X-Plugin-FilePath"],
				"X-Plugin-ContentType": this.extendProps?.["X-Plugin-ContentType"],
				"icode-ai-plugin-completion-prompt": this.extendProps?.["icode-ai-plugin-completion-prompt"],
				"icode-ai-plugin-completion-toggle": this.extendProps?.["icode-ai-plugin-completion-toggle"],
				"X-Tenant-Code": this.extendProps?.["X-Tenant-Code"],
				"X-Plugin-Delay": this.extendProps?.["X-Plugin-Delay"],
			},
		}
	}
}
