import path from "path"
import * as fs from "fs"
import * as log4js from "log4js"
import { LogType } from "../types/index"
import { serializeError } from "serialize-error"
import * as os from "os"

const getLogsDir = () => {
	const homeDir = os.homedir()
	const pluginName = ".icodemate"

	return path.join(homeDir, pluginName, "logs")
}

const logsDir = getLogsDir()

if (!fs.existsSync(logsDir)) {
	fs.mkdirSync(logsDir, { recursive: true })
}

const appenders: { [name: string]: { type: string; [key: string]: any } } = {
	app: {
		type: "file",
		filename: path.join(logsDir, "info.log"),
		maxLogSize: "100M",
		backups: 3,
		compress: true,
	},
}

log4js.configure({
	appenders: appenders,
	categories: {
		default: { appenders: ["app"], level: "trace" },
	},
})
const logger = log4js.getLogger()

export class LoggerManager {
	private traceId: string = ""

	public setTraceId(traceId: string) {
		this.traceId = traceId
	}

	public clearTraceId() {
		this.traceId = ""
	}

	public log(type: LogType, message: string | object | number | undefined, key?: string) {
		if (message instanceof Error) {
			message = serializeError(message)
		} else if (typeof message === "number") {
			message = message.toString()
		}

		let logMessageSegment = ""

		if (message instanceof Map) {
			try {
				const mapObject = Object.fromEntries(message)
				logMessageSegment = JSON.stringify(mapObject)
			} catch (e) {
				logMessageSegment = `[Map conversion error: ${(e as Error).message}`
			}
		} else if (typeof message === "object" && message !== null) {
			try {
				logMessageSegment = JSON.stringify(message)
			} catch (e) {
				logMessageSegment = `[Object could not be stringified: ${(e as Error).message}]`
			}
		} else {
			logMessageSegment = `${message}`
		}
		let finalLogMessage = `-${key ? key + " " : ""}`
		finalLogMessage += logMessageSegment
		if (this.traceId) {
			finalLogMessage += ` -traceId: ${this.traceId}`
		}

		logger[type](finalLogMessage.trim())
	}
}
const LogInstance = new LoggerManager()
export const Logger = LogInstance.log.bind(LogInstance)
