import { Logger } from "./logger"

function formatBytes(bytes: number, decimals = 2) {
	if (bytes === 0) return "0 Bytes"
	const k = 1024
	const dm = decimals < 0 ? 0 : decimals
	const sizes = ["Bytes", "KB", "MB", "GB", "TB"]
	const i = Math.floor(Math.log(bytes) / Math.log(k))
	return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i]
}

export function getFormattedMemoryUsage(name: string) {
	const memoryUsage = process.memoryUsage()
	const loggerName = `${name} Memory Usage`
	Logger(
		"info",
		`${loggerName}:
    - RSS: ${formatBytes(memoryUsage.rss)}
    - Heap Total: ${formatBytes(memoryUsage.heapTotal)}
    - Heap Used: ${formatBytes(memoryUsage.heapUsed)}
    - External: ${formatBytes(memoryUsage.external)}`,
	)
}
