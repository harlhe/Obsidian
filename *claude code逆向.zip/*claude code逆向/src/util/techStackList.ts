export enum RELATIVE_FILE {
	PACKAGE_JSON = "package.json",
}

export interface TechStackInfo {
	label: string
	relativeFile: string
	includes: string[]
}

const vue: TechStackInfo = {
	label: "vue",
	relativeFile: RELATIVE_FILE.PACKAGE_JSON,
	includes: ["vue"],
}

const javascript: TechStackInfo = {
	label: "typescript | javascript | ts | js | tsx | jsx",
	relativeFile: RELATIVE_FILE.PACKAGE_JSON,
	includes: ["express", "koa", "nestjs", "vue", "react", "angular", "svelte", "vscode"],
}

export const techStackList: TechStackInfo[] = [javascript, vue]
