import * as vscode from "vscode"
import { checkResult } from "./decorators"

/**
 * 判断快捷键是否被占用
 * @param keybinding 快捷键值
 * @returns boolean 是否被占用
 */
function isKeybindingTaken(keybinding: string): boolean {
	const keybindings = vscode.workspace.getConfiguration("keybindings").get<string[]>("keybindings")

	if (keybindings) {
		return keybindings.some((binding) => binding.toLowerCase() === keybinding.toLowerCase())
	}

	return false
}

/**
 * 定义快捷键命令
 * @param keybinding 快捷键值
 * @param callFn 使用快捷键的回调
 */
export function defineKeybindingCommand(keybinding: string, callFn: (_: string) => any): void {
	if (isKeybindingTaken(keybinding)) {
		vscode.window.showErrorMessage(`快捷键 ${keybinding} 已经被占用，清先移除该快捷键设置`)
		return
	}
	try {
		callFn(keybinding)
	} catch (error) {
		// 报错时记录到日志
		checkResult(`keybindingCommand-${keybinding}`, error, "error")
	}
}
