export class LRFUCache<keyType, valueType> {
	private capacity: number
	private cache: Map<keyType, valueType>
	private frequency: Map<keyType, number> //频率次数
	private recency: Map<keyType, number> //新旧程度
	private timestamp: number //时长统计

	//默认设置容量为5
	constructor(capacity: number = 5) {
		this.capacity = capacity
		this.cache = new Map<keyType, valueType>()
		this.frequency = new Map<keyType, number>()
		this.recency = new Map<keyType, number>()
		this.timestamp = 0
	}

	private getRecencyWeight(key: keyType): number {
		return this.recency.get(key) ?? 0
	}

	private getFrequencyWeight(key: keyType): number {
		return this.frequency.get(key) ?? 0
	}

	private calculateLRFUScore(key: keyType): number {
		const recencyWeight = this.getRecencyWeight(key)
		const frequencyWeight = this.getFrequencyWeight(key)
		const lambda = 0.5 // 调整参数来平衡 LRU 和 LFU 的权重
		return lambda * recencyWeight + (1 - lambda) * frequencyWeight
	}

	private evict(): void {
		let lrfuKey: keyType | null = null
		let minScore = Infinity

		for (const key of this.cache.keys()) {
			const score = this.calculateLRFUScore(key)
			if (score < minScore) {
				minScore = score
				lrfuKey = key
			}
		}

		if (lrfuKey !== null) {
			this.cache.delete(lrfuKey)
			this.frequency.delete(lrfuKey)
			this.recency.delete(lrfuKey)
		}
	}

	public get(key: keyType): valueType | undefined {
		if (!this.cache.has(key)) {
			return undefined
		}

		this.timestamp++
		this.recency.set(key, this.timestamp)
		this.frequency.set(key, (this.frequency.get(key) ?? 0) + 1)

		return this.cache.get(key)
	}

	public set(key: keyType, value: valueType): void {
		if (this.cache.has(key)) {
			this.cache.set(key, value)
			this.get(key) // 更新 recency 和 frequency
			return
		}

		if (this.cache.size >= this.capacity) {
			this.evict()
		}

		this.cache.set(key, value)
		this.timestamp++
		this.recency.set(key, this.timestamp)
		this.frequency.set(key, 1)
	}

	public has(key: keyType): boolean {
		return this.cache.has(key)
	}

	public keys(): IterableIterator<keyType> {
		return this.cache.keys()
	}

	public delete(key: keyType): boolean {
		if (!this.cache.has(key)) {
			return false
		}
		this.cache.delete(key)
		this.frequency.delete(key)
		this.recency.delete(key)
		return true
	}

	public entries(): IterableIterator<[keyType, valueType]> {
		return this.cache.entries()
	}
}
