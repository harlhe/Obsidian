import * as vscode from "vscode"

export class OpenFilesTracker {
	private openFiles: Map<string, { fullPath: string; name: string; language: string; content: string }> = new Map()
	public static fileInfo: { [k: string]: { fullPath: string; name: string; language: string; content: string } } = {}

	constructor() {
		// this.initializeListeners();
		this.loadOpenFiles()
	}

	public async loadOpenFiles() {
		this.openFiles.clear()
		const openTabs = vscode.window.tabGroups.all.flatMap((group) => group.tabs)
		for (const tab of openTabs) {
			if (tab.input instanceof vscode.TabInputText) {
				const filePath = tab.input.uri.fsPath
				// 过滤掉 .git 文件和未命名的文件
				if (!filePath.endsWith(".git")) {
					try {
						const document = await vscode.workspace.openTextDocument(tab.input.uri)
						if (!document.isUntitled) {
							this.updateOpenFiles(document)
						}
					} catch (error) {
						console.log(error)
					}
				}
			}
		}

		this.getFileInfo()
	}

	private initializeListeners() {
		vscode.workspace.onDidOpenTextDocument(this.updateOpenFiles.bind(this))
		vscode.workspace.onDidCloseTextDocument(this.removeClosedFile.bind(this))
		vscode.workspace.onDidChangeTextDocument((event: vscode.TextDocumentChangeEvent) => {
			this.updateFileName(event.document)
		})
	}

	private async updateOpenFiles(document: vscode.TextDocument) {
		const { uri, languageId } = document
		const content = document.getText()
		const fileName = uri.fsPath.split(/[/\\]/).pop() || ""
		this.openFiles.set(uri.fsPath, {
			fullPath: uri.fsPath,
			name: fileName,
			language: languageId,
			content: content,
		})
	}

	private getFileInfo() {
		OpenFilesTracker.fileInfo = Object.fromEntries(Array.from(this.openFiles))
	}

	private removeClosedFile(document: vscode.TextDocument) {
		this.openFiles.delete(document.uri.fsPath)
		this.getFileInfo()
	}

	private updateFileName(document: vscode.TextDocument) {
		const { uri } = document
		if (this.openFiles.has(uri.fsPath)) {
			this.openFiles.get(uri.fsPath)!.name = uri.fsPath.split("/").pop() || ""
			this.openFiles.get(uri.fsPath)!.content = document.getText() // 更新文件内容
		}
		this.getFileInfo()
	}

	public getOpenFiles() {
		return Array.from(this.openFiles.values())
	}
}
