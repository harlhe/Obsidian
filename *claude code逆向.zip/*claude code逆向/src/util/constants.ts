export const HELP_DOC =
	"https://i.zte.com.cn/#/space/7da9c62f6d5d4e8483b9382729b0479f/wiki/page/cd17bc55f2c84c5c90557ed4b52bec22/view"

export const EVENT_NAME = {
	UAC_LOGIN: "UAC_LOGIN",
	AUTH_FAILED_STATUS: "AUTH_FAILED_STATUS",
	UDS_USER_INFO: "UDS_USER_INFO",
	OPTIMIZE: "OPTIMIZE",
	EXPLAIN: "EXPLAIN",
	FINDBUG: "FIND_BUG",
	GENERATE_BY_COMMENT: "GENERATE_BY_COMMENT",
	SEND_THEME: "SEND_THEME", // 发送当前主题
	USER_AGENT_INFO: "USER_AGENT_INFO",
	TRACKING_INFO_RESPONSE: "TRACKING_INFO_RESPONSE", // 发送埋点信息
	GENUT: "GENUT",
	COMPLETION: "COMPLETION",
	EXTERNAL_NETWORK_LOGIN_STATUS: "EXTERNAL_NETWORK_LOGIN_STATUS",
	ANALYZE: "ANALYZE",
	EXTERNAL_NETWORK_SEND_KEY: "EXTERNAL_NETWORK_SEND_KEY",
	CHAT: "CHAT",
	LANG: "LANG",
	VSCODE_CONFIG: "VSCODE_CONFIG",
	SELECTION_CHANGE: "SELECTION_CHANGE",
	OPEN_FILES_INFO: "OPEN_FILES_INFO",
	SELECT_FILE_CONTENT: "SELECT_FILE_CONTENT",
	CHECK_FILE_EXIST: "CHECK_FILE_EXIST",
	OPEN_EXTENISON: "OPEN_EXTENISON",
	OPEN_PROMPT: "OPEN_PROMPT",
	DO_LOGOUT: "DO_LOGOUT",
}

export const urlPath = {
	metric: "/gpt/api/v3/code/complete/accept",
	competion: "/gpt/api/v3/code/complete",
	trace: "/gpt/api/v1/trace/reportTrace",
	interception: "/gpt/api/v3/code/complete/markValid",
	preemptive: "/gpt/api/v1/metric",
	feedback: "/gpt/api/v1/feedback/temp-ticket",
}

export const USER_INFO_KEY = "ai_assistant_userinfo"

// 流式响应的标志
export const STREAM_DATA_SIGNAL = "data: "

// 流式响应的结束标志
export const DONE_SIGNAL = `${STREAM_DATA_SIGNAL}[DONE]`

export const event = {
	CHAT_RESPONSE: "CHAT_RESPONSE",
}

//用户指南链接
export const Guidance_Url =
	"https://i.zte.com.cn/#/shared/c8c49951846348f88e08b3638a7c008f/wiki/page/4cad92b914a9487eb1fe6c244b36ed23/view"

// 生产环境
export const API_URL = "https://gerritdb.zte.com.cn"
export const WEB_URL = "https://gerritdb.zte.com.cn/chat282"
export const AGENT_REPORT_URL = "https://gerritdb.zte.com.cn/gpt_shengchenglv/report"
export const INDEX_API_URL = "https://gerritdb.zte.com.cn/codebase"

// 测试环境
// export const API_URL = "https://aicode.test.zte.com.cn"
// export const WEB_URL = "https://aicode.test.zte.com.cn/chat"
// export const AGENT_REPORT_URL = "http://10.57.183.137:5000/report"
// export const INDEX_API_URL = "https://aicode.test.zte.com.cn/codebase"
