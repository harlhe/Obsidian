const fs = require("fs")
const path = require("path")

function getPackageData() {
	const packageJsonPath = path.join(__dirname, "..", "package.json")
	const data = fs.readFileSync(packageJsonPath, "utf8")
	const packageJson = JSON.parse(data)
	return packageJson
}

function getPackageVersion(): string | null {
	try {
		const packageJson = getPackageData()
		return packageJson.version
	} catch (err) {
		console.error("Error:", err)
		return null
	}
}

export { getPackageData, getPackageVersion }
