import { readFileSync, existsSync } from "fs"
import { GetParserResult, getParser } from "../completion/util/tree-sitter-util"
import { SyntaxTreeAnalysisC } from "../completion/SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisC"
import { SyntaxTreeAnalysisCpp } from "../completion/SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisCpp"
import { SyntaxTreeAnalysisJavaScript } from "../completion/SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisJavaScript"
import { SyntaxTreeAnalysis } from "../completion/SyntaxTreeAnalysis/SyntaxTreeAnalysis"
import { ClassInfo, EnumInfo, FileCommonData, FunctionInfo, StructInfo } from "../completion/types"
import { Tree } from "web-tree-sitter"
import { LRFUCache } from "./lrfucache"
import path from "path"
import { checkResult } from "./decorators"
import { LOG_KEYS, WASM_LANGAUAGES } from "../completion/util/consants"
import { InlineCompletionInfo } from "../completion/SyntaxTreeAnalysis/InlineCompletionInfo"
import { SyntaxTreeAnalysisJava } from "../completion/SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisJava"
import { SyntaxTreeAnalysisScala } from "../completion/SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisScala"
import { TextDocument } from "vscode"
import { FileCommonInfo } from "../completion/common/file-common-info"

export interface ParserTreesInfo {
	uriList: { fsPath: string; absoluteFile: string }[]
	fileDataCache: LRFUCache<string, FileData>
}

export interface FileData {
	version: number
	languageId: string
	fileFunc: Array<FunctionInfo>
	fileEnum: Array<EnumInfo>
	fileStruct: Array<StructInfo>
	fileClass: Array<ClassInfo>
}

export interface FileInfo {
	fileFunc: Array<FunctionInfo>
	fileEnum: Array<EnumInfo>
	fileStruct: Array<StructInfo>
	fileClass: Array<ClassInfo>
}

export class ParserTrees {
	private static uriList: { fsPath: string; absoluteFile: string }[] = []
	private static fileDataCache: LRFUCache<string, FileData> = new LRFUCache<string, FileData>(5)
	/**
	 *
	 * @param uriPath 地址
	 */
	public static async set(uriPath: { fsPath: string; absoluteFile: string }[]) {
		let uriRealList = uriPath.filter((uri) => {
			return existsSync(uri.fsPath)
		})
		let isSameUri: boolean =
			ParserTrees.uriList.length === uriRealList.length &&
			ParserTrees.uriList.every((value, index) => value.fsPath === uriRealList[index].fsPath)
		if (!isSameUri) {
			ParserTrees.uriList = uriRealList
			await ParserTrees.addFilePath(uriRealList)
			ParserTrees.deleteUselessPath(uriRealList)
		}
	}

	/**
	 *
	 * @param uriPath 地址
	 */
	public static async updateSingleFile(document: TextDocument) {
		const fileData = ParserTrees.fileDataCache.get(document.uri.fsPath)
		if (fileData && fileData.version === document.version) return
		await ParserTrees.addHandler(document.uri.fsPath, document.version, document.uri.path)
	}

	/**
	 * 获取当前编辑器的文件解析内容
	 * @returns 返回树的解析结果
	 */
	public static get(): ParserTreesInfo {
		return {
			uriList: ParserTrees.uriList || [],
			fileDataCache: ParserTrees.fileDataCache || undefined,
		}
	}

	/**
	 * 增加文件信息
	 * @param uriPath 地址
	 */
	public static async addFilePath(uriPath: { fsPath: string; absoluteFile: string }[]) {
		// 增加 Map 中不在文件路径数组中的元素
		for (let { fsPath, absoluteFile } of uriPath) {
			if (!ParserTrees.fileDataCache.has(fsPath)) {
				await ParserTrees.addHandler(fsPath, 1, absoluteFile)
			}
		}
	}

	/**
	 * 增加文件信息
	 * @param uriPath 地址
	 */
	public static async addHandler(fsPath: string, version: number, absoluteFile: string) {
		let fileContent = readFileSync(fsPath, "utf8") ?? ""
		const fileExtension = path.extname(fsPath).slice(1)
		const languageId = WASM_LANGAUAGES[fileExtension]
		const fileCommonInfo = new FileCommonInfo()
		fileCommonInfo.setFileBaseInfo(fsPath, fileContent, fileContent.split("\n").length, languageId, version, absoluteFile)
		const fileInfo: FileCommonData | undefined = await fileCommonInfo.fileActiveDo()
		if (!fileInfo) return
		ParserTrees.fileDataCache.set(fsPath, {
			version: version,
			languageId: languageId,
			fileFunc: fileInfo.codeInfo?.functionList || [],
			fileEnum: fileInfo.codeInfo?.enumList || [],
			fileClass: fileInfo.codeInfo?.classList || [],
			fileStruct: fileInfo.codeInfo?.customTypeList || [],
		})
	}

	/**
	 * 删除文件信息
	 * @param uriPath 地址
	 */
	public static deleteUselessPath(uriPath: { fsPath: string; absoluteFile: string }[]) {
		// 删除 Map 中不在文件路径数组中的元素
		for (let { fsPath } of uriPath) {
			if (!ParserTrees.fileDataCache.has(fsPath)) {
				ParserTrees.fileDataCache.delete(fsPath)
			}
		}
	}

	/**
	 * 解析器获取
	 * @param uriList 文件路径列表
	 */
	private static async setParserTrees(uriPath: string) {
		let tree: GetParserResult | null
		let isPath: boolean = true
		tree = await getParser(uriPath, isPath)
		return tree
	}

	/**
	 * 设置文件函数列表
	 * @param fileTree 文件解析树
	 * @param fileContent 文件内容
	 */
	private static async setFileFunc(fsPath: string, fileTree: GetParserResult, fileContent: string): Promise<FileInfo> {
		let syntaxTreeListAnalysis: SyntaxTreeAnalysis | null = null
		let fileInfo: FileInfo = {
			fileFunc: [],
			fileEnum: [],
			fileClass: [],
			fileStruct: [],
		}
		let tree: Tree
		let initError: boolean = false
		try {
			tree = fileTree.parser.parse(fileContent)
			InlineCompletionInfo.initFailedCount.set(fileTree.languageId, 0)
		} catch (err) {
			initError = true
			checkResult(LOG_KEYS.SyntaxTreeInit, err, "error")
			InlineCompletionInfo.initFailedCount.set(
				fileTree.languageId,
				InlineCompletionInfo.initFailedCount.get(fileTree.languageId)! + 1,
			)
		}
		if (!initError) {
			switch (fileTree.languageId) {
				case "c":
					syntaxTreeListAnalysis = new SyntaxTreeAnalysisC(tree!, fileTree.parser)
					break
				case "cpp":
					syntaxTreeListAnalysis = new SyntaxTreeAnalysisCpp(tree!, fileTree.parser)
					break
				case "java":
					syntaxTreeListAnalysis = new SyntaxTreeAnalysisJava(tree!, fileTree.parser)
					break
				case "javascript":
					syntaxTreeListAnalysis = new SyntaxTreeAnalysisJavaScript(tree!, fileTree.parser)
					break
				case "scala":
					syntaxTreeListAnalysis = new SyntaxTreeAnalysisScala(tree!, fileTree.parser)
					break
			}
			if (syntaxTreeListAnalysis !== null) {
				await syntaxTreeListAnalysis.setFileType(fsPath)
				fileInfo.fileFunc.push(...syntaxTreeListAnalysis.getFunctionList())
				fileInfo.fileEnum.push(...syntaxTreeListAnalysis.getEnumList())
				fileInfo.fileClass.push(...syntaxTreeListAnalysis.getClassList())
				fileInfo.fileStruct.push(...syntaxTreeListAnalysis.getCustomTypeList())
			}
		}
		return fileInfo
	}
}
