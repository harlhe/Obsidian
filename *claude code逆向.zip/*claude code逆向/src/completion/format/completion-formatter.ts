import { Position, Range, TextEditor } from "vscode"

import { CLOSING_BRACKETS, LINE_BREAK_REGEX, OPENING_BRACKETS, QUOTES } from "../util/consants"
import { Bracket, CompletionType } from "../types/index"
import * as os from "os"

export class CompletionFormatter {
	private _characterAfterCursor: string
	private _charAfterCursor: string
	private _charBeforeCursor: string
	private _completion = ""
	private _cursorPosition: Position
	private _editor: TextEditor
	private _lineText: string
	private _normalisedCompletion = ""
	private _originalCompletion = ""
	private _textAfterCursor: string
	private _textBeforeCursor: string
	private _completionType: CompletionType | undefined = "InlineCompletion"
	public handleType: "removeDuplicateLine" | "" = ""
	private _specialChars = ["=", '"', "'", "*", "/", "\\", "+", "-", "<", ">", "|", "&"]
	private _prefixText: string = ""

	constructor(editor: TextEditor, completionType: CompletionType | undefined, prefixText: string = "") {
		this._editor = editor
		this._cursorPosition = this._editor.selection.active
		const document = editor.document
		const lineEndPosition = document.lineAt(this._cursorPosition.line).range.end
		const lineStartPosition = new Position(this._cursorPosition.line, 0)
		const textBeforeRange = new Range(lineStartPosition, this._cursorPosition)
		const textAfterRange = new Range(this._cursorPosition, lineEndPosition)
		this._lineText = this._editor.document.lineAt(this._cursorPosition.line).text
		this._textBeforeCursor = document && textBeforeRange ? document.getText(textBeforeRange) : ""
		this._textAfterCursor = document && textAfterRange ? document.getText(textAfterRange) : ""
		this._characterAfterCursor = this._textAfterCursor ? (this._textAfterCursor.at(0) as string) : ""
		this._editor = editor
		this._charBeforeCursor = this._cursorPosition.character > 0 ? this._lineText[this._cursorPosition.character - 1] : ""
		this._charAfterCursor = this._lineText[this._cursorPosition.character]
		this._completionType = completionType
		this._prefixText = prefixText
	}

	private isMatchingPair = (open?: Bracket, close?: string): boolean => {
		return (open === "[" && close === "]") || (open === "(" && close === ")") || (open === "{" && close === "}")
	}

	private matchCompletionBrackets = (): CompletionFormatter => {
		let accumulatedCompletion = ""
		const openBrackets: Bracket[] = []
		for (const character of this._originalCompletion) {
			if (OPENING_BRACKETS.includes(character)) {
				openBrackets.push(character)
			}

			if (CLOSING_BRACKETS.includes(character)) {
				if (openBrackets.length && this.isMatchingPair(openBrackets.at(-1), character)) {
					openBrackets.pop()
				} else {
					break
				}
			}
			accumulatedCompletion += character
		}

		this._completion = accumulatedCompletion.trimEnd() || this._originalCompletion.trimEnd()

		return this
	}

	private ignoreBlankLines = (): CompletionFormatter => {
		if (this._completion.trim() === "") {
			this._completion = ""
		}
		return this
	}

	private normalise = (text: string) => text?.trim()

	private removeDuplicateText() {
		const after = this.normalise(this._textAfterCursor)
		const before = this.normalise(this._textBeforeCursor)

		const maxLengthAfter = Math.min(this._completion.length, after.length)
		const maxLengthBefore = Math.min(this._completion.length, before.length)

		const overlapLengthAfter = this.calculateOverlapLength(this._completion, after, maxLengthAfter, true)
		const overlapLengthBefore = this.calculateOverlapLength(this._completion, before, maxLengthBefore, false)

		if (overlapLengthAfter > 0) {
			this._completion = this._completion.slice(0, -overlapLengthAfter)
		}

		if (overlapLengthBefore > 0) {
			this._completion = this._completion.slice(overlapLengthBefore)
		}

		return this
	}

	private calculateOverlapLength(completion: string, text: string, maxLength: number, isAfter: boolean): number {
		for (let length = 1; length <= maxLength; length++) {
			const completionSegment = isAfter ? completion.slice(-length) : completion.slice(0, length)
			const textSegment = isAfter ? text.slice(0, length) : text.slice(-length)

			if (completionSegment === textSegment) {
				const nextChar = isAfter ? text[length] : text[text.length - length - 1]
				if (!this._specialChars.includes(nextChar)) {
					return length
				}
			}
		}
		return 0
	}

	private isCursorAtMiddleOfWord(): boolean {
		return Boolean(this._charAfterCursor && /\w/.test(this._charBeforeCursor) && /\w/.test(this._charAfterCursor))
	}

	private removeUnnecessaryMiddleQuote(): CompletionFormatter {
		const isCursorAtMiddle = this.isCursorAtMiddleOfWord()
		if (isCursorAtMiddle) {
			if (QUOTES.includes(this._completion[0])) {
				this._completion = this._completion.substring(1)
			}
			if (QUOTES.includes(this._completion.at(-1) as string)) {
				this._completion = this._completion.slice(0, -1)
			}
		}
		return this
	}

	private removeDuplicateQuotes = () => {
		const trimmedCharAfterCursor = this._characterAfterCursor.trim()
		const lastCharOfCompletion = this._completion.at(-1) as string

		if (
			trimmedCharAfterCursor &&
			(this._normalisedCompletion.endsWith("',") ||
				this._normalisedCompletion.endsWith('",') ||
				(this._normalisedCompletion.endsWith("`,") && QUOTES.includes(trimmedCharAfterCursor)))
		) {
			this._completion = this._completion.slice(0, -2)
		} else if (
			(this._normalisedCompletion.endsWith("'") ||
				this._normalisedCompletion.endsWith('"') ||
				this._normalisedCompletion.endsWith("`")) &&
			QUOTES.includes(trimmedCharAfterCursor)
		) {
			this._completion = this._completion.slice(0, -1)
		} else if (QUOTES.includes(lastCharOfCompletion) && trimmedCharAfterCursor === lastCharOfCompletion) {
			this._completion = this._completion.slice(0, -1)
		}

		return this
	}

	private preventDuplicateLine = (): CompletionFormatter => {
		if (this._completionType === "InlineCompletion" || this._completionType === "LineCompletion") {
			const document = this._editor.document

			// 检查光标前一行
			let prevLineIndex = this._cursorPosition.line - 1
			if (prevLineIndex >= 0) {
				const prevLine = document.lineAt(prevLineIndex)
				if (prevLine.text.trim() === this._completion.trim()) {
					this._completion = ""
					return this
				}
			}

			// 检查光标后面的两行
			let nextLineIndex = this._cursorPosition.line + 1
			while (nextLineIndex < this._cursorPosition.line + 3 && nextLineIndex <= document.lineCount) {
				const line = document.lineAt(nextLineIndex)
				if (line.text.trim() === this._completion.trim()) {
					this._completion = ""
					return this
				}
				nextLineIndex++
			}
		}

		return this
	}

	public removeInvalidLineBreaks = (): CompletionFormatter => {
		if (this._textAfterCursor) {
			this._completion = this._completion.trimEnd()
		}
		return this
	}

	private skipMiddleOfWord() {
		if (this.isCursorAtMiddleOfWord()) {
			this._completion = ""
		}
		return this
	}

	private skipSimilarCompletions = (): this => {
		const { document } = this._editor
		const textAfter: any = document.getText(
			new Range(this._cursorPosition, document.lineAt(this._cursorPosition.line).range.end),
		)

		if (textAfter.score(this._completion) > 0.6) {
			this._completion = ""
		}

		return this
	}

	private getCompletion = () => {
		if (this._completion.trim().length === 0) {
			this._completion = ""
		}
		return this._completion
	}

	private getCompletionType = (): this => {
		if (this._completionType === "InlineCompletion" || this._completionType === "LineCompletion") {
			let completionText: string[] = this._completion.split(LINE_BREAK_REGEX)
			this._completion = ""
			for (let i = 0; i < completionText.length; i++) {
				if (completionText[i].trim() !== "") {
					this._completion += completionText[i]
					break
				} else {
					this._completion = os.EOL + this._completion
				}
			}
		}
		return this
	}

	private trimStart = () => {
		const firstNonSpaceIndex = this._completion.search(/\S/)

		if (firstNonSpaceIndex > 0 && this._cursorPosition.character <= firstNonSpaceIndex) {
			this._completion = this._completion.trimStart()
		}
		return this
	}

	/**
	 * 光标位置前满足条件时，不补全
	 * 条件: 光标位置的前一个字符为['}', ';']
	 */
	private skipCompletion = (): this => {
		const temp = this._completion.replace(/^[ \t]+|[ \t]+$/g, "")
		if (temp && !(temp.startsWith("\n") || temp.startsWith("\r")) && ["}", ";"].indexOf(this._charBeforeCursor) > -1) {
			this._completion = ""
		}
		return this
	}

	/**
	 * 检查 _completion 是否与上下行的非空代码行相似，仅在单行补全情况下执行。
	 * @returns 如果与上下行的非空代码行内容相似，返回空字符串；否则返回 _completion
	 */
	private checkSimilarityAndInsert = (): this => {
		try {
			if (this._completionType !== "LineCompletion") {
				return this
			}

			const currentPosition = this._editor.selection.active
			const previousRange = new Range(0, 0, currentPosition.line, currentPosition.character)
			const nextRange = new Range(currentPosition.line, currentPosition.character, this._editor.document.lineCount - 1, 0)
			const previousLineText = this.getPreviousNonEmptyLine(previousRange)
			const nextLineText = this.getNextNonEmptyLine(nextRange)
			const currentCompletion = this.normalise(this._completion)

			// 比较 _completion 与上下行的内容
			if (currentCompletion.length >= 3 && (currentCompletion === previousLineText || currentCompletion === nextLineText)) {
				this._completion = ""
				this.handleType = "removeDuplicateLine"
			}

			return this
		} catch (error) {
			console.error("An error occurred in checkSimilarityAndInsert:", error)
			return this
		}
	}

	/**
	 * 查找指定范围内之前的非空代码行内容。
	 * @param range 指定的范围（如从文档开头到当前光标位置）
	 * @returns 范围内的第一个非空代码行内容，如果没有则返回空字符串
	 */
	private getPreviousNonEmptyLine(range: Range): string {
		// 获取文本并去除末尾空白，按行分割
		const lines = this._editor.document.getText(range).trimEnd().split("\n")

		// 直接返回最后一行内容（去除末尾空白后的最后一个非空行）
		return lines[lines.length - 1]?.trim() || ""
	}

	/**
	 * 查找指定范围内之后的非空代码行内容。
	 * @param range 指定的范围（如从当前光标位置到文档末尾）
	 * @returns 范围内的最后一个非空代码行内容，如果没有则返回空字符串
	 */
	private getNextNonEmptyLine(range: Range): string {
		// 获取文本并去除开头空白，按行分割
		const lines = this._editor.document.getText(range).trimStart().split("\n")

		// 直接返回第一行内容（去除开头空白后的第一个非空行）
		return lines[0]?.trim() || ""
	}

	public debug() {
		console.log(`text after: ${this._textAfterCursor}`)
		console.log(`original completion: ${this._originalCompletion}`)
		console.log(`normalised completion: ${this._normalisedCompletion}`)
		console.log(`character after: ${this._characterAfterCursor}`)
	}

	public format = (completion: string): string => {
		this._completion = completion
		this._normalisedCompletion = this.normalise(completion)
		this._originalCompletion = completion
		const infillText = this.getCompletionType()
			.checkSimilarityAndInsert()
			// this.matchCompletionBrackets()
			// .preventDuplicateLine()
			// this.removeDuplicateQuotes()
			// .removeUnnecessaryMiddleQuote()
			// .ignoreBlankLines()
			// .removeInvalidLineBreaks()
			.removeDuplicateText()
			// .skipMiddleOfWord()
			// .skipSimilarCompletions()
			// .skipCompletion()
			.removeLeadingSpaceOnEmptyLine()
			.getCompletion()
		return infillText
	}

	private removeLeadingSpaceOnEmptyLine(): CompletionFormatter {
		if (this._completion && this._completion[0] === " ") {
			// 使用 prefixText 的最后一行来判断
			const lastLine = this._prefixText.split("\n").pop()
			if (/^\s*$/.test(lastLine ?? "")) {
				let lines = this._completion.split("\n")
				lines[0] = lines[0].replace(/^\s+/, "")
				this._completion = lines.join("\n")
			}
		}
		return this
	}
}
