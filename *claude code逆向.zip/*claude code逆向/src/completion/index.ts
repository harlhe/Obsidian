import {
	InlineCompletionItem,
	InlineCompletionItemProvider,
	InlineCompletionList,
	Position,
	Range,
	TextDocument,
	StatusBarItem,
	window,
	InlineCompletionContext,
	ExtensionContext,
} from "vscode"
import * as vscode from "vscode"
import * as os from "os"
import { getPackageVersion } from "../util/getPackageVersion"
import { getPlatFormOS, formatTime } from "../util/index"
import { getFimDataFromProvider as getProviderFimData, getPrefixSuffix } from "./util/index"
import {
	PrefixSuffix,
	CompletionResponse,
	CompletionType,
	FileCommonData,
	ContextualCompletion,
	FunctionInfo,
} from "./types/index"
import { EXTENSION_NAME, LOG_KEYS, ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY, RESPONSE_CODE } from "./util/consants"
import { MockToolType, TestFrameType, UserInfoType } from "../types/index"
import setting from "./config/setting.json"
import { createStreamRequestBodyFim } from "./template/index"
import { CompletionFormatter } from "./format/index"
import { FileInteractionCache } from "./prompt/index"
import { cache, completionLineCache } from "./cache/index"
import { fileDataCache } from "./cache/cache"
import { MetricProvider } from "../util/metricProvider"
import { trackingV2, Tracing, TracingClassType, resInterception } from "../api/tracking"
import { NeighborFileSnippet } from "./prompt/neighbor-file-snippet"
import { InlineCompletionInfo } from "./SyntaxTreeAnalysis/InlineCompletionInfo"
import { CompletionInterceptor } from "./interceptor/completion-interceptor"
import { streamResponse } from "./api"
import { deepClone } from "../util/common-util"
import ChatGPTViewProvider from "../chatgptViewProvider"
import { SpanEnum } from "./util/consants"
import { Background } from "../util/background"
import nls from "../nls/index"
const { v4: uuidv4 } = require("uuid")
import { LoggerManager, Logger } from "../util/logger"
import { AbortError } from "./api/stream"
import { KnowledgeService } from "./service/knowledgeService"
import { GhostCacheManager } from "./service/ghostCacheService"
import { PromptBuilder } from "./service/promptBuilder"
import { SimilarCodeProvider } from "./service/similarCodeProvider"
import { EditChangeHandler } from "./service/editChangeHandler"
import { PreemptiveInterception } from "./service/preemptiveInterceptionService"
import { CompletionTypeHandler } from "./common/completion-type"
import { FileNameCache } from "./prompt/file-name"
import { PrefixSuffixHandler } from "./handler/prefix-suffix-handler"
import { FileCommonInfo } from "./common/file-common-info"
import { SyntaxInfoManager } from "./service/syntaxInfoManager"
import { RemoteKnowledgeBase } from "./service/remoteKnowledgeBase"

let branch: string | undefined = undefined

export class CompletionProvider implements InlineCompletionItemProvider {
	// 获取插件配置
	_config = vscode.workspace.getConfiguration(EXTENSION_NAME)

	static isForce: boolean = false
	private _abortController: AbortController | null
	private _dispose: vscode.Disposable | null = null
	// 匹配补全可选项列表
	private _completeChoices: any[] = []

	private _debouncer: NodeJS.Timeout | undefined

	// 激活/停用Ai补全功能
	private _enabled = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.enabled) as boolean
	// 实时补全的语言类型
	private _languages: object = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.languages) as object
	// 测试框架
	private _testFrame: TestFrameType = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.testFrame) as TestFrameType
	// Mock 工具
	private _mockTool: MockToolType = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.mockTool) as MockToolType

	private _completionInterceptor: CompletionInterceptor = new CompletionInterceptor()
	// 编辑操作是否需要触发补全
	private _needToComplete: boolean = true

	private _candidateNum: number = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.candidateNum) as number
	private _completeType: string = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.completeType) as string
	private _technologyStack: string = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.technologyStack) as string

	// 最新请求的标识uuid
	private _latestReqUuid: string = ""

	private _debounceWait = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.delay) as number
	// 是否缓存FIM补全结果
	private _completionCacheEnabled: boolean = this._config.get(
		ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.completionCacheEnabled,
	) as boolean
	// 上下文行数
	private _numLineContext = setting.complete.contextLength as number
	private _contextRatio: number[] = setting.base.contextRatio

	// 上下文的前缀最少字符数
	private _contextPrefixMinCharLength = setting.complete.contextPrefixMinCharLength as number

	// 相似代码选项， 0  BestMatch,  1 TopK
	private _snippetSelectionOption = setting.complete.snippetSelectionOption as number

	// 补全项幽灵缓存行数,设置为0可关闭幽灵缓存
	private _ghostCacheRowLevel = setting.complete.ghostCacheRowLevel as number
	// 幽灵缓存开关
	private _ghostCacheSwitch = setting.complete.ghostCacheSwitch as boolean

	private _streamEnable = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.streamEnable) as boolean

	private _neighborFileSnippet: NeighborFileSnippet

	private _knowledgeUrl: string = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.knowledgeUrl) as string
	public _openTabFileSnippetsEnbaled = setting.complete.localFindSimilarEnbaled as boolean

	public _expandHeadEnable: string = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.expandHeadEnable) as string

	private _remoteKnowledgeBase = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.enableRemoteKnowledgeBase) as string

	// 完整语义上下文开关
	public _funcBlockPrefixSuffixEnbaled = setting.complete.funcBlockPrefixSuffixEnbaled as boolean

	// 编辑界面的quick suggestion 框的当前选项
	private _currQuickSuggestion: string = ""
	private _currKeywordInputLength: number = 0

	private _document: TextDocument | null
	private _nonce = 0

	private _position: Position | null
	private _statusBar: StatusBarItem
	private totalKeystrokes: number = 0 //用户键入总数
	private userInfo: UserInfoType | undefined
	private _metricProvider: MetricProvider
	private _completionResponse: {
		result: string
		chatUuid: string
		docId: string
		formattedCompletion: string
		prompt: string
		finishReason: string
	}
	private _relativePath: string = ""
	private _absoluteRepoName: string = ""
	// 流式请求拼接的补全信息
	private streamCompletion = ""
	private _gptProvider: ChatGPTViewProvider
	private _knowledgeService: KnowledgeService
	private _ghostCacheManager: GhostCacheManager
	private _similarCodeProvider: SimilarCodeProvider
	private _editChangeHandler: EditChangeHandler
	public _fileNameCache: FileNameCache

	constructor(
		statusBar: StatusBarItem,
		fileInteractionCache: FileInteractionCache,
		extentionContext: ExtensionContext,
		neighborFileSnippet: NeighborFileSnippet,
		gptProvider: ChatGPTViewProvider,
		fileNameCache: FileNameCache,
	) {
		this._neighborFileSnippet = neighborFileSnippet
		this._abortController = null
		this._document = null
		this._position = null
		this._statusBar = statusBar
		this._metricProvider = MetricProvider.getInstance()
		this._completionResponse = {
			result: "",
			chatUuid: "",
			docId: "",
			formattedCompletion: "",
			prompt: "",
			finishReason: "",
		}
		this._gptProvider = gptProvider
		this._knowledgeService = new KnowledgeService(this._knowledgeUrl)
		this._ghostCacheManager = new GhostCacheManager(
			this._numLineContext,
			this._contextRatio,
			this._ghostCacheRowLevel,
			this._completionCacheEnabled,
			this._completionResponse,
		)
		this._similarCodeProvider = new SimilarCodeProvider(
			this._knowledgeService,
			this._neighborFileSnippet,
			this._snippetSelectionOption,
		)

		this._editChangeHandler = new EditChangeHandler()
		this._fileNameCache = fileNameCache
	}

	private handleCompletionAccepted(completion: string, accType: string = "all") {
		this.setMetric({
			content: completion,
			accType,
		})
	}

	private initCompletionResponse() {
		this._completionResponse = {
			result: "",
			chatUuid: "",
			docId: "",
			formattedCompletion: "",
			prompt: "",
			finishReason: "",
		}
	}

	private async getParallelSimilarCode(
		document: TextDocument,
		position: Position,
		prefixSuffix: PrefixSuffix,
		loggerManager: LoggerManager,
		inlineCompletionInfo: InlineCompletionInfo,
	) {
		const commandName = `zteAiAssistant.backgroundProcess.${Date.now()}.${Math.random().toString(36).substr(2, 9)}`

		const disposable = vscode.commands.registerCommand(commandName, async () => {
			try {
				const fileCommonData = await this.getFileCommonData(document, position)
				if (!fileCommonData) return
				const { curFunctionInfo } = await this.getSyntaxInfo(inlineCompletionInfo, document, position, prefixSuffix)
				await this.getSimilarCode(
					document,
					position,
					prefixSuffix,
					loggerManager,
					fileCommonData,
					curFunctionInfo,
					inlineCompletionInfo,
					true,
				)
			} catch (error) {
				Logger("error", `Error in background process: ${error}`)
			} finally {
				disposable.dispose()
			}
		})

		// 异步执行命令
		vscode.commands.executeCommand(commandName)
	}

	public async provideInlineCompletionItems(
		document: TextDocument,
		position: Position,
		context: InlineCompletionContext,
	): Promise<InlineCompletionItem[] | InlineCompletionList | null | undefined> {
		Logger("info", "---------- start -----------")
		const _traceId = uuidv4().replace(/-/g, "")
		this._latestReqUuid = _traceId
		if (this._debouncer) clearTimeout(this._debouncer)
		let debounceWait = CompletionProvider.isForce ? 0 : this._debounceWait
		const inlineCompletionInfo: InlineCompletionInfo = new InlineCompletionInfo(document.uri.path)
		const loggerManager = new LoggerManager()
		loggerManager.setTraceId(_traceId)
		const prefixSuffix = getPrefixSuffix(this._numLineContext, document, position, setting.base.contextRatio)
		// 异步获取相似代码缓存
		this.getParallelSimilarCode(document, position, prefixSuffix, loggerManager, inlineCompletionInfo)
		return new Promise((resolve, reject) => {
			this._debouncer = setTimeout(async () => {
				try {
					const completionItems = await this.provideCompletionItems(
						document,
						position,
						context,
						inlineCompletionInfo,
						prefixSuffix,
						_traceId,
						loggerManager,
					)
					resolve(completionItems)
				} catch (error: any) {
					reject(null)
				} finally {
					if (CompletionProvider.isForce) CompletionProvider.isForce = false
					this._statusBar.text = nls.t("icode.extension.title")
					this._statusBar.color = new vscode.ThemeColor("statusBar.foreground")
					// this._statusBar.tooltip = nls.t("icode.extension.tooltip")
				}
			}, debounceWait)
		})
	}

	private async getFileCommonData(document: TextDocument, position: Position): Promise<FileCommonData | null | undefined> {
		let fileCommonData: FileCommonData | null | undefined = fileDataCache.get(document.uri.fsPath)
		if (!fileCommonData) {
			fileCommonData = await new FileCommonInfo(document).fileActiveDo(position)
		}
		return fileCommonData
	}

	private getContextual(
		fileCommonData: FileCommonData,
		document: TextDocument,
		position: Position,
		inlineCompletionInfo: InlineCompletionInfo,
	) {
		const prefixSuffixHandler = new PrefixSuffixHandler(
			fileCommonData,
			this._numLineContext,
			document,
			position,
			this._contextRatio,
		)

		let contextualCompletion: ContextualCompletion
		if (this._funcBlockPrefixSuffixEnbaled) {
			contextualCompletion = prefixSuffixHandler.getFuncBlockPrefixSuffix(inlineCompletionInfo)
		} else {
			contextualCompletion = prefixSuffixHandler.getFixWindowPrefixSuffix()
		}
		return contextualCompletion
	}

	private async getSyntaxInfo(
		inlineCompletionInfo: InlineCompletionInfo,
		document: TextDocument,
		position: Position,
		prefixSuffix: PrefixSuffix,
	) {
		const syntaxInfoManager = new SyntaxInfoManager(inlineCompletionInfo, document, position)
		const syntaxInfo = await syntaxInfoManager.collectSyntaxInfo(prefixSuffix)
		const curFunctionInfo = syntaxInfoManager.getCurrentFunctionInfo()
		return { syntaxInfo, curFunctionInfo }
	}

	private async getSimilarCode(
		document: TextDocument,
		position: Position,
		prefixSuffix: PrefixSuffix,
		loggerManager: LoggerManager,
		fileCommonData: FileCommonData,
		curFunctionInfo: FunctionInfo | null,
		inlineCompletionInfo: InlineCompletionInfo,
		isParallel?: boolean,
	) {
		const spanStartTime = Date.now()

		let contextualCompletion: ContextualCompletion = this.getContextual(
			fileCommonData,
			document,
			position,
			inlineCompletionInfo,
		)

		const similarCodeSnippets = await this._similarCodeProvider.getSimilarCodeSnippets(
			document,
			position,
			prefixSuffix.prefix,
			prefixSuffix.suffix,
			this._knowledgeUrl,
			loggerManager,
			prefixSuffix,
			contextualCompletion,
			this._fileNameCache,
			fileCommonData,
			curFunctionInfo,
			this._openTabFileSnippetsEnbaled,
		)
		loggerManager.log(
			"info",
			Date.now() - spanStartTime,
			!isParallel ? SpanEnum.getSimilarCode : `parallel ${SpanEnum.getSimilarCode}`,
		)
		return similarCodeSnippets
	}

	async provideCompletionItems(
		document: TextDocument,
		position: Position,
		context: InlineCompletionContext,
		inlineCompletionInfo: InlineCompletionInfo,
		prefixSuffix: PrefixSuffix,
		_traceId: string,
		loggerManager: LoggerManager,
	): Promise<InlineCompletionItem[] | InlineCompletionList | null | undefined> {
		const startDate = Date.now()
		loggerManager.log("info", formatTime(Date.now()), "startTime")
		const _tracing = new Tracing()
		_tracing.initTracingParams()
		_tracing.tracingId = _traceId
		const isForceCompletion = CompletionProvider.isForce
		let languageSupported: boolean = Array.isArray(this._languages)
			? this._languages.includes(document.languageId)
			: !!(<{ [_: string]: boolean }>this._languages)[document.languageId]
		loggerManager.log("info", document.languageId, LOG_KEYS.languageId)

		if (this._abortController) {
			loggerManager.log("info", this._abortController, "abort lastRequest")
			this.abortCompletion()
		}
		this._abortController = new AbortController()
		this._statusBar.text = "$(loading~spin)"

		// 不触发补全场景：未启用、语言不支持、特殊规则不需要
		if (!this._enabled || !languageSupported || !this._needToComplete) {
			loggerManager.log(
				"warn",
				{ _enabled: this._enabled, languageSupported: languageSupported, _needToComplete: this._needToComplete },
				"completion intercept",
			)
			this._needToComplete = true
			this._statusBar.text = nls.t("icode.extension.title")
			return
		}

		const fileCommonData = await this.getFileCommonData(document, position)
		if (!fileCommonData) return

		let contextualCompletion: ContextualCompletion = this.getContextual(
			fileCommonData,
			document,
			position,
			inlineCompletionInfo,
		)

		const currentLinePrefix = document.getText(new Range(position.line, 0, position.line, position.character))
		if (!CompletionProvider.isForce && context.selectedCompletionInfo) {
			// 在输入触发vscode 自带的补全效果时，拦截
			loggerManager.log("info", "vscode tip interceptor")
			this.abortCompletion()
			const { completionText } = this._completionInterceptor.tipInterceptor(
				document,
				position,
				contextualCompletion,
				context.selectedCompletionInfo,
				this._completionCacheEnabled,
			)
			const endPosition = new Position(position.line, position.character + completionText.length)
			const inlineCompletionItem = new InlineCompletionItem(completionText, new Range(position, endPosition))
			const inlineCompleteItems = [inlineCompletionItem]
			return inlineCompleteItems
		}

		const ghostCompletions = this.handleGhostTextCompletion(currentLinePrefix, position, loggerManager)
		if (ghostCompletions) {
			return ghostCompletions
		}

		const startDateBackground = Date.now()
		try {
			await Background.extractGitRepositoryInfo(document.uri.fsPath, loggerManager)
		} catch (e: unknown) {
			loggerManager.log("error", e as object, "extractGitRepositoryInfo")
		}

		loggerManager.log("info", Date.now() - startDateBackground, "getbackgroundinfo")
		branch = Background.get().branch
		this._relativePath = Background.get().relativePath
		this._absoluteRepoName = Background.get().absolutRepoName
		this._metricProvider.setRepoInfo(this._relativePath, this._absoluteRepoName, branch)

		let prefixContent = prefixSuffix.prefix.replace(/\s+/g, "").replace(/\s/g, "")

		if (prefixContent.length < this._contextPrefixMinCharLength) {
			//前置拦截埋点
			this.checkMinChatLength()
		}

		const userInfo: UserInfoType = await vscode.commands.executeCommand("zteChatGPT.getUserInfo")

		this.userInfo = userInfo
		this._metricProvider.setUserInfo(this.userInfo.userId, this.userInfo.token, this.userInfo.tenant)
		let tempPrefixSuffix = deepClone(prefixSuffix)

		// 在输入触发vscode 自带的补全效果时
		tempPrefixSuffix = this.handleQuickSuggestion(context, document, position, prefixSuffix)
		if (!tempPrefixSuffix) {
			return
		}

		// 补全类型
		const completionTypeDate = Date.now()
		let completionType = new CompletionTypeHandler(document).getCompletionType(prefixSuffix, this._testFrame)
		if (
			(completionType === "BlockCompletion" || completionType === "FunctionCompletion") &&
			this._completeType === "single"
		) {
			if (currentLinePrefix.trim() === "") {
				completionType = "LineCompletion"
			} else {
				completionType = "InlineCompletion"
			}
		}

		const needToComplete: boolean = this._completionInterceptor.grammarParseTriggerCompletion(completionType)
		if (!isForceCompletion && !needToComplete) {
			this._statusBar.text = nls.t("icode.extension.title")
			return
		}
		loggerManager.log("info", Date.now() - completionTypeDate, "getCompletionType")

		this._position = position
		const cacheStartTime = Date.now()
		const cachedCompletion = cache.getCache(tempPrefixSuffix)
		if (!isForceCompletion && this._completionCacheEnabled && cachedCompletion && JSON.parse(cachedCompletion)) {
			return this.handleCacheHit(
				cachedCompletion,
				tempPrefixSuffix,
				completionType,
				_tracing,
				loggerManager,
				startDate,
				position,
				contextualCompletion,
			)
		}
		loggerManager.log("info", Date.now() - cacheStartTime, "getCache")

		let spanStartTime = Date.now()
		_tracing.setTracingParams({
			name: SpanEnum.getLocalKnowledgeBase,
			startTimeUnixNano: spanStartTime + "000000",
			endTimeUnixNano: Date.now() + "000000",
		})

		this._document = document
		this._nonce = this._nonce + 1

		_tracing.setTracingParams({
			name: SpanEnum.getSyntaxTree,
			startTimeUnixNano: spanStartTime + "000000",
			endTimeUnixNano: Date.now() + "000000",
		})

		if (this._debouncer) clearTimeout(this._debouncer)

		spanStartTime = Date.now()
		const { syntaxInfo, curFunctionInfo } = await this.getSyntaxInfo(inlineCompletionInfo, document, position, prefixSuffix)
		loggerManager.log("info", Date.now() - spanStartTime, "getInfoFromSyntaxTreeTime")

		const promptBuilder = new PromptBuilder(
			document,
			position,
			inlineCompletionInfo,
			this._technologyStack,
			this._streamEnable,
			this._candidateNum,
		)

		const similarCodeSnippets = await this.getSimilarCode(
			document,
			position,
			prefixSuffix,
			loggerManager,
			fileCommonData,
			curFunctionInfo,
			inlineCompletionInfo,
		)
		//远端知识库
		const remoteKnowledgeBase = RemoteKnowledgeBase.getRemoteKnowBaseTypes(
			this._remoteKnowledgeBase,
			this._knowledgeUrl,
			false,
		)

		const prompt = await promptBuilder.buildPrompt(
			tempPrefixSuffix,
			similarCodeSnippets,
			completionType,
			this._testFrame,
			this._mockTool,
			loggerManager,
			syntaxInfo,
			remoteKnowledgeBase,
		)

		const endDate = Date.now()
		_tracing.setTracingParams({
			name: SpanEnum.getPromptTime,
			startTimeUnixNano: spanStartTime + "000000",
			endTimeUnixNano: endDate + "000000",
		})
		loggerManager.log("info", `get prompt took ${endDate - startDate} ms`, LOG_KEYS.performance)
		if (!prompt) return

		spanStartTime = Date.now()
		let llmCompletionResult: any = []
		this._completeChoices = []
		this.streamCompletion = ""
		this.initCompletionResponse()
		this.totalKeystrokes = this.calculateTotalKeystrokes()
		const request: any = this.buildStreamRequest(prompt, _traceId, loggerManager, endDate - startDate)
		this.totalKeystrokes = 0
		loggerManager.log("info", request.options, LOG_KEYS.completionHeader)
		try {
			this.verifyUuid(_traceId)
			llmCompletionResult = await streamResponse({
				isStream: this._streamEnable,
				body: request.body,
				options: request.options,
				controller: this._abortController,
				logger: loggerManager,
				onStart: () => {
					this.verifyUuid(_traceId)
				},
				onEnd: () => {
					this.verifyUuid(_traceId)
					const logKey = request.body?.stream ? LOG_KEYS.streamEnd : LOG_KEYS.respEnd
					const { result, docId, chatUuid, finishReason } = this._completionResponse
					loggerManager.log("info", this._completeChoices, logKey)
					loggerManager.log("info", { result, docId, chatUuid, finishReason }, LOG_KEYS.completionResponse)
					loggerManager.log("info", `api request ${Date.now() - spanStartTime} ms`, "api request")
					_tracing.setTracingParams({
						name: SpanEnum.getResponse,
						startTimeUnixNano: spanStartTime + "000000",
						endTimeUnixNano: Date.now() + "000000",
					})
					return this.provideInlineCompletion(
						this._completeChoices,
						tempPrefixSuffix,
						false,
						completionType,
						_tracing,
						loggerManager,
						startDate,
						position,
						contextualCompletion,
					)
				},
				onError: (err) => this.onError(err, loggerManager),
				onData: (data: any) => {
					this.verifyUuid(_traceId)
					this._statusBar.color = new vscode.ThemeColor("statusBar.foreground")
					// this._statusBar.tooltip = nls.t("icode.extension.tooltip")
					if (data.code?.code !== RESPONSE_CODE.SUCCESS) {
						if (data.code?.code === RESPONSE_CODE.AUTH_FAILED) {
							vscode.window
								.showErrorMessage(nls.t("icode.completion.authFailed"), nls.t("icode.completion.login"))
								.then((selection) => {
									if (selection === nls.t("icode.completion.login")) {
										vscode.commands.executeCommand("zteAIAssitant.toggleSidebar").then(async () => {
											setTimeout(async () => {
												// 直接尝试聚焦 Webview，无需判断侧边栏状态
												await vscode.commands.executeCommand("zteAIAssitant.chatView.focus")
												// 登录 GPT 服务
												this._gptProvider.login(
													{ networkType: this._gptProvider.netWorkType },
													{ token: this.userInfo?.token ?? "" },
												)
											}, 300)
										})
									}
								})
						} else if (data.code?.code === RESPONSE_CODE.LIMIT_STATUS) {
							this._statusBar.text = nls.t("icode.extension.title")
							this._statusBar.color = "rgb(245, 106, 0)"
							this._statusBar.tooltip = nls.t("icode.completion.limitStatus")
						} else if (data.code?.code === RESPONSE_CODE.SMART_INTERCEPTOR) {
							this._statusBar.text = nls.t("icode.extension.title")
							loggerManager.log("warn", data, "smart interceptor")
						} else {
							vscode.window.showErrorMessage(typeof data === "string" ? data : data.code.msg)
						}
						loggerManager.log("info", data, LOG_KEYS.streamResponse)
						throw new AbortError()
					}
					if (typeof data.bo.result === "string") {
						data.bo.result = data.bo.result.replace(/\r\n|\r/g, "\n")
					}
					this._completionResponse.result = data.bo.result || ""
					this._completionResponse.docId = data.bo.docId || ""
					this._completionResponse.chatUuid = data.bo.chatUuid || ""
					this._completionResponse.prompt = JSON.stringify(request.body)
					this._completionResponse.finishReason = data.bo.finishReason
					this.onData(data, _tracing, loggerManager, request.body?.stream)
				},
			})
			this.abortCompletion()
			this._abortController = null
			loggerManager.log("info", llmCompletionResult, "llmCompletionResult")
			return llmCompletionResult
		} catch (error: any) {
			throw this.onError(error, loggerManager)
		}
	}

	private handleQuickSuggestion(
		context: InlineCompletionContext,
		document: TextDocument,
		position: Position,
		prefixSuffix: PrefixSuffix,
	): PrefixSuffix | undefined {
		if (context.selectedCompletionInfo) {
			this._currQuickSuggestion = context.selectedCompletionInfo.text

			const wordRange = document.getWordRangeAtPosition(position)
			if (!wordRange) {
				return undefined
			}

			const currPartialKeyword = document.getText(wordRange)
			if (!this._currQuickSuggestion.startsWith(currPartialKeyword)) {
				return undefined
			}

			return {
				...prefixSuffix,
				prefix: this.generateQuickSuggestionPrefix(prefixSuffix.prefix, context.selectedCompletionInfo.text),
			}
		}

		this._currQuickSuggestion = ""
		this._currKeywordInputLength = 0
		return prefixSuffix
	}

	private handleGhostTextCompletion(
		currentLinePrefix: string,
		position: Position,
		loggerManager: LoggerManager,
	): InlineCompletionItem[] | null {
		const ghostText = this._completionResponse?.formattedCompletion || ""
		const ghostStartPosition = this._position || null

		if (!ghostText || !ghostStartPosition) {
			return null
		}

		const remainingGhostText = this._completionInterceptor.isMatchingGhostText(
			currentLinePrefix,
			position,
			ghostText,
			ghostStartPosition,
		)

		if (remainingGhostText === false || typeof remainingGhostText !== "string" || !remainingGhostText.trim()) {
			return null
		}

		loggerManager.log("warn", "matched ghost text, return ghost text")
		this.abortCompletion()
		loggerManager.log("warn", remainingGhostText, "remainingGhostText")

		return [
			new InlineCompletionItem(
				remainingGhostText,
				new Range(position, new Position(position.line, position.character + remainingGhostText.length)),
			),
		]
	}

	@PreemptiveInterception("minChatlength")
	private checkMinChatLength(): void {
		this._needToComplete = false
	}

	@PreemptiveInterception("cacheHit")
	private handleCacheHit(
		cachedCompletion: string,
		tempPrefixSuffix: PrefixSuffix,
		completionType: CompletionType,
		_tracing: TracingClassType,
		loggerManager: LoggerManager,
		startDate: number,
		position: Position,
		contextualCompletion: ContextualCompletion,
	) {
		const { result, chatUuid, docId, formattedCompletion, prompt } = JSON.parse(cachedCompletion)

		this._completionResponse.result = result
		this._completionResponse.chatUuid = chatUuid
		this._completionResponse.docId = docId
		this._completionResponse.formattedCompletion = formattedCompletion
		this._completionResponse.prompt = prompt

		this.abortCompletion()
		loggerManager.log("info", "hintCache", "hintCache")
		return this.provideInlineCompletion(
			[formattedCompletion],
			tempPrefixSuffix,
			true,
			completionType,
			_tracing,
			loggerManager,
			startDate,
			position,
			contextualCompletion,
		)
	}

	public resetCacheResponse() {
		if (this._completionResponse.formattedCompletion) {
			this._completionResponse.formattedCompletion = ""
		}
	}

	private verifyUuid(traceId: string) {
		if (this._latestReqUuid != traceId) {
			throw new AbortError()
		}
	}

	public setMetric({ content, accType, toggle }: { content?: string; accType: string; toggle?: number }) {
		const params = this._metricProvider.setMetricParams({
			actionType: "autoCompletion",
			docId: this._completionResponse.docId,
			chatUuid: this._completionResponse.chatUuid,
			content: content ?? JSON.stringify(this._completeChoices),
			prompt: this._completionResponse.prompt,
			accType,
			contentType: this._document?.languageId || "",
			toggle,
			delay: this._debounceWait,
		})
		trackingV2(params)
	}

	private buildStreamRequest(prompt: string, _traceId: string, loggerManager: LoggerManager, totalOfPreRequestTime: number) {
		try {
			const body = createStreamRequestBodyFim(prompt)
			loggerManager.log("info", _traceId, "completion request traceId")

			const options: any = {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					"X-Emp-No": this.userInfo?.userId,
					"X-Auth-Value": this.userInfo?.token,
					"X-Plugin-Type": "VSCODE",
					"X-Plugin-UserAgent": `vscode ${vscode.version}`,
					"X-Plugin-Version": `v${getPackageVersion()}`,
					"X-Plugin-Platform": getPlatFormOS(),
					"X-Plugin-Repo": this._absoluteRepoName,
					"X-Plugin-ContentType": this._document?.languageId || "",
					"X-Plugin-Branch": encodeURIComponent(branch as string),
					"X-Plugin-FilePath": encodeURIComponent(this._relativePath),
					"X-Trace-Id": _traceId,
					"X-Parent-Span-Id": uuidv4().replace(/-/g, "").slice(0, 16),
					"X-Front-Duration": totalOfPreRequestTime,
					"X-Front-Timestamp": Date.now(),
					"X-Tenant-Code": this.userInfo?.tenant || "",
					"X-Total-Keystrokes": this.totalKeystrokes,
				},
			}

			return { options, body }
		} catch (error) {
			// 记录错误信息到日志
			loggerManager.log("error", error as object, `Error building stream request: ${error}`)
			// 重新抛出错误以便上层处理
			throw error
		}
	}

	private onData(
		data: CompletionResponse | undefined,
		tracing: TracingClassType,
		loggerManager: LoggerManager,
		stream?: boolean,
	): void {
		const provider = this.getProvider()
		if (!provider) return
		try {
			const providerFimDataOptions = getProviderFimData(provider.provider, data)
			// 在连续键入字符发起请求时，校验响应是否是最新请求的响应报文
			if (this._latestReqUuid != tracing.tracingId) {
				this._completeChoices = []
				this.streamCompletion = ""
				throw new AbortError()
			}

			if (stream) {
				!Array.isArray(this._completeChoices) && (this._completeChoices = [])
				!this._completeChoices[0] && (this._completeChoices[0] = [""])
				this._completeChoices[0] = this.streamCompletion + (providerFimDataOptions[0] ?? "")
				this.streamCompletion = this._completeChoices[0]
			} else if (providerFimDataOptions === undefined || providerFimDataOptions.length === 0) {
				this._completeChoices = []
				return
			} else {
				this._completeChoices = providerFimDataOptions.slice(
					0,
					Math.min(this._candidateNum, providerFimDataOptions.length),
				)
			}
		} catch (e) {
			loggerManager.log("error", e as object, "onDataError")
			throw e
		}
	}

	public onError(err: any, loggerManager: LoggerManager) {
		this._abortController?.abort()
		if (err.name === "AbortError") {
			loggerManager.log("warn", err, LOG_KEYS.onError)
		} else {
			loggerManager.log("error", err, LOG_KEYS.onError)
		}
		return err
	}

	private getProvider = () => {
		return setting.provider
	}

	@PreemptiveInterception("abortCompletion")
	public abortCompletion() {
		this._abortController?.abort()
		this._statusBar.text = nls.t("icode.extension.title")
		this._statusBar.color = new vscode.ThemeColor("statusBar.foreground")
		// this._statusBar.tooltip = nls.t("icode.extension.tooltip")
	}

	private provideInlineCompletion(
		completeChoices: any[],
		prefixSuffix: PrefixSuffix,
		fromCache: boolean,
		completionType: CompletionType,
		_tracing: TracingClassType,
		loggerManager: LoggerManager,
		startDate: number,
		position: Position,
		contextualCompletion: ContextualCompletion,
	): InlineCompletionItem[] {
		const postHandleDataTime = Date.now()
		const editor = window.activeTextEditor
		if (!editor || !this._position) {
			return []
		}

		let inlineCompleteItems: any[] = []

		completeChoices?.forEach((item) => {
			let formattedCompletion = ""
			const completionFormatter = new CompletionFormatter(editor, completionType, prefixSuffix.prefix)
			formattedCompletion = completionFormatter.format(item)
			if (completionFormatter.handleType) {
				loggerManager.log("warn", item, completionFormatter.handleType)
			}
			if (!formattedCompletion) return
			this._completionResponse.formattedCompletion = formattedCompletion
			if (item.trimStart().includes("\n")) this._completionResponse.formattedCompletion += os.EOL
			if (this._completionCacheEnabled && formattedCompletion.length > 0) {
				cache.setCache(prefixSuffix, JSON.stringify(this._completionResponse))
			}

			if (this._position) {
				let completionText = ""
				if (this._currQuickSuggestion) {
					completionText = this._currQuickSuggestion.substring(this._currKeywordInputLength) + formattedCompletion
				} else {
					completionText = formattedCompletion
				}
				let endPosition = new Position(this._position.line, this._position.character + completionText.length)
				if (completionType === "InlineCompletion" && !item.trimStart().includes("\n")) {
					endPosition = this._position
				}
				const inlineCompletionItem = new InlineCompletionItem(completionText, new Range(this._position, endPosition))
				inlineCompleteItems.push(inlineCompletionItem)
			}

			// 判断幽灵缓存开关是否打开
			if (this._ghostCacheSwitch) {
				this._ghostCacheManager.setCompletionResponse(this._completionResponse)
				this._ghostCacheManager.setGhostCompletionCache(item, prefixSuffix, completionType)
			}
		})
		if (this._latestReqUuid !== _tracing.tracingId) {
			return []
		}
		this._statusBar.text = nls.t("icode.extension.title")
		this._currQuickSuggestion = ""
		this._currKeywordInputLength = 0

		this._dispose = vscode.workspace.onDidChangeTextDocument((event) => {
			this.judgeAcceptType(event, inlineCompleteItems)
		})
		_tracing.setTracingParams({
			name: SpanEnum.totalOfCompetion,
			startTimeUnixNano: startDate + "000000",
			endTimeUnixNano: Date.now() + "000000",
		})
		_tracing.run()
		if (!fromCache) {
			this.setInterception(inlineCompleteItems)
		}

		const completionRespText = JSON.stringify(contextualCompletion.completionRespData)
		const cacheCompletionText =
			inlineCompleteItems[0].range.end.line === position.line &&
			inlineCompleteItems[0].range.end.character === position.character
				? inlineCompleteItems[0].insertText
				: inlineCompleteItems[0].insertText + contextualCompletion.eol
		completionLineCache.setCache(contextualCompletion, cacheCompletionText, completionRespText, _tracing.tracingId)

		loggerManager.log("info", Date.now() - postHandleDataTime, "postHandleData")
		loggerManager.log("info", `total took ${Date.now() - startDate} ms`, LOG_KEYS.performance)
		loggerManager.log("info", formatTime(Date.now()), "endTime")
		loggerManager.log("info", inlineCompleteItems, "inlineCompleteItems")
		return inlineCompleteItems
	}

	private judgeAcceptType(event: vscode.TextDocumentChangeEvent, inlineCompleteItems: InlineCompletionItem[]) {
		const change = event.contentChanges[0]
		if (change === undefined || change === null) return
		const range = change.range
		const changeText = change.text
		const startPosition = range.start
		const { line: changeStartLine, character: changeStartCharacter } = startPosition
		inlineCompleteItems.forEach((inlineCompleteItem) => {
			const itemStartLine = inlineCompleteItem?.range?.start?.line ?? 0
			const itemStartCharacter = inlineCompleteItem?.range?.start?.character ?? 0
			const insertText = inlineCompleteItem?.insertText ?? ""
			if (changeStartLine === itemStartLine && changeStartCharacter === itemStartCharacter) {
				// 全部补全
				if (changeText === insertText) {
					this.handleCompletionAccepted(insertText, "all")
					return
				}
				if (changeText && insertText && insertText?.toString()?.indexOf(changeText) == 0) {
					this.handleCompletionAccepted(changeText, "part")
					return
				}
			}
		})
	}

	public updateConfig() {
		this._config = vscode.workspace.getConfiguration(EXTENSION_NAME)

		// 激活/停用Ai补全功能
		this._enabled = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.enabled) as boolean
		// 实时补全的语言类型
		this._languages = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.languages) as object

		this._candidateNum = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.candidateNum) as number
		this._completeType = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.completeType) as string

		this._testFrame = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.testFrame) as TestFrameType
		this._mockTool = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.mockTool) as MockToolType
		this._technologyStack = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.technologyStack) as string
		// 是否缓存FIM补全结果
		this._completionCacheEnabled = this._config.get(
			ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.completionCacheEnabled,
		) as boolean

		this._streamEnable = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.streamEnable) as boolean

		this._expandHeadEnable = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.expandHeadEnable) as string
		this._knowledgeUrl = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.knowledgeUrl) as string

		this._debounceWait = this._config.get(ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.delay) as number
		this._remoteKnowledgeBase = this._config.get(
			ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY.enableRemoteKnowledgeBase,
		) as string
	}

	/**
	 * 代码补全插件针对用户对文档的编辑处理
	 * @param editChange 文件修改事件
	 */
	dealEditChange(editChange: vscode.TextDocumentContentChangeEvent) {
		this._needToComplete = this._editChangeHandler.handleEditChange(editChange, this._completionInterceptor)
	}

	/**
	 * 在出现quick suggestion时，以 选项补充 prefix
	 * @param prefix
	 * @param suggestionKeyword
	 * @returns
	 */
	generateQuickSuggestionPrefix(prefix: string, suggestionKeyword: string): string {
		const sameWordLength = Math.min(prefix.length, suggestionKeyword.length)
		let i = sameWordLength
		while (i > 0) {
			if (prefix.substring(prefix.length - i) !== suggestionKeyword.substring(0, i)) {
				i--
			} else {
				break
			}
		}

		this._currKeywordInputLength = i
		return prefix.substring(0, prefix.length - i) + suggestionKeyword
	}

	//有效埋点
	private setInterception(completeChoices: any) {
		const params = this._metricProvider.setMetricParams({
			actionType: "autoCompletion",
			docId: this._completionResponse.docId,
			chatUuid: this._completionResponse.chatUuid,
			content: "",
			prompt: this._completionResponse.prompt,
			accType: "",
			contentType: "",
			delay: this._debounceWait,
		})
		const hasValues = completeChoices.some((item: { insertText: string }) => item.insertText)
		if (hasValues) {
			resInterception(params)
		}
	}

	private calculateTotalKeystrokes(): number {
		return this._editChangeHandler.getTotalKeystrokes()
	}
}
