import { InlineCompletionItem, InlineCompletionList } from "vscode"
import { ALL_BRACKETS } from "../util/consants"
import { Point, SyntaxNode } from "web-tree-sitter"
import { Response } from "../../types"
import { LoggerManager } from "../../util/logger"

export interface ExtractedValue {
	type: string
	text: string
}

export interface ExtractedContents {
	node: SyntaxNode | null
	extractedValues: Map<string, any>
}

export interface StreamBodyBase {
	stream: boolean
	n_predict?: number
	temperature?: number
}

export interface StreamOptionsLitellm extends StreamBodyBase {
	user_id: string
}

export interface StreamOptionsOllama extends StreamBodyBase {
	model: string
	keep_alive?: string | number
	messages?: Message[] | Message
	prompt: string
	options: Record<string, unknown>
}

export interface StreamBodyOpenAI extends StreamBodyBase {
	messages?: Message[] | Message
	max_tokens: number
}

export interface PrefixSuffix {
	prefixLineNum: number
	suffixLineNum: number
	currentLine: number
	totalLine: number
	prefix: string
	suffix: string
}

export type FileCommonData = {
	fileType: FileType
	version: number
	repo: string
	branch: string
	languageId: string
	relativePath: string
	totalLine: number
	codeInfo: CodeInfo | null
	content: string
}

/**
 * 相邻打开文件信息
 */
export interface NeighborFileItem {
	// 文件的上次访问时间
	lastVisited: number
	// 打开的文件名称
	name: string | null | undefined
	// 语言类型
	languageId: string
	source: string
	uri: string
}

export type FileType = "business" | "ut" | "ft"

export type CodeInfo = {
	functionList: Array<FunctionInfo>
	importList: Array<any>
	customTypeList: Array<StructInfo> | undefined
	macroDefinitionList: Array<MacroDefinitionInfo> | undefined
	globalVariableList: Array<VariableInfo>
	enumList: Array<EnumInfo> | undefined
	classList: Array<ClassInfo> | undefined
	updateTimeStamp: number
}

export interface PrefixSuffixRow {
	prefixLineNum: number
	suffixLineNum: number
}

export interface LanguageType {
	languageId: string | undefined
}

export interface ClientMessage<T = string | boolean | Message[]> {
	data?: T
	type?: string
	key?: string
}

export interface ServerMessage<T = LanguageType> {
	type: string
	value: {
		completion: string
		data?: T
		error?: boolean
		errorMessage?: string
		type: string
	}
}
export interface Message {
	role: string
	content: string | undefined
	type?: string
	language?: LanguageType
	error?: boolean
}

export interface Conversation {
	id?: string
	title?: string
	messages: Message[]
}

export interface DefaultTemplate {
	systemMessage?: string
}

export interface TemplateData extends Record<string, string | undefined> {
	systemMessage?: string
	code: string
	language: string
}
export interface FimTemplateData extends Record<string, string | undefined> {
	context: string
	fileName: string
	prefix: string
	suffix: string
	systemMessage: string
}

export interface ChatTemplateData {
	systemMessage?: string
	role: string
	messages: Message[]
	code: string
	language?: string
}

export interface FimPromptTemplate {
	context: string
	header: string
	prefixSuffix: PrefixSuffix
	fileContextEnabled: boolean
	language?: string
}

export interface ApiProviders {
	[key: string]: { fimApiPath: string; chatApiPath: string; port: number }
}

export type Bracket = (typeof ALL_BRACKETS)[number]

export interface StreamRequestOptions {
	hostname: string
	path: string
	port: string | number
	protocol: string
	method: string
	headers: Record<string, string>
}

export interface StreamRequest {
	isStream: boolean
	body: StreamBodyBase | StreamBodyOpenAI
	options: StreamRequestOptions
	controller: AbortController
	logger: LoggerManager
	onEnd?: () => void
	onStart?: () => void
	onError?: (error: Error) => void
	onData: (streamResponse: CompletionResponse | undefined) => void
}

export interface AxiosRequest {
	body: any
	options: { method: string; headers: Record<string, string>; proxy?: boolean }
	onData: (response: CompletionResponse | undefined) => void
	onStart?: (controller: AbortController) => void
	onError?: (error: Error) => void
	onEnd?: () => void
}

export interface CompatibleTransformer {
	start: () => void
	transform: (chunk: string, controller: { terminate: () => void }) => void
	flush: () => void
}

export interface CompatibleStreamReader {
	read: () => Promise<{ done: boolean; value?: string }>
	releaseLock: () => void
}

export const ApiProvidersData = {
	LiteLLM: "litellm",
	LlamaCpp: "llamacpp",
	LMStudio: "lmstudio",
	Ollama: "ollama",
	Oobabooga: "oobabooga",
	OpenWebUI: "openwebui",
} as const

export interface ApiModel {
	parent_model: string
	format: string
	family: string
	parameter_size: string
	digest: string
	model: string
	modified_at: string
	name: string
	size: number
}

export interface ApiModels {
	models: ApiModel[]
}

export type ResolvedInlineCompletion =
	| InlineCompletionItem[]
	| InlineCompletionList
	| PromiseLike<InlineCompletionItem[] | InlineCompletionList | null | undefined>
	| null
	| undefined

export interface InteractionItem {
	keyStrokes: number | null | undefined
	lastVisited: number
	name: string | null | undefined
	sessionLength: number
	visits: number | null | undefined
	activeLines: {
		line: number
		character: number
	}[]
}

export interface InferenceProvider {
	apiBaseUrl?: string
	apiHostname?: string
	apiKey?: string
	apiPath?: string
	apiPort?: number
	apiProtocol?: string
	modelName?: string
	name: string
	type: (typeof ApiProvidersData)[keyof typeof ApiProvidersData]
}

/**
 * 相似代码片段打分
 */
export interface SnippetScore {
	snippet: string
	languageId: string
	name: string | null | undefined
	score: number
	startLine: number
	endLine: number
}

export type SimilarCodeData = {
	code: string
	score: number
	project: string
	source: string
	vector_score?: string
	keyword_score?: string
}

/**
 * 代码片段枚举
 */
export enum SnippetSelectionOption {
	// eslint-disable-next-line no-unused-vars
	BestMatch,
	// eslint-disable-next-line no-unused-vars
	TopK,
}

/**
 * 记录文件会话
 */
export interface FileInteractionSessionItem {
	// 文件的上次访问时间
	lastVisited: number
	// 打开的文件名称
	name: string | null | undefined
	// 语言类型
	languageId: string
}

/**
 * 文件片段 窗口 token 集合
 */
export interface FileSnippetToken {
	tokenSet: Set<string>
	startLine: number
	endLine: number
}
/**
 * 位置范围
 */
export type PointRange = {
	startPoint: Point
	endPoint: Point
}

/**
 * 函数信息
 */
export type FunctionInfo = {
	// 类名
	className: string
	// 返回类型
	returnType: string
	// 函数声明，仅不包含返回值
	functionDeclarator: string
	// 参数列表
	parameterList: Array<ParamInfo>
	// 函数块范围
	blockRange: PointRange
	// 函数签名，包含返回值、参数
	functionSign: string
	// 函数签名范围
	functionSignBlockRange: PointRange
	// 局部变量列表
	localVariableList: Array<VariableInfo>
	// 函数调用列表
	callExpressionList: Array<CallFuncInfo>
	// 关联代码
	associatedCodeList: string[]
	// 函数定义
	functionDefinition: string
	// 函数名
	functionName: string
	// 函数索引
	functionIndex: string
	// 是否有语法错误
	isHasGrammarError: boolean
}

/**
 * 变量信息
 */
export type VariableInfo = {
	// 变量声明
	variableText: string
	// 作用范围，语法树父节点位置区间
	curBlockRange: PointRange
	// 变量定义位置区间
	pointRange: PointRange
	// 是否为全局变量
	isGlobal: boolean
	// 变量类型
	variableType: string
}

/**
 * 结构体信息
 */
export type StructInfo = {
	// 结构体声明
	structText: string
	structName: string
	// 局部变量列表
	localVariableList: Array<VariableInfo>
	// 调用列表
	callExpressionList: Array<CallFuncInfo>
	pointRange: PointRange
	curBlockRange: PointRange
	isHasGrammarError: boolean
}

/**
 * 宏定义信息
 */
export type MacroDefinitionInfo = {
	// 结构体声明
	macroName: string
	pointRange: PointRange
}

export interface MethodInfo {
	methodName: string
	pointRange: PointRange
	returnType: string
	parameters: Array<VariableInfo>
}

export enum RetrieveMethod {
	// eslint-disable-next-line no-unused-vars
	Function,
	// eslint-disable-next-line no-unused-vars
	FixWindow,
}

export type ParamInfo = {
	paramText: string
	variableType: string
}

export interface CompletionRespData {
	result: string
	chatUuid: string
	docId: string
	formattedCompletion: string
	prompt: string
	finishReason: string
}

export interface ContextualCompletion {
	languageId?: string
	prefixLineNum: number
	suffixLineNum: number
	currentLine: number
	totalLine: number
	prefix: string
	suffix: string
	prefixSuffixBlockRange?: PointRange
	currentLinePrefix?: string
	currentLineSuffix?: string
	retrieveMethod: RetrieveMethod
	eol?: string
	completeChoices: any[]
	completionRespData: CompletionRespData
	smartInterceptor: boolean
	completionType?: string
	vscodeTip?: string
	completionText?: string
	traceId?: string
	rawPrompt?: string
}

export interface CompletionCacheValue {
	currentLine: string
	completionResText: string
	traceId: string
}

/**
 * 枚举信息
 */
export type EnumInfo = {
	// 声明
	enumText: string
	enumName: string
	pointRange: PointRange
	curBlockRange: PointRange
}

/**
 * 类定义信息
 */
export type ClassInfo = {
	// 声明
	classText: string
	className: string
	// 局部变量列表
	localVariableList: Array<VariableInfo>
	// 调用列表
	callExpressionList: Array<CallFuncInfo>
	pointRange: PointRange
	curBlockRange: PointRange
	isHasGrammarError: boolean
}

/**
 * 被调用函数信息
 */
export type CallFuncInfo = {
	//调用函数名称
	callFuncName: string
	// 声明
	callFuncText: string
	pointRange: PointRange
}

/**
 * 被调用信息
 */
export type CallInfo = {
	// 声明
	callFuncText: string[]
	callMulDefineText: string[]
}

export type CodeBlock = {
	startPoint: Point
	endPoint: Point
	functionSignBlockRange?: PointRange
	isHasGrammarError: boolean
	code: string
}

/**
 * 被调用信息
 */
export type KnowledgeInfo = {
	// 声明
	FuncText: string[]
	EnumText: string[]
	StructText: string[]
	MacroText: string[]
	ClassText: string[]
}

export interface CompletionData {
	chatUuid: string
	docId: string
	finishReason: "stop" | "length"
	modelType: string
	result: string
}

/**
 * 补全接口返回
 */
export interface CompletionResponse extends Response<CompletionData> {}

export type CompletionType =
	| "InlineCompletion" // 行内补
	| "LineCompletion" // 单行补
	| "BlockCompletion" // 块补
	| "FunctionCompletion" // 函数补
	| "CommentCompletion" // 注释补
	| "UnitTestCompletion" // 补UT
	| "NotNeedCompletion" // 不补全

/**
 * 知识库返回结果
 */
export type KnowledgeResponseType = {
	code: string
	similarity: number
}

// 请求头
export interface RequestHeaderType {
	"Content-Type": string
	"X-Emp-No": string
	"X-Auth-Value": string
}

type AttributeValue = {
	stringValue?: string
	intValue?: number
	boolValue?: boolean
	doubleValue?: number
}

type Attribute = {
	key: string
	value: AttributeValue
}

type Span = {
	traceId: string
	spanId: string
	name: string
	startTimeUnixNano: string
	endTimeUnixNano: string
	kind: number
	attributes: Attribute[]
}

type ScopeSpan = {
	spans: Span[]
}

type Resource = {
	attributes: Attribute[]
}

type ResourceSpan = {
	resource: Resource
	scopeSpans: ScopeSpan[]
}

// 性能埋点请求body体类型
export type TraceType = {
	resourceSpans: ResourceSpan[]
}

export type ChangeDetail = {
	startPoint: Point
	endPoint: Point
	content: string
	count: number
	type: "add" | "remove"
}

export type CompletionSyntaxInfo = {
	curFunctionInfo: FunctionInfo | null
	curStructInfo: StructInfo | null
	curClassInfo: ClassInfo | null
	associatedCode: string[]
	structList: string[]
	enumList: string[]
	classList: string[]
	globalVariableList: VariableInfo[]
	macroDefinitionList: string[]
	dependencyPackageList: string[]
}

export type RemoteKnowledgeBaseType = {
	similarCodeTypeUser: string
	similarCodeTypeActual: string
}
