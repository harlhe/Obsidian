import { KnowledgeInfo } from "./index"
import { Point } from "web-tree-sitter"

export interface ISyntaxInfo {
	curFunctionSign: string
	associatedCode: string[]
	localVariableList: string[]
	globalVariableList: VariableInfo[]
	structList: string[]
	macroDefinitionList: string[]
	enumList: string[]
	classList: string[]
	dependencyPackageList: string[]
	localKnowledgeMsgList: KnowledgeInfo
}

/**
 * 变量信息
 */
export type VariableInfo = {
	// 变量声明
	variableText: string
	// 变量类型
	variableType: string
	// 作用范围，语法树父节点位置区间
	curBlockRange: PointRange
	// 变量定义位置区间
	pointRange: PointRange
	// 是否为全局变量
	isGlobal: boolean
}

/**
 * 位置范围
 */
export type PointRange = {
	startPoint: Point
	endPoint: Point
}

export interface IPoint {
	row: number
	column: number
}
