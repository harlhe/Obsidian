import { ApiProvidersData, Message, StreamBodyBase, StreamBodyOpenAI, StreamOptionsLitellm, StreamOptionsOllama } from "../types"

export function createStreamRequestBody(
	provider: string,
	options: {
		temperature: number
		numPredictChat: number
		model: string
		messages?: Message[]
		keepAlive?: string | number
	},
): StreamBodyBase | StreamOptionsOllama | StreamBodyOpenAI {
	switch (provider) {
		case ApiProvidersData.Ollama:
		case ApiProvidersData.OpenWebUI:
			return {
				model: options.model,
				stream: false,
				messages: options.messages,
				keep_alive: options.keepAlive === "-1" ? -1 : options.keepAlive,
				options: {
					temperature: options.temperature,
					num_predict: options.numPredictChat,
				},
			}
		case ApiProvidersData.LiteLLM:
		default:
			return {
				model: options.model,
				stream: false,
				max_tokens: options.numPredictChat,
				messages: options.messages,
				temperature: options.temperature,
			}
	}
}

export function createStreamRequestBodyFim(
	prompt: string,
): StreamBodyBase | StreamOptionsOllama | StreamBodyOpenAI | StreamOptionsLitellm {
	return JSON.parse(prompt)
}
