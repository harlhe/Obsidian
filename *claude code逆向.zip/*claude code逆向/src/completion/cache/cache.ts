import {
	PrefixSuffix,
	NeighborFileItem,
	FileCommonData,
	CompletionCacheValue,
	ContextualCompletion,
	SimilarCodeData,
} from "../types/index"
import { CHAT_JOIN_TAG } from "../util/consants"
import { Uri } from "vscode"
import { LINE_BREAK_REGEX, CACHE_LINE_JOIN_TAG } from "../util/consants"

export class LRUCache<T = string> {
	private capacity: number
	public cache: Map<string, T | null>

	constructor(capacity: number) {
		this.capacity = capacity
		this.cache = new Map()
	}

	getAll(): Map<string, T | null> {
		return this.cache
	}

	get(key: string): T | null | undefined {
		if (!this.cache.has(key)) return undefined

		const value = this.cache.get(key)
		this.cache.delete(key)
		if (value !== undefined) {
			this.cache.set(key, value)
		}
		return value
	}

	delete(key: string): void {
		this.cache.delete(key)
	}

	set(key: string, value: T | null): void {
		if (this.cache.has(key)) {
			this.cache.delete(key)
		} else if (this.cache.size === this.capacity) {
			const firstKey = this.cache.keys().next().value
			this.cache.delete(firstKey)
		}
		this.cache.set(key, value)
	}

	normalize(src: string): string {
		return src.split("\n").join("").replace(/\s+/g, "").replace(/\s/g, "")
	}

	getKey(prefixSuffix: PrefixSuffix): string {
		const { prefix, suffix } = prefixSuffix
		if (suffix) {
			return this.normalize(prefix + CHAT_JOIN_TAG + suffix)
		}
		return this.normalize(prefix)
	}

	getCache(prefixSuffix: PrefixSuffix): T | undefined | null {
		const key = this.getKey(prefixSuffix)
		return this.get(key)
	}

	setCache(prefixSuffix: PrefixSuffix, completion: T): void {
		const key = this.getKey(prefixSuffix)
		this.set(key, completion)
	}
}

export class NeighborFileItemCache {
	private cache: LRUCache<NeighborFileItem[]>

	constructor() {
		this.cache = new LRUCache<NeighborFileItem[]>(10)
	}

	get(uri: string): NeighborFileItem[] | null | undefined {
		return this.cache.get(uri)
	}

	set(uri: string, neighborFileItems: NeighborFileItem[]): void {
		this.cache.set(uri, neighborFileItems)
	}

	/**
	 * 缓存需要在目录中的文件出现增加或删除时失效
	 */
	delete(uri: string): void {
		this.cache.delete(uri)
	}

	deleteWithSameDir(fileUri: Uri) {
		const fileDir = Uri.joinPath(fileUri, "..").toString() // 获取 fileUri 的父目录
		for (let cacheKey of this.cache.getAll().keys()) {
			const cacheDir = Uri.joinPath(Uri.parse(cacheKey), "..").toString()
			if (cacheDir === fileDir) {
				this.cache.delete(cacheKey)
			}
		}
	}
}

export class FileDataCache {
	private cache: LRUCache<FileCommonData>

	constructor(capability: number) {
		this.cache = new LRUCache<FileCommonData>(capability)
	}

	get(uri: string): FileCommonData | null | undefined {
		return this.cache.get(uri)
	}

	set(uri: string, funcStrs: FileCommonData): void {
		this.cache.set(uri, funcStrs)
	}

	/**
	 * 缓存需要在目录中的文件出现增加或删除时失效
	 */
	delete(uri: string): void {
		this.cache.delete(uri)
	}
}
export class FileFuncCache {
	private cache: LRUCache<string[]>

	constructor() {
		this.cache = new LRUCache<string[]>(10)
	}

	get(uri: string): string[] | null | undefined {
		return this.cache.get(uri)
	}

	set(uri: string, funcStrs: string[]): void {
		this.cache.set(uri, funcStrs)
	}

	/**
	 * 缓存需要在目录中的文件出现增加或删除时失效
	 */
	delete(uri: string): void {
		this.cache.delete(uri)
	}
}

export class SimilarCodeCache {
	private cache: LRUCache<SimilarCodeData[]>
	private currentLine: string | undefined = ""

	constructor(capacity: number) {
		this.cache = new LRUCache<SimilarCodeData[]>(capacity)
	}

	get(key: string): SimilarCodeData[] | null | undefined {
		return this.cache.get(key)
	}

	set(key: string, value: SimilarCodeData[] | null): void {
		this.cache.set(key, value)
	}

	getKey(contextualCompletion: ContextualCompletion): string {
		let { prefix, suffix, eol } = contextualCompletion
		prefix = prefix.split(LINE_BREAK_REGEX).slice(0, -1).join(eol).trimEnd()
		if (suffix) {
			suffix = suffix.split(LINE_BREAK_REGEX).slice(1).join(eol).trimStart()
			return this.cache.normalize(prefix + CACHE_LINE_JOIN_TAG + suffix)
		}
		return this.cache.normalize(prefix)
	}

	getCache(contextualCompletion: ContextualCompletion): SimilarCodeData[] | undefined | null {
		const key = this.getKey(contextualCompletion)
		return this.get(key)
	}

	setCache(contextualCompletion: ContextualCompletion, similarCode: SimilarCodeData[]): void {
		if (similarCode) {
			const key = this.getKey(contextualCompletion)
			this.set(key, similarCode)
		}
	}

	delete(key: string): void {
		this.cache.delete(key)
	}

	public getAll() {
		return this.cache.cache
	}
}

export class CompletionLineCache {
	private cache: LRUCache<string>

	constructor(capacity: number) {
		this.cache = new LRUCache<string>(capacity)
	}

	get(key: string): string | null | undefined {
		return this.cache.get(key)
	}

	set(key: string, value: string | null): void {
		this.cache.set(key, value)
	}

	getKey(contextualCompletion: ContextualCompletion): string {
		let { prefix, suffix, eol } = contextualCompletion
		prefix = prefix.split(LINE_BREAK_REGEX).slice(0, -1).join(eol).trimEnd()
		if (suffix) {
			suffix = suffix.split(LINE_BREAK_REGEX).slice(1).join(eol).trimStart()
			return this.cache.normalize(prefix + CACHE_LINE_JOIN_TAG + suffix)
		}
		return this.cache.normalize(prefix)
	}

	getCache(contextualCompletion: ContextualCompletion): CompletionCacheValue | undefined | null {
		const key = this.getKey(contextualCompletion)
		const value = this.get(key)
		return value ? JSON.parse(value) : value
	}

	setCache(contextualCompletion: ContextualCompletion, completion: string, completionResText: string, traceId: string): void {
		const { currentLinePrefix } = contextualCompletion

		if (currentLinePrefix !== undefined && completion) {
			const key = this.getKey(contextualCompletion)
			const currentLine = currentLinePrefix + CACHE_LINE_JOIN_TAG + completion
			this.set(key, JSON.stringify({ currentLine, completionResText, traceId }))
		}
	}

	delete(key: string): void {
		this.cache.delete(key)
	}
}

export const completionLineCache = new CompletionLineCache(10)
export const cache = new LRUCache(100)
export const similarCodeCache = new SimilarCodeCache(20)
export const fileDataCache = new FileDataCache(50)
