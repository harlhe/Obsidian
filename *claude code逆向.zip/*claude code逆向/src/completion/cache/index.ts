import { cache, completionLineCache } from "./cache"

export { cache, completionLineCache }
