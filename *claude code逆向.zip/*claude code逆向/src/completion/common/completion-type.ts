import { TextDocument } from "vscode"
import path from "path"
import { LINE_BREAK_REGEX, WASM_LANGAUAGES } from "../util/consants"
import { CompletionType, PrefixSuffix } from "../types"
import { TestFrameType } from "../../types"

export class CompletionTypeHandler {
	private languageId: string = ""

	constructor(document: TextDocument) {
		const fileExtension = path.extname(document.uri.path).slice(1)
		this.languageId = WASM_LANGAUAGES[fileExtension]
	}

	getCompletionType(prefixSuffix: PrefixSuffix, testFrame: TestFrameType): CompletionType {
		if (!prefixSuffix) return "InlineCompletion"
		const { prefix, suffix } = prefixSuffix

		const _prefixArr = prefix.split(LINE_BREAK_REGEX)
		const prefixArr = _prefixArr.filter((item) => item.trim())
		const suffixArr: string[] = suffix.split(LINE_BREAK_REGEX)

		if (prefixArr.length === 0) {
			// 光标前内容为空
			if (suffixArr.length >= 0) {
				const firstLineSuffix = suffixArr[0]
				if (firstLineSuffix === "") {
					// 本行光标后没有内容
					return "LineCompletion"
				} else {
					// 本行光标后有内容
					return "InlineCompletion"
				}
			} else {
				// 光标前后均为空
				return "NotNeedCompletion"
			}
		} else {
			// 光标前内容不为空
			const lastLinePrefix = prefixArr.pop()!
			const penultimateLinePrefix = prefixArr.length != 0 ? prefixArr.pop()! : ""
			const firstLineSuffix = suffixArr[0]

			if (firstLineSuffix.trim() === "") {
				// 光标后没有内容
				// 是否为注释
				if (this.isComment(lastLinePrefix.trim(), this.languageId)) {
					return "CommentCompletion"
				}
				// 是否为逻辑块
				if (this.isBlock(lastLinePrefix.trim(), this.languageId)) {
					return "BlockCompletion"
				}
				// 是否为函数签名
				if (lastLinePrefix.trim().startsWith("{")) {
					if (penultimateLinePrefix && this.isFunction(penultimateLinePrefix, this.languageId)) {
						return this.isUtTest(penultimateLinePrefix.trim(), this.languageId, testFrame)
							? "UnitTestCompletion"
							: "FunctionCompletion"
					}
				} else {
					if (this.isFunction(lastLinePrefix.trim(), this.languageId)) {
						return this.isUtTest(lastLinePrefix.trim(), this.languageId, testFrame)
							? "UnitTestCompletion"
							: "FunctionCompletion"
					}
				}

				// 其他
				return _prefixArr.pop()?.trim() ? "InlineCompletion" : "LineCompletion"
			} else {
				// 光标后有内容
				if (
					firstLineSuffix.startsWith("}") ||
					firstLineSuffix.startsWith("]") ||
					firstLineSuffix.startsWith(")") ||
					firstLineSuffix.startsWith('"') ||
					firstLineSuffix.startsWith("'")
				) {
					return "InlineCompletion"
				} else {
					return "NotNeedCompletion"
				}
			}
		}
	}

	private isUtTest(codeStr: string, language: string, testFrame: TestFrameType): boolean {
		// 测试框架目前只针对c/cpp语言
		if (!language || (language !== "c" && language !== "cpp")) return false

		// 去除字符串两端的空白字符
		codeStr = codeStr.trim()
		if (testFrame === "gtest") {
			// 测试框架为gtest
			return this.isGtestFunction(codeStr)
		} else if (testFrame === "cunit") {
			// 测试框架为cunit
			return this.isCUnitTestFunction(codeStr)
		} else if (testFrame === "cppunit") {
			// 测试框架为cppunit
			return this.isCppUnitTestFunction(codeStr)
		}

		return false
	}

	private isGtestFunction(funcStr: string): boolean {
		// 正则表达式解释：
		// ^\s*：匹配字符串开始处的任意数量的空白字符。
		// TEST：匹配字符串 "TEST"。
		// (?:_F|_P)?：非捕获组，匹配 "_F" 或 "_P"，出现0次或1次。
		// \s*：匹配任意数量的空白字符。
		// \(：匹配左括号 "("。
		// [A-Za-z0-9_]+：匹配一个或多个字母、数字或下划线（测试套签名或类名）。
		// \s*：匹配任意数量的空白字符。
		// ,：匹配逗号。
		// \s*：再次匹配任意数量的空白字符。
		// [A-Za-z0-9_]+：匹配一个或多个字母、数字或下划线（测试用例描述）。
		// \s*\)：匹配任意数量的空白字符和一个右括号 ")"。
		const regex = /^\s*TEST(?:_F|_P)?\s*\(\s*[A-Za-z0-9_]+\s*,\s*[A-Za-z0-9_"-]+\s*\)/
		return regex.test(funcStr)
	}

	private isCUnitTestFunction(funcStr: string): boolean {
		// 正则表达式解释：
		// ^\s*void\s+：匹配字符串开始处的任意数量的空白字符后跟关键字void和至少一个空白字符
		// [A-Za-z0-9_]+：匹配测试用例描述，由字母、数字或下划线组成
		// Test\s*\(\s*void\s*\)：匹配Test后跟任意数量的空白字符、左括号、void参数和右括号
		const regex = /^\s*void\s+[A-Za-z0-9_]+Test\s*\(\s*void\s*\)\s*/
		return regex.test(funcStr)
	}

	private isCppUnitTestFunction(funcStr: string): boolean {
		// 正则表达式1：匹配 virtual void runTest() override
		const regex1 = /^\s*virtual\s+void\s+runTest\s*\(\s*\)\s*override\s*/

		// 正则表达式2：匹配 void 测试用例描述Test()
		// 这里使用 [A-Za-z0-9_]+ 来匹配测试用例描述部分
		const regex2 = /^\s*void\s+[A-Za-z0-9_]+Test\s*\(\s*\)\s*/

		return regex1.test(funcStr) || regex2.test(funcStr)
	}

	private isFunction(codeStr: string, language: string): boolean {
		if (!language) {
			return false
		}
		// 去除字符串两端的空白字符
		codeStr = codeStr.trim()
		// 注释符合
		let commentSymbol
		// 根据编程语言来定义函数定义的正则表达式
		let functionPattern: RegExp

		switch (language.toLowerCase()) {
			case "javascript":
			case "python":
				// JavaScript 和 Python 中的函数定义通常以 'function' 关键字开始
				functionPattern = /^\s*function\s+\w+/
				commentSymbol = "#"
				break
			case "c":
			case "cpp":
			case "java":
				// C/C++/Java 中的函数定义通常包括返回类型、函数名和参数列表
				functionPattern = /^\s*(\w+\s+)*[\w|:]+\s*\(.*\)\s*\{?\s*$/
				commentSymbol = "//"
				break
			case "scala":
				functionPattern = /^\s*def\s+\w+/
				commentSymbol = "//"
				break
			default:
				// 如果不是以上语言，返回 false
				return false
		}
		if (codeStr.startsWith(commentSymbol) || codeStr.includes(` ${commentSymbol}`)) {
			codeStr = codeStr.substring(0, codeStr.indexOf(commentSymbol))
		}
		// 测试字符串是否匹配函数定义模式
		return functionPattern.test(codeStr)
	}

	private isBlock(codeStr: string, language: string): boolean {
		if (!language) {
			return false
		}
		// 去除字符串两端的空白字符
		codeStr = codeStr.trim()

		// 定义可能的代码块关键字
		const blockKeywords: { [key: string]: string[] } = {
			c: ["if", "while", "for", "switch", "case", "default"],
			cpp: ["if", "while", "for", "switch", "case", "default", "class"],
			java: ["if", "while", "for", "switch", "case", "default", "class"],
			javascript: ["if", "while", "for", "switch", "case", "default", "function"],
			python: ["if", "while", "for", "def", "class"],
			// 其他语言可以继续添加
		}

		// 获取对应语言的关键字列表
		const keywords = blockKeywords[language.toLowerCase()]

		// 如果没有为该语言定义关键字，则返回 false
		if (!keywords) {
			return false
		}

		// 检查字符串是否以任何一个关键字开始
		for (const keyword of keywords) {
			if (codeStr.startsWith(keyword)) {
				return true // 找到匹配的关键字，返回 true
			}
		}

		// 没有找到匹配的关键字，返回 false
		return false
	}

	private isComment(codeStr: string, language: string): boolean {
		if (!language) {
			return false
		}
		// 去除字符串两端的空白字符
		codeStr = codeStr.trim()

		// 根据编程语言来定义注释的正则表达式
		let commentPattern: RegExp

		switch (language.toLowerCase()) {
			case "c":
			case "cpp":
			case "java":
			case "javascript":
			case "scala":
				// 检查是否是单行注释或多行注释的开始
				commentPattern = /^\s*(\/\/|\/\*).*/
				break
			case "python":
				// 检查是否是单行注释
				commentPattern = /^#.*/
				break
			default:
				// 如果不是以上语言，返回 false
				return false
		}

		// 测试字符串是否匹配注释模式
		return commentPattern.test(codeStr)
	}
}
