import { CodeInfo, FileType } from "./../types/index"
import { Background } from "../../util/background"
import { fileDataCache } from "../cache/cache"
import { FileCommonData } from "../types"
import { existsSync, readFileSync } from "fs"
import { Logger } from "../../util/logger"
import setting from "../config/setting.json"
import { TextDocument, Uri, workspace } from "vscode"
import path from "path"
import { WASM_LANGAUAGES } from "../util/consants"
import * as vscode from "vscode"
import { CodeParser } from "../handler/code-parser"
import { loadSystemEnv } from "../util"
import { parseFileType } from "../util/tree-sitter-util"

export let systemEnv: NodeJS.ProcessEnv | undefined = undefined

export class FileCommonInfo {
	private repo: string
	private branch: string
	private fsPath: string | undefined
	private fileText: string | undefined
	private lineCount: number | undefined
	private languageId: string | undefined
	private version: number | undefined
	private document: TextDocument | undefined

	constructor(document?: TextDocument) {
		this.repo = Background.get().absolutRepoName
		this.branch = Background.get().branch
		if (!this.repo && !this.branch) {
			systemEnv = systemEnv ?? loadSystemEnv()
			this.repo = systemEnv.COPILOT_EVAL_PROJECT ?? ""
			this.branch = systemEnv.COPILOT_EVAL_BRANCH ?? ""
		}
		if (document) {
			const extname = path.extname(document.uri.fsPath).slice(1)
			this.languageId = WASM_LANGAUAGES[extname] ?? document.languageId!
			this.repo = this.adoptyCopilotEval(this.repo, document.uri.path)
			this.document = document
		}
	}

	public setFileBaseInfo(
		fsPath: string,
		fileText: string,
		lineCount: number,
		languageId: string,
		version: number,
		absoluteFile: string,
	) {
		this.fsPath = fsPath
		this.fileText = fileText
		this.lineCount = lineCount
		this.languageId = languageId
		this.languageId = languageId
		this.version = version
		this.repo = this.adoptyCopilotEval(this.repo, absoluteFile)
	}

	public async fileActiveDo(position: vscode.Position | undefined = undefined): Promise<FileCommonData | undefined> {
		const filePath = this.fsPath ?? this.document?.uri.fsPath
		const lineCount = this.lineCount ?? this.document?.lineCount
		const version = this.version ?? this.document?.version
		if (!filePath || !lineCount || !version || !this.languageId) return
		let fileText: string | undefined
		let fileData: FileCommonData | null | undefined = fileDataCache.get(filePath)
		if (fileData && fileData.version === this.document?.version) return fileData

		const fileType: FileType = await parseFileType(filePath)
		const relativePath: string = Background.get().relativePath

		let codeInfo: CodeInfo | null = null
		const shouldCacheContent = lineCount < setting.complete.maxFileLineForCache
		if (fileData) {
			fileData.codeInfo = codeInfo
			if (shouldCacheContent) {
				fileText = this.fileText ?? this.document?.getText()
				if (fileText) {
					if (this.document) {
						fileData.codeInfo = await new CodeParser(this.document).parse(fileText, position)
					} else {
						const codeParser = new CodeParser()
						codeParser.init(filePath, this.languageId)
						fileData.codeInfo = await codeParser.parse(fileText, position)
					}
				}
			}
			fileData.version = version
			fileData.content = fileText ?? ""
			fileData.totalLine = lineCount
			fileData.languageId = this.languageId
			fileData.relativePath = relativePath
			fileDataCache.set(filePath, fileData)
			return fileData
		}
		fileData = {
			version: version,
			fileType: fileType,
			repo: this.repo,
			branch: this.branch,
			relativePath: relativePath,
			languageId: this.languageId,
			totalLine: lineCount,
			content: fileText ?? "",
			codeInfo: codeInfo,
		}
		fileDataCache.set(filePath, fileData)
		if (shouldCacheContent) {
			fileText = this.fileText ?? this.document?.getText()
			if (fileText) {
				fileData.content = fileText
				if (this.document) {
					fileData.codeInfo = await new CodeParser(this.document).parse(fileText, position)
				} else {
					const codeParser = new CodeParser()
					codeParser.init(filePath, this.languageId)
					fileData.codeInfo = await codeParser.parse(fileText, position)
				}
				fileDataCache.set(filePath, fileData)
			}
		}
		return fileData
	}

	// 窗口解析
	public async windowParse(position: vscode.Position | undefined): Promise<CodeInfo | null> {
		if (!position) {
			Logger("info", `windowParse position为空, 超过解析阈值，不进行窗口解析。`)
			return null
		}
		if (!this.document) return null
		const codeParser = new CodeParser(this.document)
		// 取光标前后1000行代码进行解析
		Logger("info", `parse between 1000 lines of cursor`)
		const windowsParseLength: number = setting.complete.maxWindowParseLength
		const halfOfWindowLength: number = windowsParseLength / 2
		const startLine = position.line - halfOfWindowLength > 0 ? position.line - halfOfWindowLength : 0
		const remainCount = windowsParseLength - (position.line - startLine)
		const endLine = remainCount > 0 ? position.line + remainCount : this.document?.lineCount
		const newText = this.document?.getText(new vscode.Range(startLine, 0, endLine, 0))
		const codeInfo = await codeParser.parse(newText ?? "", position)

		if (codeInfo) {
			// 对结构进行位置修正
			codeInfo.functionList.forEach((func) => {
				func.blockRange.startPoint.row += startLine
				func.blockRange.endPoint.row += startLine
			})
			codeInfo.customTypeList?.forEach((type) => {
				type.pointRange.startPoint.row += startLine
				type.pointRange.endPoint.row += startLine
			})
			codeInfo.classList?.forEach((cls) => {
				cls.pointRange.startPoint.row += startLine
				cls.pointRange.endPoint.row += startLine
			})
		}

		return codeInfo
	}

	public async getNeighborFileInfo() {
		if (!this.document) return
		const currentFileUri = this.document.uri
		const currentDirPath = Uri.joinPath(currentFileUri, "..")
		if (!existsSync(currentDirPath.fsPath)) {
			return
		}
		const dirEntries = await workspace.fs.readDirectory(currentDirPath)

		// 处理当前目录中的文件
		for (const [fileName, fileType] of dirEntries) {
			if (fileType === vscode.FileType.File) {
				const fileUri = Uri.joinPath(currentDirPath, fileName)
				if (fileUri.fsPath === currentFileUri.fsPath) {
					continue
				}
				const existingFile = fileDataCache.get(fileUri.fsPath)

				if (!existingFile) {
					const fileText = readFileSync(fileUri.fsPath, "utf8")
					const lineCount = fileText.split("\n").length
					const _fileType: FileType = await parseFileType(fileUri.fsPath)
					const extname = path.extname(fileUri.fsPath).slice(1)
					const languageId = WASM_LANGAUAGES[extname] ?? ""
					const updatedFileInfo = {
						version: -1,
						fileType: _fileType,
						repo: this.repo,
						branch: this.branch,
						relativePath: "",
						totalLine: lineCount,
						languageId: languageId,
						content: lineCount > setting.complete.neighborFileLineCountLimit ? "" : fileText,
						codeInfo: null,
					}
					fileDataCache.set(fileUri.fsPath, updatedFileInfo)
				} else {
					if (existingFile.version === -1) continue
					if (existingFile.totalLine > setting.complete.neighborFileLineCountLimit) {
						existingFile.content = ""
						existingFile.codeInfo = null
					}
					fileDataCache.set(fileUri.fsPath, existingFile)
				}
			}
		}
	}

	private adoptyCopilotEval(repo: string, absoluteFile: string) {
		let project = repo
		return project
	}
}
