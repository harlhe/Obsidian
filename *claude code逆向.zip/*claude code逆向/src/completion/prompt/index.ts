import { FileInteractionCache } from "./file-interaction"

export { FileInteractionCache }
