import * as vscode from "vscode"
import path from "path"
import { Position, TabInputText, TextDocument, Uri } from "vscode"
import { fileDataCache, FileFuncCache, LRUCache, NeighborFileItemCache } from "../cache/cache"
import { Tree } from "web-tree-sitter"
import { SyntaxTreeAnalysis } from "../SyntaxTreeAnalysis/SyntaxTreeAnalysis"
import { SyntaxTreeAnalysisC } from "../SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisC"
import { SyntaxTreeAnalysisCpp } from "../SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisCpp"
import { SyntaxTreeAnalysisJavaScript } from "../SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisJavaScript"
import setting from "../config/setting.json"
import { languageIgnoreKeywordSet, WASM_LANGAUAGES } from "../util/consants"
import { getParser, GetParserResult } from "../util/tree-sitter-util"
import { FileInteractionSessionItem, FileSnippetToken, NeighborFileItem } from "../../types"
import {
	ContextualCompletion,
	FileCommonData,
	PointRange,
	RetrieveMethod,
	SimilarCodeData,
	SnippetScore,
	SnippetSelectionOption,
} from "../types"
import { calculateSHA256 } from "../../util/crypto-util"
import { FileNameCache } from "./file-name"
import { SyntaxTreeAnalysisJava } from "../SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisJava"
import { readFileSync, existsSync } from "fs"
import { SyntaxTreeAnalysisScala } from "../SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisScala"
import { pretreatment } from "../SyntaxTreeAnalysis/InlineCompletionInfo"
import { Logger } from "../../util/logger"
import { DirectoryCacheService } from "../service/directoryCacheService"

abstract class FileSnippetsSpliter {
	abstract retrieveCurrFileSnippetsByFixedBlock(): Array<SnippetScore>
	abstract retrieveCurrFileSnippetsByFunc(): Promise<Array<SnippetScore>>

	abstract retrieveAllSnippets(neighborFile: NeighborFileItem): SnippetScore[]
	abstract retrieveAllSnippetsByFunc(neighborFile: NeighborFileItem): Promise<SnippetScore[]>

	abstract getHotFiles(): Promise<NeighborFileItem[]>
	abstract getSimilarFilesFromCurrentDir(): Promise<NeighborFileItem[]>
}

class FixWindowSnippetsFinder {
	private file: FileSnippetsSpliter

	constructor(file: FileSnippetsSpliter) {
		this.file = file
	}

	async getSnippets(referenceTokens: Set<string>, referenceFiles: NeighborFileItem[]): Promise<SnippetScore[]> {
		let snippets: SnippetScore[] = []
		referenceFiles.forEach((neighborFile) => {
			const fileContent = neighborFile.source
			if (0 === fileContent.length || 0 === referenceTokens.size) {
				return
			}

			snippets.push(...this.file.retrieveAllSnippets(neighborFile))
		})

		snippets.push(...this.file.retrieveCurrFileSnippetsByFixedBlock())
		return snippets
	}
}

class FuncBolckSnippetsFinder {
	private file: FileSnippetsSpliter

	constructor(file: FileSnippetsSpliter) {
		this.file = file
	}

	async getSnippets(referenceTokens: Set<string>, neighborFiles: NeighborFileItem[]): Promise<SnippetScore[]> {
		let snippets: SnippetScore[] = []

		for (const neighborFile of neighborFiles) {
			const fileContent = neighborFile.source
			if (0 === fileContent.length || 0 === referenceTokens.size) {
				continue
			}
			const fileSnippetScores = await this.file.retrieveAllSnippetsByFunc(neighborFile)
			snippets.push(...fileSnippetScores)
		}

		snippets.push(...(await this.file.retrieveCurrFileSnippetsByFunc()))
		return snippets
	}
}
class SnippetsFinder {
	constructor(private file: NeighborFileSnippet) {}

	public async getSnippets(referenceTokens: Set<string>, retrieve: RetrieveMethod) {
		let referenceFiles
		if (this.file._openTabFileSnippetsEnbaled) {
			referenceFiles = await this.file.getHotFiles()
		} else {
			const time = Date.now()
			referenceFiles = await this.file.getSimilarFilesFromCurrentDir()
			Logger("info", Date.now() - time, "getSimilarFilesFromCurrentDirTime")
		}
		if (retrieve === RetrieveMethod.FixWindow) {
			const time = Date.now()
			const result = await new FixWindowSnippetsFinder(this.file).getSnippets(referenceTokens, referenceFiles)
			Logger("info", Date.now() - time, "getSnippetsTime")
			return result
		} else {
			return await new FuncBolckSnippetsFinder(this.file).getSnippets(referenceTokens, referenceFiles)
		}
	}
}

/**
 * 相邻文件代码片段
 */
export class NeighborFileSnippet extends FileSnippetsSpliter {
	// 文件代码片段长度限制
	private _snippetLength = setting.complete.snippetLength as number
	private _prefixSuffix: ContextualCompletion | undefined
	private _fileNameCache: FileNameCache | undefined
	private _fileCommonData!: FileCommonData
	private _queryBlockRange!: PointRange
	private _contextRetrieveMethod: RetrieveMethod = RetrieveMethod.Function
	public _openTabFileSnippetsEnbaled!: boolean
	private _neighborFileLimit = setting.complete.neighborFileLimit as number
	private _neighborFileLineCountLimit = setting.complete.neighborFileLineCountLimit as number

	/**
	 * 文件代码片段缓存
	 */
	private _cacheSnippets = new LRUCache<FileSnippetToken[]>(30)
	private _cacheNeighborFileItems = new NeighborFileItemCache()
	private _cacheFileFuncStrs = new FileFuncCache()
	/**
	 * 上下文的token集合
	 */
	private _referenceTokens: Set<string> = new Set()

	/**
	 * 代码片段数量
	 */
	private _snippetLimit = setting.complete.snippetLimit as number

	/**
	 * 代码片段相似度阈值
	 */
	private _snippetSimilarityThreshold = setting.complete.snippetSimilarityThreshold as number

	/**
	 * Tab 文件交互,打开文件列表
	 */
	private _fileInteractions = new LRUCache<FileInteractionSessionItem>(30)

	/**
	 * 当前编辑文件
	 */
	private document!: TextDocument

	/**
	 * 当前光标位置
	 */

	private position!: Position

	/**
	 * 相似代码片段开关
	 */
	private _snippetSimilaritySwitch = setting.complete.snippetSimilaritySwitch as boolean

	// 代码扫描步长
	private _snippetScanStep = setting.complete.snippetScanStep as number

	// 扫描代码片段的文件行限制
	private _snippetFileRowsLimit = setting.complete.snippetFileRowsLimit as number

	// 当前打开的文件列表
	private _openedTabFiles = new LRUCache<vscode.TextDocument>(30)

	constructor() {
		super()
		this.getAllOpenFiles()
	}

	public initDocument(
		document: TextDocument,
		position: Position,
		queryContent: string,
		similarRetrieveMethod: RetrieveMethod,
		fileNameCache: FileNameCache,
		fileCommonData: FileCommonData,
		openTabFileSnippetsEnbaled: boolean,
		queryBlockRange: PointRange,
	) {
		this.document = document
		this.position = position
		this._fileNameCache = fileNameCache
		this._fileCommonData = fileCommonData
		this._contextRetrieveMethod = similarRetrieveMethod
		this._openTabFileSnippetsEnbaled = openTabFileSnippetsEnbaled
		this._referenceTokens = this.tokenize(queryContent)
		this._queryBlockRange = queryBlockRange
	}

	/**
	 * 返回打开文件在指定大小窗口的所有可能返回结果范围列表
	 *
	 * windowRowSize = 2
	 * rowArray 共有7行的返回结果
	 *  [ [ 0, 2 ], [ 1, 3 ], [ 2, 4 ], [ 3, 5 ], [ 4, 6 ], [ 5, 7 ] ]
	 *
	 * @param windowRowSize 滑动窗口大小，窗口行数
	 * @param stepSize 窗口步长
	 * @param fileRowLength 打开文件的行数
	 * @returns 所有可能的窗口结果范围列表
	 */
	getWindowDelineations(windowRowSize: number, fileStartRow: number = 0, fileEndRow: number): number[][] {
		const allPossibleSnippet: number[][] = []
		const rowSize = fileEndRow - fileStartRow
		if (0 == rowSize) {
			return []
		}

		if (rowSize <= windowRowSize) {
			return [[fileStartRow, fileEndRow]]
		}

		for (let t = fileStartRow; t < fileEndRow - windowRowSize + 1; t = t + this._snippetScanStep) {
			allPossibleSnippet.push([t, t + windowRowSize])
		}

		return allPossibleSnippet
	}

	/**
	 * 提取语句的有效关键字
	 * @param sentence 语句
	 * @returns
	 */
	private tokenize(sentence: string): Set<string> {
		const tokenArray = this.splitIntoWords(sentence).filter((e) => !languageIgnoreKeywordSet.has(e))
		return tokenArray.length > 0 ? new Set(tokenArray) : new Set()
	}

	private splitIntoWords(sentence: string) {
		return sentence.split(/[^a-zA-Z0-9]/).filter((e) => e.length > 0)
	}

	private splitIntoWordsForFileName(sentence: string) {
		const nameWithoutExt = sentence.substring(0, sentence.lastIndexOf("."))

		return nameWithoutExt
			.split(/[-_.]/)
			.flatMap((part) => part.split(/(?=[A-Z][a-z])|(?<=[a-z])(?=[A-Z])/))
			.map((word) => word.toLowerCase())
			.filter((word) => word.length > 0)
	}

	/**
	 *  Jaccard 相似度计算方法,计算两块代码片段的相似度
	 * @param firstSnippetTokens
	 * @param secondSnippetTokens
	 * @returns
	 */
	private calculateSimilarity(firstSnippetTokens: string[], secondSnippetTokens: string[]): number {
		const intersection = new Set([...firstSnippetTokens].filter((x) => secondSnippetTokens.includes(x)))
		const union = new Set([...firstSnippetTokens, ...secondSnippetTokens])

		const jaccardSimilarity = intersection.size / union.size
		return jaccardSimilarity
	}

	public async retrieveAllSnippetsByFunc(neighborFile: NeighborFileItem): Promise<SnippetScore[]> {
		return this.getFileSnippetScores(await this.retrieveAllCodeSnippetsByFunc(neighborFile), neighborFile)
	}

	private async retrieveAllCodeSnippetsByFunc(neighborFile: NeighborFileItem): Promise<Array<string>> {
		const fileFuncStrFromCache = this._cacheFileFuncStrs.get(neighborFile.uri)
		if (fileFuncStrFromCache) {
			return fileFuncStrFromCache
		}
		const codeSource = neighborFile.source
		const languageId = neighborFile.languageId
		let prefixResult: GetParserResult | null = await getParser(languageId)
		let syntaxTreeAnalysis: SyntaxTreeAnalysis
		const tree: Tree = prefixResult!.parser.parse(pretreatment(languageId, codeSource))

		switch (languageId) {
			case "c":
				syntaxTreeAnalysis = new SyntaxTreeAnalysisC(tree!, prefixResult!.parser)
				break
			case "cpp":
				syntaxTreeAnalysis = new SyntaxTreeAnalysisCpp(tree!, prefixResult!.parser)
				break
			case "java":
				syntaxTreeAnalysis = new SyntaxTreeAnalysisJava(tree!, prefixResult!.parser)
				break
			case "javascript":
				syntaxTreeAnalysis = new SyntaxTreeAnalysisJavaScript(tree!, prefixResult!.parser)
				break
			case "scala":
				syntaxTreeAnalysis = new SyntaxTreeAnalysisScala(tree!, prefixResult!.parser)
				break
		}

		const functionBodyList = syntaxTreeAnalysis!.getFunctionBodyList()
		this._cacheFileFuncStrs.set(neighborFile.uri, functionBodyList)
		return functionBodyList
	}

	/**
	 * 对代码片段根据打分倒序排列
	 * @param snippetArray 代码片段集合
	 * @returns
	 */
	private filterSortScoredSnippets(snippetArray: SnippetScore[] = []) {
		// 对代码片段进行排重，代码片段前后的空行，会产生除空行外相同的代码片段
		const snippetSet = new Set()

		let filterScoreArray = snippetArray.filter((item) => {
			if (snippetSet.has(item.snippet)) {
				return false
			}

			snippetSet.add(item.snippet)
			return item.score > this._snippetSimilarityThreshold
		})

		filterScoreArray.sort((a, b) => b.score - a.score)
		return filterScoreArray
	}

	/**
	 * 获取文件中的代码片段范围集合，按照score 倒序排列结构如下
	 *      score: 0.7,
	 *      startLine: startLine,
	 *      endLine: endLine
	 *
	 * @param fileContent 文件文本
	 * @returns
	 */
	public retrieveAllSnippets(neighborFile: NeighborFileItem): SnippetScore[] {
		let fileContent: string = neighborFile.source

		const allSnippet: SnippetScore[] = []
		if (0 === fileContent.length || 0 === this._referenceTokens.size) {
			return allSnippet
		}

		let sourceRows = fileContent.split("\n")
		// 如果文件的行数超过限制，进行截取
		sourceRows = sourceRows.slice(0, Math.min(this._snippetFileRowsLimit, sourceRows.length))

		// 使用文件内容的 sha256 作为缓存key
		const key = calculateSHA256(fileContent)
		// key: [滑动窗口代码片段1 token, 滑动窗口代码片段2 token]
		const windowTokenSetArray: FileSnippetToken[] = this._cacheSnippets.get(key) ?? []
		const fileTokenCached = windowTokenSetArray.length > 0

		// 存在文件窗口 token 缓存
		if (!fileTokenCached) {
			// 没有文件窗口token 缓存
			// 把文件拆分成行toke集合，[[token1,token2],[token1,token2],...]
			let tokens: any[] = sourceRows.map((row) => this.tokenize(row))

			// 遍历文件根据窗口大小划分后的窗口列表
			for (const [, [startLine, endLine]] of this.getWindowDelineations(
				this._snippetLength,
				0,
				sourceRows.length,
			).entries()) {
				const snapTokenSet = new Set<string>()
				tokens.slice(startLine, endLine).forEach((t) => t.forEach(snapTokenSet.add, snapTokenSet))
				windowTokenSetArray.push({
					tokenSet: snapTokenSet,
					startLine: startLine,
					endLine: endLine,
				})
			}
			this._cacheSnippets.set(key, windowTokenSetArray)
		}
		windowTokenSetArray.forEach((tokenItem) => {
			// 记录每个代码片段与当前代码片段的相似度
			const snapScore = this.calculateSimilarity([...tokenItem.tokenSet], [...this._referenceTokens])

			// 如果代码片段的相似度分值达标，存储
			if (snapScore > this._snippetSimilarityThreshold) {
				allSnippet.push({
					snippet: sourceRows.slice(tokenItem.startLine, tokenItem.endLine).join("\n").trim(), // 获取代码片段
					languageId: neighborFile.languageId,
					name: neighborFile.name,
					score: snapScore,
					startLine: tokenItem.startLine,
					endLine: tokenItem.endLine,
				})
			}
		})

		return allSnippet
	}

	/**
	 * 获取最匹配的代码片段
	 *
	 * @param fileContent 文件内容文本
	 */

	private findBestMatch(snippets: SnippetScore[]) {
		// void 0 用于表示 undefined 值
		return 0 !== snippets.length && 0 !== snippets[0].score ? snippets[0] : void 0
	}

	/**
	 * 获取前K个匹配的代码片段
	 *
	 */

	private findTopKMatch(snippets: SnippetScore[]): SimilarCodeData[] {
		const snippetNum = Math.min(snippets.length, this._snippetLimit)
		if (snippetNum > 0) {
			const topKSimilarCode: SimilarCodeData[] = []
			snippets.slice(0, snippetNum).forEach((item) => {
				topKSimilarCode.push({
					code: item.snippet,
					score: item.score,
					project: this._fileCommonData?.repo ?? "",
					source: item.name ?? "",
				})
			})
			return topKSimilarCode
		}
		return []
	}

	/**
	 * 代码片段匹配,默认是最佳匹配
	 *
	 */
	public async getSimilarityCodeSnippets(matchType = SnippetSelectionOption.BestMatch): Promise<SimilarCodeData[]> {
		let snippets: SnippetScore[] = await new SnippetsFinder(this).getSnippets(
			this._referenceTokens,
			this._contextRetrieveMethod,
		)

		snippets = this.filterSortScoredSnippets(snippets)

		// 如果是获取最佳匹配
		if (matchType == SnippetSelectionOption.BestMatch) {
			const bestSnippts = this.findBestMatch(snippets)
			return bestSnippts
				? [
						{
							code: bestSnippts.snippet,
							score: bestSnippts.score,
							project: this._fileCommonData?.repo ?? "",
							source: bestSnippts.name ?? "",
						},
					]
				: []
		}

		// 获取前k个匹配代码片段，求出现频率最高的K个数，这类问题称为"TOPK"问题
		if (matchType == SnippetSelectionOption.TopK) {
			return this.findTopKMatch(snippets)
		}
		return []
	}

	private getFileSnippetScores(fileCodeSnippets: string[], neighborFile: NeighborFileItem) {
		const fileSnippetScores: SnippetScore[] = []
		for (let fileCodeSnippet of fileCodeSnippets) {
			const simScore = this.calculateSimilarity([...this.tokenize(fileCodeSnippet)], [...this._referenceTokens])
			if (simScore > this._snippetSimilarityThreshold) {
				fileSnippetScores.push({
					snippet: fileCodeSnippet,
					languageId: neighborFile.languageId,
					name: neighborFile.name,
					score: simScore,
					startLine: 0,
					endLine: 0,
				})
			}
		}
		return fileSnippetScores
	}

	public async getHotFiles(): Promise<NeighborFileItem[]> {
		let openFiles = Array.from(this._openedTabFiles.getAll().values() ?? []) as TextDocument[]

		let neighborFiles: NeighborFileItem[] = this.getCurrFileNeighborFiles(openFiles, this.document)
		this.sortByAccessTimeDesc(neighborFiles)
		return neighborFiles
	}

	private sortByAccessTimeDesc(neighborFiles: NeighborFileItem[]) {
		neighborFiles.sort((a, b) => b.lastVisited - a.lastVisited)
	}

	// 获取当前编辑文件在同一个文件夹内的同后缀文件(cc和c视为同后缀)
	public async getSimilarFilesFromCurrentDir(): Promise<NeighborFileItem[]> {
		const currentFileUri = this.document.uri
		const currentFileName = path.basename(this.document.uri.path)
		const neighborFileItemsFromCache = this._cacheNeighborFileItems.get(currentFileUri.toString())
		if (neighborFileItemsFromCache) {
			return neighborFileItemsFromCache
		}
		const currentDirPath = vscode.Uri.joinPath(currentFileUri, "..")
		if (!existsSync(currentDirPath.fsPath)) {
			return []
		}
		const currentFileExtension = this.getFileExtension(this.document.fileName)

		const directoryCacheService = DirectoryCacheService.getInstance()

		const time1 = Date.now()
		const dirEntries = await directoryCacheService.getDirEntriesWithCache(currentDirPath)
		Logger("info", Date.now() - time1, "get dir file time")
		// const dirEntries = await vscode.workspace.fs.readDirectory(currentDirPath);
		Logger("info", dirEntries, "get similar code from current dir files")
		let filteredEntries: Uri[] = []
		// 先筛选出与当前文件后缀相同的文件
		let scoredEntries: { uri: Uri; score: number }[] = []
		for (const [fileName, fileType] of dirEntries) {
			if (fileType === vscode.FileType.File && this.isSameExtension(fileName, currentFileExtension)) {
				const fileUri = vscode.Uri.joinPath(currentDirPath, fileName)
				if (fileUri.fsPath === currentFileUri.fsPath) {
					continue
				}
				const score = this.calculateSimilarity(
					this.splitIntoWordsForFileName(fileName),
					this.splitIntoWordsForFileName(currentFileName),
				)
				scoredEntries.push({ uri: fileUri, score })
			}
		}
		const isMeetNumber: boolean = scoredEntries.length >= this._neighborFileLimit
		if (this._fileNameCache) {
			const similarFileDetails: { path: string; score: number }[] = this._fileNameCache.getSimilarNameFile(
				[...FileNameCache.parseFileName(this.getFileNameWithoutExtension(this.document.uri))],
				currentFileExtension,
			)
			for (const detail of similarFileDetails) {
				if (detail.path === currentFileUri.fsPath || scoredEntries.some((entry) => entry.uri.fsPath === detail.path)) {
					continue
				}
				const fileUri = vscode.Uri.parse(detail.path)
				if (isMeetNumber) {
					scoredEntries.sort((a, b) => b.score - a.score)
					scoredEntries.pop()
					scoredEntries.push({ uri: fileUri, score: detail.score })
					break
				} else {
					scoredEntries.push({ uri: fileUri, score: detail.score })
					if (scoredEntries.length >= this._neighborFileLimit) {
						break
					}
				}
			}
		}
		filteredEntries = scoredEntries.map((entry) => entry.uri)
		const neighborFiles: NeighborFileItem[] = []
		for (const fileUri of filteredEntries) {
			try {
				let fileText = ""
				const neighborFileInfo = fileDataCache.get(fileUri.fsPath)
				if (neighborFileInfo) {
					if (neighborFileInfo.totalLine > this._neighborFileLineCountLimit) {
						continue
					}
					fileText = neighborFileInfo.content
				} else {
					fileText = readFileSync(fileUri.fsPath, "utf8")
					if (fileText.trim() === "") {
						continue
					}
					let lineCount = fileText.split("\n").length
					if (lineCount > this._neighborFileLineCountLimit) {
						continue
					}
				}
				neighborFiles.push({
					name: fileUri.fsPath,
					languageId: this._fileCommonData.languageId,
					source: fileText,
					uri: fileUri.toString(),
					lastVisited: this._fileInteractions.get(fileUri.fsPath)?.lastVisited ?? 0,
				})
				this._cacheNeighborFileItems.set(currentFileUri.toString(), neighborFiles)
			} catch (error) {
				/* empty */
			}
		}
		return neighborFiles
	}

	private getFileNameWithoutExtension(fileUri: Uri) {
		let filename = fileUri.path.split("/").pop()
		let filenameWithoutExtension = filename!.split(".").slice(0, -1).join(".")
		return filenameWithoutExtension
	}

	private getFileExtension(fileName: string): string {
		// eslint-disable-next-line no-useless-escape
		const extMatch = fileName.match(/\.([0-9a-z]+)(?:[\?#]|$)/i)
		return extMatch ? extMatch[1] : ""
	}

	private isSameExtension(fileName: string, currentFileExtension: string): boolean {
		const ext = this.getFileExtension(fileName)
		if (
			currentFileExtension === "c" ||
			currentFileExtension === "cc" ||
			currentFileExtension === "cpp" ||
			currentFileExtension === "java" ||
			currentFileExtension === "scala"
		) {
			return ext === "c" || ext === "cc" || ext === "cpp" || ext === "java" || ext === "scala"
		}
		return ext === currentFileExtension
	}

	/**
	 * Tab 文件会话
	 * @param document
	 */
	public startSession(document: TextDocument): void {
		if (!this._snippetSimilaritySwitch) {
			return
		}

		const currentFile = document.uri.fsPath.replace(".git", "").replace(".hg", "")
		const fileExtension = currentFile.split(".").pop()

		if (currentFile.includes(".") && fileExtension) {
			this._openedTabFiles.set(document.fileName, document)
			this._fileInteractions.set(currentFile, {
				name: currentFile,
				lastVisited: Date.now(),
				languageId: document.languageId,
			})
		}
	}

	endSession(document: TextDocument): void {
		if (!this._snippetSimilaritySwitch) {
			return
		}

		const currentFile = document.uri.fsPath.replace(".git", "").replace(".hg", "")
		this._fileInteractions.delete(currentFile)
		this._openedTabFiles.delete(document.fileName)
	}

	/**
	 * 获取当前打开文件的相邻文件
	 * @param documents
	 * @param currDocument
	 * @returns
	 */
	private getCurrFileNeighborFiles(documents: TextDocument[], currDocument: TextDocument): NeighborFileItem[] {
		const neighborFiles: NeighborFileItem[] = []

		for (const document of documents) {
			if (
				"file" == document.uri.scheme &&
				document.fileName !== currDocument.fileName &&
				document.languageId == currDocument.languageId
			) {
				neighborFiles.push({
					name: document.fileName,
					uri: document.uri.toString(),
					languageId: document.languageId,
					source: document.getText(),
					lastVisited: this._fileInteractions.get(document.fileName)?.lastVisited ?? 0,
				})
			}
		}
		return neighborFiles
	}

	async getAllOpenFiles() {
		for (const item of vscode.window.tabGroups.all) {
			for (const tab of item.tabs) {
				try {
					// 文件后缀
					let fileSuffix = tab.label.includes(".") ? tab.label.substring(tab.label.lastIndexOf(".") + 1) : ""
					if (WASM_LANGAUAGES[fileSuffix]) {
						const document = await vscode.workspace.openTextDocument((tab.input as TabInputText).uri)
						this._openedTabFiles.set(document.fileName, document)
					}
				} catch (error) {
					console.log(`获取文件${tab.label}失败`, error)
				}
			}
		}
	}

	public async retrieveCurrFileSnippetsByFunc(): Promise<Array<SnippetScore>> {
		// 不能包括当前函数
		const codeSource = this.document.getText()
		const languageId = this._fileCommonData.languageId
		let prefixResult: GetParserResult | null = await getParser(languageId)
		let syntaxTreeAnalysis: SyntaxTreeAnalysis | null = null
		const tree: Tree = prefixResult!.parser.parse(pretreatment(languageId, codeSource))

		switch (languageId) {
			case "c":
				syntaxTreeAnalysis = new SyntaxTreeAnalysisC(tree!, prefixResult!.parser)
				break
			case "cpp":
				syntaxTreeAnalysis = new SyntaxTreeAnalysisCpp(tree!, prefixResult!.parser)
				break
			case "java":
				syntaxTreeAnalysis = new SyntaxTreeAnalysisJava(tree!, prefixResult!.parser)
				break
			case "javascript":
				syntaxTreeAnalysis = new SyntaxTreeAnalysisJavaScript(tree!, prefixResult!.parser)
				break
			case "scala":
				syntaxTreeAnalysis = new SyntaxTreeAnalysisScala(tree!, prefixResult!.parser)
				break
		}

		if (!syntaxTreeAnalysis) {
			return []
		} else {
			return syntaxTreeAnalysis
				.getFunctionBodyExceptPointFunc({ row: this.position.line, column: this.position.character })
				.map((item) => {
					return {
						snippet: item,
						languageId: this._fileCommonData.languageId,
						name: this.document.fileName,
						score: this.calculateSimilarity([...this.tokenize(item)], [...this._referenceTokens]),
						startLine: 0,
						endLine: 0,
					}
				})
		}
	}

	public retrieveCurrFileSnippetsByFixedBlock() {
		const allSnippet: SnippetScore[] = []
		let prefixSnippetEndline = this._queryBlockRange.startPoint.row
		let suffixSnippetStartline = this._queryBlockRange.endPoint.row
		if (!prefixSnippetEndline || !suffixSnippetStartline) return allSnippet
		prefixSnippetEndline = Math.max(0, prefixSnippetEndline - 1)
		suffixSnippetStartline = Math.min(this.document.lineCount - 1, suffixSnippetStartline + 1)
		let prefixSnippetWindowArray = this.getWindowDelineations(this._snippetLength, 0, prefixSnippetEndline)
		let suffixSnippetWindowArray = this.getWindowDelineations(
			this._snippetLength,
			suffixSnippetStartline,
			this.document.lineCount,
		)

		let sourceRows = this.document.getText().split("\n")
		// 如果文件的行数超过限制，进行截取
		sourceRows = sourceRows.slice(0, Math.min(this._snippetFileRowsLimit, this.document.lineCount))
		let tokens: any[] = sourceRows.map((row) => this.tokenize(row))

		const windowTokenSetArray: FileSnippetToken[] = []
		windowTokenSetArray.push(...this.listSnippetToken(prefixSnippetWindowArray, tokens))
		windowTokenSetArray.push(...this.listSnippetToken(suffixSnippetWindowArray, tokens))
		const referenceTokensArray = [...this._referenceTokens]
		windowTokenSetArray.forEach((tokenItem) => {
			// 记录每个代码片段与当前代码片段的相似度
			const snapScore = this.calculateSimilarity([...tokenItem.tokenSet], referenceTokensArray)

			// 如果代码片段的相似度分值达标，存储
			if (snapScore > this._snippetSimilarityThreshold) {
				allSnippet.push({
					snippet: sourceRows.slice(tokenItem.startLine, tokenItem.endLine).join("\n").trim(), // 获取代码片段
					languageId: this._fileCommonData.languageId,
					name: this.document.fileName,
					score: snapScore,
					startLine: tokenItem.startLine,
					endLine: tokenItem.endLine,
				})
			}
		})

		return allSnippet
	}

	private listSnippetToken(windowSnippetArray: number[][], fileTokenRow: any[]) {
		const windowTokenSetArray: FileSnippetToken[] = []

		// 遍历文件根据窗口大小划分后的窗口列表
		for (const [, [startLine, endLine]] of windowSnippetArray.entries()) {
			const snapTokenSet = new Set<string>()
			fileTokenRow.slice(startLine, endLine).forEach((t) => t.forEach(snapTokenSet.add, snapTokenSet))
			windowTokenSetArray.push({
				tokenSet: snapTokenSet,
				startLine: startLine,
				endLine: endLine,
			})
		}

		return windowTokenSetArray
	}

	public refreshFileFuncCache(fileUri: Uri) {
		this._cacheFileFuncStrs.delete(fileUri.toString())
	}

	public refreshNeighborFileCache(fileUri: Uri) {
		this._cacheNeighborFileItems.deleteWithSameDir(fileUri)
	}
}
