import * as vscode from "vscode"
import * as path from "path"
import * as fs from "fs"
import { NeighborFileSnippet } from "./neighbor-file-snippet"
import { fileDataCache } from "../cache/cache"

export interface FileDetail {
	path: string
	name: string
	nameToken: string[]
}

/**
 * 尽可能保存缓存的正确性，不保证完全正确
 */
export class FileNameCache {
	public fileNameGroup: Record<string, FileDetail[]> = {}
	private readonly FILE_NAME_SIMILAR_THRESHOLD = 0.4
	private static readonly CATEGORY_MAP: Record<string, string> = {
		".cc": "c",
		".c": "c",
		".cpp": "c",
	}
	private _neighborFileSnippet: NeighborFileSnippet

	constructor(neighborFileSnippet: NeighborFileSnippet) {
		this.initializeFileNameGroup()
		this.initializeListeners()
		this._neighborFileSnippet = neighborFileSnippet
	}

	private initializeListeners(): void {
		const watcher = vscode.workspace.createFileSystemWatcher("**/*.*")
		watcher.onDidCreate((uri) => {
			this.handleFileCreate(uri)
			this._neighborFileSnippet.refreshNeighborFileCache(uri)
		})
		watcher.onDidChange((uri) => {
			this._neighborFileSnippet.refreshFileFuncCache(uri)
		})

		const delWatcher = vscode.workspace.createFileSystemWatcher("**/*")
		delWatcher.onDidDelete((uri) => {
			this.handleFileDelete(uri)
			fileDataCache.delete(uri.fsPath)
			this._neighborFileSnippet.refreshNeighborFileCache(uri)
		})
	}

	private async initializeFileNameGroup(): Promise<void> {
		let extFileDict: Record<string, FileDetail[]> = {}
		for (const folder of vscode.workspace.workspaceFolders || []) {
			await this.processDirectoryAsync(folder.uri.fsPath, extFileDict)
		}
		this.fileNameGroup = extFileDict
		console.log("icode-gpt: File name cache initialized --------------------")
	}

	private async processDirectoryAsync(dirPath: string, extFileDict: Record<string, FileDetail[]>): Promise<void> {
		const entries = await fs.promises.readdir(dirPath, { withFileTypes: true })
		for (const dirent of entries) {
			const fullPath = path.join(dirPath, dirent.name)
			if (dirent.isDirectory()) {
				await this.processDirectoryAsync(fullPath, extFileDict)
			} else if (!dirent.name.startsWith(".")) {
				this.processFile(dirent.name, fullPath, extFileDict)
			}
		}
	}

	private processFile(fileName: string, fullPath: string, extFileDict: Record<string, FileDetail[]>): void {
		const ext = path.extname(fileName)
		const category = this.getCategory(ext)
		if (!extFileDict[category]) extFileDict[category] = []
		extFileDict[category].push({
			path: fullPath,
			name: path.basename(fileName, ext),
			nameToken: FileNameCache.parseFileName(path.basename(fileName, ext)),
		})
	}

	public getSimilarNameFile(tokens: string[], ext: string): { path: string; score: number }[] {
		const category = this.getCategory("." + ext)
		return (
			this.fileNameGroup[category]
				?.filter(
					(fileDetail) => this.calculateSimilarity(tokens, fileDetail.nameToken) > this.FILE_NAME_SIMILAR_THRESHOLD,
				)
				.map((fileDetail) => ({
					path: fileDetail.path,
					score: this.calculateSimilarity(tokens, fileDetail.nameToken),
				}))
				.sort((a, b) => b.score - a.score) || []
		)
	}

	private calculateSimilarity(firstSnippetTokens: string[], secondSnippetTokens: string[]): number {
		const intersection = new Set(firstSnippetTokens.filter((x) => secondSnippetTokens.includes(x)))
		const union = new Set([...firstSnippetTokens, ...secondSnippetTokens])
		return intersection.size / union.size
	}

	public async handleFileCreate(uri: vscode.Uri): Promise<void> {
		const filePath = uri.fsPath

		const fileExt = path.extname(filePath)
		const fileName = path.basename(filePath, fileExt)
		const category = this.getCategory(fileExt)

		if (!this.fileNameGroup[category]) {
			this.fileNameGroup[category] = []
		}

		const existingFileIndex = this.fileNameGroup[category].findIndex((file) => file.path === filePath)
		if (existingFileIndex === -1) {
			this.fileNameGroup[category].push({
				path: filePath,
				name: fileName,
				nameToken: FileNameCache.parseFileName(fileName),
			})
		}
	}

	public async handleFileDelete(uri: vscode.Uri): Promise<void> {
		const filePath = uri.fsPath

		if (!this.isFilePathInFileNameGroup(filePath)) {
			Object.keys(this.fileNameGroup).forEach((category) => {
				this.fileNameGroup[category] = this.fileNameGroup[category].filter(
					(fileDetail) => !fileDetail.path.startsWith(filePath),
				)
			})
		} else {
			const fileExt = path.extname(filePath)
			const category = this.getCategory(fileExt)
			if (this.fileNameGroup[category]) {
				this.fileNameGroup[category] = this.fileNameGroup[category].filter((file) => file.path !== filePath)
			}
		}
	}

	private isFilePathInFileNameGroup(filePath: string): boolean {
		return Object.values(this.fileNameGroup).some((files) => files.some((file) => file.path === filePath))
	}

	private getCategory(ext: string): string {
		return FileNameCache.CATEGORY_MAP[ext] || ext.slice(1)
	}

	public static parseFileName(inputText: string): string[] {
		return inputText
			.replace(/([a-z])([A-Z])/g, "$1_$2")
			.replace(/-/g, "_")
			.toLowerCase()
			.split("_")
			.filter(Boolean)
	}
}
