import * as vscode from "vscode"
import { CompletionType, ContextualCompletion } from "../types"
import setting from "../config/setting.json"
import * as os from "os"
import { Logger } from "../../util/logger"
import { Position, SelectedCompletionInfo, TextDocument, Range } from "vscode"
import { CACHE_LINE_JOIN_TAG } from "../util/consants"
import { completionLineCache } from "../cache"

/**
 * 相邻文件代码片段
 */
export class CompletionInterceptor {
	// 输入拦截字符
	private _interceptorChars = setting.complete.interceptorChars as Array<string>
	constructor() {}

	/**
	 * 判断编辑事件是否触发补全逻辑
	 * @param editChange 文件修改事件
	 * @param document 当前文档
	 * @returns 是否触发补全
	 */
	public isEditChangeTriggerCompletion(editChange: vscode.TextDocumentContentChangeEvent): boolean {
		const { text, range } = editChange

		// 删除到上一行不补全
		const isMultiLineBackspace = !text && range.end.line > range.start.line
		// 在拦截字符数组中不补全
		const isInterceptorChar = text.trim() && this._interceptorChars.includes(text.trim())
		// tab 特殊处理
		const tabKeys = ["\t", "  "]
		const isTabKey = tabKeys.includes(text)
		Logger("info", `intercept text-${text}`)
		Logger(
			isMultiLineBackspace || isInterceptorChar || isTabKey ? "warn" : "info",
			isMultiLineBackspace || isInterceptorChar || isTabKey
				? `删除到上一行拦截-${isMultiLineBackspace}-${text},包含拦截字符-${isInterceptorChar},tab拦截-${isTabKey}`
				: "not need intercept",
		)
		return !(isMultiLineBackspace || isInterceptorChar || isTabKey)
	}

	/**
	 * 语法解析判断是否需要触发补全
	 * @param completionType
	 * @return
	 */
	public grammarParseTriggerCompletion(completionType: CompletionType): boolean {
		if (completionType === "NotNeedCompletion") {
			return false
		} else {
			return true
		}
	}

	/**
	 * 判断变化字符是否匹配幽灵代码，并返回幽灵代码的剩余部分
	 * @param currentLinePrefix 当前行的前缀文本
	 * @param position 当前输入位置
	 * @param ghostText 当前的幽灵代码
	 * @param ghostStartPosition 幽灵代码的起始位置
	 * @returns {boolean | string} 是否匹配，如果匹配，返回幽灵文本剩余部分，否则返回false
	 */
	public isMatchingGhostText(
		currentLinePrefix: string,
		position: Position,
		ghostText: string,
		ghostStartPosition: Position,
	): boolean | string {
		if (!currentLinePrefix || !ghostText || !ghostStartPosition) {
			return false
		}

		const lineOffset = position.line - ghostStartPosition.line
		const characterOffset = lineOffset === 0 ? position.character - ghostStartPosition.character : position.character

		const ghostLines = ghostText.split(os.EOL)
		if (lineOffset >= 0 && lineOffset < ghostLines.length && characterOffset >= 0) {
			const expectedText = ghostLines[lineOffset].slice(0, characterOffset)
			console.log("expectedText", ghostLines[lineOffset].slice(0, characterOffset))
			if (currentLinePrefix.endsWith(expectedText)) {
				const remainingGhostText =
					ghostLines[lineOffset].slice(characterOffset) +
					(ghostLines.slice(lineOffset + 1).length > 0 ? os.EOL + ghostLines.slice(lineOffset + 1).join(os.EOL) : "")
				return remainingGhostText
			}
		}

		return false
	}

	/**
	 * 提示拦截
	 * @param completionType
	 * @return
	 */
	public tipInterceptor(
		document: TextDocument,
		position: Position,
		prefixSuffix: ContextualCompletion,
		selectedCompletionInfo: SelectedCompletionInfo | undefined,
		isEnabledCache: boolean,
	) {
		let result = {
			completionText: "",
			cacheLineText: "" as string | null | undefined,
		}
		const currentLinePrefix = document.getText(new Range(position.line, 0, position.line, position.character))
		const selectedCompletionText = selectedCompletionInfo?.text
		if (!currentLinePrefix || currentLinePrefix.trim() === "" || !selectedCompletionText) {
			return result
		}
		let maxOverlap = 0

		for (let i = 0; i < currentLinePrefix.length; i++) {
			if (selectedCompletionText.startsWith(currentLinePrefix.slice(i))) {
				maxOverlap = currentLinePrefix.length - i
				break
			}
		}
		const expectCurrentLinePrefix = currentLinePrefix + selectedCompletionText.slice(maxOverlap)
		result.cacheLineText = completionLineCache.getCache(prefixSuffix)?.currentLine
		if (result.cacheLineText && isEnabledCache) {
			const historyLine = result.cacheLineText.replace(CACHE_LINE_JOIN_TAG, "")
			if (historyLine.startsWith(expectCurrentLinePrefix)) {
				result.completionText = historyLine.replace(currentLinePrefix, "")
			}
		}
		return result
	}
}
