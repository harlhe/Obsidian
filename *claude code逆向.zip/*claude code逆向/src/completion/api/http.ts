import axios, { AxiosRequestConfig, AxiosResponse } from "axios"
import { constructRequestUrl } from "../../util"
import { DONE_SIGNAL, urlPath } from "../../util/constants"
import { AxiosRequest, CompletionResponse } from "../types"
import { safeParseJsonResponse } from "../util"
import { RESPONSE_CODE } from "../util/consants"

export async function HttpResponse(request: AxiosRequest): Promise<void> {
	const { body, options, onData, onEnd, onError, onStart } = request
	const { method, headers, proxy } = options
	const controller = new AbortController()
	const { signal } = controller
	const data = body
	const url = constructRequestUrl(urlPath.competion)

	const config: AxiosRequestConfig = {
		method,
		headers,
		data,
		url,
		signal,
	}

	let enableFetch = false

	proxy === false && (config.proxy = proxy)

	// 兼容性处理，fetch方法不存在时执行axios默认请求
	if (typeof fetch === "function") {
		enableFetch = true
		config.adapter = "fetch"
		// fetch返回响应为只读流
		config.responseType = "stream"
	} else {
		data.stream = false
	}

	return new Promise((resolve) => {
		try {
			axios(config)
				.then(async (response: AxiosResponse) => {
					if (enableFetch) {
						// 使用fetch请求
						let buffer = ""
						const reader = response.data
							// 字节流转换成文本流
							.pipeThrough(new TextDecoderStream())
							.pipeThrough(
								new TransformStream({
									// 转换流开始时调用
									start() {
										buffer = ""
									},
									// 新数据流到达时调用
									transform(chunk, controller) {
										// chunk接口数据格式：data: {xxx}\n\ndata: [DONE]\n\n
										buffer += chunk
										let position
										while ((position = buffer.indexOf("\n")) !== -1) {
											const line = buffer.substring(0, position).trim()
											buffer = buffer.substring(position + 1)
											// 后端返回done时，断掉连接
											if (line === DONE_SIGNAL) {
												controller.terminate()
												return
											}
											try {
												const json = safeParseJsonResponse(line)
												if (json) {
													// eslint-disable-next-line no-prototype-builtins
													const data = json.hasOwnProperty("bo")
														? json
														: {
																bo: <any>json,
																code: {
																	code: RESPONSE_CODE.SUCCESS,
																	msg: "",
																	msgId: "",
																},
															}
													onData(data)
												}
											} catch (e) {
												onError?.(new Error("Error parsing JSON data from event"))
											}
										}
									},
									// 数据流处理完成时调用
									flush() {
										if (buffer) {
											try {
												const json = safeParseJsonResponse(buffer)
												if (json) {
													// eslint-disable-next-line no-prototype-builtins
													const data = json.hasOwnProperty("bo")
														? json
														: {
																bo: <any>json,
																code: {
																	code: RESPONSE_CODE.SUCCESS,
																	msg: "",
																	msgId: "",
																},
															}
													onData(data)
												}
											} catch (e) {
												onError?.(new Error("Error parsing JSON data from event"))
											}
										}
									},
								}),
							)
							.getReader()

						let connection = true
						while (connection) {
							if (signal.aborted) break
							const { done } = await reader.read()
							if (done) {
								connection = false
							}
						}
						controller.abort()
						onEnd?.()
						reader.releaseLock()
						resolve()
					} else {
						// 使用默认axios请求
						response && onData(response.data as CompletionResponse)
						controller.abort()
						onEnd?.()
						resolve()
					}
				})
				.catch((error) => {
					controller.abort()
					if (error instanceof Error) {
						if (error.name === "AbortError") {
							onEnd?.()
						} else {
							onError?.(error)
						}
					}
					resolve()
				})

			onStart?.(controller)
			if (signal.aborted) {
				resolve()
			}
		} catch (error) {
			controller.abort()
			if (error instanceof Error) {
				if (error.name === "AbortError") {
					onEnd?.()
				} else {
					onError?.(error)
				}
			}
			resolve()
		}
	})
}
