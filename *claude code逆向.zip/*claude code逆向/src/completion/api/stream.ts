import { safeParseJsonResponse } from "../util/index"
import { CompletionResponse, StreamRequest, CompatibleTransformer, CompatibleStreamReader } from "../types"
import { constructRequestUrl } from "../../util"
import { DONE_SIGNAL, urlPath } from "../../util/constants"
import { RESPONSE_CODE } from "../util/consants"

/**
 * 流数据解析
 */
class StreamParser {
	private buffer: string = ""
	private signal: AbortSignal

	constructor(signal: AbortSignal) {
		this.signal = signal
	}

	/**
	 * 构造转换流的Transformer对象
	 * @param onData 每片数据正确处理时的回调
	 * @param onError 错误处理的回调
	 * @returns Transformer对象 { start, transform, flush }
	 */
	transformer(
		onData: (streamResponse: CompletionResponse | undefined) => void,
		onError: ((error: Error) => void) | undefined,
	): CompatibleTransformer {
		const self = this
		const start = () => {
			self.buffer = ""
		}
		const transform = (chunk: string, controller: { terminate: () => void }) => {
			try {
				const { done } = self.parseChunk(chunk, (data) => onData?.(data as CompletionResponse))
				if (done) {
					controller.terminate()
				}
			} catch (error) {
				onError?.(error as Error)
			}
		}
		const flush = () => {
			try {
				self.parseBuffer((data) => onData?.(data as CompletionResponse))
			} catch (error) {
				onError?.(error as Error)
			}
		}
		return { start, transform, flush }
	}

	private parseChunk(chunk: string, callFn: (_: { [_: string]: any }) => void): { done: boolean } {
		if (typeof chunk === "string") {
			// 解析chunk接口数据格式：data: {xxx}\n\ndata: [DONE]\n\n
			this.buffer += chunk
			let position: number
			while ((position = this.buffer.indexOf("\n")) !== -1) {
				const line = this.buffer.substring(0, position).trim()
				this.buffer = this.buffer.substring(position + 1)
				// 后端返回done时，返回{done: true}
				if (line === DONE_SIGNAL) {
					return { done: true }
				}
				const data = this.getStreamData(line)
				data && callFn(data)
				if (this.signal.aborted) {
					return { done: true }
				}
			}
			return { done: false }
		} else {
			throw new Error("Chunk is not string")
		}
	}

	private parseBuffer(callFn: (_: { [_: string]: any }) => void): void {
		const data = this.getStreamData(this.buffer)
		data && callFn(data)
	}

	private getStreamData(line: string): { [_: string]: any } | undefined {
		try {
			const json = safeParseJsonResponse(line)
			if (json) {
				// eslint-disable-next-line no-prototype-builtins
				const data = json.hasOwnProperty("bo")
					? json
					: {
							bo: <any>json,
							code: {
								code: RESPONSE_CODE.SUCCESS,
								msg: "",
								msgId: "",
							},
						}
				return data
			}
			return undefined
		} catch {
			throw new Error("Error parsing JSON data from event")
		}
	}
}

/**
 * 兼容转换流
 */
class CompatibleTransformStream {
	public set body(v: any) {
		!this.lock && (this._body = v)
	}

	public get body() {
		return this._body
	}

	private start
	private transform
	private flush
	private controller!: { terminate: () => void }
	private done: boolean = false
	private lock: boolean = false
	private _body: any

	constructor(transformer: Partial<CompatibleTransformer>) {
		const { start, transform, flush } = transformer
		this.start = start
		this.transform = transform
		this.flush = flush
		this.controller = {
			terminate: () => (this.done = true),
		}
	}

	/**
	 * 获取兼容的可读流
	 * @returns 兼容的可读流
	 */
	getReader(): CompatibleStreamReader {
		return {
			read: this.read.bind(this),
			releaseLock: this.releaseLock.bind(this),
		}
	}

	private read(): Promise<{ done: boolean; value?: string }> {
		return new Promise((resolve, reject) => {
			try {
				!this.lock && this.start?.()
				this.body.on("readable", () => {
					let chunk: string
					while (null !== (chunk = this.body.read())) {
						const value = chunk.toString()
						this.transform?.(value, this.controller)
						resolve({ done: this.done, value })
					}
				})
				this.body.on("close", () => {
					if (!this.done) {
						this.flush?.()
						this.done = true
					}
					resolve({ done: this.done })
				})
			} catch (error) {
				reject(error)
			} finally {
				this.lock = true
			}
		})
	}

	private releaseLock() {
		this.lock = false
	}
}

export async function streamResponse(request: StreamRequest) {
	let reader: CompatibleStreamReader | ReadableStreamDefaultReader | undefined
	const { isStream, body, options, controller, logger, onData, onEnd, onError, onStart } = request
	const { signal } = controller

	try {
		const fetchOptions = {
			method: options.method,
			headers: options.headers,
			body: JSON.stringify(body),
			signal: controller.signal,
		}
		const response = await fetch(constructRequestUrl(urlPath.competion), fetchOptions)
		if (!response.ok) {
			throw new Error(`Server responded with status code: ${response.status}`)
		}

		if (!response.body) {
			throw new Error("Failed to get a ReadableStream from the response")
		}

		onStart?.()

		// 兼容非流
		if (!isStream) {
			const data = await response.json() // or response.text() based on the API response format
			const parsedData = safeParseJsonResponse(JSON.stringify(data))

			if (parsedData) {
				onData?.(parsedData as CompletionResponse)
			}
			return onEnd?.() // Return early since this is a non-streaming request
		}

		const streamParser = new StreamParser(signal)
		const transformer = streamParser.transformer(onData, onError)

		if (!response.body.pipeThrough) {
			// 兼容处理
			;(response.body as any).pipeThrough = (stream: CompatibleTransformStream) => {
				stream.body = response.body
				return stream
			}
			reader = (response.body as any).pipeThrough(new CompatibleTransformStream(transformer)).getReader()
		} else {
			reader = response.body.pipeThrough(new TextDecoderStream()).pipeThrough(new TransformStream(transformer)).getReader()
		}
		if (!reader) {
			return
		}
		let connection = true
		while (connection) {
			if (signal.aborted) break
			const { done } = await reader.read()
			if (done) {
				connection = false
			}
		}
		controller.abort()
		reader.releaseLock()
		return onEnd?.()
	} catch (error: unknown) {
		controller && controller.abort()
		reader?.releaseLock()
		if (error instanceof Error) {
			if (error.name === "AbortError") {
				logger.log("info", "有新请求，中断当前请求")
				// 信息可能不全，进onEnd会导致缓存中出现
				// onEnd?.();
			}
		}
		throw error
	}
}

/**
 * 中断异常
 * @returns
 */
export class AbortError extends Error {
	constructor() {
		super()
		this.name = "AbortError"
		Object.setPrototypeOf(this, AbortError.prototype)
	}
}
