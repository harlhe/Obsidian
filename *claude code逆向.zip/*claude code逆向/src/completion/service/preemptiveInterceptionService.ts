import { preemptiveInterception } from "../../api/tracking"

export function PreemptiveInterception(reason: string) {
	return function (target: any, propertyKey: string, descriptor: PropertyDescriptor) {
		const originalMethod = descriptor.value
		descriptor.value = function (this: any, ...args: any[]) {
			const params = this._metricProvider.setMetricParams({
				actionType: "autoCompletionIntercept",
				docId: this._completionResponse.docId,
				chatUuid: this._completionResponse.chatUuid,
				content: "",
				prompt: this._completionResponse.prompt,
				accType: "",
				contentType: this._document?.languageId || "",
			})
			preemptiveInterception(params, reason)
			return originalMethod.apply(this, args)
		}
		return descriptor
	}
}
