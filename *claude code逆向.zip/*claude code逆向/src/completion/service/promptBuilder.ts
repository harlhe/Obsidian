import { TextDocument, Position } from "vscode"
import { InlineCompletionInfo } from "../SyntaxTreeAnalysis/InlineCompletionInfo"
import { PrefixSuffix, VariableInfo } from "../types/index"
import { PromptConfig } from "../../types/index"
import { ISyntaxInfo } from "../types/syntaxInfo"
import { LoggerManager } from "../../util/logger"
// import { SyntaxInfoManager } from './syntaxInfoManager';
import { LOG_KEYS } from "../util/consants"
import { CompletionType, RemoteKnowledgeBaseType } from "../types/index"
import { TestFrameType, MockToolType } from "../../types/index"

export class PromptBuilder {
	// public syntaxInfoManager: SyntaxInfoManager;

	constructor(
		private document: TextDocument,
		private position: Position,
		private inlineCompletionInfo: InlineCompletionInfo,
		private technologyStack: string,
		private streamEnable: boolean,
		private candidateNum: number,
	) {
		// this.syntaxInfoManager = new SyntaxInfoManager(inlineCompletionInfo, document, position);
	}

	async buildPromptConfig(
		prefixSuffix: PrefixSuffix,
		similarCodeSnippets: string[],
		completionType: CompletionType,
		testFrame: TestFrameType,
		mockTool: MockToolType,
		loggerManager: LoggerManager,
		syntaxInfo: ISyntaxInfo,
		remoteKnowledgeBase: RemoteKnowledgeBaseType,
	): Promise<Partial<PromptConfig>> {
		return {
			dependencyPackage: syntaxInfo.dependencyPackageList,
			globalVariable: syntaxInfo.globalVariableList,
			localVariable: syntaxInfo.localVariableList,
			dataStructure: syntaxInfo.structList,
			macroDefinition: syntaxInfo.macroDefinitionList,
			enumeration: syntaxInfo.enumList,
			classDefinition: syntaxInfo.classList,
			dependencyFunction: syntaxInfo.localKnowledgeMsgList.FuncText,
			absoluteFilePath: this.document?.uri ? this.document.uri.fsPath : "",
			technologyStack: this.technologyStack || "",
			associatedCode: syntaxInfo.associatedCode,
			similarCode: similarCodeSnippets,
			curFunction: syntaxInfo.curFunctionSign,
			stream: this.streamEnable,
			language: this.inlineCompletionInfo.languageId,
			completionType: completionType,
			testFrame: completionType === "UnitTestCompletion" ? testFrame : "auto",
			mockTool: completionType === "UnitTestCompletion" ? mockTool : "",
			similarCodeTypeUser: remoteKnowledgeBase.similarCodeTypeUser,
			similarCodeTypeActual: remoteKnowledgeBase.similarCodeTypeActual,
		}
	}

	async buildPrompt(
		prefixSuffix: PrefixSuffix,
		similarCodeSnippets: string[],
		completionType: CompletionType,
		testFrame: TestFrameType,
		mockTool: MockToolType,
		loggerManager: LoggerManager,
		syntaxInfo: ISyntaxInfo,
		remoteKnowledgeBase: RemoteKnowledgeBaseType,
	): Promise<string> {
		const config = await this.buildPromptConfig(
			prefixSuffix,
			similarCodeSnippets,
			completionType,
			testFrame,
			mockTool,
			loggerManager,
			syntaxInfo,
			remoteKnowledgeBase,
		)

		const globalVariable = config.globalVariable ?? []

		const prompt = {
			preText: prefixSuffix.prefix,
			sufText: prefixSuffix.suffix,
			stream: config.stream ?? null,
			n: this.candidateNum,
			dependencyPackage: config.dependencyPackage ?? [],
			globalVariable: globalVariable.map((variable: VariableInfo) => variable.variableText),
			localVariable: config.localVariable ?? [],
			dataStructure: config.dataStructure ?? [],
			macroDefinition: config.macroDefinition ?? [],
			enumeration: config.enumeration ?? [],
			classDefinition: config.classDefinition ?? [],
			dependencyFunction: config.dependencyFunction ?? [],
			similarCode: config.similarCode ?? "",
			associatedCode: config.associatedCode ?? "",
			technologyStack: config.technologyStack ?? "",
			absoluteFilePath: config.absoluteFilePath ?? "",
			curFunction: config.curFunction ?? "",
			language: config.language ?? "",
			completionType: config.completionType ?? "InlineCompletion",
			testFrame: config.testFrame ?? "auto",
			mockTool: config.mockTool ?? "",
			similarCodeTypeUser: config.similarCodeTypeUser ?? "HOT_FILE",
			similarCodeTypeActual: config.similarCodeTypeActual ?? "HOT_FILE",
			enablePromptGuard: true,
		}

		loggerManager.log("info", prompt, LOG_KEYS.prompt)
		return JSON.stringify(prompt)
	}
}
