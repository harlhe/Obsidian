import * as vscode from "vscode"
import { CompletionInterceptor } from "../interceptor/completion-interceptor"

/**
 * Handles document edit changes and keystroke tracking
 */
export class EditChangeHandler {
	private totalKeystrokes: number = 0

	/**
	 * Handle document edit changes and determine if completion should be triggered
	 */
	handleEditChange(editChange: vscode.TextDocumentContentChangeEvent, completionInterceptor: CompletionInterceptor): boolean {
		// Track keystrokes
		this.setupKeyStrokeListener(editChange)

		// Check if it's a paste operation
		if (this.isPasteOperation(editChange)) {
			return false
		}

		// Determine if completion should be triggered based on the edit
		return completionInterceptor.isEditChangeTriggerCompletion(editChange)
	}

	/**
	 * Check if the edit change is from a paste operation
	 */
	private isPasteOperation(editChange: vscode.TextDocumentContentChangeEvent): boolean {
		return (
			editChange.text.length > 1 && editChange.text.includes("\n") && /\S/.test(editChange.text) // Only consider as paste if text contains non-whitespace
		)
	}

	/**
	 * Track keystroke counts for analytics
	 */
	private setupKeyStrokeListener(editChange: vscode.TextDocumentContentChangeEvent) {
		const { text, rangeLength } = editChange
		if (text.length > 0 || rangeLength > 0) {
			this.totalKeystrokes++
		}
	}

	/**
	 * Get total keystrokes count
	 */
	getTotalKeystrokes(): number {
		return this.totalKeystrokes
	}

	/**
	 * Reset keystroke counter
	 */
	resetKeystrokes() {
		this.totalKeystrokes = 0
	}
}
