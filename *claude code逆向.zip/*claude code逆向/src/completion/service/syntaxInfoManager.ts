import { InlineCompletionInfo } from "../SyntaxTreeAnalysis/InlineCompletionInfo"
import { ISyntaxInfo } from "../types/syntaxInfo"
import { PrefixSuffix, FunctionInfo } from "../types/index"
import { TextDocument, Position } from "vscode"

export class SyntaxInfoManager {
	private curFunctionInfo: FunctionInfo | null = null

	constructor(
		private inlineCompletionInfo: InlineCompletionInfo,
		private document: TextDocument,
		private position: Position,
	) {}

	public getCurrentFunctionInfo() {
		return this.curFunctionInfo
	}

	async collectSyntaxInfo(prefixSuffix: PrefixSuffix): Promise<ISyntaxInfo> {
		const defaultInfo: ISyntaxInfo = this.getDefaultSyntaxInfo()
		let {
			curFunctionInfo,
			associatedCode,
			globalVariableList,
			structList,
			macroDefinitionList,
			enumList,
			classList,
			dependencyPackageList,
		} = await this.inlineCompletionInfo.getCompletionSyntaxInfo(this.position, this.document)

		this.curFunctionInfo = curFunctionInfo

		const syntaxInfo: ISyntaxInfo = {
			...defaultInfo,
			curFunctionSign: curFunctionInfo?.functionSign || "",
			associatedCode,
			localVariableList: [],
			globalVariableList,
			structList,
			macroDefinitionList,
			enumList,
			classList,
			dependencyPackageList,
		}
		if (curFunctionInfo) {
			syntaxInfo.localVariableList = [
				...curFunctionInfo.parameterList.map((item) => item.paramText),
				...curFunctionInfo.localVariableList.map((item) => item.variableText),
			]
		}

		// 获取本地知识信息
		const localKnowledgeMsgList = await this.inlineCompletionInfo.getLocalKnowledgeMsgList(prefixSuffix)

		if (localKnowledgeMsgList) {
			syntaxInfo.localKnowledgeMsgList = localKnowledgeMsgList
			syntaxInfo.structList.push(...localKnowledgeMsgList.StructText)
			syntaxInfo.enumList.push(...localKnowledgeMsgList.EnumText)
			syntaxInfo.classList.push(...localKnowledgeMsgList.ClassText)
		}

		return syntaxInfo
	}

	private getDefaultSyntaxInfo(): ISyntaxInfo {
		return {
			curFunctionSign: "",
			associatedCode: [],
			localVariableList: [],
			globalVariableList: [],
			structList: [],
			macroDefinitionList: [],
			enumList: [],
			classList: [],
			dependencyPackageList: [],
			localKnowledgeMsgList: {
				FuncText: [],
				EnumText: [],
				StructText: [],
				MacroText: [],
				ClassText: [],
			},
		}
	}
}
