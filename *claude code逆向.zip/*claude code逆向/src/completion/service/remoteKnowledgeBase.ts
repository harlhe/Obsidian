import { RemoteKnowledgeBaseType } from "../types/index"

export class RemoteKnowledgeBase {
	private static readonly HOT_FILE = "HOT_FILE"
	private static readonly REMOTE = "REMOTE"
	private static readonly CUSTOM = "CUSTOM"

	private static _remoteKnowledgeBaseInfo: RemoteKnowledgeBaseType = {
		similarCodeTypeUser: RemoteKnowledgeBase.HOT_FILE,
		similarCodeTypeActual: RemoteKnowledgeBase.HOT_FILE,
	}

	// 添加静态 getter/setter，支持外部直接赋值
	static get similarCodeTypeUser(): string {
		return this._remoteKnowledgeBaseInfo.similarCodeTypeUser
	}

	static set similarCodeTypeUser(value: string) {
		this._remoteKnowledgeBaseInfo.similarCodeTypeUser = value
	}

	static get similarCodeTypeActual(): string {
		return this._remoteKnowledgeBaseInfo.similarCodeTypeActual
	}

	static set similarCodeTypeActual(value: string) {
		this._remoteKnowledgeBaseInfo.similarCodeTypeActual = value
	}

	static getRemoteKnowBaseTypes(
		enableRemoteKnowledgeBase?: string,
		knowledgeUrl?: string,
		similarCodeSnippetsFromKnowledge?: boolean,
	): RemoteKnowledgeBaseType {
		const hasKnowledgeUrl = knowledgeUrl && knowledgeUrl.trim().length > 0
		const hasSimilarSnippets = similarCodeSnippetsFromKnowledge

		if (enableRemoteKnowledgeBase) {
			this.similarCodeTypeUser = this.REMOTE
			this.similarCodeTypeActual = this.HOT_FILE
		} else if (!enableRemoteKnowledgeBase) {
			if (hasKnowledgeUrl) {
				this.similarCodeTypeUser = this.CUSTOM
				this.similarCodeTypeActual = this.HOT_FILE
				// 只在 actual 为 HOT_FILE 时才判断是否需要提升为 CUSTOM
				if (hasSimilarSnippets) {
					this.similarCodeTypeActual = this.CUSTOM
				}
			} else {
				this.similarCodeTypeUser = this.HOT_FILE
				this.similarCodeTypeActual = this.HOT_FILE
			}
		}
		return this._remoteKnowledgeBaseInfo
	}
}
