import { TextDocument, Position } from "vscode"
import { KnowledgeService } from "./knowledgeService"
import { RemoteKnowledgeBase } from "./remoteKnowledgeBase"
import { NeighborFileSnippet } from "../prompt/neighbor-file-snippet"
import { Background } from "../../util/background"
import { LoggerManager } from "../../util/logger"
import { similarCodeCache } from "../cache/cache"
import { PrefixSuffix, FunctionInfo, RetrieveMethod, FileCommonData, ContextualCompletion, SimilarCodeData } from "../types/index"
import { FileNameCache } from "../prompt/file-name"

export class SimilarCodeProvider {
	constructor(
		private knowledgeService: KnowledgeService,
		private neighborFileSnippet: NeighborFileSnippet,
		private snippetSelectionOption: number,
	) {}

	async getSimilarCodeSnippets(
		document: TextDocument,
		position: Position,
		prefix: string,
		suffix: string,
		knowledgeUrl: string,
		loggerManager: LoggerManager,
		prefixSuffix: PrefixSuffix,
		contextualCompletion: ContextualCompletion,
		fileNameCache: FileNameCache,
		fileCommonData: FileCommonData,
		curFunctionInfo: FunctionInfo | null,
		openTabFileSnippetsEnbaled: boolean,
	): Promise<string[]> {
		const similarCodeSnippets: SimilarCodeData[] = []
		const similarCodes: string[] = []

		// Get snippets from knowledge base
		let spanStartTime = Date.now()
		const similarCodeSnippetsFromKnowledge = await this.knowledgeService.getSimilarCodeSnippets(
			prefix,
			suffix,
			knowledgeUrl,
			Background.get().repository,
			Background.get().branch,
		)
		loggerManager.log("info", Date.now() - spanStartTime, "getLocalKnowledgeBase")

		const similarCodeCacheValue = similarCodeCache.getCache(contextualCompletion)
		if (similarCodeCacheValue) {
			loggerManager.log("info", "the similar code originates from cache")
			similarCodeSnippets.push(...similarCodeCacheValue)
			loggerManager.log("info", similarCodeSnippets, "similarCodeSnippets")
			similarCodeCacheValue.forEach((item) => {
				similarCodes.push(item.code)
			})
			return similarCodes
		}

		if (similarCodeSnippetsFromKnowledge !== "") {
			similarCodes.push(similarCodeSnippetsFromKnowledge)
			RemoteKnowledgeBase.getRemoteKnowBaseTypes("", "", true)
		}

		// Get snippets from neighbor files if needed
		if (similarCodeSnippets.length === 0) {
			let queryContent
			let queryBlockRange

			if (curFunctionInfo) {
				queryContent = curFunctionInfo.functionDefinition
				queryBlockRange = curFunctionInfo.blockRange
				loggerManager.log("info", queryContent, "get similar code from curFunction")
			} else {
				queryContent = `${prefix}${suffix}`
				queryBlockRange = contextualCompletion.prefixSuffixBlockRange
			}

			if (queryContent && queryBlockRange) {
				const similarRetrieveMethod = RetrieveMethod.FixWindow

				this.neighborFileSnippet.initDocument(
					document,
					position,
					queryContent,
					similarRetrieveMethod,
					fileNameCache,
					fileCommonData,
					openTabFileSnippetsEnbaled,
					queryBlockRange,
				)

				const neighborFileSimilarCodeSnippets = await this.neighborFileSnippet.getSimilarityCodeSnippets(
					this.snippetSelectionOption,
				)

				loggerManager.log("info", `similar num: ${neighborFileSimilarCodeSnippets.length}`)

				if (neighborFileSimilarCodeSnippets && neighborFileSimilarCodeSnippets.length > 0) {
					similarCodeSnippets.push(...neighborFileSimilarCodeSnippets)
					neighborFileSimilarCodeSnippets.forEach((item) => {
						similarCodes.push(item.code)
					})
					similarCodeCache.setCache(contextualCompletion, neighborFileSimilarCodeSnippets)
					loggerManager.log("info", "similarcode cache update")
					loggerManager.log("info", similarCodeCache.getAll(), "similarcode cache")
					loggerManager.log("info", similarCodeSnippets, "similarCodeSnippets")
				}
			}
		}

		return similarCodes
	}
}
