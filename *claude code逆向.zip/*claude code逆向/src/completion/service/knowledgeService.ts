import { Logger } from "../../util/logger"
import { KnowledgeResponseType } from "../types/index"
import { checkResult } from "../../util/decorators"
import { LOG_KEYS, KNOWLEDGE_TIMEOUT, MAX_FAILED_COUNT_OF_REQ_TO_KNOWLEDGE, RE_REQ_TO_KNOWLEDGE_TIMEOUT } from "../util/consants"

export class KnowledgeService {
	private lastReqToKnowledgeDatetime: number = 0
	private failedCountOfReqToKnowledge: number = 0
	private knowledgeUrl: string

	constructor(knowledgeUrl: string) {
		this.knowledgeUrl = knowledgeUrl
	}

	private _fetch(fetch_promise: any, timeout: number | undefined): Promise<Response | undefined> {
		return new Promise((resolve, reject) => {
			const timer = setTimeout(() => {
				resolve(undefined)
			}, timeout)
			fetch_promise
				.then((res: Response) => {
					clearTimeout(timer)
					resolve(res)
				})
				.catch((err: any) => {
					checkResult(LOG_KEYS.reqKnowledge, err)
					clearTimeout(timer)
					resolve(undefined)
				})
		})
	}

	async getSimilarCodeSnippets(
		prefix: string,
		suffix: string,
		knowledgeUrl: string,
		repo?: string,
		branch?: string,
	): Promise<string> {
		this.knowledgeUrl = knowledgeUrl
		if (!this.knowledgeUrl || !this.knowledgeUrl.trim() || (!prefix && !suffix)) return ""

		const reqDate: number = Date.now()
		// 连续失败次数超过5次，且请求时间小于180秒，则不请求知识库
		if (
			this.failedCountOfReqToKnowledge >= MAX_FAILED_COUNT_OF_REQ_TO_KNOWLEDGE &&
			reqDate - this.lastReqToKnowledgeDatetime < RE_REQ_TO_KNOWLEDGE_TIMEOUT
		) {
			return ""
		}

		const url = this.knowledgeUrl + "/search_code"
		const body = JSON.stringify({
			repo,
			branch,
			prefix_code: prefix,
			suffix_code: suffix,
		})

		const headers: any = {
			"Content-Type": "application/json",
		}

		this.lastReqToKnowledgeDatetime = reqDate
		try {
			const res: Response | undefined = await this._fetch(
				fetch(url, { method: "POST", headers, body: body }),
				KNOWLEDGE_TIMEOUT,
			)

			if (res) {
				const resText: KnowledgeResponseType = await res.json()
				this.failedCountOfReqToKnowledge = 0
				return resText.code
			} else {
				this.failedCountOfReqToKnowledge++
				return ""
			}
		} catch (e) {
			Logger("error", e as string, "LOCALKNOWLEDGE_REQUEST")
			return ""
		}
	}
}
