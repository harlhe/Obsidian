import * as vscode from "vscode"
import * as path from "path"

export class DirectoryCacheService {
	private static instance: DirectoryCacheService
	private directoryCache = new Map<
		string,
		{
			entries: [string, vscode.FileType][]
			mtime: number
			expiresAt: number // 新增：过期时间戳
		}
	>()
	private _preloadTimeout: NodeJS.Timeout | null = null
	private cacheTTL: number = 600 * 1000 // 默认10分钟

	// 单例模式获取实例
	public static getInstance(context?: vscode.ExtensionContext): DirectoryCacheService {
		if (!this.instance) {
			if (!context) {
				throw new Error("Context must be provided the first time getInstance is called.")
			}
			this.instance = new DirectoryCacheService(context)
		}
		return this.instance
	}

	constructor(private context: vscode.ExtensionContext) {
		this.startExpirationCheck() // 启动定期清理
	}

	// 初始化事件监听
	public initialize() {
		this.context.subscriptions.push(
			vscode.window.onDidChangeActiveTextEditor((editor) => {
				if (editor) {
					this.preloadDirectoryForCurrentFile(editor.document.uri)
				}
			}),
		)

		const initialEditor = vscode.window.activeTextEditor
		if (initialEditor) {
			this.preloadDirectoryForCurrentFile(initialEditor.document.uri)
		}
	}

	private preloadDirectoryForCurrentFile(fileUri: vscode.Uri) {
		const currentFileDir = vscode.Uri.file(path.dirname(fileUri.fsPath))
		this.preloadDirectory(currentFileDir)
	}

	// 预加载目录
	public async preloadDirectory(dirUri: vscode.Uri): Promise<void> {
		if (!dirUri) return

		clearTimeout(this._preloadTimeout!)
		this._preloadTimeout = setTimeout(async () => {
			try {
				const dirPath = dirUri.fsPath
				const stat = await vscode.workspace.fs.stat(dirUri)
				const currentMtime = stat.mtime

				// 检查是否需要重新加载（mtime变化或已过期）
				const cached = this.directoryCache.get(dirPath)
				const isExpired = cached && cached.expiresAt < Date.now()
				if (cached && !isExpired && cached.mtime === currentMtime) {
					return
				}

				const entries = await vscode.workspace.fs.readDirectory(dirUri)
				this.directoryCache.set(dirPath, {
					entries: entries,
					mtime: currentMtime,
					expiresAt: Date.now() + this.cacheTTL,
				})
			} catch (error) {
				console.error(`预加载目录 ${dirUri.fsPath} 失败:`, error)
			} finally {
				this._preloadTimeout = null
			}
		}, 500)
	}

	// 从缓存获取目录内容
	public async getDirEntriesWithCache(dirUri: vscode.Uri): Promise<[string, vscode.FileType][]> {
		const dirPath = dirUri.fsPath
		const cached = this.directoryCache.get(dirPath)
		// const stat = await vscode.workspace.fs.stat(dirUri);
		// if (!stat) return [];

		// const isExpired = cached?.expiresAt !== undefined && cached.expiresAt < Date.now();
		if (cached) {
			return cached.entries
		} else {
			return []
		}

		// 检查过期和mtime
		// const isExpired = cached?.expiresAt !== undefined && cached.expiresAt < Date.now();
		// if (cached && !isExpired && cached.mtime === stat.mtime) {
		//   return cached.entries;
		// } else {
		//   return [];
		// }

		// 重新加载并更新缓存
		// const entries = await vscode.workspace.fs.readDirectory(dirUri);
		// this.directoryCache.set(dirPath, {
		//   entries: entries,
		//   mtime: stat.mtime,
		//   expiresAt: Date.now() + this.cacheTTL,
		// });
		// return entries;
	}

	// 启动后台任务定期清理过期缓存
	private startExpirationCheck() {
		const cleanup = () => {
			const now = Date.now()
			this.directoryCache.forEach((value, key) => {
				if (value.expiresAt < now) {
					this.directoryCache.delete(key)
				}
			})
		}
		const timer = setInterval(cleanup, this.cacheTTL)
		const disposable = {
			dispose: () => clearInterval(timer),
		}

		this.context.subscriptions.push(disposable)
	}
}
