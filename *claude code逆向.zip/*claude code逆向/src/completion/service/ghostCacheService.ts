import { PrefixSuffix, CompletionType, PrefixSuffixRow } from "../types/index"
import { getPrefixSuffixRow } from "../util/index"
import { cache } from "../cache/index"

export class GhostCacheManager {
	private _numLineContext: number
	private _contextRatio: number[]
	private _ghostCacheRowLevel: number
	private _completionCacheEnabled: boolean
	private _completionResponse: any

	constructor(
		numLineContext: number,
		contextRatio: number[],
		ghostCacheRowLevel: number,
		completionCacheEnabled: boolean,
		completionResponse: any,
	) {
		this._numLineContext = numLineContext
		this._contextRatio = contextRatio
		this._ghostCacheRowLevel = ghostCacheRowLevel
		this._completionCacheEnabled = completionCacheEnabled
		this._completionResponse = completionResponse
	}

	public setCompletionResponse(completionResponse: any) {
		this._completionResponse = completionResponse
	}

	/**
	 * 仅针对 行内补、单行补场景
	 * 设置幽灵缓存,第一行直接显示幽灵提示，剩下的行分别作为缓存，因为第一行直接显示，缓存不做处理
	 * @param completion 补全数组
	 */
	public setGhostCompletionCache(completion: string, ghostPrefixSuffix: PrefixSuffix, completionType: CompletionType) {
		// 幽灵补仅针对行内补、单行补场景
		if (completionType !== "InlineCompletion" && completionType !== "LineCompletion") {
			return
		}

		let numLinesPrefix = Math.floor(Math.abs(this._numLineContext * this._contextRatio[0]))
		let numLinesSuffix = Math.ceil(Math.abs(this._numLineContext * this._contextRatio[1]))

		let completionRow: string[] = completion.split(/\r\n|\r|\n/i).filter((line) => line.trim() !== "")
		if (completionRow.length < 2) {
			return
		}

		let cacheLevel = Math.min(completionRow.length, this._ghostCacheRowLevel)
		completionRow = completionRow.slice(0, cacheLevel)

		if (completionType === "InlineCompletion") {
			this.setGhostCompletionCacheInlineCompletionType(ghostPrefixSuffix, completionRow, numLinesPrefix, numLinesSuffix)
		} else {
			this.setGhostCompletionCacheLineCompletionType(ghostPrefixSuffix, completionRow, numLinesPrefix, numLinesSuffix)
		}
	}

	private setGhostCompletionCacheInlineCompletionType(
		ghostPrefixSuffix: PrefixSuffix,
		completionRow: string[],
		linePrefixLimit: number,
		lineSufffixLimit: number,
	) {
		const breakLineCommon = "\n"
		for (let level: number = 1; level < completionRow.length; level++) {
			let toCompletionValue = breakLineCommon + completionRow[level]
			let lastCompletionValue = completionRow[level - 1]

			if (level === 1) {
				ghostPrefixSuffix.prefix += lastCompletionValue
			} else {
				ghostPrefixSuffix.currentLine++
				ghostPrefixSuffix.totalLine++

				const newPrefixSuffix: PrefixSuffixRow = getPrefixSuffixRow(
					this._numLineContext,
					ghostPrefixSuffix.currentLine,
					ghostPrefixSuffix.totalLine,
					this._contextRatio,
				)

				ghostPrefixSuffix.prefixLineNum = newPrefixSuffix.prefixLineNum
				ghostPrefixSuffix.suffixLineNum = newPrefixSuffix.suffixLineNum

				this.getPrefixSuffixAfterAddRow(level, ghostPrefixSuffix, linePrefixLimit, lineSufffixLimit, lastCompletionValue)
			}

			if (this._completionCacheEnabled) {
				let ghostCompletionResponse = this._completionResponse
				ghostCompletionResponse.formattedCompletion = toCompletionValue
				cache.setCache(ghostPrefixSuffix, JSON.stringify(ghostCompletionResponse))
			}
		}
	}

	private setGhostCompletionCacheLineCompletionType(
		ghostPrefixSuffix: PrefixSuffix,
		completionRow: string[],
		linePrefixLimit: number,
		lineSufffixLimit: number,
	) {
		const breakLineCommon = "\n"
		for (let level: number = 1; level < completionRow.length; level++) {
			let toCompletionValue = completionRow[level]
			let lastCompletionValue = completionRow[level - 1]

			toCompletionValue = breakLineCommon + toCompletionValue
			if (level > 1) {
				ghostPrefixSuffix.currentLine++
				ghostPrefixSuffix.totalLine++
			}

			const newPrefixSuffix: PrefixSuffixRow = getPrefixSuffixRow(
				this._numLineContext,
				ghostPrefixSuffix.currentLine,
				ghostPrefixSuffix.totalLine,
				this._contextRatio,
			)

			ghostPrefixSuffix.prefixLineNum = newPrefixSuffix.prefixLineNum
			ghostPrefixSuffix.suffixLineNum = newPrefixSuffix.suffixLineNum

			this.getPrefixSuffixAfterAddRow(level, ghostPrefixSuffix, linePrefixLimit, lineSufffixLimit, lastCompletionValue)

			if (this._completionCacheEnabled) {
				let ghostCompletionResponse = this._completionResponse
				ghostCompletionResponse.formattedCompletion = toCompletionValue
				cache.setCache(ghostPrefixSuffix, JSON.stringify(ghostCompletionResponse))
			}
		}
	}

	private getPrefixSuffixAfterAddRow(
		level: number,
		ghostPrefixSuffix: PrefixSuffix,
		linePrefixLimit: number,
		lineSufffixLimit: number,
		lastCompletion: string,
	) {
		if (level === 1) {
			const breakLineCommon = "\n"
			let prefix = ghostPrefixSuffix.prefix.replace(/\r\n/g, breakLineCommon)
			ghostPrefixSuffix.prefix = prefix + lastCompletion
			return
		}

		// 编辑文件头时，后缀范围充足
		if (ghostPrefixSuffix.totalLine - ghostPrefixSuffix.currentLine > lineSufffixLimit) {
			if (ghostPrefixSuffix.currentLine < ghostPrefixSuffix.prefixLineNum) {
				// 当前行小于前缀范围时，前缀追加、后缀不变
				this.prefixAppendRow(ghostPrefixSuffix, lastCompletion)
			} else if (
				ghostPrefixSuffix.prefixLineNum < linePrefixLimit &&
				ghostPrefixSuffix.currentLine === ghostPrefixSuffix.prefixLineNum
			) {
				// 前缀行数在递增，后缀行数在递减
				this.prefixAppendRow(ghostPrefixSuffix, lastCompletion)
				this.suffixMoveFrontSlideWindow(ghostPrefixSuffix)
			} else {
				this.prefixMoveBackSlideWindow(ghostPrefixSuffix, lastCompletion)
			}
		} else if (ghostPrefixSuffix.totalLine - ghostPrefixSuffix.currentLine < lineSufffixLimit) {
			// 编辑文件尾部，后缀小于后缀范围
			if (ghostPrefixSuffix.currentLine < ghostPrefixSuffix.prefixLineNum) {
				this.prefixAppendRow(ghostPrefixSuffix, lastCompletion)
			} else {
				this.prefixMoveBackSlideWindow(ghostPrefixSuffix, lastCompletion)
			}
		} else {
			// 编辑中间部分，前后缀范围充足
			this.prefixMoveBackSlideWindow(ghostPrefixSuffix, lastCompletion)
		}
	}

	private prefixMoveBackSlideWindow(ghostPrefixSuffix: PrefixSuffix, lastCompletion: string) {
		const breakLineCommon = "\n"

		let prefix = ghostPrefixSuffix.prefix.replace(/\r\n/g, breakLineCommon)
		prefix = prefix.substring(prefix.indexOf(breakLineCommon) + breakLineCommon.length) + breakLineCommon + lastCompletion
		ghostPrefixSuffix.prefix = prefix
	}

	private suffixMoveFrontSlideWindow(ghostPrefixSuffix: PrefixSuffix) {
		const breakLineCommon = "\n"
		let suffix = ghostPrefixSuffix.suffix.replace(/\r\n/g, breakLineCommon).replace(/\r?\n$/, "")
		ghostPrefixSuffix.suffix = suffix.substring(0, suffix.lastIndexOf(breakLineCommon))
	}

	private prefixAppendRow(ghostPrefixSuffix: PrefixSuffix, lastCompletion: string) {
		const breakLineCommon = "\n"
		let prefix = ghostPrefixSuffix.prefix.replace(/\r\n/g, breakLineCommon)

		ghostPrefixSuffix.prefix = prefix + breakLineCommon + lastCompletion
	}
}
