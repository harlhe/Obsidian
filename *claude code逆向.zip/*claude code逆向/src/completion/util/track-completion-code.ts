import { TextDocumentChangeEvent, TextDocument } from "vscode"
import { CompletionCode } from "../../types/index"

export class TrackCompletionCode {
	private static instance: TrackCompletionCode
	private _capacity = 50
	private _queue: CompletionCode[] = []
	private constructor() {}

	// 单例模式
	public static getInstance(): TrackCompletionCode {
		if (!TrackCompletionCode.instance) {
			TrackCompletionCode.instance = new TrackCompletionCode()
		}
		return TrackCompletionCode.instance
	}

	// 有采纳，更新数组。只做数组的push和shift
	public recordCompletion(id: string, accType: string, path: string, content: string, prompt: string, startLine: number) {
		const endLine = startLine + content.split("\n").length
		// 容量达到一定_capacity时候触发数据飞轮
		if (this._queue.length === this._capacity) {
			this.triggerFlywheel()
		}
		this._queue.push({
			id,
			accType,
			path,
			content,
			prompt,
			startLine,
			endLine,
			// 时间备用
			createdAt: new Date(),
		})
	}

	// 监听文档有任何变化更新数组。使用全局监听事件，因为在非全局监听状态下，有的编辑行为被拦截器拦截了。 全局监听事件先发生。
	public updateTextInRange(event: TextDocumentChangeEvent, changeLines: number) {
		const startLine = event?.contentChanges[0]?.range?.start?.line
		const path = event?.document?.uri?.path
		if ((!startLine && startLine !== 0) || path) {
			return
		}
		// 更新行信息算法
		this._queue.map((element) => {
			// 同文档更改位置
			if (element.path === path) {
				/*
        算法待补充，重新设定行
         */
				// 重新取文本
				element.content = this.getTextByRange(event?.document, element.startLine, element.endLine)
			}
			return element
		})
		// 过滤掉已经删除的
		this._queue.filter((element) => element.startLine > element.endLine)
	}

	// 触发数据飞轮,并删除最先入栈的数据
	private triggerFlywheel() {
		this._queue.shift()
	}

	private getTextByRange(document: TextDocument, startLine: number, endLine: number): string {
		let text = ""
		for (let i = startLine; i <= endLine; i++) {
			text += document.lineAt(i).text + "\n"
		}
		return text
	}
}
