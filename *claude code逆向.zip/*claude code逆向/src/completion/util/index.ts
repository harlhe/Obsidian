import {
	InlineCompletionContext,
	InlineCompletionTriggerKind,
	Position,
	Range,
	Terminal,
	TextDocument,
	window,
	workspace,
} from "vscode"
import * as util from "util"
import { exec } from "child_process"
import { CompletionResponse, PrefixSuffixRow } from "../types/index"
import { execSync } from "child_process"

const execAsync = util.promisify(exec)

import { PrefixSuffix, Bracket } from "../types/index"
import {
	ALL_BRACKETS,
	CLOSING_BRACKETS,
	LINE_BREAK_REGEX,
	LOG_KEYS,
	MULTILINE_TYPES,
	OPENING_BRACKETS,
	QUOTES,
	QUOTES_REGEX,
	SKIP_DECLARATION_SYMBOLS,
	ZTE_AI_ASSITANT,
} from "./consants"
import { SyntaxNode } from "web-tree-sitter"
import { STREAM_DATA_SIGNAL } from "../../util/constants"
import { checkResult } from "../../util/decorators"
import * as os from "os"

export const delayExecution = <T extends () => void>(fn: T, delay = 200): NodeJS.Timeout => {
	return setTimeout(() => {
		fn()
	}, delay)
}

export const getTextSelection = () => {
	const editor = window.activeTextEditor
	const selection = editor?.selection
	const text = editor?.document.getText(selection)
	return text || ""
}

export const getIsBracket = (char: string): char is Bracket => {
	return ALL_BRACKETS.includes(char as Bracket)
}

export const getIsClosingBracket = (char: string): char is Bracket => {
	return CLOSING_BRACKETS.includes(char as Bracket)
}

export const getIsOpeningBracket = (char: string): char is Bracket => {
	return OPENING_BRACKETS.includes(char as Bracket)
}

export const getIsSingleBracket = (chars: string) => chars?.length === 1 && getIsBracket(chars)

export const getIsOnlyOpeningBrackets = (chars: string) => {
	if (!chars || !chars.length) return false

	for (const char of chars) {
		if (!getIsOpeningBracket(char)) {
			return false
		}
	}
	return true
}

export const getIsOnlyClosingBrackets = (chars: string) => {
	if (!chars || !chars.length) return false

	for (const char of chars) {
		if (!getIsClosingBracket(char)) {
			return false
		}
	}
	return true
}

export const getIsOnlyBrackets = (chars: string) => {
	if (!chars || !chars.length) return false

	for (const char of chars) {
		if (!getIsBracket(char)) {
			return false
		}
	}
	return true
}

export const getSkipVariableDeclataion = (characterBefore: string, textAfter: string) => {
	if (
		characterBefore &&
		SKIP_DECLARATION_SYMBOLS.includes(characterBefore.trim()) &&
		textAfter.length &&
		(textAfter.at(0) ?? "") === "?" &&
		!getIsOnlyBrackets(textAfter)
	) {
		return true
	}

	return false
}

export const getBeforeAndAfter = () => {
	const editor = window.activeTextEditor
	if (!editor)
		return {
			charBefore: "",
			charAfter: "",
		}

	const position = editor.selection.active
	const lineText = editor.document.lineAt(position.line).text

	const charBefore = lineText.substring(0, position.character).trim().split("").reverse()[0]

	const charAfter = lineText.substring(position.character).trim().split("")[0]

	return {
		charBefore,
		charAfter,
	}
}

export const getShouldSkipCompletion = (context: InlineCompletionContext, autoSuggestEnabled: boolean) => {
	const editor = window.activeTextEditor
	if (!editor) return true
	const document = editor.document
	const cursorPosition = editor.selection.active
	const lineEndPosition = document.lineAt(cursorPosition.line).range.end
	const textAfterRange = new Range(cursorPosition, lineEndPosition)
	const textAfter = document.getText(textAfterRange)
	const { charBefore } = getBeforeAndAfter()

	if (getSkipVariableDeclataion(charBefore, textAfter)) {
		return true
	}

	return context.triggerKind === InlineCompletionTriggerKind.Automatic && !autoSuggestEnabled
}

export const getPrefixSuffix = (
	numLines: number,
	document: TextDocument,
	position: Position,
	contextRatio: number[],
): PrefixSuffix => {
	const currentLine = position.line
	const numLinesToEnd = document.lineCount - currentLine
	let numLinesPrefix = Math.floor(Math.abs(numLines * contextRatio[0]))
	let numLinesSuffix = Math.ceil(Math.abs(numLines * contextRatio[1]))

	if (numLinesPrefix > currentLine) {
		numLinesSuffix += numLinesPrefix - currentLine
		numLinesPrefix = currentLine
	}

	if (numLinesSuffix > numLinesToEnd) {
		numLinesPrefix += numLinesSuffix - numLinesToEnd
		numLinesSuffix = numLinesToEnd
	}

	const prefixRange = new Range(Math.max(0, currentLine - numLinesPrefix), 0, currentLine, position.character)
	const suffixRange = new Range(currentLine, position.character, currentLine + numLinesSuffix, 0)

	return {
		prefixLineNum: numLinesPrefix,
		suffixLineNum: numLinesSuffix,
		currentLine: currentLine,
		totalLine: document.lineCount,
		prefix: document.getText(prefixRange),
		suffix: document.getText(suffixRange),
	}
}

export const getPrefixSuffixRow = (
	numLines: number,
	currentLine: number,
	totalLine: number,
	contextRatio: number[],
): PrefixSuffixRow => {
	const numLinesToEnd = totalLine - currentLine
	let numLinesPrefix = Math.floor(Math.abs(numLines * contextRatio[0]))
	let numLinesSuffix = Math.ceil(Math.abs(numLines * contextRatio[1]))

	if (numLinesPrefix > currentLine) {
		numLinesSuffix += numLinesPrefix - currentLine
		numLinesPrefix = currentLine
	}

	if (numLinesSuffix > numLinesToEnd) {
		numLinesPrefix += numLinesSuffix - numLinesToEnd
		numLinesSuffix = numLinesToEnd
	}

	return {
		prefixLineNum: numLinesPrefix,
		suffixLineNum: numLinesSuffix,
	}
}

export const getIsMiddleOfString = () => {
	const { charBefore, charAfter } = getBeforeAndAfter()

	return charBefore && charAfter && /\w/.test(charBefore) && /\w/.test(charAfter)
}

export const getCurrentLineText = (position: Position | null) => {
	const editor = window.activeTextEditor
	if (!editor || !position) return ""

	const lineText = editor.document.lineAt(position.line).text

	return lineText
}

export const getHasLineTextBeforeAndAfter = () => {
	const { charBefore, charAfter } = getBeforeAndAfter()

	return charBefore && charAfter
}

export const isCursorInEmptyString = () => {
	const { charBefore, charAfter } = getBeforeAndAfter()

	return QUOTES.includes(charBefore) && QUOTES.includes(charAfter)
}

export const getNextLineIsClosingBracket = () => {
	const editor = window.activeTextEditor
	if (!editor) return false
	const position = editor.selection.active
	const nextLineText = editor.document.lineAt(Math.min(position.line + 1, editor.document.lineCount - 1)).text.trim()
	return getIsOnlyClosingBrackets(nextLineText)
}

export const getPreviousLineIsOpeningBracket = () => {
	const editor = window.activeTextEditor
	if (!editor) return false
	const position = editor.selection.active
	const previousLineCharacter = editor.document
		.lineAt(Math.max(position.line - 1, 0))
		.text.trim()
		.split("")
		.reverse()[0]
	return getIsOnlyOpeningBrackets(previousLineCharacter)
}

export const getIsMultilineCompletion = ({
	node,
	prefixSuffix,
}: {
	node: SyntaxNode | null
	prefixSuffix: PrefixSuffix | null
}) => {
	if (!node) return false

	const isMultilineCompletion =
		!getHasLineTextBeforeAndAfter() && !isCursorInEmptyString() && MULTILINE_TYPES.includes(node.type)

	return !!(isMultilineCompletion || !prefixSuffix?.suffix.trim())
}

// 如果finishReason为lenght,截掉最后一行
const postHandleData = (data: string): string => {
	const lines = data.split(/\r\n|\r|\n/i)
	lines.pop()
	return lines.join(os.EOL)
}

export const getFimDataFromProvider = (provider: string, data: CompletionResponse | undefined) => {
	let result = []
	if (data?.bo?.result) {
		try {
			if (typeof data.bo.result === "string") {
				result = data.bo.finishReason === "length" ? [postHandleData(data.bo.result)] : [data.bo.result]
			} else if (Array.isArray(data.bo.result)) {
				result = data.bo.result
			} else {
				const parsedResult = JSON.parse(data.bo.result)
				result = Array.isArray(parsedResult) ? parsedResult : []
			}
		} catch (error) {
			checkResult(LOG_KEYS.fimResultError, error, "error")
			result = []
		}
	}
	return result
}

export function isStreamWithDataPrefix(stringBuffer: string) {
	return stringBuffer.startsWith(STREAM_DATA_SIGNAL.trim())
}

export const getNoTextBeforeOrAfter = () => {
	const editor = window.activeTextEditor
	if (!editor) return
	const cursorPosition = editor.selection.active
	if (!cursorPosition) return
	const lastLinePosition = new Position(cursorPosition.line, editor.document.lineCount)
	const textAfterRange = new Range(cursorPosition, lastLinePosition)
	const textAfter = editor.document.getText(textAfterRange)
	const textBeforeRange = new Range(new Position(0, 0), cursorPosition)
	const textBefore = editor.document.getText(textBeforeRange)
	return !textAfter || !textBefore
}

export function safeParseJsonResponse(stringBuffer: string): CompletionResponse | undefined {
	try {
		if (isStreamWithDataPrefix(stringBuffer)) {
			return JSON.parse(stringBuffer.split(STREAM_DATA_SIGNAL)[1])
		}
		return JSON.parse(stringBuffer)
	} catch (e) {
		return undefined
	}
}

export const getCurrentWorkspacePath = (): string | undefined => {
	if (workspace.workspaceFolders && workspace.workspaceFolders.length > 0) {
		const workspaceFolder = workspace.workspaceFolders[0]
		return workspaceFolder.uri.fsPath
	} else {
		window.showInformationMessage("No workspace is open.")
		return undefined
	}
}

export const getGitChanges = async (): Promise<string> => {
	try {
		const path = getCurrentWorkspacePath()
		const { stdout } = await execAsync("git diff --cached", {
			cwd: path,
		})
		return stdout
	} catch (error) {
		console.error("Error executing git command:", error)
		return ""
	}
}

export const getTerminal = async (): Promise<Terminal | undefined> => {
	const zteTerminal = window.terminals.find((t) => t.name === ZTE_AI_ASSITANT)
	if (zteTerminal) return zteTerminal
	const terminal = window.createTerminal({ name: ZTE_AI_ASSITANT })
	terminal.show()
	return terminal
}

export const getTerminalExists = (): boolean => {
	if (window.terminals.length === 0) {
		window.showErrorMessage("No active terminals")
		return false
	}
	return true
}

export const getSanitizedCommitMessage = (commitMessage: string) => {
	const sanitizedMessage = commitMessage.replace(QUOTES_REGEX, "").replace(LINE_BREAK_REGEX, "").trim()

	return `git commit -m "${sanitizedMessage}"`
}

export const getLineBreakCount = (str: string) => str.split("\n").length

export const loadSystemEnv = () => {
	try {
		const envOutput = process.platform === "win32" ? execSync("set").toString() : execSync("env").toString()
		return envOutput.split("\n").reduce((env, line) => {
			const [key, value] = line.split("=")
			if (key && value) {
				env[key] = value.trim()
			}
			return env
		}, {} as NodeJS.ProcessEnv)
	} catch {
		return {}
	}
}
