import Parser, { Point, SyntaxNode } from "web-tree-sitter"
import path from "path"
import { WASM_LANGAUAGES, LINE_BREAK_REGEX } from "./consants"
import { FileType } from "./../types/index"
import * as fs from "fs"

let isInited: boolean = false
const languageMap: Map<string, GetParserResult> = new Map()

export async function getParser(fileMessage: string, isPath: boolean = false): Promise<GetParserResult | null> {
	if (!isInited) {
		try {
			// 此处需要考虑加锁
			await Parser.init()
			isInited = true
		} catch (ex) {
			console.log("----ex: ", ex)
		}
	}

	let languageId = fileMessage
	if (isPath) {
		const fileExtension = path.extname(fileMessage).slice(1)
		languageId = WASM_LANGAUAGES[fileExtension]
	}

	if (!languageId) return null

	if (languageMap.has(languageId)) {
		return languageMap.get(languageId)!
	}

	try {
		const parser = new Parser()
		const wasmPath = path.join(__dirname, "tree-sitter-wasms", `tree-sitter-${languageId}.wasm`)
		const parserLanguage = await Parser.Language.load(wasmPath)
		// 此处需要考虑加锁
		parser.setLanguage(parserLanguage)

		const rst: GetParserResult = { parser: parser, languageId: languageId }
		languageMap.set(languageId, rst)
		return rst
	} catch (ex) {
		console.log("----ex: ", ex)
		return null
	}
}

/**
 * 打印语法树
 * @param node 语法树节点
 * @param level 语法树层级，默认为0，即根节点
 */
export function printTree(node: SyntaxNode, level: number = 0): void {
	if (level === 0) {
		console.log(
			"  ".repeat(0) +
				`${node.type ?? ""} [${node.startPosition.row}, ${node.startPosition.column}] - [${node.endPosition.row}, ${node.endPosition.column}]`,
		)
	}
	for (let i = 0; i < node.childCount; i++) {
		const itemNode = node.namedChild(i)
		if (itemNode !== null) {
			const fieldName =
				node.fieldNameForChild(i) !== undefined && node.fieldNameForChild(i) !== null
					? node.fieldNameForChild(i) + ": "
					: ""
			console.log(
				"  ".repeat(level) +
					fieldName +
					`${itemNode.type ?? ""} [${itemNode.startPosition.row}, ${itemNode.startPosition.column}] - [${itemNode.endPosition.row}, ${itemNode.endPosition.column}]`,
			)
			printTree(itemNode, level + 1)
		}
	}
}

export type QueryResultHandler = (queryResult: Parser.QueryMatch[]) => any
export type GetParserResult = {
	parser: Parser
	languageId: string
}

export function getPrefixText(startPoint: Point, point: Point, node: SyntaxNode): string {
	let prefix = ""

	if (point.row === startPoint.row) {
		// 如果point在开始行，只需要获取从开始到point的文本
		prefix = node.text.slice(0, point.column - startPoint.column)
	} else {
		// 获取第一行（从函数体开始到行尾）
		let lines = node.text.split("\n")
		prefix = lines[0] + "\n"

		// 获取中间的完整行
		for (let i = 1; i < point.row - startPoint.row; i++) {
			prefix += lines[i] + "\n"
		}

		// 获取point所在行（从行首到point）
		prefix += lines[point.row - startPoint.row].slice(0, point.column)
	}

	return prefix
}

export function getSuffixText(startPoint: Point, point: Point, endPoint: Point, node: SyntaxNode): string {
	let suffix = ""
	let lines = node.text.split("\n")

	if (point.row === endPoint.row) {
		// 如果point在结束行，只需要获取从point到结束的文本
		suffix = lines[endPoint.row - startPoint.row].slice(point.column)
	} else {
		// 获取point所在行（从point到行尾）
		suffix = lines[point.row - startPoint.row].slice(point.column) + "\n"

		// 获取中间的完整行
		for (let i = point.row - startPoint.row + 1; i < endPoint.row - startPoint.row; i++) {
			suffix += lines[i] + "\n"
		}

		// 获取最后一行
		suffix += lines[endPoint.row - startPoint.row]
	}

	return suffix
}

export function isPointInRange(point: Point, startPoint: Point, endPoint: Point): boolean {
	if (point.row === startPoint.row && point.column < startPoint.column) {
		return false
	}
	if (point.row === endPoint.row && point.column > endPoint.column) {
		return false
	}
	if (point.row < startPoint.row || point.row > endPoint.row) {
		return false
	}
	return true
}

export function parseFileType(filePath: string): Promise<FileType> {
	const result: Promise<FileType> = new Promise((resolve, reject) => {
		const ftRegx: RegExp = /^(TEST|TEST_F|TEST_P)\(/
		let fileType: FileType = "business"

		const stream = fs.createReadStream(filePath, { encoding: "utf-8" })
		let buffer = ""

		stream.on("data", (chunk) => {
			buffer += chunk

			const lines = buffer.split(LINE_BREAK_REGEX)
			buffer = lines.pop() || "" // 保留最后一个可能未完整的行

			for (const line of lines) {
				if (ftRegx.test(line.trim())) {
					fileType = "ft"
					stream.destroy() // 找到匹配后终止流
					resolve(fileType)
					return
				}
			}
		})

		stream.on("end", () => resolve(fileType)) // 如果未找到匹配项
		stream.on("error", (error) => reject(error))
	})
	return result
}
