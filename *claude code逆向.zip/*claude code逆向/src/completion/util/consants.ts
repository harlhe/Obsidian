import { defaultTemplates } from "../template/templates"

// 插件配置
export const EXTENSION_NAME = "icodemate"
export const ASSISTANT = "assistant"
export const USER = "user"
export const ZTE_AI_ASSITANT = "开发智能伙伴"
export const SYSTEM = "system"
export const YOU = "? You"
export const EMPTY_MESAGE = "Sorry, I don’t understand. Please try again."
export const MODEL_ERROR = "Sorry, something went wrong..."
export const OPENING_BRACKETS = ["[", "{", "("]
export const CLOSING_BRACKETS = ["]", "}", ")"]
export const OPENING_TAGS = ["<"]
export const CLOSING_TAGS = ["</"]
export const QUOTES = ['"', "'", "`"]
export const ALL_BRACKETS = [...OPENING_BRACKETS, ...CLOSING_BRACKETS] as const
export const BRACKET_REGEX = /^[()[\]{}]+$/
export const NORMALIZE_REGEX = /\s*\r?\n|\r/g
export const LINE_BREAK_REGEX = /\r?\n|\r|\n/g
export const QUOTES_REGEX = /["'`]/g
export const MAX_CONTEXT_LINE_COUNT = 200
export const SKIP_DECLARATION_SYMBOLS = ["="]
export const IMPORT_SEPARATOR = [",", "{"]
export const SKIP_IMPORT_KEYWORDS_AFTER = ["from", "as", "import"]
export const MIN_COMPLETION_CHUNKS = 2
export const MAX_EMPTY_COMPLETION_CHARS = 250
// 知识库访问超时时间，单位ms
export const KNOWLEDGE_TIMEOUT: number = 500
// 知识库访问最大失败次数
export const MAX_FAILED_COUNT_OF_REQ_TO_KNOWLEDGE = 5
// 重新访问知识库超时时间，单位ms
export const RE_REQ_TO_KNOWLEDGE_TIMEOUT = 180000
export const CHAT_JOIN_TAG = " #### "
export const CACHE_LINE_JOIN_TAG = "```"

export const EVENT_NAME = {
	zteAddMessage: "zte-add-message",
	zteAcceptSolution: "zte-accept-solution",
	zteChat: "zte-chat",
	zteChatMessage: "zte-chat-message",
	zteClickSuggestion: "zte-click-suggestion",
	zteEnableModelDownload: "zte-enable-model-download",
	zteFetchOllamaModels: "zte-fetch-ollama-models",
	zteGetConfigValue: "zte-get-config-value",
	zteGetGitChanges: "zte-get-git-changes",
	zteGlobalContext: "zte-global-context",
	zteHideBackButton: "zte-hide-back-button",
	zteListTemplates: "zte-list-templates",
	zteManageTemplates: "zte-manage-templates",
	zteNewDocument: "zte-new-document",
	zteNotification: "zte-notification",
	zteOnCompletion: "zte-on-completion",
	zteOnEnd: "zte-on-end",
	zteOnLoading: "zte-on-loading",
	zteOpenDiff: "zte-open-diff",
	zteOpenSettings: "zte-open-settings",
	zteSendLanguage: "zte-send-language",
	zteSendSystemMessage: "zte-send-system-message",
	zteSendTheme: "zte-send-theme",
	zteSetConfigValue: "zte-set-config-value",
	zteSetGlobalContext: "zte-set-global-context",
	zteSetOllamaModel: "zte-set-ollama-model",
	zteSetTab: "zte-set-tab",
	zteSetWorkspaceContext: "zte-set-workspace-context",
	zteStopGeneration: "zte-stop-generation",
	zteTextSelection: "zte-text-selection",
	zteWorkspaceContext: "zte-workspace-context",
}

// 插件命令列表
export const ZTE_AI_ASSISTANT_COMMAND_NAME = {
	// addTests: 'zteAiAssistant.addTests',
	// addTypes: 'zteAiAssistant.addTypes',
	// conversationHistory: 'zteAiAssistant.conversationHistory',
	// disable: 'zteAiAssistant.disable',
	// enable: 'zteAiAssistant.enable',
	// explain: 'zteAiAssistant.explain',
	// focusSidebar: 'zteAiAssistant.sidebar.focus',
	// generateDocs: 'zteAiAssistant.generateDocs',
	// getGitCommitMessage: 'zteAiAssistant.getGitCommitMessage',
	// hideBackButton: 'zteAiAssistant.hideBackButton',
	// manageProviders: 'zteAiAssistant.manageProviders',
	// manageTemplates: 'zteAiAssistant.manageTemplates',
	// newChat: 'zteAiAssistant.newChat',
	// openChat: 'zteAiAssistant.openChat',
	// refactor: 'zteAiAssistant.refactor',
	// sendTerminalText: 'zteAiAssistant.sendTerminalText',
	settings: "zteAiAssistant.settings",
	stopGeneration: "zteAiAssistant.stopGeneration",
	// templateCompletion: 'zteAiAssistant.templateCompletion',
	// templates: 'zteAiAssistant.templates'
}

export const CONVERSATION_EVENT_NAME = {
	getActiveConversation: "zte.get-active-conversation",
	getConversations: "zte.get-conversations",
	removeConversation: "zte.remove-conversation",
	saveConversation: "zte.save-conversation",
	saveLastConversation: "zte.save-last-conversation",
	setActiveConversation: "zte.set-active-conversation",
	clearAllConversations: "zte.clear-all-conversations",
}

export const PROVIDER_EVENT_NAME = {
	addProvider: "zte.add-provider",
	copyProvider: "zte.copy-provider",
	focusProviderTab: "zte.focus-provider-tab",
	getActiveChatProvider: "zte.get-active-provider",
	getActiveFimProvider: "zte.get-active-fim-provider",
	getAllProviders: "zte.get-providers",
	removeProvider: "zte.remove-provider",
	resetProvidersToDefaults: "zte.reset-providers-to-defaults",
	setActiveChatProvider: "zte.set-active-chat-provider",
	setActiveFimProvider: "zte.set-active-fim-provider",
	updateProvider: "zte.update-provider",
}

export const ACTIVE_CHAT_PROVIDER_STORAGE_KEY = "zte.active-chat-provider"
export const ACTIVE_CONVERSATION_STORAGE_KEY = "zte.active-conversation"
export const ACTIVE_FIM_PROVIDER_STORAGE_KEY = "zte.active-fim-provider"
export const CONVERSATION_STORAGE_KEY = "zte.conversations"
export const INFERENCE_PROVIDERS_STORAGE_KEY = "zte.inference-providers"

export const WORKSPACE_STORAGE_KEY = {
	autoScroll: "autoScroll",
	chatMessage: "chatMessage",
	downloadCancelled: "downloadCancelled",
	selectedTemplates: "selectedTemplates",
	selection: "selection",
	showProviders: "showProviders",
}

export const EXTENSION_SETTING_KEY = {
	apiProvider: "apiProvider",
	apiProviderFim: "apiProviderFim",
	chatModelName: "chatModelName",
	fimModelName: "fimModelName",
}

export const EXTENSION_CONTEXT_NAME = {
	zteConversationHistory: "zteConversationHistory",
	zteGeneratingText: "zteGeneratingText",
	zteManageProviders: "zteManageProviders",
	zteManageTemplates: "zteManageTemplates",
}

export const WEBUI_TABS = {
	chat: "chat",
	history: "history",
	providers: "providers",
	templates: "templates",
}

export const FIM_TEMPLATE_FORMAT = {
	automatic: "automatic",
	codegemma: "codegemma",
	codellama: "codellama",
	codeqwen: "codeqwen",
	custom: "custom-template",
	deepseek: "deepseek",
	llama: "llama",
	stableCode: "stable-code",
	starcoder: "starcoder",
}

export const STOP_LLAMA = ["<EOT>"]

export const STOP_DEEPSEEK = ["<｜fim▁begin｜>", "<｜fim▁hole｜>", "<｜fim▁end｜>", "<END>", "<｜end▁of▁sentence｜>"]

export const STOP_STARCODER = ["<|endoftext|>"]

export const STOP_CODEGEMMA = ["<|file_separator|>", "<|end_of_turn|>", "<eos>"]

export const DEFAULT_TEMPLATE_NAMES = defaultTemplates.map(({ name }) => name)

export const DEFAULT_ACTION_TEMPLATES = ["refactor", "add-tests", "add-types", "explain"]

export const DEFAULT_PROVIDER_FORM_VALUES = {
	apiHostname: "0.0.0.0",
	apiKey: "",
	apiPath: "",
	apiPort: 11434,
	apiProtocol: "http",
	id: "",
	label: "",
	modelName: "",
	name: "",
	provider: "ollama",
	type: "chat",
}

export const TITLE_GENERATION_PROMPT_MESAGE = `
  Generate a title for this conversation in under 10 words.
  It should not contain any special characters or quotes.
`

export const WASM_LANGAUAGES: { [key: string]: string } = {
	cpp: "cpp",
	hpp: "cpp",
	cc: "cpp",
	cxx: "cpp",
	hxx: "cpp",
	cs: "c_sharp",
	c: "c",
	h: "c",
	css: "css",
	php: "php",
	phtml: "php",
	php3: "php",
	php4: "php",
	php5: "php",
	php7: "php",
	phps: "php",
	"php-s": "php",
	bash: "bash",
	sh: "bash",
	json: "json",
	ts: "typescript",
	mts: "typescript",
	cts: "typescript",
	tsx: "tsx",
	vue: "vue",
	yaml: "yaml",
	yml: "yaml",
	elm: "elm",
	js: "javascript",
	jsx: "javascript",
	mjs: "javascript",
	cjs: "javascript",
	py: "python",
	pyw: "python",
	pyi: "python",
	el: "elisp",
	emacs: "elisp",
	ex: "elixir",
	exs: "elixir",
	go: "go",
	eex: "embedded_template",
	heex: "embedded_template",
	leex: "embedded_template",
	html: "html",
	htm: "html",
	java: "java",
	lua: "lua",
	ocaml: "ocaml",
	ml: "ocaml",
	mli: "ocaml",
	ql: "ql",
	res: "rescript",
	resi: "rescript",
	rb: "ruby",
	erb: "ruby",
	rs: "rust",
	rdl: "systemrdl",
	toml: "toml",
	systemverilog: "systemverilog",
}

export const MULTILINE_OUTSIDE = ["class_body", "interface_body", "interface", "class", "program", "identifier", "export"]

export const MULTILINE_INSIDE = [
	"body",
	"export_statement",
	"formal_parameters",
	"function_definition",
	"named_imports",
	"object_pattern",
	"object_type",
	"object",
	"parenthesized_expression",
	"statement_block",
]

export const MULTILINE_TYPES = [...MULTILINE_OUTSIDE, ...MULTILINE_INSIDE]

export const MULTI_LINE_DELIMITERS = ["\n\n", "\r\n\r\n"]

export const MULTI_LINE_REACT = [
	"jsx_closing_element",
	"jsx_element",
	"jsx_element",
	"jsx_opening_element",
	"jsx_self_closing_element",
]

// 配置属性
export const ZTE_AI_ASSISTANT_COMPLETE_CONFIG_PROPERTY = {
	enabled: "complete.enabled", //AI 助手功能是否启用
	languages: "complete.languages", // 配置实时补全的语言类型
	candidateNum: "complete.candidateNum", // 候选项最大条数
	completeType: "complete.type", // 自定义调节推荐内容为多行优先或单行优先
	technologyStack: "complete.techStack", // 配置的技术栈信息
	completionCacheEnabled: "cache.completionCacheEnabled", // 是否启用缓存
	proxyEnable: "complete.proxyEnable", // 是否启用代理
	streamEnable: "complete.streamEnable", // 是否启用流式响应
	expandHeadEnable: "complete.expandHeadEnable", // 是否启用扩展头文件
	testFrame: "complete.testFrame", // 测试框架
	mockTool: "complete.mockTool", // Mock 工具
	knowledgeUrl: "complete.knowledgeUrl", // 自定义知识库URL
	fileContentLengthLimit: "complete.fileContentLengthLimit", // 文件最大行数，如果超出阈值语法树不解析，相似代码不获取
	delay: "complete.delay", // 延迟时间
	enableRemoteKnowledgeBase: "complete.enableRemoteKnowledgeBase", //远端知识库
}

export const commonIgnoreKeywordSet = new Set([
	"we",
	"our",
	"you",
	"it",
	"its",
	"they",
	"them",
	"their",
	"this",
	"that",
	"these",
	"those",
	"is",
	"are",
	"was",
	"were",
	"be",
	"been",
	"being",
	"have",
	"has",
	"had",
	"having",
	"do",
	"does",
	"did",
	"doing",
	"can",
	"don",
	"t",
	"s",
	"will",
	"would",
	"should",
	"what",
	"which",
	"who",
	"when",
	"where",
	"why",
	"how",
	"a",
	"an",
	"the",
	"and",
	"or",
	"not",
	"no",
	"but",
	"because",
	"as",
	"until",
	"again",
	"further",
	"then",
	"once",
	"here",
	"there",
	"all",
	"any",
	"both",
	"each",
	"few",
	"more",
	"most",
	"other",
	"some",
	"such",
	"above",
	"below",
	"to",
	"during",
	"before",
	"after",
	"of",
	"at",
	"by",
	"about",
	"between",
	"into",
	"through",
	"from",
	"up",
	"down",
	"in",
	"out",
	"on",
	"off",
	"over",
	"under",
	"only",
	"own",
	"same",
	"so",
	"than",
	"too",
	"very",
	"just",
	"now",
])
export const languageIgnoreKeywordSet = new Set([
	"if",
	"then",
	"else",
	"for",
	"while",
	"with",
	"def",
	"function",
	"return",
	"TODO",
	"import",
	"try",
	"catch",
	"raise",
	"finally",
	"repeat",
	"switch",
	"case",
	"match",
	"assert",
	"continue",
	"break",
	"const",
	"class",
	"enum",
	"struct",
	"static",
	"new",
	"super",
	"this",
	"var",
	...commonIgnoreKeywordSet,
])

export const LOG_KEYS = {
	prompt: "prompt",
	inlineCompletion: "inlineCompletion",
	onData: "onData",
	streamResponse: "流式请求返回",
	SyntaxTreeInit: "SyntaxTreeInit",
	languageId: "LANG_ID",
	exportChat: "EXPORT_CHAT",
	onError: "补全请求错误",
	streamEnd: "流式请求完成",
	respEnd: "非流式请求完成",
	performance: "performance",
	completionResponse: "补全响应",
	fimResultError: "补全结果错误",
	uacAuthentication: "UAC鉴权",
	reqKnowledge: "请求知识库",
	completionHeader: "Completion Header",
	webUacInfo: "Web UAC Info",
}

export const RESPONSE_CODE = {
	SUCCESS: "0000",
	AUTH_FAILED: "0002",
	RESPONSE_ERROR: "0100",
	LIMIT_STATUS: "0008",
	SMART_INTERCEPTOR: "0009",
}

/* eslint-disable no-unused-vars */
export enum SpanEnum {
	getSyntaxTree = "getSyntaxTree",
	getLocalKnowledgeBase = "getLocalKnowledgeBase",
	getSimilarCode = "getSimilarCode",
	getPromptTime = "getPromptTime",
	getResponse = "getResponse",
	totalOfCompetion = "totalOfCompetion",
}
