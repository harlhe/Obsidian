import { PointRange } from "../types/index"
import { Point } from "web-tree-sitter"

// 检查point是否在PointRange的范围内容
export function indexOfPoint(point: Point, pointRange: PointRange): boolean {
	// 如果在中间行，直接返回true
	if (point.row > pointRange.startPoint.row && point.row < pointRange.endPoint.row) {
		return true
	} else if (point.row === pointRange.startPoint.row && point.row === pointRange.endPoint.row) {
		return point.column >= pointRange.startPoint.column && point.column <= pointRange.endPoint.column
	} else if (point.row === pointRange.startPoint.row) {
		return point.column >= pointRange.startPoint.column
	} else if (point.row === pointRange.endPoint.row) {
		return point.column <= pointRange.endPoint.column
	}
	return false
}

// 比较两个点，返回值为1表示point1在point2之前，返回值为-1表示point1在point2之后
// 如果两个点相等，则返回0
export function comparePoint(point1: Point, point2: Point): number {
	if (point1.row < point2.row) {
		return -1
	} else if (point1.row > point2.row) {
		return 1
	} else {
		if (point1.column < point2.column) {
			return -1
		} else if (point1.column > point2.column) {
			return 1
		} else {
			return 0
		}
	}
}
