import Parser, { Point, Tree } from "web-tree-sitter"
import { fileDataCache } from "../cache/cache"
import {
	FunctionInfo,
	VariableInfo,
	StructInfo,
	MacroDefinitionInfo,
	EnumInfo,
	ClassInfo,
	CallInfo,
	CallFuncInfo,
	FileType,
	PointRange,
} from "../types"
import { indexOfPoint } from "../util/point-utils"
import { parseFileType } from "../util/tree-sitter-util"

export abstract class SyntaxTreeAnalysis {
	fileType: FileType = "business"
	tree: Tree
	parser: Parser
	constructor(tree: Tree, parser: Parser) {
		this.tree = tree
		this.parser = parser
	}

	/**
	 * 查询函数信息
	 */
	abstract getFunctionList(): Array<FunctionInfo>

	abstract getFunctionBodyExceptPointFunc(point: Point): Array<string>
	/**
	 * 列出所有的函数
	 */
	abstract getFunctionBodyList(): Array<string>

	/**
	 * 查询全局变量列表
	 */
	abstract getGlobalVariableList(): Array<VariableInfo>

	/**
	 * 查询导入、引入信息
	 */
	abstract getImportList(): Array<any>

	/**
	 * 查询自定义类型信息
	 */
	abstract getCustomTypeList(): Array<StructInfo>

	/**
	 * 查询宏定义
	 */
	abstract getMacroDefinitionList(): Array<MacroDefinitionInfo>

	/**
	 * 查询枚举
	 */
	abstract getEnumList(): Array<EnumInfo>
	/**
	 * 查询类定义
	 */
	abstract getClassList(): Array<ClassInfo>
	/**
	 * 查询函数调用
	 */
	abstract getCallFunctionInfoList(): Array<CallFuncInfo>

	/**
	 * 生效变量过滤器
	 * @param point 当前位置
	 * @param variableList 变量列表
	 */
	abstract effectVariableFilter(point: Point, variableList: Array<VariableInfo>): Array<VariableInfo>

	/**
	 * 查询调用方法
	 */
	abstract getCallList(): CallInfo

	public async setFileType(fileUri: string) {
		const fileCommonData = fileUri && fileDataCache.get(fileUri)
		if (fileCommonData) {
			this.fileType = fileCommonData.fileType
		} else {
			this.fileType = await parseFileType(fileUri)
		}
	}

	public getCurLocalVariable(variableInfoList: VariableInfo[], pointRange: PointRange) {
		const localVariableList: VariableInfo[] = []
		for (const item of variableInfoList) {
			if (item.pointRange.startPoint.row > pointRange.endPoint.row) {
				break
			}
			if (indexOfPoint(item.pointRange.startPoint, pointRange)) {
				localVariableList.push(item)
			}
		}
		return localVariableList
	}

	public getCurCallExpression(callFuncInfoList: CallFuncInfo[], curFunctionRange: PointRange) {
		const curCallFunctionList: CallFuncInfo[] = []
		for (const item of callFuncInfoList) {
			if (item.pointRange.startPoint.row > curFunctionRange.endPoint.row) {
				break
			}
			if (indexOfPoint(item.pointRange.startPoint, curFunctionRange)) {
				curCallFunctionList.push(item)
			}
		}
		return curCallFunctionList
	}

	public searchDefineName(node: Parser.SyntaxNode): string {
		let defineName: string = ""
		for (let element of node.children) {
			if (element.type === "type_identifier") {
				defineName = element.text
				break
			}
		}
		return defineName
	}
}
