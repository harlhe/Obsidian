import { Point, Tree } from "web-tree-sitter"
import { SyntaxTreeAnalysis } from "./SyntaxTreeAnalysis"
import setting from "../config/setting.json"
import {
	ClassInfo,
	EnumInfo,
	FunctionInfo,
	MacroDefinitionInfo,
	PrefixSuffix,
	StructInfo,
	VariableInfo,
	CallInfo,
	KnowledgeInfo,
	CodeInfo,
	FileCommonData,
	ChangeDetail,
	CompletionSyntaxInfo,
} from "../types/index"
import { readFileSync } from "fs"
import { indexOfPoint } from "../util/point-utils"
import { GetParserResult, getParser, isPointInRange } from "../util/tree-sitter-util"
import { TextDocument, Position, Range } from "vscode"
import * as vscode from "vscode"
import path from "path"

import { SyntaxTreeAnalysisC } from "./languages/SyntaxTreeAnalysisC"
import { SyntaxTreeAnalysisCpp } from "./languages/SyntaxTreeAnalysisCpp"
import { SyntaxTreeAnalysisJavaScript } from "./languages/SyntaxTreeAnalysisJavaScript"
import { LOG_KEYS } from "../util/consants"
import { FileInfo, ParserTrees } from "../../util/parserTrees"
import { WASM_LANGAUAGES } from "../util/consants"
import { SyntaxTreeAnalysisJava } from "./languages/SyntaxTreeAnalysisJava"
import { SyntaxTreeAnalysisScala } from "./languages/SyntaxTreeAnalysisScala"
import { fileDataCache } from "../cache/cache"
import { CodeParser } from "../handler/code-parser"
import { Logger } from "../../util/logger"
import { FileCommonInfo } from "../common/file-common-info"

export function pretreatment(languageId: string, fileData: string): string {
	if (languageId === "cpp") {
		fileData = fileData + "\n" // 末尾增加一个空行，使正则处理统一
		fileData = fileData.replace(/\n[ | \t]*USING_\w+[ | \t]*\n/g, "\n\n")
		fileData = fileData.replace(/\n[ | \t]*\w+_NS_\w+[ | \t]*\n/g, "\n\n")
		fileData = fileData.replace(/\n[ | \t]*template\s*<.+>[ | \t]*\n/g, "\n\n")
		fileData = fileData.replace(/ROLE\(\s*(\w+)\s*\)\./g, "$1::")
		fileData = fileData.replace(/DEFINE_ROLE\(\s*(\w+)\s*\)/g, "struct $1")
		fileData = fileData.replace(/GET_OBJECT_TO_ROLE\(\s*(\S+)\s*,\s*(\S+)\)\s*;/g, "$1 $2;")
	}
	return fileData
}
export class InlineCompletionInfo {
	private filePath: string
	private syntaxTreeAnalysis: SyntaxTreeAnalysis | null = null

	private functionList: Array<FunctionInfo> = []
	private importList: Array<any> = []
	private customTypeList: Array<StructInfo> | undefined
	private macroDefinitionList: Array<MacroDefinitionInfo> | undefined
	private globalVariableList: Array<VariableInfo> = []
	private enumList: Array<EnumInfo> | undefined
	private classList: Array<ClassInfo> | undefined
	private callList: CallInfo = {
		callFuncText: [],
		callMulDefineText: [],
	}

	public languageId: string = ""
	public initOk: boolean = false
	public static initFailedCount: Map<string, number> = new Map<string, number>()
	constructor(filePath: string) {
		this.filePath = filePath
		const fileExtension = path.extname(this.filePath).slice(1)
		this.languageId = WASM_LANGAUAGES[fileExtension]
	}

	public async getCompletionSyntaxInfo(position: Position, document: TextDocument): Promise<CompletionSyntaxInfo> {
		// 当前函数签名
		let curFunctionInfo: FunctionInfo | null = null
		let curStructInfo: StructInfo | null = null
		let curClassInfo: ClassInfo | null = null
		// 关联代码
		let associatedCode: string[] = []
		// 全局变量
		let globalVariableList: VariableInfo[] = []
		// 结构体变量
		let structList: string[] = []
		// 宏定义
		let macroDefinitionList: string[] = []
		// 枚举变量
		let enumList: string[] = []
		// 类定义变量
		let classList: string[] = []
		// 引入列表
		let dependencyPackageList: string[] = []
		if (document.getText().trim() !== "") {
			await this.update(position, document)
		}
		if (this.initOk) {
			curFunctionInfo = this.getCurFunction({
				row: position.line,
				column: position.character,
			})
			curStructInfo = this.getCurStruct({
				row: position.line,
				column: position.character,
			})
			curClassInfo = this.getCurClass({
				row: position.line,
				column: position.character,
			})
			const curPoint = { row: position.line, column: position.character }
			globalVariableList = this.getGlobalVariableList(curPoint)
			structList = this.getStructList(curPoint)
			macroDefinitionList = this.getMacroDefinitionList(curPoint)
			enumList = this.getEnumTypeList(curPoint)
			classList = this.getClassList(curPoint)
			dependencyPackageList = this.getImportList()
			if (curFunctionInfo !== null) {
				associatedCode = this.getAssociatedCode(curFunctionInfo.functionName!, document)

				if (curFunctionInfo.isHasGrammarError) {
					const startPosition = new Position(
						curFunctionInfo.blockRange.startPoint.row,
						curFunctionInfo.blockRange.startPoint.column,
					)
					curFunctionInfo.functionDefinition = document.getText(new Range(startPosition, position))
					if (curFunctionInfo.functionSign.length > curFunctionInfo.functionDefinition.length) {
						curFunctionInfo.functionSign = curFunctionInfo.functionDefinition
						const functionMatch = curFunctionInfo.functionSign.match(/(?:\w+\s+)*(\w+)\s*\(/)
						if (functionMatch) {
							curFunctionInfo.functionName = functionMatch[1]
							curFunctionInfo.functionDeclarator = curFunctionInfo.functionSign.split("(")[0]
						}
						curFunctionInfo.functionSignBlockRange.endPoint = {
							row: position.line,
							column: position.character,
						}
					}
				}
			}
		}
		return {
			curFunctionInfo: curFunctionInfo,
			curStructInfo: curStructInfo,
			curClassInfo: curClassInfo,
			associatedCode: associatedCode,
			globalVariableList: globalVariableList,
			structList: structList,
			enumList: enumList,
			classList: classList,
			macroDefinitionList: macroDefinitionList,
			dependencyPackageList: dependencyPackageList,
		}
	}

	// 更新补全文件语义信息
	async update(position: vscode.Position, document: TextDocument) {
		let codeInfo: CodeInfo | null | undefined = null
		const codeParser = new CodeParser(document)

		try {
			if (document.lineCount < setting.complete.maxFileLineForCache) {
				let fileInfo: FileCommonData | null | undefined = fileDataCache.get(document.uri.fsPath)
				if (fileInfo) {
					let isNeedUpdate = false
					const oldContent = fileInfo.content
					const newContent = document.getText()
					let oldCurentFunction: FunctionInfo | null = null
					let oldCurrentStruct: StructInfo | null = null
					let oldCurrentClass: ClassInfo | null = null
					let changePointBelongFunction: FunctionInfo | null = null
					let changeEndPointBelongStruct: StructInfo | null = null
					let changeEndPointBelongClass: ClassInfo | null = null
					let positionReferenceChange: ChangeDetail[] = []
					if (document.version !== fileInfo.version && fileInfo.codeInfo && oldContent) {
						// 增量更新
						codeInfo = fileInfo.codeInfo
						// 获取变更内容
						const changeDetails = codeParser.getChangeDetails(oldContent, newContent)
						const currentPoint = {
							row: position.line,
							column: position.character,
						}
						if (changeDetails.length === 1) {
							positionReferenceChange = changeDetails
						} else {
							for (let changeDetail of changeDetails) {
								if (isPointInRange(currentPoint, changeDetail.startPoint, changeDetail.endPoint)) {
									positionReferenceChange.push(changeDetail)
								}
							}
						}
						if (positionReferenceChange.length != 0) {
							oldCurentFunction = this.getCurFunction(currentPoint, codeInfo.functionList)
							oldCurrentStruct = this.getCurStruct(currentPoint, codeInfo.customTypeList)
							oldCurrentClass = this.getCurClass(currentPoint, codeInfo.classList)
							if (oldCurentFunction && !oldCurentFunction.isHasGrammarError) {
								const startLine = oldCurentFunction.blockRange.startPoint.row
								let endLine = oldCurentFunction.blockRange.endPoint.row
								positionReferenceChange.map((item) => {
									if (item.type === "remove" && oldCurentFunction) {
										endLine -= item.count
									} else if (item.type === "add" && oldCurentFunction) {
										endLine += item.count
									}
								})
								endLine = Math.min(document.lineCount - 1, endLine)
								const textRange = new Range(
									new Position(startLine, 0),
									new Position(endLine, document.lineAt(endLine).text.length),
								)
								const newText = document.getText(textRange)
								const newCodeInfo = await codeParser.parse(newText, position)
								changePointBelongFunction = this.getCurFunction(
									{
										row: position.line - startLine,
										column: position.character,
									},
									newCodeInfo?.functionList,
								)
								if (
									changePointBelongFunction &&
									changePointBelongFunction.functionName === oldCurentFunction.functionName
								) {
									this.adjustFunctionPositions(changePointBelongFunction, startLine)
									isNeedUpdate = true
								}
							}
							if (oldCurrentStruct) {
								const startLine = oldCurrentStruct.pointRange.startPoint.row
								let endLine = oldCurrentStruct.pointRange.endPoint.row
								positionReferenceChange.map((item) => {
									if (item.type === "remove" && oldCurrentStruct) {
										endLine = oldCurrentStruct.pointRange.endPoint.row - item.count
									}
									if (item.type === "add" && oldCurrentStruct) {
										endLine = oldCurrentStruct.pointRange.endPoint.row + item.count
									}
								})
								endLine = Math.min(document.lineCount - 1, endLine)
								const textRange = new Range(
									new Position(startLine, 0),
									new Position(endLine, document.lineAt(endLine).text.length),
								)
								const newText = document.getText(textRange)
								const newCodeInfo = await codeParser.parse(newText, position)
								changeEndPointBelongStruct = this.getCurStruct(
									{
										row: position.line - startLine,
										column: position.character,
									},
									newCodeInfo?.customTypeList,
								)

								if (
									changeEndPointBelongStruct &&
									changeEndPointBelongStruct.structName === oldCurrentStruct.structName
								) {
									this.adjustStructPositions(changeEndPointBelongStruct, startLine)
									isNeedUpdate = true
								}
							}
							if (oldCurrentClass) {
								const startLine = oldCurrentClass.pointRange.startPoint.row
								let endLine = oldCurrentClass.pointRange.endPoint.row
								positionReferenceChange.map((item) => {
									if (item.type === "remove" && oldCurrentStruct) {
										endLine = oldCurrentStruct.pointRange.endPoint.row - item.count
									}
									if (item.type === "add" && oldCurrentStruct) {
										endLine = oldCurrentStruct.pointRange.endPoint.row + item.count
									}
								})
								endLine = Math.min(document.lineCount - 1, endLine)
								const textRange = new Range(
									new Position(startLine, 0),
									new Position(endLine, document.lineAt(endLine).text.length),
								)
								const newText = document.getText(textRange)
								const newCodeInfo = await codeParser.parse(newText, position)

								changeEndPointBelongClass = this.getCurClass(
									{
										row: position.line - startLine,
										column: position.character,
									},
									newCodeInfo?.classList,
								)

								if (
									changeEndPointBelongClass &&
									changeEndPointBelongClass.className === oldCurrentClass.className
								) {
									this.adjustClassPositions(changeEndPointBelongClass, startLine)
									isNeedUpdate = true
								}
							}
						}
					}
					if (isNeedUpdate && codeInfo) {
						Logger("info", "the file parse info will update")
						if (changePointBelongFunction && oldCurentFunction) {
							const index = codeInfo.functionList.indexOf(oldCurentFunction)
							if (index !== -1) {
								codeInfo.functionList[index] = changePointBelongFunction!
							}
							if (changeEndPointBelongStruct && oldCurrentStruct && codeInfo.customTypeList) {
								const index = codeInfo.customTypeList.indexOf(oldCurrentStruct)
								if (index !== -1) {
									codeInfo.customTypeList[index] = changeEndPointBelongStruct!
								}
							}
							if (changeEndPointBelongClass && oldCurrentClass && codeInfo.classList) {
								const index = codeInfo.classList.indexOf(oldCurrentClass)
								if (index !== -1) {
									codeInfo.classList[index] = changeEndPointBelongClass!
								}
							}
						} else {
							if (document.version === fileInfo.version) {
								codeInfo = fileInfo.codeInfo
							} else {
								Logger("info", "the file will re-parse")
								// 全量解析
								codeInfo = await codeParser.parse(document.getText(), position)
							}
						}
						// 更新缓存
						fileInfo.version = document.version
						fileInfo.totalLine = document.lineCount
						fileInfo.content = document.lineCount > setting.complete.maxFileLineForCache ? "" : newContent
						fileInfo.codeInfo = document.lineCount > setting.complete.maxFileLineForCache ? null : codeInfo
						fileDataCache.set(document.uri.fsPath, fileInfo)
					} else {
						if (document.version === fileInfo.version) {
							codeInfo = fileInfo.codeInfo
						} else {
							fileInfo = await new FileCommonInfo(document).fileActiveDo(position)
							codeInfo = fileInfo?.codeInfo
						}
					}
				} else {
					// 没有缓存
					Logger("info", "no file cache, so the file will parse")
					fileInfo = await new FileCommonInfo(document).fileActiveDo(position)
					codeInfo = fileInfo?.codeInfo
				}
			} else {
				// 超大文件
				Logger("info", "larger file parse")
				codeInfo = await new FileCommonInfo(document).windowParse(position)
			}

			if (!codeInfo) return
			// 更新语法信息
			this.functionList = codeInfo.functionList
			this.importList = codeInfo.importList
			this.customTypeList = codeInfo.customTypeList
			this.macroDefinitionList = codeInfo.macroDefinitionList
			this.enumList = codeInfo.enumList
			this.classList = codeInfo.classList
			this.globalVariableList = codeInfo.globalVariableList
			this.initOk = true
		} catch (ex: any) {
			Logger("error", `解析${this.filePath}异常：${ex.message}`, LOG_KEYS.SyntaxTreeInit)
			this.initOk = false
		}
	}

	/**
	 * 解析依赖信息
	 */
	public async initLocalKnowledge(): Promise<void> {
		if (!this.languageId) {
			this.initOk = false
			return
		}
		if (!InlineCompletionInfo.initFailedCount.has(this.languageId)) {
			InlineCompletionInfo.initFailedCount.set(this.languageId, 0)
		}

		if (InlineCompletionInfo.initFailedCount.get(this.languageId)! > 3) {
			// 连续超过3次失败，直接返回
			this.initOk = false
			return
		}
		const rst = await getParser(this.languageId)
		if (!rst) {
			this.initOk = false
			return
		}

		let fileData: string | null = readFileSync(this.filePath, "utf8")
		if (fileData === null || fileData === "") {
			this.initOk = false
			return
		}

		// 文档内容进行预处理
		fileData = pretreatment(this.languageId, fileData)

		let tree: Tree | null = rst.parser.parse(fileData)
		// TODO 这里需要根据文件类型来选择不同的解析器。 目前只支持C和JavaScript。可以考虑实现为自动加载，类似Java的反射
		switch (this.languageId) {
			case "c":
				this.syntaxTreeAnalysis = new SyntaxTreeAnalysisC(tree!, rst.parser)
				break
			case "cpp":
				this.syntaxTreeAnalysis = new SyntaxTreeAnalysisCpp(tree!, rst.parser)
				break
			case "javascript":
				this.syntaxTreeAnalysis = new SyntaxTreeAnalysisJavaScript(tree!, rst.parser)
				break
			case "scala":
				this.syntaxTreeAnalysis = new SyntaxTreeAnalysisScala(tree!, rst.parser)
				break
		}
		if (this.syntaxTreeAnalysis !== null) {
			this.syntaxTreeAnalysis.setFileType(this.filePath)
			this.functionList = this.syntaxTreeAnalysis.getFunctionList()
			this.customTypeList = this.syntaxTreeAnalysis.getCustomTypeList()
		}
		this.syntaxTreeAnalysis = null
		tree.delete()
		rst.parser.reset()
		this.initOk = true
		InlineCompletionInfo.initFailedCount.set(this.languageId, 0)
	}

	/**
	 * 获取当前函数名称
	 * @param point 光标位置
	 * @returns string | null 函数签名
	 */
	getCurFunction(point: Point, functionList: FunctionInfo[] = this.functionList): FunctionInfo | null {
		if (!functionList) {
			return null
		}
		const collect = []
		for (const item of functionList) {
			if (indexOfPoint(point, item.blockRange)) {
				collect.push(item)
			}
		}
		let result = null
		let maxRow: number = -1
		for (let item of collect) {
			if (item.blockRange.startPoint.row > maxRow) {
				result = item
				maxRow = item.blockRange.startPoint.row
			}
		}
		return result
	}

	/**
	 * 获取当前结构体
	 * @param point 光标位置
	 * @returns string | null 函数签名
	 */
	getCurStruct(point: Point, customTypeList: Array<StructInfo> | undefined = this.customTypeList): StructInfo | null {
		if (!customTypeList) {
			return null
		}
		for (const item of customTypeList) {
			if (indexOfPoint(point, item.pointRange)) {
				return item
			}
		}
		return null
	}

	/**
	 * 获取当前类
	 * @param point 光标位置
	 * @returns string | null 函数签名
	 */
	getCurClass(point: Point, classList: Array<ClassInfo> | undefined = this.classList): ClassInfo | null {
		if (!classList) {
			return null
		}
		for (const item of classList) {
			if (indexOfPoint(point, item.pointRange)) {
				return item
			}
		}
		return null
	}

	/**
	 * 获取当前函数的兄弟函数
	 * @param point 光标位置
	 * @returns Array<string> | null 兄弟函数签名列表
	 */
	getBrotherFunction(point: Point): Array<string> | null {
		return null
	}

	/**
	 * 获取文件引入列表
	 * @returns string | null 引入信息列表
	 */
	getImportList(): Array<string> {
		return this.importList
	}

	getGlobalVariableList(point: Point): Array<VariableInfo> {
		return this.globalVariableList
	}

	getStructList(point: Point): Array<string> {
		if (!this.customTypeList) return []
		let structList: string[] = []
		for (let struct of this.customTypeList) {
			if (
				struct.curBlockRange.startPoint.row < point.row &&
				struct.curBlockRange.endPoint.row > point.row &&
				struct.pointRange.endPoint.row < point.row
			) {
				structList.push(struct.structText)
			}
		}
		return structList
	}

	getMacroDefinitionList(point: Point): Array<string> {
		if (!this.macroDefinitionList) return []
		let macroDefinitionListTemp: string[] = []
		for (let macroDefinition of this.macroDefinitionList) {
			if (macroDefinition.pointRange.endPoint.row <= point.row) {
				macroDefinitionListTemp.push(macroDefinition.macroName)
			}
		}
		return macroDefinitionListTemp
	}

	getEnumTypeList(point: Point): Array<string> {
		if (!this.enumList) return []
		let enumList: string[] = []
		for (let enumMember of this.enumList) {
			if (enumMember.pointRange.endPoint.row < point.row) {
				enumList.push(enumMember.enumText)
			}
		}
		return enumList
	}

	getClassList(point: Point): Array<string> {
		if (!this.classList) return []
		let classList: string[] = []
		for (let classMember of this.classList) {
			if (
				classMember.curBlockRange.startPoint.row < point.row &&
				classMember.curBlockRange.endPoint.row > point.row &&
				classMember.pointRange.endPoint.row < point.row
			) {
				classList.push(classMember.classText)
			}
		}
		return classList
	}

	async getLocalKnowledgeMsgList(prefixSuffix: PrefixSuffix): Promise<KnowledgeInfo | undefined> {
		let knowledgeInit: KnowledgeInfo = {
			// 声明
			FuncText: [],
			EnumText: [],
			StructText: [],
			MacroText: [],
			ClassText: [],
		}

		if (!this.initOk) return knowledgeInit

		let prefixResult: GetParserResult | null = await getParser(this.languageId)

		if (!prefixResult || prefixSuffix.prefix === "") return knowledgeInit

		const tree: Tree = prefixResult.parser.parse(prefixSuffix.prefix)

		switch (this.languageId) {
			case "c":
				this.syntaxTreeAnalysis = new SyntaxTreeAnalysisC(tree!, prefixResult.parser)
				break
			case "cpp":
				this.syntaxTreeAnalysis = new SyntaxTreeAnalysisCpp(tree!, prefixResult.parser)
				break
			case "java":
				this.syntaxTreeAnalysis = new SyntaxTreeAnalysisJava(tree!, prefixResult.parser)
				break
			case "javascript":
				this.syntaxTreeAnalysis = new SyntaxTreeAnalysisJavaScript(tree!, prefixResult.parser)
				break
			case "scala":
				this.syntaxTreeAnalysis = new SyntaxTreeAnalysisScala(tree!, prefixResult.parser)
				break
		}

		if (this.syntaxTreeAnalysis !== null) {
			this.callList = this.syntaxTreeAnalysis.getCallList()
			return this.searchDefinitionInOther(this.languageId)
		}
		return knowledgeInit
	}

	private searchDefinitionInOther(curFileLanguageId: string): KnowledgeInfo {
		let knowledgeList: KnowledgeInfo = {
			// 声明
			FuncText: [],
			EnumText: [],
			StructText: [],
			MacroText: [],
			ClassText: [],
		}
		let sameLangeageInfoInOther: FileInfo = {
			fileFunc: [],
			fileEnum: [],
			fileStruct: [],
			fileClass: [],
		}

		if (ParserTrees.get().fileDataCache) {
			for (const [, fileData] of ParserTrees.get().fileDataCache.entries()) {
				if (fileData.languageId === curFileLanguageId || (fileData.languageId === "c" && curFileLanguageId === "cpp")) {
					sameLangeageInfoInOther.fileFunc.push(...fileData.fileFunc)
					sameLangeageInfoInOther.fileEnum.push(...fileData.fileEnum)
					sameLangeageInfoInOther.fileClass.push(...fileData.fileClass)
					sameLangeageInfoInOther.fileStruct.push(...fileData.fileStruct)
				}
			}
		}

		// 使用 Set 来提高查找效率
		const callFuncSet = new Set(this.callList.callFuncText)
		// 遍历 sameLangeageInfoInOther.fileFunc，并检查 functionNameText 是否在 callFuncSet 中
		sameLangeageInfoInOther.fileFunc.forEach((fileFunc) => {
			if (fileFunc.functionName && callFuncSet.has(fileFunc.functionName)) {
				knowledgeList.FuncText.push(fileFunc.functionDefinition)
			}
		})

		const callMulDefineSet = new Set(this.callList.callMulDefineText)
		sameLangeageInfoInOther.fileEnum.forEach((fileEnum) => {
			if (fileEnum && callMulDefineSet.has(fileEnum.enumName)) {
				knowledgeList.EnumText.push(fileEnum.enumText)
			}
		})

		sameLangeageInfoInOther.fileStruct.forEach((fileStruct) => {
			if (fileStruct && callMulDefineSet.has(fileStruct.structName)) {
				knowledgeList.StructText.push(fileStruct.structText)
			}
		})

		sameLangeageInfoInOther.fileClass.forEach((fileClass) => {
			if (fileClass && callMulDefineSet.has(fileClass.className)) {
				knowledgeList.ClassText.push(fileClass.classText)
			}
		})
		return knowledgeList
	}

	/**
	 * 获取关联代码
	 * @param curFuncName 当前函数名
	 */
	getAssociatedCode(curFuncName: string, document: TextDocument): string[] {
		if (!this.functionList || !this.syntaxTreeAnalysis) return []
		let associatedCode: string[] = []
		const prefixMap: { [key: string]: string } = {
			get: "set",
			set: "get",
			add: "del",
			del: "add",
		}

		let transformedPrefix = curFuncName
		for (const [original, transformed] of Object.entries(prefixMap)) {
			if (curFuncName.startsWith(original)) {
				transformedPrefix = transformed + curFuncName.slice(original.length)
				break
			}
		}

		let associateFuncName = ""
		if (transformedPrefix === curFuncName) {
			return associatedCode
		} else {
			associateFuncName = transformedPrefix.replace(/\(.*?\)/g, "")
		}

		this.functionList?.forEach((item) => {
			if (item.functionDeclarator.includes(associateFuncName)) {
				const block = item.blockRange
				const start = new vscode.Position(block.startPoint.row, block.startPoint.column)
				const end = new vscode.Position(block.endPoint.row, block.endPoint.column)
				const range = new vscode.Range(start, end)
				const codeContent = document.getText(range) || ""
				associatedCode.push(codeContent)
			}
		})

		return associatedCode
	}

	getAllStruct(): StructInfo[] | undefined {
		return this.customTypeList
	}

	getAllFunction(): FunctionInfo[] | undefined {
		return this.functionList
	}

	private adjustFunctionPositions(func: FunctionInfo, startLine: number): void {
		func.blockRange.startPoint = {
			row: func.blockRange.startPoint.row + startLine,
			column: func.blockRange.startPoint.column,
		}
		func.blockRange.endPoint = {
			row: func.blockRange.endPoint.row + startLine,
			column: func.blockRange.endPoint.column,
		}
		func.functionSignBlockRange.startPoint = {
			row: func.functionSignBlockRange.startPoint.row + startLine,
			column: func.functionSignBlockRange.startPoint.column,
		}
		func.functionSignBlockRange.endPoint = {
			row: func.functionSignBlockRange.endPoint.row + startLine,
			column: func.functionSignBlockRange.endPoint.column,
		}

		func.localVariableList.forEach((item) => {
			item.pointRange.startPoint = {
				row: item.pointRange.startPoint.row + startLine,
				column: item.pointRange.startPoint.column,
			}
			item.pointRange.endPoint = {
				row: item.pointRange.endPoint.row + startLine,
				column: item.pointRange.endPoint.column,
			}
		})

		func.callExpressionList.forEach((item) => {
			item.pointRange.startPoint = {
				row: item.pointRange.startPoint.row + startLine,
				column: item.pointRange.startPoint.column,
			}
			item.pointRange.endPoint = {
				row: item.pointRange.endPoint.row + startLine,
				column: item.pointRange.endPoint.column,
			}
		})
	}

	private adjustStructPositions(struct: StructInfo, startLine: number): void {
		struct.pointRange.startPoint = {
			row: struct.pointRange.startPoint.row + startLine,
			column: struct.pointRange.startPoint.column,
		}
		struct.pointRange.endPoint = {
			row: struct.pointRange.endPoint.row + startLine,
			column: struct.pointRange.endPoint.column,
		}
		struct.curBlockRange.startPoint = {
			row: struct.curBlockRange.startPoint.row + startLine,
			column: struct.curBlockRange.startPoint.column,
		}
		struct.curBlockRange.endPoint = {
			row: struct.curBlockRange.endPoint.row + startLine,
			column: struct.curBlockRange.endPoint.column,
		}
		struct.localVariableList.forEach((item) => {
			item.pointRange.startPoint = {
				row: item.pointRange.startPoint.row + startLine,
				column: item.pointRange.startPoint.column,
			}
			item.pointRange.endPoint = {
				row: item.pointRange.endPoint.row + startLine,
				column: item.pointRange.endPoint.column,
			}
		})

		struct.callExpressionList.forEach((item) => {
			item.pointRange.startPoint = {
				row: item.pointRange.startPoint.row + startLine,
				column: item.pointRange.startPoint.column,
			}
			item.pointRange.endPoint = {
				row: item.pointRange.endPoint.row + startLine,
				column: item.pointRange.endPoint.column,
			}
		})
	}

	private adjustClassPositions(cls: ClassInfo, startLine: number): void {
		cls.pointRange.startPoint = {
			row: cls.pointRange.startPoint.row + startLine,
			column: cls.pointRange.startPoint.column,
		}
		cls.pointRange.endPoint = {
			row: cls.pointRange.endPoint.row + startLine,
			column: cls.pointRange.endPoint.column,
		}
		cls.curBlockRange.startPoint = {
			row: cls.curBlockRange.startPoint.row + startLine,
			column: cls.curBlockRange.startPoint.column,
		}
		cls.curBlockRange.endPoint = {
			row: cls.curBlockRange.endPoint.row + startLine,
			column: cls.curBlockRange.endPoint.column,
		}
		cls.localVariableList.forEach((item) => {
			item.pointRange.startPoint = {
				row: item.pointRange.startPoint.row + startLine,
				column: item.pointRange.startPoint.column,
			}
			item.pointRange.endPoint = {
				row: item.pointRange.endPoint.row + startLine,
				column: item.pointRange.endPoint.column,
			}
		})

		cls.callExpressionList.forEach((item) => {
			item.pointRange.startPoint = {
				row: item.pointRange.startPoint.row + startLine,
				column: item.pointRange.startPoint.column,
			}
			item.pointRange.endPoint = {
				row: item.pointRange.endPoint.row + startLine,
				column: item.pointRange.endPoint.column,
			}
		})
	}
}
