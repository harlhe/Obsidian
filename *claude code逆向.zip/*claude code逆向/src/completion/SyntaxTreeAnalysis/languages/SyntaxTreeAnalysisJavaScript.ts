import Parser, { Point, QueryMatch, Tree } from "web-tree-sitter"
import { SyntaxTreeAnalysis } from "../SyntaxTreeAnalysis"
import {
	FunctionInfo,
	PointRange,
	VariableInfo,
	StructInfo,
	MacroDefinitionInfo,
	EnumInfo,
	ClassInfo,
	CallInfo,
	ContextualCompletion,
	CallFuncInfo,
} from "../../types"

export class SyntaxTreeAnalysisJavaScript extends SyntaxTreeAnalysis {
	constructor(tree: Tree, parser: Parser) {
		super(tree, parser)
	}

	getFunctionList(): Array<FunctionInfo> {
		const query = `(function_declaration name: (identifier) @function_name parameters: (formal_parameters) @parameters )`

		const language = this.parser.getLanguage()
		const queryInstance = language.query(query)
		const matches: QueryMatch[] = queryInstance.matches(this.tree.rootNode)
		return this.functionQueryResultHandler(matches)
	}

	getFunctionContextAtPoint(point: Point): ContextualCompletion | null {
		return null
	}

	getFunctionBodyList(): Array<string> {
		return []
	}

	getFunctionBodyExceptPointFunc(point: Point): Array<string> {
		return []
	}

	getImportList(): Array<any> {
		return []
	}

	/**
	 * 查询全局变量列表
	 */
	getGlobalVariableList(): Array<VariableInfo> {
		return []
	}

	/**
	 * 查询自定义类型信息
	 */
	getCustomTypeList(): Array<StructInfo> {
		return []
	}

	/**
	 * 查询宏定义信息
	 */
	getMacroDefinitionList(): Array<MacroDefinitionInfo> {
		return []
	}

	/**
	 * 采集枚举类型
	 */
	getEnumList(): Array<EnumInfo> {
		return []
	}

	/**
	 * 采集类定义
	 */
	getClassList(): Array<ClassInfo> {
		return []
	}

	getCallFunctionInfoList(): CallFuncInfo[] {
		return []
	}

	getCallList(): CallInfo {
		let result: CallInfo = {
			callFuncText: [],
			callMulDefineText: [],
		}
		return result
	}

	private functionQueryResultHandler(matches: Parser.QueryMatch[]): Array<FunctionInfo> {
		const funcInfoList: Array<FunctionInfo> = new Array<FunctionInfo>()
		for (let match of matches) {
			let functionName: string = ""
			let parameters: string = ""
			let functionSignBlockRange: PointRange | undefined = undefined
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			let curBlockRange: PointRange | undefined = undefined
			let functionNameText: string = ""
			for (let capture of match.captures) {
				if (capture.name === "function_name") {
					if (capture.node.parent !== null) {
						curBlockRange = {
							startPoint: capture.node.parent.startPosition,
							endPoint: capture.node.parent.endPosition,
						}
					}
					functionSignBlockRange = {
						startPoint: {
							row: capture.node.startPosition.row,
							column: 0,
						},
						endPoint: capture.node.endPosition,
					}
					functionName = capture.node.text
					startPoint = capture.node.startPosition
				} else if (capture.name === "parameters") {
					parameters = capture.node.text
					endPoint = capture.node.endPosition
				}
			}

			let funSign = `${functionName} ${parameters}`
			if (
				startPoint !== undefined &&
				endPoint !== undefined &&
				curBlockRange !== undefined &&
				functionSignBlockRange != undefined
			) {
				const functionInfo: FunctionInfo = {
					className: "",
					functionDeclarator: funSign,
					blockRange: {
						startPoint: startPoint,
						endPoint: endPoint,
					},
					functionSign: funSign,
					functionSignBlockRange: functionSignBlockRange,
					returnType: "",
					parameterList: [],
					localVariableList: [],
					callExpressionList: [],
					associatedCodeList: [],
					functionDefinition: "",
					functionName: functionNameText,
					functionIndex: functionNameText,
					isHasGrammarError: true,
				}
				funcInfoList.push(functionInfo)
			}
		}

		return funcInfoList
	}

	/**
	 * 生效变量过滤器
	 * @param point 当前位置
	 * @param variableList 变量列表
	 */
	effectVariableFilter(point: Point, variableList: Array<VariableInfo>): Array<VariableInfo> {
		return []
	}
}
