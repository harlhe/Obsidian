import Parser, { Language, Point, Query, QueryMatch, SyntaxNode, Tree } from "web-tree-sitter"
import { SyntaxTreeAnalysis } from "../SyntaxTreeAnalysis"
import {
	CallInfo,
	ClassInfo,
	EnumInfo,
	FunctionInfo,
	MacroDefinitionInfo,
	PointRange,
	StructInfo,
	VariableInfo,
	CallFuncInfo,
} from "../../types"
import { indexOfPoint } from "../../util/point-utils"
import { isPointInRange } from "../../util/tree-sitter-util"

export class SyntaxTreeAnalysisC extends SyntaxTreeAnalysis {
	private static language: Language
	private static funcQueryInstance: Query
	private static testFuncQueryInstance: Query
	private static funcBodyQueryInstance: Query
	private static importQueryInstance: Query
	private static globalQueryInstance: Query
	private static localQueryInstance: Query
	private static customQueryInstance: Query
	private static macroDefinitionQueryInstance: Query
	private static callQueryInstance: Query
	private static enumQueryInstance: Query
	private variableInfoList: VariableInfo[] = []
	private callFunctionInfoList: CallFuncInfo[] = []

	constructor(tree: Tree, parser: Parser) {
		super(tree, parser)
		if (!SyntaxTreeAnalysisC.language) {
			SyntaxTreeAnalysisC.language = this.parser.getLanguage()
		}

		if (!SyntaxTreeAnalysisC.funcQueryInstance) {
			const query = `
        (function_definition type: [(primitive_type)(type_identifier)] @primitiveType declarator: [(function_declarator declarator: (identifier) @functionName parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType)]) @parameterDeclaration)?) (pointer_declarator declarator: (function_declarator declarator: (identifier) @functionName parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType)]) @parameterDeclaration)?))] @functionDeclarator body: (compound_statement) @functionBody)
        (ERROR type:[(primitive_type)(type_identifier)] @primitiveType (function_declarator declarator: (identifier) @functionName) parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType)]) @parameterDeclaration)?) @errorFunctionDeclarator
      `
			SyntaxTreeAnalysisC.funcQueryInstance = SyntaxTreeAnalysisC.language.query(query)
		}

		if (!SyntaxTreeAnalysisC.testFuncQueryInstance) {
			const query = `
        (function_definition type: [(primitive_type)(type_identifier)] @primitiveType declarator: [(function_declarator declarator: (identifier) @functionName parameters: (parameter_list (parameter_declaration) @parameterDeclaration)?) (pointer_declarator declarator: (function_declarator declarator: (identifier) @functionName parameters: (parameter_list (parameter_declaration) @parameterDeclaration)?))] @functionDeclarator body: (compound_statement) @functionBody)
        (ERROR type:[(primitive_type)(type_identifier)] @primitiveType (function_declarator declarator: (identifier) @functionName) parameters: (parameter_list (parameter_declaration) @parameterDeclaration)?) @errorFunctionDeclarator
      `
			SyntaxTreeAnalysisC.testFuncQueryInstance = SyntaxTreeAnalysisC.language.query(query)
		}

		if (!SyntaxTreeAnalysisC.funcBodyQueryInstance) {
			const query = `(function_definition body: (compound_statement)) @function_body`
			SyntaxTreeAnalysisC.funcBodyQueryInstance = SyntaxTreeAnalysisC.language.query(query)
		}

		if (!SyntaxTreeAnalysisC.importQueryInstance) {
			const query = `(preproc_include) @include`
			SyntaxTreeAnalysisC.importQueryInstance = SyntaxTreeAnalysisC.language.query(query)
		}

		if (!SyntaxTreeAnalysisC.globalQueryInstance) {
			const query = `(translation_unit (declaration type: [(type_identifier) @varType (primitive_type)]) @varDeclaration)`
			SyntaxTreeAnalysisC.globalQueryInstance = SyntaxTreeAnalysisC.language.query(query)
		}

		if (!SyntaxTreeAnalysisC.localQueryInstance) {
			const query = `(function_definition body: (compound_statement ([(declaration type: [(type_identifier) @varType (primitive_type) @varType]) (field_declaration type: [(type_identifier) @varType (primitive_type) @varType])]) @varDeclaration))`
			SyntaxTreeAnalysisC.localQueryInstance = SyntaxTreeAnalysisC.language.query(query)
		}

		if (!SyntaxTreeAnalysisC.customQueryInstance) {
			const query = `(struct_specifier name: (type_identifier) @structName)@struct`
			SyntaxTreeAnalysisC.customQueryInstance = SyntaxTreeAnalysisC.language.query(query)
		}

		if (!SyntaxTreeAnalysisC.macroDefinitionQueryInstance) {
			const query = `
        (preproc_function_def name: (identifier) @macroName)
        (preproc_def name: (identifier) @macroName)
      `
			SyntaxTreeAnalysisC.macroDefinitionQueryInstance = SyntaxTreeAnalysisC.language.query(query)
		}

		if (!SyntaxTreeAnalysisC.callQueryInstance) {
			const query = `
        (call_expression function: (identifier) @callFuncName) @callExpression
        (declaration type: (type_identifier) @callMulDefineText)
      `
			SyntaxTreeAnalysisC.callQueryInstance = SyntaxTreeAnalysisC.language.query(query)
		}

		if (!SyntaxTreeAnalysisC.enumQueryInstance) {
			const query = `(enum_specifier name:(type_identifier) @enumName) @enum`
			SyntaxTreeAnalysisC.enumQueryInstance = SyntaxTreeAnalysisC.language.query(query)
		}
	}

	getFunctionBodyExceptPointFunc(point: Point): Array<string> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisC.funcBodyQueryInstance.matches(this.tree.rootNode)
		let result = []
		for (let match of matches) {
			for (let capture of match.captures) {
				switch (capture.name) {
					case "function_body": {
						let startPoint: Point = capture.node.startPosition
						let endPoint: Point = capture.node.endPosition
						if (endPoint.row < point.row || startPoint.row > point.row) {
							result.push(capture.node.text)
							continue
						}
						if (!isPointInRange(point, startPoint, endPoint)) {
							result.push(capture.node.text)
						}
					}
				}
			}
		}
		return result
	}

	getFunctionList(): Array<FunctionInfo> {
		// 获取函数列表前，先获取所有局部变量定义
		const variableInfoList: VariableInfo[] = this.getLocalVariableList()
		const callFunctionInfoList: CallFuncInfo[] = this.getCallFunctionInfoList()

		let matches: QueryMatch[]
		if (this.fileType !== "business") {
			matches = SyntaxTreeAnalysisC.testFuncQueryInstance.matches(this.tree.rootNode)
		} else {
			matches = SyntaxTreeAnalysisC.funcQueryInstance.matches(this.tree.rootNode)
		}
		return this.functionQueryResultHandler(matches, variableInfoList, callFunctionInfoList)
	}

	getFunctionBodyList(): Array<string> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisC.funcBodyQueryInstance.matches(this.tree.rootNode)
		const rst: string[] = this.functionBodyQueryResultHandler(matches)
		return rst
	}

	getImportList(): Array<any> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisC.importQueryInstance.matches(this.tree.rootNode)
		const rst: Array<any> = this.importQueryResultHandler(matches)
		return rst
	}

	/**
	 * 获取全局变量列表
	 */
	getGlobalVariableList(): Array<VariableInfo> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisC.globalQueryInstance.matches(this.tree.rootNode)
		const rst: Array<VariableInfo> = this.globalVariableQueryResultHandler(matches)
		return rst
	}

	getLocalVariableList(): VariableInfo[] {
		if (this.variableInfoList.length === 0) {
			const matches: QueryMatch[] = SyntaxTreeAnalysisC.localQueryInstance.matches(this.tree.rootNode)
			this.variableInfoList = this.localVariableQueryResultHandler(matches)
		}
		return this.variableInfoList
	}

	/**
	 * 查询自定义类型信息
	 */
	getCustomTypeList(): Array<StructInfo> {
		const variableInfoList: VariableInfo[] = this.getLocalVariableList()
		const callFunctionInfoList: CallFuncInfo[] = this.getCallFunctionInfoList()
		const matches: QueryMatch[] = SyntaxTreeAnalysisC.customQueryInstance.matches(this.tree.rootNode)
		const rst: Array<StructInfo> = this.customTypeQueryResultHandler(matches, variableInfoList, callFunctionInfoList)
		return rst
	}

	/**
	 * 查询宏定义
	 */

	getMacroDefinitionList(): Array<MacroDefinitionInfo> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisC.macroDefinitionQueryInstance.matches(this.tree.rootNode)
		return this.macroDefinitionQueryResultHandler(matches)
	}

	getCallFunctionInfoList(): CallFuncInfo[] {
		if (this.callFunctionInfoList) {
			const matches: QueryMatch[] = SyntaxTreeAnalysisC.callQueryInstance.matches(this.tree.rootNode)
			this.callFunctionInfoList = this.callFuncQueryResultHandler(matches)
		}
		return this.callFunctionInfoList
	}

	getCallList(): CallInfo {
		let callList: CallInfo = {
			callFuncText: [],
			callMulDefineText: [],
		}
		//callMulDefineText 包含类实例、结构体实例、枚举实例
		const matches: QueryMatch[] = SyntaxTreeAnalysisC.callQueryInstance.matches(this.tree.rootNode)
		return this.callQueryResultHandler(matches, callList)
	}

	private localVariableQueryResultHandler(matches: QueryMatch[]): VariableInfo[] {
		const result: VariableInfo[] = []
		for (let match of matches) {
			let variableType = ""
			let variableText = ""
			let pointRange: PointRange | undefined = undefined
			let curBlockRange: PointRange | undefined = undefined
			for (let capture of match.captures) {
				switch (capture.name) {
					case "varType": {
						variableType = capture.node.text
						break
					}
					case "varDeclaration": {
						variableText = capture.node.text
						pointRange = { startPoint: capture.node.startPosition, endPoint: capture.node.endPosition }
						const parentNode: SyntaxNode | null = capture.node.parent
						if (parentNode !== null) {
							curBlockRange = { startPoint: capture.node.endPosition, endPoint: parentNode.endPosition }
						}
						break
					}
				}
			}
			if (pointRange !== undefined && curBlockRange !== undefined) {
				result.push({
					variableType: variableType,
					variableText: variableText,
					pointRange: pointRange,
					curBlockRange: curBlockRange,
					isGlobal: false,
				})
			}
		}
		return result
	}

	private globalVariableQueryResultHandler(matches: QueryMatch[]): any[] {
		const result: Array<VariableInfo> = []
		for (let match of matches) {
			let variableType = ""
			let variableText = ""
			let pointRange: PointRange | undefined = undefined
			let curBlockRange: PointRange | undefined = undefined
			for (let capture of match.captures) {
				switch (capture.name) {
					case "varType": {
						variableType = capture.node.text
						break
					}
					case "varDeclaration": {
						variableText = capture.node.text
						pointRange = { startPoint: capture.node.startPosition, endPoint: capture.node.endPosition }
						if (capture.node.parent !== null) {
							curBlockRange = {
								startPoint: capture.node.endPosition,
								endPoint: capture.node.parent.endPosition,
							}
						}
						break
					}
				}
			}
			if (curBlockRange !== undefined && pointRange !== undefined) {
				result.push({
					variableType: variableType,
					variableText: variableText,
					pointRange: pointRange,
					curBlockRange: curBlockRange,
					isGlobal: true,
				})
			}
		}
		return result
	}

	/**
	 * 采集枚举类型
	 */
	getEnumList(): Array<EnumInfo> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisC.enumQueryInstance.matches(this.tree.rootNode)
		return this.enumQueryResultHandler(matches)
	}

	/**
	 * 采集类定义
	 */
	getClassList(): Array<ClassInfo> {
		return []
	}

	/**
	 * 解析自定义类型信息
	 */
	private customTypeQueryResultHandler(
		matches: Parser.QueryMatch[],
		variableInfoList: VariableInfo[],
		callFunctionInfoList: CallFuncInfo[],
	): StructInfo[] {
		const structInfoList: StructInfo[] = []
		for (let match of matches) {
			let structText = ""
			let structName = ""
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			let actionRangeStartPoint: Point | undefined = undefined
			let actionRangeEndPoint: Point | undefined = undefined
			let isHasGrammarError: boolean = false
			for (let capture of match.captures) {
				switch (capture.name) {
					case "structName": {
						structName = capture.node.text
						break
					}
					case "struct": {
						structText = capture.node.text
						startPoint = capture.node.startPosition
						endPoint = capture.node.endPosition
						actionRangeStartPoint = startPoint
						actionRangeEndPoint = endPoint
						if (capture.node.parent !== null) {
							actionRangeStartPoint = capture.node.parent.startPosition
							actionRangeEndPoint = capture.node.parent.endPosition
						}
						break
					}
				}
			}
			if (!startPoint || !endPoint || !actionRangeStartPoint || !actionRangeEndPoint) continue
			const pointRange = { startPoint: startPoint, endPoint: endPoint }
			const localVariableList = this.getCurLocalVariable(variableInfoList, pointRange)
			const callExpressionList = this.getCurCallExpression(callFunctionInfoList, pointRange)
			structInfoList.push({
				structName: structName,
				structText: structText,
				localVariableList: localVariableList,
				callExpressionList: callExpressionList,
				pointRange: pointRange,
				curBlockRange: {
					startPoint: actionRangeStartPoint,
					endPoint: actionRangeEndPoint,
				},
				isHasGrammarError: isHasGrammarError,
			})
		}
		return structInfoList
	}

	searchMulDefineName(node: Parser.SyntaxNode): string {
		let elementName: string = ""

		node.children.forEach((element) => {
			if (element.type === "type_identifier") {
				elementName = element.text
			}
		})

		return elementName
	}

	/**
	 * 解析函数体信息
	 */
	private functionBodyQueryResultHandler(matches: Parser.QueryMatch[]) {
		const funcBodyList: Array<string> = new Array<string>()
		for (let match of matches) {
			for (let capture of match.captures) {
				switch (capture.name) {
					case "function_body": {
						funcBodyList.push(capture.node.text)
					}
				}
			}
		}

		return funcBodyList
	}

	/**
	 * 解析函数信息
	 */
	private functionQueryResultHandler(
		matches: QueryMatch[],
		variableInfoList: VariableInfo[],
		callFunctionInfoList: CallFuncInfo[],
	): Array<FunctionInfo> {
		const funcInfoMap: Map<string, FunctionInfo> = new Map<string, FunctionInfo>()
		for (let i = 0; i < matches.length; i++) {
			const match = matches[i]
			let functionDeclarator: string = ""
			let functionBody: string = ""
			let returnType: string = ""
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			let functionSignBlockRange: PointRange | undefined = undefined
			let curBlockStartPoint: Point | undefined = undefined
			let curBlockEndPoint: Point | undefined = undefined
			let functionDefinition: string = ""
			let param: string = ""
			let varType: string = ""
			let functionName: string = ""
			let isHasGrammarError: boolean = false
			for (let capture of match.captures) {
				switch (capture.name) {
					case "functionDeclarator": {
						functionSignBlockRange = {
							startPoint: {
								row: capture.node.startPosition.row,
								column: 0,
							},
							endPoint: capture.node.endPosition,
						}
						functionDeclarator = capture.node.text
						break
					}
					case "parameterDeclaration": {
						param = capture.node.text
						if (capture.node.parent && capture.node.parent.children.length > 0) {
							const lastChildren = capture.node.parent.children[capture.node.parent.children.length - 1]
							if (lastChildren && lastChildren.isMissing) {
								isHasGrammarError = true
							}
						}
						break
					}
					case "varType": {
						varType = capture.node.text
						break
					}
					case "functionName": {
						functionName = capture.node.text
						if (!curBlockStartPoint && !startPoint) {
							curBlockStartPoint = capture.node.startPosition
							startPoint = capture.node.startPosition
						}
						break
					}
					case "functionBody": {
						functionBody = capture.node.text
						curBlockEndPoint = capture.node.endPosition
						endPoint = capture.node.endPosition
						if (capture.node.children.length > 0) {
							const lastChildren = capture.node.children[capture.node.children.length - 1]
							if (lastChildren && lastChildren.isMissing) {
								isHasGrammarError = true
							}
						}
						break
					}
					case "primitiveType": {
						returnType = capture.node.text
						curBlockStartPoint = capture.node.startPosition
						startPoint = capture.node.startPosition
						break
					}
					case "errorFunctionDeclarator": {
						functionDeclarator = capture.node.text
						isHasGrammarError = true
						if (!curBlockStartPoint && !startPoint) {
							curBlockStartPoint = capture.node.startPosition
							startPoint = capture.node.startPosition
						}
						endPoint = capture.node.endPosition
						curBlockEndPoint = endPoint
						endPoint = capture.node.endPosition
						curBlockEndPoint = endPoint
						if (i < matches.length - 1) {
							const captures = matches[i + 1].captures
							const nextFunctionCapture = captures.find((capture) => capture.name === "functionName")
							if (nextFunctionCapture) {
								curBlockEndPoint = {
									row: nextFunctionCapture.node.startPosition.row - 1,
									column: 0,
								}
							}
						}
						break
					}
				}
			}

			const funSign = `${returnType} ${functionDeclarator}`.trim()
			functionDefinition = `${funSign}${functionBody}`
			if (
				startPoint !== undefined &&
				endPoint !== undefined &&
				curBlockStartPoint !== undefined &&
				curBlockEndPoint !== undefined &&
				functionSignBlockRange != undefined
			) {
				const blockRange = {
					startPoint: curBlockStartPoint,
					endPoint: curBlockEndPoint,
				}
				const localVariableList = this.getCurLocalVariable(variableInfoList, blockRange)
				const callExpressionList = this.getCurCallExpression(callFunctionInfoList, blockRange)
				const key = `${startPoint.row}${startPoint.column}${endPoint.row}${endPoint.column}`
				let functionInfo: FunctionInfo | undefined = funcInfoMap.get(key)
				if (!functionInfo) {
					functionInfo = {
						className: "",
						functionDeclarator: functionDeclarator,
						blockRange: blockRange,
						functionSign: funSign,
						functionSignBlockRange: functionSignBlockRange,
						returnType: returnType,
						parameterList: param !== "" ? new Array({ paramText: param, variableType: varType }) : [],
						localVariableList: localVariableList,
						callExpressionList: callExpressionList,
						associatedCodeList: [],
						functionDefinition: functionDefinition,
						functionName: functionName,
						functionIndex: functionName,
						isHasGrammarError: isHasGrammarError,
					}
					funcInfoMap.set(key, functionInfo)
				} else {
					functionInfo.parameterList.push({ paramText: param, variableType: varType })
				}
			}
		}

		return Array.from(funcInfoMap.values())
	}

	/**
	 * 解析宏定义信息
	 */
	private macroDefinitionQueryResultHandler(matches: Parser.QueryMatch[]): MacroDefinitionInfo[] {
		const definitionInfoList: MacroDefinitionInfo[] = []
		for (let match of matches) {
			for (let capture of match.captures) {
				if (capture.name === "macroName" && capture.node.parent !== null) {
					const curVariableInfo: MacroDefinitionInfo = {
						macroName: capture.node.parent.text,
						pointRange: {
							startPoint: capture.node.parent.startPosition,
							endPoint: capture.node.parent.endPosition,
						},
					}
					definitionInfoList.push(curVariableInfo)
				}
			}
		}
		return definitionInfoList
	}

	/**
	 * 解析枚举信息
	 */
	private enumQueryResultHandler(matches: Parser.QueryMatch[]): EnumInfo[] {
		const enumInfoList: EnumInfo[] = []
		for (let match of matches) {
			let enumText = ""
			let enumName = ""
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			for (let capture of match.captures) {
				switch (capture.name) {
					case "enumName": {
						enumName = capture.node.text
						break
					}
					case "enum": {
						enumText = capture.node.text
						startPoint = capture.node.startPosition
						endPoint = capture.node.endPosition
						break
					}
				}
			}
			if (!startPoint || !endPoint) continue
			enumInfoList.push({
				enumText: enumText,
				enumName: enumName,
				pointRange: {
					startPoint: startPoint,
					endPoint: endPoint,
				},
				curBlockRange: {
					startPoint: startPoint,
					endPoint: endPoint,
				},
			})
		}
		return enumInfoList
	}

	/**
	 * 解析引入信息
	 */
	private importQueryResultHandler(matches: QueryMatch[]): Array<string> {
		const rst: Array<string> = []

		for (let match of matches) {
			for (let capture of match.captures) {
				if (capture.name === "include") {
					rst.push(capture.node.text.trim())
				}
			}
		}

		return rst
	}

	/**
	 * 解析调用函数信息
	 */
	private callFuncQueryResultHandler(matches: Parser.QueryMatch[]): CallFuncInfo[] {
		const callFuncList: CallFuncInfo[] = []
		for (let match of matches) {
			let callFuncName: string = ""
			let callFuncText: string = ""
			let pointRange: PointRange | undefined = undefined
			for (let capture of match.captures) {
				switch (capture.name) {
					case "callFuncName": {
						callFuncName = capture.node.text
						break
					}
					case "callExpression": {
						callFuncText = capture.node.text
						pointRange = { startPoint: capture.node.startPosition, endPoint: capture.node.endPosition }
						break
					}
				}
			}
			if (pointRange !== undefined) {
				callFuncList.push({
					callFuncName: callFuncName,
					callFuncText: callFuncText,
					pointRange: pointRange,
				})
			}
		}
		return callFuncList
	}

	/**
	 * 解析调用函数信息
	 */
	private callQueryResultHandler(matches: Parser.QueryMatch[], callList: CallInfo): CallInfo {
		for (let match of matches) {
			for (let capture of match.captures) {
				if (capture.name === "callFuncName" && capture.node.parent !== null) {
					callList.callFuncText.push(capture.node.text)
				}
				if (capture.name === "callMulDefineText" && capture.node.parent !== null) {
					callList.callMulDefineText.push(capture.node.text)
				}
			}
		}
		return callList
	}

	/**
	 * 生效变量过滤器
	 * @param point 当前位置
	 * @param variableList 变量列表
	 */
	effectVariableFilter(point: Point, variableList: Array<VariableInfo>): Array<VariableInfo> {
		const rst: Array<VariableInfo> = []

		variableList.forEach((item) => {
			if (indexOfPoint(point, item.curBlockRange)) {
				rst.push(item)
			}
		})

		return rst
	}
}
