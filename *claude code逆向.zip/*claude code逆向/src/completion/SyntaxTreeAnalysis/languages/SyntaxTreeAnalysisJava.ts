import Parser, { Language, Point, Query, QueryMatch, SyntaxNode, Tree } from "web-tree-sitter"
import { SyntaxTreeAnalysis } from "../SyntaxTreeAnalysis"
import {
	CallInfo,
	ClassInfo,
	EnumInfo,
	FunctionInfo,
	MacroDefinitionInfo,
	MethodInfo,
	PointRange,
	ContextualCompletion,
	RetrieveMethod,
	StructInfo,
	VariableInfo,
	CallFuncInfo,
	ParamInfo,
} from "../../types"
import { getPrefixText, getSuffixText, isPointInRange } from "../../util/tree-sitter-util"

export class SyntaxTreeAnalysisJava extends SyntaxTreeAnalysis {
	private static language: Language
	private static classQueryInstance: Query
	private static methodQueryInstance: Query
	private static importQueryInstance: Query
	private static fieldQueryInstance: Query
	private static callQueryInstance: Query

	constructor(tree: Tree, parser: Parser) {
		super(tree, parser)
		if (!SyntaxTreeAnalysisJava.language) {
			SyntaxTreeAnalysisJava.language = this.parser.getLanguage()
		}

		if (!SyntaxTreeAnalysisJava.classQueryInstance) {
			const query = `(class_declaration name: (identifier) @class_name)`
			SyntaxTreeAnalysisJava.classQueryInstance = SyntaxTreeAnalysisJava.language.query(query)
		}

		if (!SyntaxTreeAnalysisJava.methodQueryInstance) {
			const query = `(method_declaration name: (identifier) @method_name)`
			SyntaxTreeAnalysisJava.methodQueryInstance = SyntaxTreeAnalysisJava.language.query(query)
		}

		if (!SyntaxTreeAnalysisJava.importQueryInstance) {
			const query = `(import_declaration) @import`
			SyntaxTreeAnalysisJava.importQueryInstance = SyntaxTreeAnalysisJava.language.query(query)
		}

		if (!SyntaxTreeAnalysisJava.fieldQueryInstance) {
			const query = `(field_declaration) @field`
			SyntaxTreeAnalysisJava.fieldQueryInstance = SyntaxTreeAnalysisJava.language.query(query)
		}
		if (!SyntaxTreeAnalysisJava.callQueryInstance) {
			const query = `
        (method_invocation
        name: (identifier) @callFunc)
        (object_creation_expression
        type: (type_identifier) @callMulDefineText)
        `
			SyntaxTreeAnalysisJava.callQueryInstance = SyntaxTreeAnalysisJava.language.query(query)
		}
	}

	getCustomTypeList(): Array<StructInfo> {
		return []
	}
	getMacroDefinitionList(): Array<MacroDefinitionInfo> {
		return []
	}

	getCallFunctionInfoList(): CallFuncInfo[] {
		return []
	}

	getCallList(): CallInfo {
		let result: CallInfo = {
			callFuncText: [],
			callMulDefineText: [],
		}
		const matches: QueryMatch[] = SyntaxTreeAnalysisJava.callQueryInstance.matches(this.tree.rootNode)
		result = this.callQueryResultHandler(matches, result)
		return result
	}

	getMethodContextAtPoint(point: Point): ContextualCompletion | null {
		const matches: QueryMatch[] = SyntaxTreeAnalysisJava.methodQueryInstance.matches(this.tree.rootNode)
		for (let match of matches) {
			for (let capture of match.captures) {
				if (capture.name === "method_name") {
					const methodNode = capture.node.parent
					if (methodNode) {
						const startPoint: Point = methodNode.startPosition
						const endPoint: Point = methodNode.endPosition
						if (isPointInRange(point, startPoint, endPoint)) {
							return {
								prefixLineNum: startPoint.row,
								suffixLineNum: endPoint.row,
								currentLine: point.row,
								totalLine: endPoint.row - startPoint.row + 1,
								prefix: getPrefixText(startPoint, point, methodNode),
								suffix: getSuffixText(startPoint, point, endPoint, methodNode),
								retrieveMethod: RetrieveMethod.Function,
								completeChoices: [], // 添加这行
								completionRespData: {
									result: "",
									chatUuid: "",
									docId: "",
									formattedCompletion: "",
									prompt: "",
									finishReason: "",
								}, // 添加这行
								smartInterceptor: false,
							}
						}
					}
				}
			}
		}
		return null
	}

	getClassList(): Array<ClassInfo> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisJava.classQueryInstance.matches(this.tree.rootNode)
		return matches.map((match) => {
			const classNode = match.captures[0].node.parent
			return {
				className: match.captures[0].node.text,
				classText: classNode!.text,
				pointRange: {
					startPoint: classNode!.startPosition,
					endPoint: classNode!.endPosition,
				},
				localVariableList: [],
				callExpressionList: [],
				curBlockRange: {
					startPoint: classNode!.startPosition,
					endPoint: classNode!.endPosition,
				},
				isHasGrammarError: false,
				methods: this.getMethodsForClass(classNode!),
				fields: this.getFieldsForClass(classNode!),
			}
		})
	}

	private getMethodsForClass(classNode: SyntaxNode): Array<MethodInfo> {
		const methodMatches: QueryMatch[] = SyntaxTreeAnalysisJava.methodQueryInstance.matches(classNode)
		return methodMatches.map((match) => {
			const methodNode = match.captures[0].node.parent
			return {
				methodName: match.captures[0].node.text,
				pointRange: {
					startPoint: methodNode!.startPosition,
					endPoint: methodNode!.endPosition,
				},
				returnType: this.getReturnType(methodNode!),
				parameters: this.getParameters(methodNode!),
			}
		})
	}

	private getFieldsForClass(classNode: SyntaxNode): Array<VariableInfo> {
		const fieldMatches: QueryMatch[] = SyntaxTreeAnalysisJava.fieldQueryInstance.matches(classNode)
		return fieldMatches.map((match) => {
			const fieldNode = match.captures[0].node
			return {
				variableType: "",
				variableText: fieldNode.text,
				pointRange: {
					startPoint: fieldNode.startPosition,
					endPoint: fieldNode.endPosition,
				},
				curBlockRange: {
					startPoint: fieldNode.startPosition,
					endPoint: fieldNode.endPosition,
				},
				isGlobal: false,
			}
		})
	}

	getImportList(): Array<any> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisJava.importQueryInstance.matches(this.tree.rootNode)
		return matches.map((match) => {
			const importNode = match.captures[0].node
			return importNode.text.trim()
		})
	}

	private getReturnType(methodNode: SyntaxNode): string {
		// 这里需要根据 Java 语法树结构来获取返回类型
		// 示例实现，可能需要根据实际语法树结构调整
		const returnTypeNode = methodNode.childForFieldName("type")
		return returnTypeNode ? returnTypeNode.text : "void"
	}

	private getParameters(methodNode: SyntaxNode): Array<VariableInfo> {
		// 这里需要根据 Java 语法树结构来获取参数列表
		// 示例实现，可能需要根据实际语法树结构调整
		const parameters: Array<VariableInfo> = []
		const parameterListNode = methodNode.childForFieldName("parameters")
		if (parameterListNode) {
			parameterListNode.children.forEach((paramNode: SyntaxNode) => {
				if (paramNode.type === "formal_parameter") {
					const nameNode = paramNode.childForFieldName("name")
					if (nameNode) {
						parameters.push({
							variableType: "",
							variableText: nameNode.text,
							pointRange: {
								startPoint: paramNode.startPosition,
								endPoint: paramNode.endPosition,
							},
							curBlockRange: {
								startPoint: paramNode.startPosition,
								endPoint: paramNode.endPosition,
							},
							isGlobal: false,
						})
					}
				}
			})
		}
		return parameters
	}

	getFunctionList(): Array<FunctionInfo> {
		const functionList: Array<FunctionInfo> = []
		const matches: QueryMatch[] = SyntaxTreeAnalysisJava.methodQueryInstance.matches(this.tree.rootNode)

		matches.forEach((match) => {
			const methodNode = match.captures[0].node.parent
			if (methodNode) {
				const tmpParameterList: ParamInfo[] = []
				this.getParameters(methodNode).forEach((item) => {
					tmpParameterList.push({
						paramText: item.variableText,
						variableType: item.variableType,
					})
				})
				functionList.push({
					className: "",
					functionDeclarator: match.captures[0].node.text,
					blockRange: {
						startPoint: methodNode.startPosition,
						endPoint: methodNode.endPosition,
					},
					returnType: this.getReturnType(methodNode),
					parameterList: tmpParameterList,
					functionSign: methodNode.text,
					functionSignBlockRange: {
						startPoint: {
							row: methodNode.startPosition.row,
							column: 0,
						},
						endPoint: methodNode.endPosition,
					},
					localVariableList: [],
					callExpressionList: [],
					associatedCodeList: [],
					functionDefinition: methodNode.text,
					functionName: match.captures[0].node.text,
					functionIndex: match.captures[0].node.text,
					isHasGrammarError: true,
				})
			}
		})

		return functionList
	}

	getFunctionContextAtPoint(point: Point): ContextualCompletion | null {
		// Java中没有全局函数，使用方法上下文代替
		return this.getMethodContextAtPoint(point)
	}

	getFunctionBodyExceptPointFunc(point: Point): string[] {
		const methodContext = this.getMethodContextAtPoint(point)
		if (methodContext) {
			return [methodContext.prefix + methodContext.suffix]
		}
		return []
	}

	getFunctionBodyList(): Array<string> {
		// 返回所有方法体
		const matches: QueryMatch[] = SyntaxTreeAnalysisJava.methodQueryInstance.matches(this.tree.rootNode)
		return matches.map((match) => {
			const methodNode = match.captures[0].node.parent
			const bodyNode = methodNode?.childForFieldName("body")
			return bodyNode ? bodyNode.text : ""
		})
	}

	getVariableList(): Array<VariableInfo> {
		const variableList: Array<VariableInfo> = []
		this.tree.rootNode.descendantsOfType(["local_variable_declaration", "field_declaration"]).forEach((node: SyntaxNode) => {
			const declarators = node.childForFieldName("declarator")
			if (declarators) {
				declarators.children.forEach((declarator: SyntaxNode) => {
					const nameNode = declarator.childForFieldName("name")
					if (nameNode) {
						variableList.push({
							variableType: "",
							variableText: nameNode.text,
							pointRange: {
								startPoint: node.startPosition,
								endPoint: node.endPosition,
							},
							curBlockRange: {
								startPoint: node.startPosition,
								endPoint: node.endPosition,
							},
							isGlobal: node.type === "field_declaration",
						})
					}
				})
			}
		})
		return variableList
	}

	getVariableContextAtPoint(point: Point): ContextualCompletion | null {
		const variableNode = this.findNodeAtPoint(point, ["local_variable_declaration", "field_declaration"])
		if (variableNode) {
			return {
				prefixLineNum: variableNode.startPosition.row,
				suffixLineNum: variableNode.endPosition.row,
				currentLine: point.row,
				totalLine: variableNode.endPosition.row - variableNode.startPosition.row + 1,
				prefix: getPrefixText(variableNode.startPosition, point, variableNode),
				suffix: getSuffixText(variableNode.startPosition, point, variableNode.endPosition, variableNode),
				retrieveMethod: RetrieveMethod.Function,
				completeChoices: [], // 添加这行
				completionRespData: {
					result: "",
					chatUuid: "",
					docId: "",
					formattedCompletion: "",
					prompt: "",
					finishReason: "",
				}, // 添加这行
				smartInterceptor: false,
			}
		}
		return null
	}

	getGlobalVariableList(): Array<VariableInfo> {
		// Java中没有真正的全局变量，这里返回静态字段
		return this.getVariableList().filter((v) => v.isGlobal && this.isStaticField(v))
	}

	getGlobalVariableContextAtPoint(point: Point): ContextualCompletion | null {
		const fieldNode = this.findNodeAtPoint(point, ["field_declaration"])
		if (fieldNode && this.isStaticField(fieldNode)) {
			return {
				prefixLineNum: fieldNode.startPosition.row,
				suffixLineNum: fieldNode.endPosition.row,
				currentLine: point.row,
				totalLine: fieldNode.endPosition.row - fieldNode.startPosition.row + 1,
				prefix: getPrefixText(fieldNode.startPosition, point, fieldNode),
				suffix: getSuffixText(fieldNode.startPosition, point, fieldNode.endPosition, fieldNode),
				retrieveMethod: RetrieveMethod.Function,
				completeChoices: [], // 添加这行
				completionRespData: {
					result: "",
					chatUuid: "",
					docId: "",
					formattedCompletion: "",
					prompt: "",
					finishReason: "",
				}, // 添加这行
				smartInterceptor: false,
			}
		}
		return null
	}

	getClassContextAtPoint(point: Point): ContextualCompletion | null {
		const classNode = this.findNodeAtPoint(point, ["class_declaration", "interface_declaration", "enum_declaration"])
		if (classNode) {
			return {
				prefixLineNum: classNode.startPosition.row,
				suffixLineNum: classNode.endPosition.row,
				currentLine: point.row,
				totalLine: classNode.endPosition.row - classNode.startPosition.row + 1,
				prefix: getPrefixText(classNode.startPosition, point, classNode),
				suffix: getSuffixText(classNode.startPosition, point, classNode.endPosition, classNode),
				retrieveMethod: RetrieveMethod.Function,
				completeChoices: [], // 添加这行
				completionRespData: {
					result: "",
					chatUuid: "",
					docId: "",
					formattedCompletion: "",
					prompt: "",
					finishReason: "",
				},
				smartInterceptor: false,
			}
		}
		return null
	}

	private findNodeAtPoint(point: Point, nodeTypes: string[]): SyntaxNode | null {
		let currentNode: SyntaxNode | null = this.tree.rootNode.descendantForPosition(point)
		while (currentNode) {
			if (nodeTypes.includes(currentNode.type)) {
				return currentNode
			}
			currentNode = currentNode.parent
		}
		return null
	}

	private isStaticField(node: SyntaxNode | VariableInfo): boolean {
		if ("variableText" in node) {
			// VariableInfo 类型
			const fieldNode = this.findNodeByText(node.variableText, "field_declaration")
			return fieldNode ? this.hasStaticModifier(fieldNode) : false
		} else {
			// SyntaxNode 类型
			return this.hasStaticModifier(node)
		}
	}

	private hasStaticModifier(node: SyntaxNode): boolean {
		const modifiers = node.childForFieldName("modifiers")
		return modifiers ? modifiers.text.includes("static") : false
	}

	private findNodeByText(text: string, type: string): SyntaxNode | null {
		const matches = this.tree.rootNode.descendantsOfType(type)
		return matches.find((node: SyntaxNode) => node.text.includes(text)) || null
	}

	getEnumList(): Array<EnumInfo> {
		const enumList: Array<EnumInfo> = []
		this.tree.rootNode.descendantsOfType("enum_declaration").forEach((node: SyntaxNode) => {
			const nameNode = node.childForFieldName("name")
			if (nameNode) {
				enumList.push({
					enumText: node.text,
					enumName: nameNode.text,
					pointRange: {
						startPoint: node.startPosition,
						endPoint: node.endPosition,
					},
					curBlockRange: {
						startPoint: node.startPosition,
						endPoint: node.endPosition,
					},
				})
			}
		})
		return enumList
	}

	private getVariableModifiers(variableNode: SyntaxNode): string[] {
		const modifiers: string[] = []
		const modifierNodes = variableNode.childForFieldName("modifiers")
		if (modifierNodes) {
			modifierNodes.children.forEach((modifier: SyntaxNode) => {
				modifiers.push(modifier.text)
			})
		}
		return modifiers
	}

	effectVariableFilter(point: Point, variableList: Array<VariableInfo>): Array<VariableInfo> {
		return variableList
			.filter((variable) => {
				const variableNode = this.findNodeByRange(variable.pointRange)
				if (variableNode) {
					const modifiers = this.getVariableModifiers(variableNode)
					return modifiers.includes("public") && !modifiers.includes("static")
				}
				return false
			})
			.map((variable) => variable)
	}

	private findNodeByRange(range: PointRange): SyntaxNode | null {
		const startPoint = range.startPoint
		const endPoint = range.endPoint

		// 使用一个辅助函数来遍历语法树
		const findNode = (node: SyntaxNode): SyntaxNode | null => {
			if (
				node.startPosition.row >= startPoint.row &&
				node.startPosition.column >= startPoint.column &&
				node.endPosition.row <= endPoint.row &&
				node.endPosition.column <= endPoint.column
			) {
				// 节点在给定范围内
				// 检查子节点是否有更精确的匹配
				for (let child of node.children) {
					const matchingChild = findNode(child)
					if (matchingChild) {
						return matchingChild
					}
				}
				// 如果没有更精确的子节点匹配，返回当前节点
				return node
			}
			return null
		}

		// 从根节点开始搜索
		return findNode(this.tree.rootNode)
	}

	private traverseTree(node: SyntaxNode, callback: (node: SyntaxNode) => void) {
		// 对当前节点执行回调
		callback(node)

		// 遍历所有子节点
		for (let child of node.children) {
			this.traverseTree(child, callback)
		}
	}

	private callQueryResultHandler(matches: Parser.QueryMatch[], callList: CallInfo): CallInfo {
		for (let match of matches) {
			for (let capture of match.captures) {
				if (capture.name === "callFunc" && capture.node.parent !== null) {
					callList.callFuncText.push(capture.node.text)
				}
				if (capture.name === "callMulDefineText" && capture.node.parent !== null) {
					callList.callMulDefineText.push(capture.node.text)
				}
			}
		}
		return callList
	}
}
