import Parser, { Language, Point, Query, QueryMatch, Tree } from "web-tree-sitter"
import { SyntaxTreeAnalysis } from "../SyntaxTreeAnalysis"
import {
	CodeBlock,
	FunctionInfo,
	PointRange,
	VariableInfo,
	StructInfo,
	MacroDefinitionInfo,
	EnumInfo,
	ClassInfo,
	CallFuncInfo,
	CallInfo,
} from "../../types"
import { indexOfPoint } from "../../util/point-utils"
import { isPointInRange } from "../../util/tree-sitter-util"

export class SyntaxTreeAnalysisCpp extends SyntaxTreeAnalysis {
	private static language: Language
	private static classQueryInstance: Query
	private static funcQueryInstance: Query
	private static testFuncQueryInstance: Query
	private static funcBodyQueryInstance: Query
	private static importQueryInstance: Query
	private static globalQueryInstance: Query
	private static localQueryInstance: Query
	private static customQueryInstance: Query
	private static macroDefinitionQueryInstance: Query
	private static callQueryInstance: Query
	private static enumQueryInstance: Query
	private variableInfoList: VariableInfo[] = []
	private callFunctionInfoList: CallFuncInfo[] = []

	constructor(tree: Tree, parser: Parser) {
		super(tree, parser)
		if (!SyntaxTreeAnalysisCpp.language) {
			SyntaxTreeAnalysisCpp.language = this.parser.getLanguage()
		}

		if (!SyntaxTreeAnalysisCpp.funcQueryInstance) {
			const query = `
        (function_definition type: ([(type_identifier) (primitive_type) (qualified_identifier)] @returnType)? declarator: [ (function_declarator declarator:  [ (qualified_identifier scope: (namespace_identifier) @className name: (identifier) @functionName ) ((identifier) @functionName) ] parameters:  (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )? ) @functionDeclarator (pointer_declarator declarator: (function_declarator declarator: [ (qualified_identifier scope: (namespace_identifier) @className name: (identifier) @functionName ) ((identifier) @functionName) ] parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )?  ) @functionDeclarator ) @pointerDeclarator (reference_declarator (function_declarator declarator:[ (qualified_identifier scope: (namespace_identifier) @className name: (identifier) @functionName ) (identifier) @functionName ] parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )?  ) @functionDeclarator ) @referenceDeclarator ]) @functionDefinition 
        (struct_specifier name: (type_identifier) @className body: (field_declaration_list (function_definition type: ([(type_identifier) (primitive_type) (qualified_identifier) ] @returnType)? declarator: [ (function_declarator declarator: [ (identifier) (field_identifier) ] @functionName parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )? ) @functionDeclarator (pointer_declarator declarator: (function_declarator declarator: [ (identifier) (field_identifier) ] @functionName parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )? ) @functionDeclarator ) @pointerDeclarator (reference_declarator (function_declarator declarator: [ (identifier) (field_identifier) ] @functionName parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )?  ) @functionDeclarator ) @referenceDeclarator ] ) @functionDefinition ))
        (class_specifier name: (type_identifier) @className body: (field_declaration_list (function_definition type: ([(type_identifier) (primitive_type) (qualified_identifier) ] @returnType)? declarator: [ (function_declarator declarator: [ (identifier) (field_identifier) ] @functionName parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )? ) @functionDeclarator (pointer_declarator declarator: (function_declarator declarator: [ (identifier) (field_identifier) ] @functionName parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )? ) @functionDeclarator ) @pointerDeclarator (reference_declarator (function_declarator declarator: [ (identifier) (field_identifier) ] @functionName parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )?  ) @functionDeclarator ) @referenceDeclarator ] ) @functionDefinition ))
        (ERROR type: ([(type_identifier) (primitive_type) (qualified_identifier)] @returnType)? [ (reference_declarator (function_declarator declarator:  [ (qualified_identifier scope: (namespace_identifier) @className name: (identifier) @functionName ) ((identifier) @functionName) ] parameters:  (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: [(type_identifier)(template_type)] @varType ) ] ) @parameterDeclaration )? ) @functionDeclarator ) @referenceDeclarator (function_declarator declarator:  [ (qualified_identifier scope: (namespace_identifier) @className name: (identifier) @functionName ) ((identifier) @functionName) ] parameters:  (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )? ) @functionDeclarator (pointer_declarator declarator: (function_declarator declarator: [ (qualified_identifier scope: (namespace_identifier) @className name: (identifier) @functionName ) ((identifier) @functionName) ] parameters: (parameter_list (parameter_declaration type: [ ((primitive_type) @varType) ((type_identifier) @varType) (qualified_identifier name: (type_identifier) @varType ) ] ) @parameterDeclaration )?  ) @functionDeclarator ) @pointerDeclarator ]) @functionDefinition
      `
			SyntaxTreeAnalysisCpp.funcQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}

		if (!SyntaxTreeAnalysisCpp.testFuncQueryInstance) {
			const query = `
        (function_definition declarator: (function_declarator) @functionDeclarator (#match? @functionDeclarator "^\\s*TEST[_]*[FP]*") body: (compound_statement) @functionBody )
        ((expression_statement (call_expression) @functionDeclaratorCombination (#match? @functionDeclaratorCombination "^\\s*TEST[_]*[FP]*") ) )
        (function_definition type: ([(type_identifier) (primitive_type) (qualified_identifier)] @returnType)? declarator: (function_declarator) @functionDeclaratorCombination (#not-match? @functionDeclaratorCombination "^\\s*TEST[_]*[FP]*"))
        (((compound_statement) @functionBodyCombination ) (#match? @functionBodyCombination "^{") )
        ((ERROR (call_expression) @functionDeclaratorCombination (#match? @functionDeclaratorCombination "^\\s*TEST[_]*[FP]*") ) )
      `
			SyntaxTreeAnalysisCpp.testFuncQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}

		if (!SyntaxTreeAnalysisCpp.funcBodyQueryInstance) {
			const query = `(function_definition body: (compound_statement)) @function_body`
			SyntaxTreeAnalysisCpp.funcBodyQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}

		if (!SyntaxTreeAnalysisCpp.importQueryInstance) {
			const query = `(preproc_include) @include`
			SyntaxTreeAnalysisCpp.importQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}

		if (!SyntaxTreeAnalysisCpp.globalQueryInstance) {
			const query = `(translation_unit (declaration type: [(type_identifier) @varType (primitive_type) @varType (qualified_identifier name: (type_identifier) @varType)]) @varDeclaration)`
			SyntaxTreeAnalysisCpp.globalQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}

		if (!SyntaxTreeAnalysisCpp.localQueryInstance) {
			const query = `(function_definition body: (compound_statement ([(declaration type: [(type_identifier) @varType (primitive_type) @varType (qualified_identifier) @varType]) (field_declaration type: [(type_identifier) @varType (primitive_type) @varType (qualified_identifier) @varType])]) @varDeclaration))`
			SyntaxTreeAnalysisCpp.localQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}

		if (!SyntaxTreeAnalysisCpp.customQueryInstance) {
			const query = `
        (struct_specifier name: (type_identifier) @structName body: (field_declaration_list) )@struct
        (class_specifier name: (type_identifier) @structName body: (field_declaration_list) )@struct
        (type_definition type: (struct_specifier) declarator: (type_identifier) @structName ) @struct
      `
			SyntaxTreeAnalysisCpp.customQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}

		if (!SyntaxTreeAnalysisCpp.macroDefinitionQueryInstance) {
			const query = `
        (preproc_function_def name: (identifier) @macroName )
        (preproc_def name: (identifier) @macroName )
      `
			SyntaxTreeAnalysisCpp.macroDefinitionQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}

		if (!SyntaxTreeAnalysisCpp.callQueryInstance) {
			const query = `
        (call_expression function: [(qualified_identifier) (identifier)] @functionName arguments: (argument_list [(string_literal)(true)(false)(number_literal)(identifier)(pointer_expression )(call_expression)(binary_expression)(subscript_expression)(field_expression)] @parameterDeclaration )? )
      `
			SyntaxTreeAnalysisCpp.callQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}

		if (!SyntaxTreeAnalysisCpp.enumQueryInstance) {
			const query = `(enum_specifier name:(type_identifier) @enumName) @enum`
			SyntaxTreeAnalysisCpp.enumQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}

		if (!SyntaxTreeAnalysisCpp.classQueryInstance) {
			const query = `(class_specifier name:(type_identifier) @className) @class`
			SyntaxTreeAnalysisCpp.classQueryInstance = SyntaxTreeAnalysisCpp.language.query(query)
		}
	}

	getFunctionList(): Array<FunctionInfo> {
		let matches: QueryMatch[]
		if (this.fileType !== "business") {
			matches = SyntaxTreeAnalysisCpp.testFuncQueryInstance.matches(this.tree.rootNode)
			const result = this.testFuncQueryResultHandler(matches)
			return result
		} else {
			const variableInfoList: VariableInfo[] = this.getLocalVariableList()
			const callFunctionInfoList: CallFuncInfo[] = this.getCallFunctionInfoList()
			matches = SyntaxTreeAnalysisCpp.funcQueryInstance.matches(this.tree.rootNode)
			return this.functionQueryResultHandler(matches, variableInfoList, callFunctionInfoList)
		}
	}

	getFunctionBodyExceptPointFunc(point: Point): Array<string> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisCpp.funcBodyQueryInstance.matches(this.tree.rootNode)
		let result = []
		for (let match of matches) {
			for (let capture of match.captures) {
				switch (capture.name) {
					case "function_body": {
						let startPoint: Point = capture.node.startPosition
						let endPoint: Point = capture.node.endPosition
						if (endPoint.row < point.row || startPoint.row > point.row) {
							result.push(capture.node.text)
							continue
						}
						if (!isPointInRange(point, startPoint, endPoint)) {
							result.push(capture.node.text)
						}
					}
				}
			}
		}
		return result
	}

	getFunctionBodyList(): Array<string> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisCpp.funcBodyQueryInstance.matches(this.tree.rootNode)
		const rst: string[] = this.functionBodyQueryResultHandler(matches)
		return rst
	}

	getImportList(): Array<any> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisCpp.importQueryInstance.matches(this.tree.rootNode)
		return this.importQueryResultHandler(matches)
	}

	/**
	 * 查询全局变量列表
	 */
	getGlobalVariableList(): Array<VariableInfo> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisCpp.globalQueryInstance.matches(this.tree.rootNode)
		const result = this.globalVariableQueryResultHandler(matches)
		return result
	}

	getLocalVariableList(): VariableInfo[] {
		if (this.variableInfoList.length === 0) {
			const matches: QueryMatch[] = SyntaxTreeAnalysisCpp.localQueryInstance.matches(this.tree.rootNode)
			this.variableInfoList = this.localVariableQueryResultHandler(matches)
		}
		return this.variableInfoList
	}

	/**
	 * 查询自定义类型信息
	 */
	getCustomTypeList(): Array<StructInfo> {
		const variableInfoList: VariableInfo[] = this.getLocalVariableList()
		const callFunctionInfoList: CallFuncInfo[] = this.getCallFunctionInfoList()
		const matches: QueryMatch[] = SyntaxTreeAnalysisCpp.customQueryInstance.matches(this.tree.rootNode)
		const result = this.customTypeQueryResultHandler(matches, variableInfoList, callFunctionInfoList)
		return result
	}

	/**
	 * 查询宏定义
	 */

	getMacroDefinitionList(): Array<MacroDefinitionInfo> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisCpp.macroDefinitionQueryInstance.matches(this.tree.rootNode)
		const result = this.macroDefinitionQueryResultHandler(matches)
		return result
	}

	private localVariableQueryResultHandler(matches: QueryMatch[]): VariableInfo[] {
		const result: VariableInfo[] = []
		for (let match of matches) {
			let variableType = ""
			let variableText = ""
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			for (let capture of match.captures) {
				switch (capture.name) {
					case "varType": {
						variableType = capture.node.text
						startPoint = capture.node.startPosition
						break
					}
					case "varDeclaration": {
						variableText = capture.node.text
						endPoint = capture.node.endPosition
						break
					}
				}
			}
			if (startPoint !== undefined && endPoint !== undefined) {
				result.push({
					variableType: variableType,
					variableText: variableText,
					pointRange: { startPoint, endPoint },
					curBlockRange: { startPoint, endPoint },
					isGlobal: false,
				})
			}
		}
		return result
	}

	private globalVariableQueryResultHandler(matches: QueryMatch[]): any[] {
		const result: Array<VariableInfo> = []
		for (let match of matches) {
			let variableType = ""
			let variableText = ""
			let pointRange: PointRange | undefined = undefined
			let curBlockRange: PointRange | undefined = undefined
			for (let capture of match.captures) {
				switch (capture.name) {
					case "varType": {
						variableType = capture.node.text
						break
					}
					case "varDeclaration": {
						variableText = capture.node.text
						pointRange = { startPoint: capture.node.startPosition, endPoint: capture.node.endPosition }
						if (capture.node.parent !== null) {
							curBlockRange = {
								startPoint: capture.node.endPosition,
								endPoint: capture.node.parent.endPosition,
							}
						}
						break
					}
				}
			}
			if (curBlockRange !== undefined && pointRange !== undefined) {
				result.push({
					variableType: variableType,
					variableText: variableText,
					pointRange: pointRange,
					curBlockRange: curBlockRange,
					isGlobal: true,
				})
			}
		}
		return result
	}

	/**
	 * 采集枚举类型
	 */
	getEnumList(): Array<EnumInfo> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisCpp.enumQueryInstance.matches(this.tree.rootNode)
		const result = this.enumQueryResultHandler(matches)
		return result
	}

	/**
	 * 采集类定义
	 */
	getClassList(): Array<ClassInfo> {
		const variableInfoList: VariableInfo[] = this.getLocalVariableList()
		const callFunctionInfoList: CallFuncInfo[] = this.getCallFunctionInfoList()
		const matches: QueryMatch[] = SyntaxTreeAnalysisCpp.classQueryInstance.matches(this.tree.rootNode)
		const result = this.classQueryResultHandler(matches, variableInfoList, callFunctionInfoList)
		return result
	}

	getCallFunctionInfoList(): CallFuncInfo[] {
		if (this.callFunctionInfoList.length === 0) {
			const matches: QueryMatch[] = SyntaxTreeAnalysisCpp.callQueryInstance.matches(this.tree.rootNode)
			this.callFunctionInfoList = this.callFuncQueryResultHandler(matches)
		}
		return this.callFunctionInfoList
	}

	getCallList(): CallInfo {
		let result: CallInfo = {
			callFuncText: [],
			callMulDefineText: [],
		}
		//callMulDefineText 包含类实例、结构体实例、枚举实例
		const queryList = [
			`(call_expression function: (identifier) @callFunc)`,
			`(declaration type: (type_identifier) @callMulDefineText)`,
		]
		for (let query of queryList) {
			const language = this.parser.getLanguage()
			const queryInstance = language.query(query)
			const matches: QueryMatch[] = queryInstance.matches(this.tree.rootNode)
			result = this.callQueryResultHandler(matches, result)
		}
		return result
	}

	private functionQueryResultHandler(
		matches: Parser.QueryMatch[],
		variableInfoList: VariableInfo[],
		callFunctionInfoList: CallFuncInfo[],
	): Array<FunctionInfo> {
		const funcInfoMap: Map<string, FunctionInfo> = new Map<string, FunctionInfo>()
		for (let i = 0; i < matches.length; i++) {
			const match = matches[i]
			let functionDeclarator: string = ""
			let returnType: string = ""
			let functionSignBlockRange: PointRange | undefined = undefined
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			let functionDefinition: string = ""
			let parameterDeclaration: string = ""
			let functionName: string = ""
			let isHasGrammarError: boolean = false
			let className: string = ""
			let pointerDeclarator: string = ""
			let referenceDeclarator: string = ""
			let varType: string = ""
			for (let capture of match.captures) {
				switch (capture.name) {
					case "functionDefinition": {
						functionDefinition = capture.node.text
						startPoint = capture.node.startPosition
						endPoint = capture.node.endPosition
						if (capture.node.children.length > 0) {
							let lastChildren
							for (let child of capture.node.children) {
								if (child.text.trim().startsWith("{") || child.text.trim().endsWith("}")) {
									lastChildren = child
									break
								}
							}
							if (lastChildren && lastChildren.children.length > 0) {
								lastChildren = lastChildren.children[lastChildren.children.length - 1]
								if (lastChildren.isMissing) {
									isHasGrammarError = true
								}
							} else {
								isHasGrammarError = true
							}
						}
						break
					}
					case "className": {
						className = capture.node.text
						break
					}
					case "functionName": {
						functionName = capture.node.text
						break
					}
					case "parameterDeclaration": {
						parameterDeclaration = capture.node.text
						if (capture.node.parent && capture.node.parent.children.length > 0) {
							let lastChildren
							for (let child of capture.node.children) {
								if (child.text.trim().startsWith("(") || child.text.trim().endsWith(")")) {
									lastChildren = child
									break
								}
							}
							if (!lastChildren || lastChildren.isMissing) {
								isHasGrammarError = true
							}
						}
						break
					}
					case "functionDeclarator": {
						functionSignBlockRange = {
							startPoint: {
								row: capture.node.startPosition.row,
								column: 0,
							},
							endPoint: capture.node.endPosition,
						}
						functionDeclarator = capture.node.text
						break
					}
					case "returnType": {
						returnType = capture.node.text
						break
					}
					case "pointerDeclarator": {
						pointerDeclarator = capture.node.text
						break
					}
					case "referenceDeclarator": {
						referenceDeclarator = capture.node.text
						break
					}
					case "varType": {
						varType = capture.node.text
						break
					}
				}
			}

			const funSign =
				`${returnType}${pointerDeclarator !== "" ? pointerDeclarator : referenceDeclarator !== "" ? referenceDeclarator : " " + functionDeclarator}`.trim()
			if (startPoint !== undefined && endPoint !== undefined && functionSignBlockRange != undefined) {
				const key = `${startPoint.row}:${startPoint.column}-${endPoint.row}:${endPoint.column}`
				let functionInfo: FunctionInfo | undefined = funcInfoMap.get(key)
				if (!functionInfo) {
					const blockRange = { startPoint: startPoint, endPoint: endPoint }
					const localVariableList = this.getCurLocalVariable(variableInfoList, blockRange)
					const callExpressionList = this.getCurCallExpression(callFunctionInfoList, blockRange)
					const functionInfo: FunctionInfo = {
						className: className,
						functionDeclarator: functionDeclarator,
						blockRange: blockRange,
						functionSign: funSign,
						functionSignBlockRange: functionSignBlockRange,
						returnType: returnType,
						parameterList:
							parameterDeclaration !== ""
								? new Array({ paramText: parameterDeclaration, variableType: varType })
								: [],
						localVariableList: localVariableList,
						callExpressionList: callExpressionList,
						associatedCodeList: [],
						functionDefinition: functionDefinition,
						functionName: functionName,
						functionIndex: "",
						isHasGrammarError: isHasGrammarError,
					}
					funcInfoMap.set(key, functionInfo)
				} else {
					if (parameterDeclaration !== "") {
						functionInfo.parameterList.push({ paramText: parameterDeclaration, variableType: varType })
					}
				}
			}
		}
		funcInfoMap.forEach((value, _) => {
			const functionIndex: string = this.getFunctionIndex(value.className, value.functionName, value.parameterList.length)
			value.functionIndex = functionIndex
		})
		return Array.from(funcInfoMap.values())
	}

	private testFuncQueryResultHandler(matches: Parser.QueryMatch[]): Array<FunctionInfo> {
		const funcInfoMap: Map<string, FunctionInfo> = new Map<string, FunctionInfo>()
		const funcDeclaratorCombCache: Map<number, CodeBlock> = new Map<number, CodeBlock>()
		const funcBodyCombCache: Map<number, CodeBlock> = new Map<number, CodeBlock>()
		for (let i = 0; i < matches.length; i++) {
			const match = matches[i]
			let functionSignBlockRange: PointRange | undefined = undefined
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			let returnType: string = ""
			let functionDeclarator: string = ""
			let functionBody: string = ""
			let isHasGrammarError: boolean = false
			for (let capture of match.captures) {
				switch (capture.name) {
					case "returnType": {
						returnType = capture.node.text
						break
					}
					case "functionDeclaratorCombination": {
						functionSignBlockRange = {
							startPoint: {
								row: capture.node.startPosition.row,
								column: 0,
							},
							endPoint: capture.node.endPosition,
						}
						if (capture.node.children.length > 0) {
							let lastChildren
							for (let child of capture.node.children) {
								if (child.text.trim().startsWith("(") || child.text.trim().endsWith(")")) {
									lastChildren = child
									break
								}
							}
							if (lastChildren && lastChildren.children.length > 0) {
								lastChildren = lastChildren.children[lastChildren.children.length - 1]
								if (lastChildren && lastChildren.isMissing) {
									isHasGrammarError = true
								}
							} else {
								isHasGrammarError = true
							}
						}
						funcDeclaratorCombCache.set(capture.node.endPosition.row, {
							startPoint: capture.node.startPosition,
							endPoint: capture.node.endPosition,
							functionSignBlockRange: functionSignBlockRange,
							isHasGrammarError: isHasGrammarError,
							code: returnType ? `${returnType} ${capture.node.text}` : capture.node.text,
						})
						break
					}
					case "functionBodyCombination": {
						if (capture.node.children.length > 0) {
							const lastChildren = capture.node.children[capture.node.children.length - 1]
							if (!lastChildren || lastChildren.isMissing) {
								isHasGrammarError = true
							}
						}
						funcBodyCombCache.set(capture.node.startPosition.row, {
							startPoint: capture.node.startPosition,
							endPoint: capture.node.endPosition,
							isHasGrammarError: isHasGrammarError,
							code: capture.node.text,
						})
						break
					}
					case "functionDeclarator": {
						startPoint = capture.node.startPosition
						functionDeclarator = capture.node.text
						functionSignBlockRange = {
							startPoint: {
								row: capture.node.startPosition.row,
								column: 0,
							},
							endPoint: capture.node.endPosition,
						}
						if (capture.node.children.length > 0) {
							let lastChildren = capture.node.children[capture.node.children.length - 1]
							if (lastChildren && lastChildren.children.length > 0) {
								lastChildren = lastChildren.children[lastChildren.children.length - 1]
								if (lastChildren && lastChildren.isMissing) {
									isHasGrammarError = true
								}
							}
						}
						break
					}
					case "functionBody": {
						functionBody = capture.node.text
						startPoint = startPoint ?? capture.node.startPosition
						endPoint = capture.node.endPosition
						if (capture.node.children.length > 0) {
							const lastChildren = capture.node.children[capture.node.children.length - 1]
							if (lastChildren && lastChildren.isMissing) {
								isHasGrammarError = true
							}
						}
						break
					}
					case "errorFunctionDeclarator": {
						functionDeclarator = capture.node.text
						isHasGrammarError = true
						if (!startPoint) {
							startPoint = capture.node.startPosition
						}
						endPoint = capture.node.endPosition
						if (i < matches.length - 1) {
							const captures = matches[i + 1].captures
							const nextFunctionCapture = captures.find((capture) => capture.name === "functionName")
							if (nextFunctionCapture) {
								endPoint = {
									row: nextFunctionCapture.node.startPosition.row - 1,
									column: 0,
								}
							}
						}
						break
					}
				}
			}

			if (functionDeclarator !== "") {
				if (startPoint !== undefined && endPoint !== undefined && functionSignBlockRange != undefined) {
					const key = `${startPoint.row}:${startPoint.column}-${endPoint.row}:${endPoint.column}`
					const functionInfo: FunctionInfo = {
						className: "",
						functionDeclarator: functionDeclarator,
						blockRange: {
							startPoint: startPoint,
							endPoint: endPoint,
						},
						functionSign: functionDeclarator,
						functionSignBlockRange: functionSignBlockRange,
						returnType: "",
						parameterList: [],
						localVariableList: [],
						callExpressionList: [],
						associatedCodeList: [],
						functionDefinition: `${functionDeclarator}${functionBody}`,
						functionName: functionDeclarator,
						functionIndex: "",
						isHasGrammarError: isHasGrammarError,
					}
					funcInfoMap.set(key, functionInfo)
				}
			}
		}

		const tmpTestcaseFunList = this.composeTestcase(funcDeclaratorCombCache, funcBodyCombCache)

		tmpTestcaseFunList.push(...funcInfoMap.values())
		return tmpTestcaseFunList
	}

	private composeTestcase(
		funcDeclaratorCombCache: Map<number, CodeBlock>,
		funcBodyCombCache: Map<number, CodeBlock>,
	): Array<FunctionInfo> {
		const rst: Array<FunctionInfo> = []

		funcDeclaratorCombCache.forEach((funcDeclarator, key) => {
			let funcBody: CodeBlock | undefined = funcBodyCombCache.get(key)
			if (!funcBody) {
				funcBody = funcBodyCombCache.get(key + 1)
			}
			if (!funcBody) {
				funcBody = funcBodyCombCache.get(key + 2)
			}
			if (!funcBody) {
				funcBody = funcBodyCombCache.get(key + 3)
			}

			if (funcBody) {
				const functionDeclarator: string = funcDeclarator.code
				const functionSignBlockRange = funcDeclarator.functionSignBlockRange!
				const functionBody: string = funcBody.code
				const startPoint: Point = funcDeclarator.startPoint
				const endPoint: Point = funcBody.endPoint
				const isHasGrammarError = funcDeclarator.isHasGrammarError || funcBody.isHasGrammarError
				rst.push({
					className: "",
					functionDeclarator: functionDeclarator,
					blockRange: {
						startPoint: startPoint,
						endPoint: endPoint,
					},
					functionSign: functionDeclarator,
					functionSignBlockRange: functionSignBlockRange,
					returnType: "",
					parameterList: [],
					localVariableList: [],
					callExpressionList: [],
					associatedCodeList: [],
					functionDefinition: `${functionDeclarator}${functionBody}`,
					functionName: functionDeclarator,
					functionIndex: "",
					isHasGrammarError: isHasGrammarError,
				})
			}
		})

		return rst
	}

	/**
	 * 函数索引：类名 + "::" + 函数名 + "-" + 参数编号1 + "_" + 参数编号n
	 * 样例：ClassNameDemo::functionNameDemo-1_2_3
	 */
	private getFunctionIndex(className: string, functionName: string, paramCounter: number): string {
		const paramIndexSequence: string = paramCounter
			? Array.from({ length: paramCounter }, (_, index) => index + 1).join("_")
			: ""
		return (
			`${className.trim() !== "" ? className.trim() + "::" : ""}${functionName}` +
			(paramIndexSequence !== "" ? `-${paramIndexSequence}` : "")
		)
	}

	/**
	 * 解析自定义类型信息
	 */
	private customTypeQueryResultHandler(
		matches: Parser.QueryMatch[],
		variableInfoList: VariableInfo[],
		callFunctionInfoList: CallFuncInfo[],
	): StructInfo[] {
		const structInfoList: StructInfo[] = []
		for (let match of matches) {
			let structName: string = ""
			let structText: string = ""
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			let actionRangeStartPoint: Point | undefined = undefined
			let actionRangeEndPoint: Point | undefined = undefined
			let isHasGrammarError: boolean = false
			for (let capture of match.captures) {
				switch (capture.name) {
					case "structName": {
						structName = capture.node.text
						break
					}
					case "struct": {
						structText = capture.node.text
						startPoint = capture.node.startPosition
						endPoint = capture.node.endPosition
						actionRangeStartPoint = startPoint
						actionRangeEndPoint = endPoint
						if (capture.node.parent !== null) {
							actionRangeStartPoint = capture.node.parent.startPosition
							actionRangeEndPoint = capture.node.parent.endPosition
						}
						if (capture.node.children.length > 0) {
							let lastChildren
							for (let child of capture.node.children) {
								if (child.text.trim().startsWith("{") || child.text.trim().endsWith("}")) {
									lastChildren = child
									break
								}
							}
							if (lastChildren && lastChildren.children.length > 0) {
								lastChildren = lastChildren.children[lastChildren.children.length - 1]
								if (lastChildren.isMissing) {
									isHasGrammarError = true
								}
							} else {
								isHasGrammarError = true
							}
						}
						break
					}
				}
			}

			if (!startPoint || !endPoint || !actionRangeStartPoint || !actionRangeEndPoint) continue
			const pointRange = { startPoint: startPoint, endPoint: endPoint }
			const localVariableList = this.getCurLocalVariable(variableInfoList, pointRange)
			const callExpressionList = this.getCurCallExpression(callFunctionInfoList, pointRange)
			structInfoList.push({
				structName: structName,
				structText: structText,
				localVariableList: localVariableList,
				callExpressionList: callExpressionList,
				pointRange: pointRange,
				curBlockRange: {
					startPoint: actionRangeStartPoint,
					endPoint: actionRangeEndPoint,
				},
				isHasGrammarError: isHasGrammarError,
			})
		}
		return structInfoList
	}

	/**
	 * 解析变量信息
	 */
	private macroDefinitionQueryResultHandler(matches: Parser.QueryMatch[]): MacroDefinitionInfo[] {
		const definitionInfoList: MacroDefinitionInfo[] = []
		for (let match of matches) {
			for (let capture of match.captures) {
				if (capture.name === "macroName" && capture.node.parent !== null) {
					const curVariableInfo: MacroDefinitionInfo = {
						macroName: capture.node.parent.text,
						pointRange: {
							startPoint: capture.node.parent.startPosition,
							endPoint: capture.node.parent.endPosition,
						},
					}
					definitionInfoList.push(curVariableInfo)
				}
			}
		}
		return definitionInfoList
	}

	/**
	 * 解析枚举信息
	 */
	private enumQueryResultHandler(matches: Parser.QueryMatch[]): EnumInfo[] {
		const enumInfoList: EnumInfo[] = []
		for (let match of matches) {
			let enumText = ""
			let enumName = ""
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			for (let capture of match.captures) {
				switch (capture.name) {
					case "enumName": {
						enumName = capture.node.text
						break
					}
					case "enum": {
						enumText = capture.node.text
						startPoint = capture.node.startPosition
						endPoint = capture.node.endPosition
						break
					}
				}
			}
			if (!startPoint || !endPoint) continue
			enumInfoList.push({
				enumText: enumText,
				enumName: enumName,
				pointRange: {
					startPoint: startPoint,
					endPoint: endPoint,
				},
				curBlockRange: {
					startPoint: startPoint,
					endPoint: endPoint,
				},
			})
		}
		return enumInfoList
	}

	/**
	 * 解析类信息
	 */
	private classQueryResultHandler(
		matches: Parser.QueryMatch[],
		variableInfoList: VariableInfo[],
		callFunctionInfoList: CallFuncInfo[],
	): ClassInfo[] {
		const classInfoList: ClassInfo[] = []
		for (let match of matches) {
			let classText = ""
			let className = ""
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			let actionRangeStartPoint: Point | undefined = undefined
			let actionRangeEndPoint: Point | undefined = undefined
			let isHasGrammarError: boolean = false
			for (let capture of match.captures) {
				switch (capture.name) {
					case "className": {
						className = capture.node.text
						break
					}
					case "class": {
						classText = capture.node.text
						startPoint = capture.node.startPosition
						endPoint = capture.node.endPosition
						actionRangeStartPoint = startPoint
						actionRangeEndPoint = endPoint
						if (capture.node.parent !== null) {
							actionRangeStartPoint = capture.node.parent.startPosition
							actionRangeEndPoint = capture.node.parent.endPosition
						}
						break
					}
				}
			}
			if (!startPoint || !endPoint || !actionRangeStartPoint || !actionRangeEndPoint) continue
			const pointRange = { startPoint: startPoint, endPoint: endPoint }
			const localVariableList = this.getCurLocalVariable(variableInfoList, pointRange)
			const callExpressionList = this.getCurCallExpression(callFunctionInfoList, pointRange)
			classInfoList.push({
				classText: classText,
				className: className,
				localVariableList: localVariableList,
				callExpressionList: callExpressionList,
				pointRange: pointRange,
				curBlockRange: {
					startPoint: actionRangeStartPoint,
					endPoint: actionRangeEndPoint,
				},
				isHasGrammarError: isHasGrammarError,
			})
		}
		return classInfoList
	}

	/**
	 * 解析函数体信息
	 */
	private functionBodyQueryResultHandler(matches: Parser.QueryMatch[]) {
		const funcBodyList: Array<string> = new Array<string>()
		for (let match of matches) {
			for (let capture of match.captures) {
				switch (capture.name) {
					case "function_body": {
						funcBodyList.push(capture.node.text)
					}
				}
			}
		}

		return funcBodyList
	}

	/**
	 * 解析引入信息
	 */
	private importQueryResultHandler(matches: QueryMatch[]): Array<string> {
		const rst: Array<string> = []

		for (let match of matches) {
			for (let capture of match.captures) {
				if (capture.name === "include") {
					rst.push(capture.node.text.trim())
				}
			}
		}

		return rst
	}

	/**
	 * 生效变量过滤器
	 * @param point 当前位置
	 * @param variableList 变量列表
	 */
	effectVariableFilter(point: Point, variableList: Array<VariableInfo>): Array<VariableInfo> {
		const rst: Array<VariableInfo> = []

		variableList.forEach((item) => {
			if (indexOfPoint(point, item.curBlockRange)) {
				rst.push(item)
			}
		})

		return rst
	}

	/**
	 * 解析调用函数信息
	 */
	private callFuncQueryResultHandler(matches: Parser.QueryMatch[]): CallFuncInfo[] {
		type TmpCallFunc = {
			callFuncName: string
			callFuncText: string
			paramCount: number
			pointRange: PointRange
		}
		const tmpCallFuncMap: Map<string, TmpCallFunc> = new Map<string, TmpCallFunc>()
		for (let match of matches) {
			let functionName: string = ""
			let parameterDeclaration: string = ""
			let startPoint: Point | undefined = undefined
			let endPoint: Point | undefined = undefined
			for (let capture of match.captures) {
				switch (capture.name) {
					case "functionName": {
						functionName = capture.node.text
						startPoint = capture.node.startPosition
						endPoint = capture.node.endPosition
						break
					}
					case "parameterDeclaration": {
						parameterDeclaration = capture.node.text
						break
					}
				}
			}
			if (!startPoint || !endPoint) continue
			const key = `${startPoint.row}:${startPoint.column}-${endPoint.row}:${endPoint.column}`
			let tmpCallFunc: TmpCallFunc | undefined = tmpCallFuncMap.get(key)
			if (!tmpCallFunc) {
				tmpCallFunc = {
					callFuncName: functionName,
					callFuncText: functionName,
					paramCount: parameterDeclaration !== "" ? 1 : 0,
					pointRange: {
						startPoint: startPoint,
						endPoint: endPoint,
					},
				}
				tmpCallFuncMap.set(key, tmpCallFunc)
			} else {
				tmpCallFunc.paramCount++
			}
		}
		const callFuncList: CallFuncInfo[] = []
		tmpCallFuncMap.forEach((value, _) => {
			callFuncList.push({
				callFuncName: value.callFuncName,
				callFuncText: this.getFunctionIndex("", value.callFuncText, value.paramCount),
				pointRange: value.pointRange,
			})
		})
		return callFuncList
	}

	/**
	 * 解析调用函数信息
	 */
	private callQueryResultHandler(matches: Parser.QueryMatch[], callList: CallInfo): CallInfo {
		for (let match of matches) {
			for (let capture of match.captures) {
				if (capture.name === "callFunc" && capture.node.parent !== null) {
					callList.callFuncText.push(capture.node.text)
				}
				if (capture.name === "callMulDefineText" && capture.node.parent !== null) {
					callList.callMulDefineText.push(capture.node.text)
				}
			}
		}
		return callList
	}
}
