import Parser, { Language, Point, Query, QueryMatch, SyntaxNode, Tree } from "web-tree-sitter"
import { SyntaxTreeAnalysis } from "../SyntaxTreeAnalysis"
import {
	CallInfo,
	ClassInfo,
	EnumInfo,
	FunctionInfo,
	MacroDefinitionInfo,
	MethodInfo,
	ContextualCompletion,
	RetrieveMethod,
	StructInfo,
	VariableInfo,
	CallFuncInfo,
	ParamInfo,
} from "../../types"
import { getPrefixText, getSuffixText, isPointInRange } from "../../util/tree-sitter-util"
import { indexOfPoint } from "../../util/point-utils"

export class SyntaxTreeAnalysisScala extends SyntaxTreeAnalysis {
	private static language: Language
	private static classQueryInstance: Query
	private static methodQueryInstance: Query
	private static importQueryInstance: Query
	private static fieldQueryInstance: Query
	private static callQueryInstance: Query
	private static callFuncQueryInstance: Query

	constructor(tree: Tree, parser: Parser) {
		super(tree, parser)
		if (!SyntaxTreeAnalysisScala.language) {
			SyntaxTreeAnalysisScala.language = this.parser.getLanguage()
		}
		this.initializeQueries()
	}

	private initializeQueries() {
		if (!SyntaxTreeAnalysisScala.classQueryInstance) {
			const classQuery = `(class_definition name: (identifier) @class_name)`
			SyntaxTreeAnalysisScala.classQueryInstance = SyntaxTreeAnalysisScala.language.query(classQuery)
		}
		if (!SyntaxTreeAnalysisScala.methodQueryInstance) {
			const methodQuery = `(function_definition name: (identifier) @method_name)`
			SyntaxTreeAnalysisScala.methodQueryInstance = SyntaxTreeAnalysisScala.language.query(methodQuery)
		}
		if (!SyntaxTreeAnalysisScala.importQueryInstance) {
			const query = `(import_declaration) @import`
			SyntaxTreeAnalysisScala.importQueryInstance = SyntaxTreeAnalysisScala.language.query(query)
		}
		if (!SyntaxTreeAnalysisScala.fieldQueryInstance) {
			const query = `
        (val_definition (identifier) @field_name)
        (var_definition (identifier) @field_name)
      `
			SyntaxTreeAnalysisScala.fieldQueryInstance = SyntaxTreeAnalysisScala.language.query(query)
		}
		if (!SyntaxTreeAnalysisScala.callQueryInstance) {
			const query = `((call_expression) @callFunc)
      ((instance_expression) @callMulDefineText)`
			SyntaxTreeAnalysisScala.callQueryInstance = SyntaxTreeAnalysisScala.language.query(query)
		}
		if (!SyntaxTreeAnalysisScala.callFuncQueryInstance) {
			const query = `((call_expression) @callFunc)`
			SyntaxTreeAnalysisScala.callFuncQueryInstance = SyntaxTreeAnalysisScala.language.query(query)
		}
	}

	getCustomTypeList(): Array<StructInfo> {
		return []
	}

	getMacroDefinitionList(): Array<MacroDefinitionInfo> {
		return []
	}

	// 获取被调用函数信息
	getCallFunctionInfoList(): CallFuncInfo[] {
		const matches: QueryMatch[] = SyntaxTreeAnalysisScala.callFuncQueryInstance.matches(this.tree.rootNode)
		const callFuncList: CallFuncInfo[] = []
		matches.forEach((match) => {
			const callNode = match.captures[0].node
			callNode.children.forEach((childNode) => {
				if (childNode.type === "field_expression" || childNode.type === "identifier") {
					var callFuncTextValue = ""
					if (childNode.text.includes(".")) {
						const parts = childNode.text.split(".")
						callFuncTextValue = parts[parts.length - 1]
					} else {
						callFuncTextValue = childNode.text
					}
					callFuncList.push({
						callFuncName: "",
						callFuncText: callFuncTextValue,
						pointRange: {
							startPoint: childNode.startPosition,
							endPoint: childNode.endPosition,
						},
					})
				}
			})
		})
		return callFuncList
	}

	getCallList(): CallInfo {
		let result: CallInfo = {
			callFuncText: [],
			callMulDefineText: [],
		}
		const matches: QueryMatch[] = SyntaxTreeAnalysisScala.callQueryInstance.matches(this.tree.rootNode)
		result = this.callQueryResultHandler(matches, result)
		return result
	}

	//查询类，把方法里的字段也拿出来了
	getClassList(): Array<ClassInfo> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisScala.classQueryInstance.matches(this.tree.rootNode)
		return matches.map((match) => {
			const classNode = match.captures[0].node.parent
			return {
				className: match.captures[0].node.text,
				classText: classNode!.text,
				pointRange: {
					startPoint: classNode!.startPosition,
					endPoint: classNode!.endPosition,
				},
				curBlockRange: {
					startPoint: classNode!.startPosition,
					endPoint: classNode!.endPosition,
				},
				isHasGrammarError: false,
				localVariableList: [],
				callExpressionList: [],
				methods: this.getMethodsForClass(classNode!),
				fields: this.getFields(classNode!),
			}
		})
	}

	private getMethodsForClass(classNode: SyntaxNode): Array<MethodInfo> {
		const methodMatches: QueryMatch[] = SyntaxTreeAnalysisScala.methodQueryInstance.matches(classNode)
		return methodMatches.map((match) => {
			const methodNode = match.captures[0].node.parent
			return {
				methodName: match.captures[0].node.text,
				pointRange: {
					startPoint: methodNode!.startPosition,
					endPoint: methodNode!.endPosition,
				},
				returnType: this.getReturnType(methodNode!),
				parameters: this.getParameters(methodNode!),
			}
		})
	}

	// 需要考虑一次声明多个字段的情况，不过此场景较少
	private getFields(node: SyntaxNode): Array<VariableInfo> {
		const fieldMatches: QueryMatch[] = SyntaxTreeAnalysisScala.fieldQueryInstance.matches(node)
		return fieldMatches.map((match) => {
			const fieldNode = match.captures[0].node
			return {
				variableType: "",
				variableText: fieldNode.text,
				pointRange: {
					startPoint: fieldNode.startPosition,
					endPoint: fieldNode.endPosition,
				},
				curBlockRange: {
					startPoint: fieldNode.startPosition,
					endPoint: fieldNode.endPosition,
				},
				isGlobal: false,
			}
		})
	}

	private getReturnType(methodNode: SyntaxNode): string {
		const returnTypeNode = methodNode.childForFieldName("return_type")
		return returnTypeNode ? returnTypeNode.text : "Unit"
	}

	private getParameters(methodNode: SyntaxNode): Array<VariableInfo> {
		const parameters: Array<VariableInfo> = []
		const parameterListNode = methodNode.childForFieldName("parameters")
		if (parameterListNode) {
			parameterListNode.children.forEach((paramNode: SyntaxNode) => {
				const nameNode = paramNode.childForFieldName("name")
				if (nameNode) {
					parameters.push({
						variableType: "",
						variableText: nameNode.text,
						pointRange: {
							startPoint: paramNode.startPosition,
							endPoint: paramNode.endPosition,
						},
						curBlockRange: {
							startPoint: paramNode.startPosition,
							endPoint: paramNode.endPosition,
						},
						isGlobal: false,
					})
				}
			})
		}
		return parameters
	}

	getImportList(): Array<any> {
		const matches: QueryMatch[] = SyntaxTreeAnalysisScala.importQueryInstance.matches(this.tree.rootNode)
		return matches.map((match) => {
			const importNode = match.captures[0].node
			return importNode.text.trim()
		})
	}

	getFunctionList(): Array<FunctionInfo> {
		const functionList: Array<FunctionInfo> = []
		const matches: QueryMatch[] = SyntaxTreeAnalysisScala.methodQueryInstance.matches(this.tree.rootNode)

		matches.forEach((match) => {
			const methodNode = match.captures[0].node.parent
			if (methodNode) {
				const tmpParameterList: ParamInfo[] = []
				this.getParameters(methodNode).forEach((item) => {
					tmpParameterList.push({
						paramText: item.variableText,
						variableType: item.variableType,
					})
				})
				functionList.push({
					className: "",
					functionDeclarator: match.captures[0].node.text,
					blockRange: {
						startPoint: methodNode.startPosition,
						endPoint: methodNode.endPosition,
					},
					returnType: this.getReturnType(methodNode),
					parameterList: tmpParameterList,
					functionSign: methodNode.text,
					functionSignBlockRange: {
						startPoint: {
							row: methodNode.startPosition.row,
							column: 0,
						},
						endPoint: methodNode.endPosition,
					},
					localVariableList: this.getFields(methodNode),
					callExpressionList: [],
					associatedCodeList: [],
					functionDefinition: methodNode.text,
					functionName: match.captures[0].node.text,
					functionIndex: match.captures[0].node.text,
					isHasGrammarError: true,
				})
			}
		})

		return functionList
	}

	private getCallFuncList(node: SyntaxNode): Array<string> {
		const callExpressionList: Array<string> = []
		const matches: QueryMatch[] = SyntaxTreeAnalysisScala.callFuncQueryInstance.matches(node)
		matches.forEach((match) => {
			const callNode = match.captures[0].node
			callNode.children.forEach((childNode) => {
				if (childNode.type === "field_expression" || childNode.type === "identifier") {
					if (childNode.text.includes(".")) {
						const parts = childNode.text.split(".")
						callExpressionList.push(parts[parts.length - 1])
					} else callExpressionList.push(childNode.text)
				}
			})
		})
		return callExpressionList
	}

	private getMethodContextAtPoint(point: Point): ContextualCompletion | null {
		const matches: QueryMatch[] = SyntaxTreeAnalysisScala.methodQueryInstance.matches(this.tree.rootNode)
		for (let match of matches) {
			for (let capture of match.captures) {
				if (capture.name === "method_name") {
					const methodNode = capture.node.parent
					if (methodNode) {
						const startPoint: Point = methodNode.startPosition
						const endPoint: Point = methodNode.endPosition
						if (isPointInRange(point, startPoint, endPoint)) {
							return {
								prefixLineNum: startPoint.row,
								suffixLineNum: endPoint.row,
								currentLine: point.row,
								totalLine: endPoint.row - startPoint.row + 1,
								prefix: getPrefixText(startPoint, point, methodNode),
								suffix: getSuffixText(startPoint, point, endPoint, methodNode),
								retrieveMethod: RetrieveMethod.Function,
								completeChoices: [], // 添加这行
								completionRespData: {
									result: "",
									chatUuid: "",
									docId: "",
									formattedCompletion: "",
									prompt: "",
									finishReason: "",
								}, // 添加这行
								smartInterceptor: false,
							}
						}
					}
				}
			}
		}
		return null
	}

	getFunctionContextAtPoint(point: Point): ContextualCompletion | null {
		return this.getMethodContextAtPoint(point)
	}

	getFunctionBodyExceptPointFunc(point: Point): string[] {
		const methodContext = this.getMethodContextAtPoint(point)
		if (methodContext) {
			return [methodContext.prefix + methodContext.suffix]
		}
		return []
	}

	getFunctionBodyList(): Array<string> {
		// 返回所有方法体
		const matches: QueryMatch[] = SyntaxTreeAnalysisScala.methodQueryInstance.matches(this.tree.rootNode)
		return matches.map((match) => {
			const methodNode = match.captures[0].node.parent
			const bodyNode = methodNode?.childForFieldName("body")
			return bodyNode ? bodyNode.text : ""
		})
	}

	getGlobalVariableList(): Array<VariableInfo> {
		// scala语言没有全局变量
		return []
	}

	//scala2没有枚举值（一般通过继承Enumeration类来实现类似功能），scala3才有枚举值
	getEnumList(): Array<EnumInfo> {
		const enumList: Array<EnumInfo> = []
		this.tree.rootNode.descendantsOfType("enum_definition").forEach((node: SyntaxNode) => {
			const nameNode = node.childForFieldName("name")
			if (nameNode) {
				enumList.push({
					enumText: node.text,
					enumName: nameNode.text,
					pointRange: {
						startPoint: node.startPosition,
						endPoint: node.endPosition,
					},
					curBlockRange: {
						startPoint: node.startPosition,
						endPoint: node.endPosition,
					},
				})
			}
		})
		return enumList
	}

	/**
	 * 生效变量过滤器
	 * @param point 当前位置
	 * @param variableList 变量列表
	 */
	effectVariableFilter(point: Point, variableList: Array<VariableInfo>): Array<VariableInfo> {
		const rst: Array<VariableInfo> = []

		variableList.forEach((item) => {
			if (indexOfPoint(point, item.curBlockRange)) {
				rst.push(item)
			}
		})

		return rst
	}

	private callQueryResultHandler(matches: Parser.QueryMatch[], callList: CallInfo): CallInfo {
		for (let match of matches) {
			for (let capture of match.captures) {
				if (capture.name === "callFunc" && capture.node.parent !== null) {
					callList.callFuncText.push(capture.node.text)
				}
				if (capture.name === "callMulDefineText" && capture.node.parent !== null) {
					callList.callMulDefineText.push(capture.node.text)
				}
			}
		}
		return callList
	}
}
