import { TextDocument, Range, Position } from "vscode"
import path from "path"
import { diffLines } from "diff"
import { WASM_LANGAUAGES } from "../util/consants"
import { Tree } from "web-tree-sitter"
import { GetParserResult, getParser } from "../util/tree-sitter-util"
import { SyntaxTreeAnalysisC } from "../SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisC"
import { SyntaxTreeAnalysisCpp } from "../SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisCpp"
import { SyntaxTreeAnalysisJava } from "../SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisJava"
import { SyntaxTreeAnalysisJavaScript } from "../SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisJavaScript"
import { SyntaxTreeAnalysis } from "../SyntaxTreeAnalysis/SyntaxTreeAnalysis"
import { ChangeDetail, CodeInfo } from "../types"
import { SyntaxTreeAnalysisScala } from "../SyntaxTreeAnalysis/languages/SyntaxTreeAnalysisScala"
import { Logger } from "../../util/logger"

export function pretreatment(languageId: string, fileData: string): string {
	if (languageId === "cpp") {
		fileData = fileData + "\n" // 末尾增加一个空行，使正则处理统一
		fileData = fileData.replace(/\n[ | \t]*USING_\w+[ | \t]*\n/g, "\n\n")
		fileData = fileData.replace(/\n[ | \t]*\w+_NS_\w+[ | \t]*\n/g, "\n\n")
		fileData = fileData.replace(/\n[ | \t]*template\s*<.+>[ | \t]*\n/g, "\n\n")
		fileData = fileData.replace(/ROLE\(\s*(\w+)\s*\)\./g, "$1::")
		fileData = fileData.replace(/DEFINE_ROLE\(\s*(\w+)\s*\)/g, "struct $1")
		fileData = fileData.replace(/GET_OBJECT_TO_ROLE\(\s*(\S+)\s*,\s*(\S+)\)\s*;/g, "$1 $2;")
	}
	return fileData
}
export class CodeParser {
	private languageId: string | undefined
	private fsPath: string | undefined
	private syntaxTreeAnalysis: SyntaxTreeAnalysis | null = null

	constructor(document?: TextDocument) {
		if (document) {
			const fileExtension = path.extname(document.uri.fsPath).slice(1)
			this.languageId = WASM_LANGAUAGES[fileExtension]
			this.fsPath = document.uri.fsPath
		}
	}

	public init(fsPath: string, languageId: string) {
		this.fsPath = fsPath
		this.languageId = languageId
	}

	async parse(fileText: string, position: Position | undefined = undefined): Promise<CodeInfo | null> {
		if (!this.languageId || !fileText || !this.fsPath) return null
		let rst: GetParserResult | null = null
		let tree: Tree | null = null
		try {
			rst = await getParser(this.languageId)
			if (!rst) return null

			// 文档内容进行预处理
			fileText = pretreatment(this.languageId, fileText)
			tree = rst.parser.parse(fileText)
			// TODO 这里需要根据文件类型来选择不同的解析器。 目前只支持C和JavaScript。可以考虑实现为自动加载，类似Java的反射
			switch (this.languageId) {
				case "c":
					this.syntaxTreeAnalysis = new SyntaxTreeAnalysisC(tree!, rst.parser)
					break
				case "cpp":
					this.syntaxTreeAnalysis = new SyntaxTreeAnalysisCpp(tree!, rst.parser)
					break
				case "java":
					this.syntaxTreeAnalysis = new SyntaxTreeAnalysisJava(tree!, rst.parser)
					break
				case "scala":
					this.syntaxTreeAnalysis = new SyntaxTreeAnalysisScala(tree!, rst.parser)
					break
				case "javascript":
					this.syntaxTreeAnalysis = new SyntaxTreeAnalysisJavaScript(tree!, rst.parser)
					break
			}
			if (!this.syntaxTreeAnalysis) return null
			this.syntaxTreeAnalysis.setFileType(this.fsPath)
			const [functionList, importList, customTypeList, macroDefinitionList, enumList, classList, globalVariableList] =
				await Promise.all([
					this.syntaxTreeAnalysis.getFunctionList(),
					this.syntaxTreeAnalysis.getImportList(),
					this.syntaxTreeAnalysis.getCustomTypeList(),
					this.syntaxTreeAnalysis.getMacroDefinitionList(),
					this.syntaxTreeAnalysis.getEnumList(),
					this.syntaxTreeAnalysis.getClassList(),
					this.syntaxTreeAnalysis.getGlobalVariableList(),
				])
			let codeInfo: CodeInfo = {
				functionList: functionList,
				importList: importList,
				customTypeList: customTypeList,
				macroDefinitionList: macroDefinitionList,
				enumList: enumList,
				classList: classList,
				globalVariableList: globalVariableList,
				updateTimeStamp: Date.now(),
			}
			if (position) {
				this.blockRangeFineTuning(codeInfo, position)
			}
			return codeInfo
		} catch (ex: any) {
			Logger("error", `code parse is failed, the error: ${ex}, error document: ${fileText}`)
			return null
		} finally {
			this.syntaxTreeAnalysis = null
			tree?.delete()
			rst?.parser.reset()
			tree = null
		}
	}

	public getChangeDetails(oldContent: string, newContent: string): ChangeDetail[] {
		const changes = diffLines(oldContent, newContent, { ignoreWhitespace: true })
		const changeDetails: ChangeDetail[] = []
		let currentLine = 0
		let removedLines = 0
		const pendingRemove: ChangeDetail[] = []

		for (const change of changes) {
			if (!change.removed) {
				if (change.added) {
					const lines = change.value.split("\n")
					const endColumn = lines.length > 1 ? lines[lines.length - 1].length : 0
					changeDetails.push({
						startPoint: { row: currentLine, column: 0 },
						endPoint: { row: currentLine + lines.length - 1, column: endColumn },
						count: change.count || 0,
						content: change.value,
						type: "add",
					})
				}
				currentLine += change.count || 0
			} else {
				const lines = change.value.split("\n")
				const endColumn = lines.length > 1 ? lines[lines.length - 1].length : 0
				pendingRemove.push({
					startPoint: { row: currentLine + removedLines, column: 0 },
					endPoint: { row: currentLine + removedLines + lines.length - 1, column: endColumn },
					count: change.count || 0,
					content: change.value,
					type: "remove",
				})
				removedLines += change.count || 0
			}
		}
		const removeChangeDetails = pendingRemove
			.filter((item) => item.type === "remove")
			.reduce<ChangeDetail | null>((acc, item) => {
				if (!acc) return item
				if (acc.endPoint.row + 1 != item.startPoint.row) return acc
				return {
					...acc,
					endPoint: item.endPoint,
					count: acc.count + item.count,
					content: acc.content + item.content,
				}
			}, null)
		removeChangeDetails && changeDetails.push(removeChangeDetails)
		return changeDetails
	}

	public static adjustCodePoint(
		document: TextDocument,
		codeInfo: CodeInfo,
		changeLine: number,
		changeType: "add" | "delete" | "modify",
	) {
		const adjustment = changeType === "add" ? 1 : changeType === "delete" ? -1 : 0

		// 辅助函数：检查变更是否影响到代码块
		const isChangeAffectingBlock = (start: number, end: number) => {
			return changeLine >= start && changeLine <= end
		}

		// 辅助函数：更新代码块内容
		const updateBlockContent = (startRow: number, endRow: number, endColumn: number) => {
			return document.getText(new Range(startRow, 0, endRow, endColumn))
		}

		// 调整函数位置信息
		codeInfo.functionList?.forEach((func) => {
			if (isChangeAffectingBlock(func.blockRange.startPoint.row, func.blockRange.endPoint.row)) {
				if (changeType === "modify") {
					func.functionDefinition = updateBlockContent(
						func.blockRange.startPoint.row,
						func.blockRange.endPoint.row,
						func.blockRange.endPoint.column,
					)
				} else {
					func.blockRange.endPoint.row += adjustment
					func.functionDefinition = updateBlockContent(
						func.blockRange.startPoint.row,
						func.blockRange.endPoint.row,
						func.blockRange.endPoint.column,
					)
				}
			} else if (func.blockRange.startPoint.row > changeLine && changeType !== "modify") {
				func.blockRange.startPoint.row += adjustment
				func.blockRange.endPoint.row += adjustment
			}
		})

		// 调整类位置信息
		codeInfo.classList?.forEach((cls) => {
			if (isChangeAffectingBlock(cls.pointRange.startPoint.row, cls.pointRange.endPoint.row)) {
				if (changeType === "modify") {
					cls.classText = updateBlockContent(
						cls.pointRange.startPoint.row,
						cls.pointRange.endPoint.row,
						cls.pointRange.endPoint.column,
					)
				} else {
					cls.pointRange.endPoint.row += adjustment
					cls.classText = updateBlockContent(
						cls.pointRange.startPoint.row,
						cls.pointRange.endPoint.row,
						cls.pointRange.endPoint.column,
					)
				}
			} else if (cls.pointRange.startPoint.row > changeLine && changeType !== "modify") {
				cls.pointRange.startPoint.row += adjustment
				cls.pointRange.endPoint.row += adjustment
			}
		})

		// 调整枚举位置信息
		codeInfo.enumList?.forEach((enum_) => {
			if (isChangeAffectingBlock(enum_.pointRange.startPoint.row, enum_.pointRange.endPoint.row)) {
				if (changeType === "modify") {
					enum_.enumText = updateBlockContent(
						enum_.pointRange.startPoint.row,
						enum_.pointRange.endPoint.row,
						enum_.pointRange.endPoint.column,
					)
				} else {
					enum_.pointRange.endPoint.row += adjustment
					enum_.enumText = updateBlockContent(
						enum_.pointRange.startPoint.row,
						enum_.pointRange.endPoint.row,
						enum_.pointRange.endPoint.column,
					)
				}
			} else if (enum_.pointRange.startPoint.row > changeLine && changeType !== "modify") {
				enum_.pointRange.startPoint.row += adjustment
				enum_.pointRange.endPoint.row += adjustment
			}
		})

		// 调整自定义类型位置信息
		codeInfo.customTypeList?.forEach((struct) => {
			if (isChangeAffectingBlock(struct.pointRange.startPoint.row, struct.pointRange.endPoint.row)) {
				if (changeType === "modify") {
					struct.structText = updateBlockContent(
						struct.pointRange.startPoint.row,
						struct.pointRange.endPoint.row,
						struct.pointRange.endPoint.column,
					)
				} else {
					struct.pointRange.endPoint.row += adjustment
					struct.structText = updateBlockContent(
						struct.pointRange.startPoint.row,
						struct.pointRange.endPoint.row,
						struct.pointRange.endPoint.column,
					)
				}
			} else if (struct.pointRange.startPoint.row > changeLine && changeType !== "modify") {
				struct.pointRange.startPoint.row += adjustment
				struct.pointRange.endPoint.row += adjustment
			}
		})

		// 调整宏定义位置信息
		codeInfo.macroDefinitionList?.forEach((macro) => {
			if (isChangeAffectingBlock(macro.pointRange.startPoint.row, macro.pointRange.endPoint.row)) {
				if (changeType === "modify") {
					macro.macroName = updateBlockContent(
						macro.pointRange.startPoint.row,
						macro.pointRange.endPoint.row,
						macro.pointRange.endPoint.column,
					)
				} else {
					macro.pointRange.endPoint.row += adjustment
				}
			} else if (macro.pointRange.startPoint.row > changeLine && changeType !== "modify") {
				macro.pointRange.startPoint.row += adjustment
				macro.pointRange.endPoint.row += adjustment
			}
		})

		// 调整全局变量位置信息
		codeInfo.globalVariableList?.forEach((variable) => {
			if (isChangeAffectingBlock(variable.pointRange.startPoint.row, variable.pointRange.endPoint.row)) {
				if (changeType === "modify") {
					variable.variableText = updateBlockContent(
						variable.pointRange.startPoint.row,
						variable.pointRange.endPoint.row,
						variable.pointRange.endPoint.column,
					)
				} else {
					variable.pointRange.endPoint.row += adjustment
				}
			} else if (variable.pointRange.startPoint.row > changeLine && changeType !== "modify") {
				variable.pointRange.startPoint.row += adjustment
				variable.pointRange.endPoint.row += adjustment
			}
		})
	}

	public blockRangeFineTuning(codeInfo: CodeInfo, position: Position) {
		codeInfo.functionList?.forEach((func) => {
			if (func.isHasGrammarError && func.blockRange.endPoint.row + 1 === position.line) {
				func.blockRange.endPoint = {
					row: position.line,
					column: position.character,
				}
			}
		})
	}
}
