import { Position, TextDocument, Range } from "vscode"
import { ContextualCompletion, FileCommonData, PointRange, PrefixSuffixRow, RetrieveMethod } from "../types/index"
import * as vscode from "vscode"
import { InlineCompletionInfo } from "../SyntaxTreeAnalysis/InlineCompletionInfo"

export class PrefixSuffixHandler {
	private prefixSuffixRequestLine: PrefixSuffixRow

	constructor(
		private fileCommonData: FileCommonData,
		private contentLineNumRequest: number,
		private document: TextDocument,
		private position: Position,
		contextRatio: number[],
	) {
		this.prefixSuffixRequestLine = PrefixSuffixHandler.getPrefixSuffixRow(
			contentLineNumRequest,
			position.line,
			document.lineCount,
			contextRatio,
		)
	}

	public getFixWindowPrefixSuffix(): ContextualCompletion {
		const currentLine = this.position.line
		const prefixRange = new Range(
			Math.max(0, currentLine - this.prefixSuffixRequestLine.prefixLineNum),
			0,
			currentLine,
			this.position.character,
		)
		const suffixRange = new Range(
			currentLine,
			this.position.character,
			currentLine + this.prefixSuffixRequestLine.suffixLineNum,
			0,
		)
		const currentLinePrefix = this.document.getText(new Range(currentLine, 0, currentLine, this.position.character))
		const currentLineSuffix = this.document.getText(
			new Range(currentLine, this.position.character, currentLine, this.document.lineAt(currentLine).text.length),
		)
		const prefixSuffixBlockRange: PointRange = {
			startPoint: {
				row: prefixRange.start.line,
				column: prefixRange.start.character,
			},
			endPoint: {
				row: suffixRange.end.line,
				column: suffixRange.end.character,
			},
		}

		return {
			languageId: this.fileCommonData.languageId,
			prefixLineNum: this.prefixSuffixRequestLine.prefixLineNum,
			suffixLineNum: this.prefixSuffixRequestLine.suffixLineNum,
			currentLine: currentLine,
			totalLine: this.document.lineCount,
			prefix: this.document.getText(prefixRange),
			suffix: this.document.getText(suffixRange),
			prefixSuffixBlockRange: prefixSuffixBlockRange,
			currentLinePrefix: currentLinePrefix,
			currentLineSuffix: currentLineSuffix,
			retrieveMethod: RetrieveMethod.FixWindow,
			eol: this.document.eol === vscode.EndOfLine.CRLF ? "\r\n" : "\n",
			completeChoices: [],
			completionRespData: {
				result: "",
				chatUuid: "",
				docId: "",
				formattedCompletion: "",
				prompt: "",
				finishReason: "",
			},
			smartInterceptor: false,
		}
	}

	private adjustLimitLines(
		startLine: number,
		endLine: number,
		inlineCompletionInfo: InlineCompletionInfo,
		offsetLineNum: number = 0,
	): { prefixLimitStartLine: number; suffixLimitEndLine: number } {
		let prefixLimitStartLine = startLine
		let suffixLimitEndLine = endLine
		let _offsetLineNum = 0

		if (prefixLimitStartLine !== 0 && offsetLineNum <= 0) {
			const prefixStartInFunction = inlineCompletionInfo.getCurFunction({
				row: prefixLimitStartLine,
				column: 0,
			})
			if (prefixStartInFunction && prefixStartInFunction.blockRange.startPoint.row !== prefixLimitStartLine) {
				_offsetLineNum = prefixStartInFunction.blockRange.endPoint.row + 1 - prefixLimitStartLine
				prefixLimitStartLine = prefixStartInFunction.blockRange.endPoint.row + 1
			}
			const prefixStartInStruct = inlineCompletionInfo.getCurStruct({
				row: prefixLimitStartLine,
				column: 0,
			})
			if (prefixStartInStruct && prefixStartInStruct.pointRange.startPoint.row !== prefixLimitStartLine) {
				_offsetLineNum = prefixStartInStruct.pointRange.endPoint.row + 1 - prefixLimitStartLine
				prefixLimitStartLine = prefixStartInStruct.pointRange.endPoint.row + 1
			}
		}
		suffixLimitEndLine += _offsetLineNum
		if (suffixLimitEndLine !== this.document.lineCount - 1) {
			const suffixEndInFunction = inlineCompletionInfo.getCurFunction({
				row: suffixLimitEndLine,
				column: 0,
			})
			if (suffixEndInFunction && suffixEndInFunction.blockRange.endPoint.row !== suffixLimitEndLine) {
				suffixLimitEndLine = suffixEndInFunction.blockRange.startPoint.row - 1
			}
			const suffixEndInStruct = inlineCompletionInfo.getCurStruct({
				row: suffixLimitEndLine,
				column: 0,
			})
			if (suffixEndInStruct && suffixEndInStruct.pointRange.startPoint.row !== suffixLimitEndLine) {
				suffixLimitEndLine = suffixEndInStruct.pointRange.endPoint.row + 1
			}
		}

		return { prefixLimitStartLine, suffixLimitEndLine }
	}

	private createContextualCompletion(
		prefixRange: Range,
		suffixRange: Range,
		prefixLineNum: number,
		suffixLineNum: number,
	): ContextualCompletion {
		const currentLine = this.position.line
		const currentLinePrefix = this.document.getText(new Range(currentLine, 0, currentLine, this.position.character))
		const currentLineSuffix = this.document.getText(
			new Range(currentLine, this.position.character, currentLine, this.document.lineAt(currentLine).text.length),
		)
		const prefixSuffixBlockRange: PointRange = {
			startPoint: {
				row: prefixRange.start.line,
				column: prefixRange.start.character,
			},
			endPoint: {
				row: suffixRange.end.line,
				column: suffixRange.end.character,
			},
		}

		return {
			languageId: this.fileCommonData.languageId,
			prefixLineNum,
			suffixLineNum,
			currentLine,
			totalLine: this.document.lineCount,
			prefix: this.document.getText(prefixRange),
			suffix: this.document.getText(suffixRange),
			prefixSuffixBlockRange: prefixSuffixBlockRange,
			currentLinePrefix,
			currentLineSuffix,
			retrieveMethod: RetrieveMethod.FixWindow,
			eol: this.document.eol === vscode.EndOfLine.CRLF ? "\r\n" : "\n",
			completeChoices: [],
			completionRespData: {
				result: "",
				chatUuid: "",
				docId: "",
				formattedCompletion: "",
				prompt: "",
				finishReason: "",
			},
			smartInterceptor: false,
		}
	}

	public getFuncBlockPrefixSuffix(inlineCompletionInfo: InlineCompletionInfo): ContextualCompletion {
		const currentLine = this.position.line
		const currentFunction = inlineCompletionInfo.getCurFunction({
			row: this.position.line,
			column: this.position.character,
		})

		if (currentFunction) {
			const prefixLineNum = currentLine - currentFunction.blockRange.startPoint.row
			const suffixLineNum = currentFunction.blockRange.endPoint.row - currentLine

			if (prefixLineNum + suffixLineNum > this.contentLineNumRequest) {
				const prefixRange = new Range(currentFunction.blockRange.startPoint.row, 0, currentLine, this.position.character)
				const suffixRange = new Range(
					currentLine,
					this.position.character,
					currentFunction.blockRange.endPoint.row,
					currentFunction.blockRange.endPoint.column,
				)
				return this.createContextualCompletion(prefixRange, suffixRange, prefixLineNum, suffixLineNum)
			}

			let offsetLineNum = 0
			if (prefixLineNum > this.prefixSuffixRequestLine.prefixLineNum) {
				offsetLineNum = prefixLineNum - this.prefixSuffixRequestLine.prefixLineNum
			}

			if (suffixLineNum > this.prefixSuffixRequestLine.suffixLineNum) {
				offsetLineNum = this.prefixSuffixRequestLine.suffixLineNum - suffixLineNum
			}
			this.prefixSuffixRequestLine.prefixLineNum =
				offsetLineNum > 0 ? prefixLineNum : this.prefixSuffixRequestLine.prefixLineNum + offsetLineNum
			this.prefixSuffixRequestLine.suffixLineNum =
				offsetLineNum > 0 ? this.prefixSuffixRequestLine.suffixLineNum - offsetLineNum : suffixLineNum

			const { prefixLimitStartLine, suffixLimitEndLine } = this.adjustLimitLines(
				Math.max(
					0,
					currentFunction.blockRange.startPoint.row - (this.prefixSuffixRequestLine.prefixLineNum - prefixLineNum),
				),
				Math.min(
					this.document.lineCount - 1,
					currentFunction.blockRange.endPoint.row + (this.prefixSuffixRequestLine.suffixLineNum - suffixLineNum),
				),
				inlineCompletionInfo,
				offsetLineNum,
			)

			return this.createContextualCompletion(
				new Range(prefixLimitStartLine, 0, currentLine, this.position.character),
				new Range(
					currentLine,
					this.position.character,
					suffixLimitEndLine,
					suffixLimitEndLine === this.document.lineCount - 1 ? this.document.lineAt(suffixLimitEndLine).text.length : 0,
				),
				currentLine - prefixLimitStartLine,
				suffixLimitEndLine - currentLine,
			)
		}

		const { prefixLimitStartLine, suffixLimitEndLine } = this.adjustLimitLines(
			Math.max(0, this.position.line - this.prefixSuffixRequestLine.prefixLineNum),
			Math.min(this.document.lineCount - 1, this.position.line + this.prefixSuffixRequestLine.suffixLineNum),
			inlineCompletionInfo,
		)

		return this.createContextualCompletion(
			new Range(prefixLimitStartLine, 0, currentLine, this.position.character),
			new Range(
				currentLine,
				this.position.character,
				suffixLimitEndLine,
				suffixLimitEndLine === this.document.lineCount - 1 ? this.document.lineAt(suffixLimitEndLine).text.length : 0,
			),
			currentLine - prefixLimitStartLine,
			suffixLimitEndLine - currentLine,
		)
	}

	public static getPrefixSuffixRow = (
		requestLineNum: number,
		currentLine: number,
		totalLine: number,
		contextRatio: number[],
	): PrefixSuffixRow => {
		const numLinesToEnd = totalLine - currentLine
		let numLinesPrefix = Math.floor(Math.abs(requestLineNum * contextRatio[0]))
		let numLinesSuffix = Math.ceil(Math.abs(requestLineNum * contextRatio[1]))

		if (numLinesPrefix > currentLine) {
			numLinesSuffix += numLinesPrefix - currentLine
			numLinesPrefix = currentLine
		}

		if (numLinesSuffix > numLinesToEnd) {
			numLinesPrefix += numLinesSuffix - numLinesToEnd
			numLinesSuffix = numLinesToEnd
		}

		return {
			prefixLineNum: numLinesPrefix,
			suffixLineNum: numLinesSuffix,
		}
	}
}
