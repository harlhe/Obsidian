package com.zte.studio.devops.mcp.model.dto.itest.request;

import com.zte.studio.devops.mcp.model.dto.itest.workitem.FieldDTO;
import lombok.Data;


import java.util.List;

@Data
public class CreateTestCaseRequest {

    private String branchId;

    private String dirId;

    private List<FieldDTO> fields;

    private String workItemTypeKey;
}
