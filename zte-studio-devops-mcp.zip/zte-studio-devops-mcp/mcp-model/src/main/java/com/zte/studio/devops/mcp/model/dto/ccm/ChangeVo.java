package com.zte.studio.devops.mcp.model.dto.ccm;

import lombok.Data;

@Data
public class ChangeVo {
  private String project;
  private String branch;
  private String changeKey;
  private String subject;
  private String status;
  private int insertions;
  private int deletions;
  private int changeNumber;
}
