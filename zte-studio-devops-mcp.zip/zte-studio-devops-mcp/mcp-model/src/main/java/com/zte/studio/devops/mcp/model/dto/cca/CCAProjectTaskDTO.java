package com.zte.studio.devops.mcp.model.dto.cca;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class CCAProjectTaskDTO {
    private String projectId;
    private String projectName;
    private String projectShortId;
    private String taskId;
    private String taskName;
    private String taskShortId;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8",shape = JsonFormat.Shape.STRING)
    private Date createTime;

}
