package com.zte.studio.devops.mcp.model.dto.itest.request;

import com.zte.studio.devops.mcp.model.dto.itest.request.dto.QueryItem;
import lombok.Data;

@Data
public class RequireSuitQueryRequest {

    private String testrecordTemplate;

    private String requirementId;

    private QueryItem queryItem;
}
