package com.zte.studio.devops.mcp.model.dto.ipipeline;

import lombok.Data;

import java.util.List;

/**
 * desc
 *
 * @author 10261252
 */
@Data
public class PageResponseDTO<T> {
    private Long total;
    private Integer currentPage;
    private Integer pageSize;
    private List<T> data;
}
