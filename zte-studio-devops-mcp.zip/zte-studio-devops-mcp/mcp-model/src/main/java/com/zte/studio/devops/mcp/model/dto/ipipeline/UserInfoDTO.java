package com.zte.studio.devops.mcp.model.dto.ipipeline;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * desc
 *
 * @author 10261252
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserInfoDTO implements Serializable {

    private static final long serialVersionUID = 3051317985078117965L;

    /**
     * 账号
     */
    private String accountID;

    /**
     * 工号
     */
    private String employeeNo;

    /**
     * 英文名
     */
    private String employeeNameEn;

    /**
     * 中文名
     */
    private String employeeNameZh;
}