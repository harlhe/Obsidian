package com.zte.studio.devops.mcp.model.dto.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * desc
 *
 * @author 10261252
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PersonGeneralInfoBlockDTO {
    private String block;
    private String ver;
}
