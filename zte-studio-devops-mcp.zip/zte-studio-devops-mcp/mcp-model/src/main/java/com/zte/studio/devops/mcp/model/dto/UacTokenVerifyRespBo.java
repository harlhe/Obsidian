package com.zte.studio.devops.mcp.model.dto;

import lombok.Data;

@Data
public class UacTokenVerifyRespBo {
    private static final String SUCCESS_CODE = "0000";
    private String code;
    private String msg;
    private String enMsg;

    public static boolean authSuccess(UacTokenVerifyRespBo respBo) {
        if (null == respBo || null == respBo.getCode()) {
            return  false;
        }
        return SUCCESS_CODE.equals(respBo.getCode());
    }

}
