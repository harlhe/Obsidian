package com.zte.studio.devops.mcp.model.dto.itest.step;

import lombok.Data;

import java.util.List;

@Data
public class TestStep {
    private String operation;

    private String expect;

    private List<String> attachment;

    private Integer index;
}
