package com.zte.studio.devops.mcp.model.dto.ccm;

import lombok.Data;

@Data
public class ChangeDTO {
  private String project;
  private String branch;
  private String change_id;
  private String subject;
  private String status;
  private int insertions;
  private int deletions;
  private int _number;
}
