package com.zte.studio.devops.mcp.model.dto.itest.workitem;

import lombok.Data;

@Data
public class FieldUsageDefVO {
    private String id;
    private String tenantKey;
    /**
     * 字段usage所属工作区
     */
    private String workspaceKey;
    private String workItemTypeKey;
    private String referenceName;
    private String name;
    private String nameZh;
    private String nameEn;
    private String label;
    private String labelZh;
    private String labelEn;
    private String type;

    /**
     * 高级数据类型字段绑定的基础数据key
     */
    private String baseDataKey;
    private Boolean required;
    private Boolean readonly;
    private Boolean hidden;
    private String remoteDataSource;
    private String helpText;
    private Object defaultValue;
    /**
     * 单位名称
     */
    private String unitName;
    /**
     * 标准化字段
     */
    private Boolean standardField;
    /**
     * 计算公式
     */
    private String calFormula;
    /**
     * 是否多值
     */
    private Boolean multiValue;
    /**
     * 链接地址
     */
    private String hrefUrl;
    /**
     * 显示时区
     */
    private Boolean displayTimezone;

    /**
     * 是否为应用字段
     */
    private Boolean applicationField;
    /**
     * 控件布局行数（当前只有平铺）
     */
    private int rowNumber = 5;

    /**
     * 控件布局列数（当前只有平铺）
     */
    private int columnNumber = 1;

    /**
     * 附件字段允许上传数据的上限值，默认10000，支持在数据字典配置
     */
    private int allowAttachmentMaxCount = 10000;

    /**
     * 字段使用提示
     */
    private String fieldUsageHint;


}
