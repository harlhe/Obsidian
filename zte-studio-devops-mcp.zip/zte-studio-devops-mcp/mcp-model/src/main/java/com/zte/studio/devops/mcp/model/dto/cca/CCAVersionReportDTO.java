package com.zte.studio.devops.mcp.model.dto.cca;

import lombok.Data;

@Data
public class CCAVersionReportDTO {
    private String versionId;
    private String versionName;
    private String toolName;
    private String pdmProjectName;
    private String product;
    private String versionSummaryReport;
}
