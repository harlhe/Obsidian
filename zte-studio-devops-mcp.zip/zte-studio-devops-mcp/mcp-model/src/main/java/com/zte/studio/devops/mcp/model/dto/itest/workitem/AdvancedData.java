package com.zte.studio.devops.mcp.model.dto.itest.workitem;

import lombok.Data;

@Data
public class AdvancedData {

    private String id;

    private String name;

    private String value;
}
