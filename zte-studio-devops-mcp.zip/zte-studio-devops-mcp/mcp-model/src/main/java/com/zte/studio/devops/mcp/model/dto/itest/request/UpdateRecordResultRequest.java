package com.zte.studio.devops.mcp.model.dto.itest.request;

import lombok.Data;

import java.util.List;

@Data
public class UpdateRecordResultRequest {

    private String executorName;

    private Boolean checkAll;

    private Boolean isCollect;

    private List filterItems;

    private String result;

    private String testplanId;

    private List<String> testrecordIds;

    private String testsuitId;
}
