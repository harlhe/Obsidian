package com.zte.studio.devops.mcp.model.dto.itest.response;

import com.zte.studio.devops.mcp.model.dto.itest.workitem.WorkItemTypeDef;
import lombok.Data;


@Data
public class CreateWorkItemResponse {

    private WorkItemTypeDef workItem;
}
