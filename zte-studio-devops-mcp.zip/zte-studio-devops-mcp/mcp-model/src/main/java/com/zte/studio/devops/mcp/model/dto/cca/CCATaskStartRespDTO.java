package com.zte.studio.devops.mcp.model.dto.cca;

import lombok.Data;

@Data
public class CCATaskStartRespDTO {
    private CCATaskStartResultDTO data;
}
