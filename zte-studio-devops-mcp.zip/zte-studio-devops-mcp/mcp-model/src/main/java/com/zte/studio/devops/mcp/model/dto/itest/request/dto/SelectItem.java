package com.zte.studio.devops.mcp.model.dto.itest.request.dto;

import lombok.Data;

@Data
public class SelectItem {

    private String key;

    private String name;
}
