package com.zte.studio.devops.mcp.model.dto.ipipeline;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * desc
 *
 * @author 10261252
 */
@Data
public class PipelineListDTO implements Serializable {
    private static final long serialVersionUID = 4529785838546010875L;

    private Long pipelineId;
    private String pipelineName;
    private String pipelineCode;
    private Long buildNumber;
    private String relatedProduct;
    private String description;
    private Long latestDuration;
    private Integer latestBuildResult;
    private UserInfoDTO operationUser;
    private UserInfoDTO createdUser;
    private Date createdTime;
    private Date startTime;
    private Boolean favorite;
    private Integer status;
    private String buildDescription;
    private String workspace;
    private String organizationId;
    /**
     * 组织类型
     * @see com.zte.rdcloud.ipipeline.common.model.enumeration.OrganizationTypeEnum
     */
    private Integer organizationType;
}
