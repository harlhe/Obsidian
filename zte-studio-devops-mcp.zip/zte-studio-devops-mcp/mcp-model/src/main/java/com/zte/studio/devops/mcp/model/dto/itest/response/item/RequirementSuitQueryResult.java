package com.zte.studio.devops.mcp.model.dto.itest.response.item;

import lombok.Data;

import java.util.List;

@Data
public class RequirementSuitQueryResult {

    private List<TestResultItem> items;

    private Integer totalRow;

    private Integer pageNo;

    private Integer pageSize;
}
