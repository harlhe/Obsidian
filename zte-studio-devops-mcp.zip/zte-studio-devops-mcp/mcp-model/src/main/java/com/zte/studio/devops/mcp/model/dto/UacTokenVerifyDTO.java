package com.zte.studio.devops.mcp.model.dto;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;

@Data
public class UacTokenVerifyDTO {
    private String account;
    private String token;
    private String clientIP;
    private String systemCode;
    private String verifyCode;

    public void genVerifyCode() {
        String verifyStr = account + token;
        if (StringUtils.isNotBlank(clientIP)) {
            verifyStr += clientIP;
        }
        if (StringUtils.isNotBlank(systemCode)) {
            verifyStr += systemCode;
        }
        verifyCode = DigestUtils.md5DigestAsHex(verifyStr.getBytes(StandardCharsets.UTF_8));
    }
}
