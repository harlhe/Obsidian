package com.zte.studio.devops.mcp.model.dto.ipipeline;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 10261219@zte.intra
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BuildResponseDTO {
    private String flowDisplayName;
    private Long pipelineBuildId;
    private Long buildNumber;
    private String pipelineUrl;
}
