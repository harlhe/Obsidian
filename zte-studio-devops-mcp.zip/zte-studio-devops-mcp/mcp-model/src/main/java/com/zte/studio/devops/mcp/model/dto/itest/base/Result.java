package com.zte.studio.devops.mcp.model.dto.itest.base;

import lombok.Data;

import java.io.Serializable;

/**
 * Result
 *
 */
@Data
public class Result<T> implements Serializable {
    private Object others;
    private T bo;
    private StatusCode code;
}
