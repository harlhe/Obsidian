package com.zte.studio.devops.mcp.model.dto.ipipeline;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

/**
 * @author 10261219@zte.intra
 */
@Data
public class PipelineBuildDTO implements Serializable {

    private static final long serialVersionUID = -6055448474614777670L;

    /**
     * 构建历史ID
     */
    private Long pipelineBuildId;

    /**
     * 构建号
     */
    private Long buildNumber;

    /**
     * 流水线配置版本ID唯一
     */
    private Long pipelineId;

    /**
     * 流水线唯一ID
     */
    private String pipelineCode;

    /**
     * 执行人
     */
    private UserInfoDTO operationUserInfo;

    /**
     * 触发方式
     *
     * @see com.zte.rdcloud.ipipeline.common.model.enumeration.TriggerModeEnum
     */
    private Integer triggerMode;

    /**
     * 开始时间
     */
    private Date startTime;

    /**
     * 结束时间
     */
    private Date endTime;

    /**
     * 执行耗时
     */
    private Long duration;

    /**
     * 实际开始时间
     */
    private Date actualStartTime;

    /**
     * 实际结束时间
     */
    private Date actualEndTime;

    /**
     * 实际执行耗时
     */
    private Long actualDuration;

    /**
     * 执行状态
     *
     * @see com.zte.rdcloud.ipipeline.common.model.enumeration.ProcessStateEnum
     */
    private Integer processState;

    /**
     * 执行结果
     *
     * @see com.zte.rdcloud.ipipeline.common.model.enumeration.RunningResultEnum
     */
    private Integer runningResult;

    /**
     * add field to describe the state of load logs & artifacts
     *
     * @see com.zte.rdcloud.ipipeline.common.model.enumeration.LoadProductStateEnum
     */
    @Deprecated
    private Integer loadProductState;

    /**
     * 代码源
     */
    @Deprecated
    private Object[] codeSources;

    /**
     * 凭据映射
     */
    private Map<String, String> uniqueCredential;

    /**
     * 用户运行参数
     */
    private Map<String, String> userVariable;

    /**
     * 系统内置参数
     */
    private Map<String, String> systemVariable;

    /**
     * 构建进度日志
     */
    private Long systemLogId;

    /**
     * 构建产生的制品,逗号隔开
     */
    private String artifacts;

    /**
     * 执行上下文
     */
    private Map<String, Object> runtimeContext;

    /**
     * 状态
     *
     * @see com.zte.rdcloud.ipipeline.common.model.enumeration.DataStatusEnum
     */
    private Integer status;

    /**
     * 运行后参数结果
     */
    private Map<String, String> runtimeContextResult;

    /**
     * 构建描述
     */
    private String buildDescription;

    /**
     * 流水线终止时间戳，用于前端展示“强制终止”按钮，单位：ms
     */
    private String abortTimestamp;
}
