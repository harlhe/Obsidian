package com.zte.studio.devops.mcp.model.dto.itest.step;

import lombok.Data;

@Data
public class ParameterColumn {

    private String name;

    private String status;
}
