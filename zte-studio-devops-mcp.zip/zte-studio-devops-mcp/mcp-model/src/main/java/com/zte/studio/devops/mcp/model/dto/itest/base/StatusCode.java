package com.zte.studio.devops.mcp.model.dto.itest.base;

import lombok.Data;

@Data
public class StatusCode {

    private String code;

    private String msgId;

    private String msg;
}
