package com.zte.studio.devops.mcp.model.dto.cca;

import lombok.Data;

@Data
public class CCATaskStartResultDTO {
    private String executionShortId;
    private String executionId;
    private String code;
    private String projectId;
    private String taskId;
}
