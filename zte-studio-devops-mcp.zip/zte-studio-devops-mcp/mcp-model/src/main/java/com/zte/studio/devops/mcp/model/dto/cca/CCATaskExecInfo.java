package com.zte.studio.devops.mcp.model.dto.cca;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CCATaskExecInfo {
    private String id;
    private String name;
    private String startTime;
    private String endTime;
    private String costTime;
    private String taskId;
    private String status;
    private String remark;
    private String shortId;
    private String reportId;
    private String finished;
}
