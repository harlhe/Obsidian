package com.zte.studio.devops.mcp.model.dto.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * desc inone
 *
 * @author 10261252
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PersonGeneralInfoResponseDTO {
    private String emailFull;
    private String empNameEN;
    private String empName;
}
