package com.zte.studio.devops.mcp.model.dto.ipipeline;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 10242198
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserInfo implements Serializable {
    private String userId;
    private String nameZh;
    private String nameEn;
    private String strNameNoZh;
    private String strNameNoEn;
    private String deptNameEn;
    private String deptNameZh;
    private String headUrl;
}
