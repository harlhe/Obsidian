package com.zte.studio.devops.mcp.model.dto.ipipeline;

import lombok.Data;

import java.util.List;

/**
 * desc
 *
 * @author 10261252
 */
@Data
public class PipelineConfigQueryRequestDTO {
    private Integer currentPage;
    private Integer pageSize;
    private String orderBy;
    private String rule;
    private String workspace;
    private String organizationId;
    private Integer organizationType;
    private String pipelineName;
    private String relatedProduct;
    private String relatedMicroservice;
    private String relatedApplication;
    private String currentUserId;
    private Integer bizType;
    private List<Integer> runningResult;
    private List<String> operationUser;
    private List<String> createUser;
    private List<SortItem> sortItems;
}
