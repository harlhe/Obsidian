package com.zte.studio.devops.mcp.model.dto.itest.response.item;

import lombok.Data;

@Data
public class RelateItem {

    private String linkRelationName;

    private String localLastUpdateTime;

    private String relatedType;

    private String relatedWorkItemId;

    private String relateWorkItemTypeKey;

    private String relateWorkSpaceKey;

    private Boolean visible;

    private String workItemId;

    private String workItemTypeKey;

    private String workSpaceKey;
}
