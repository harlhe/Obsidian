package com.zte.studio.devops.mcp.model.dto.ipipeline;

import lombok.Data;

import java.io.Serializable;

/**
 * desc
 *
 * @author 10261252
 */
@Data
public class SortItem implements Serializable {
    private static final long serialVersionUID = 8476224792017747183L;

    private String key;
    private Boolean ascending;
}