package com.zte.studio.devops.mcp.model.dto.itest.step;

import lombok.Data;

import java.util.List;

@Data
public class TestSteps {

    private List<TestStep> table;

    private TestParameter parameters;
}
