package com.zte.studio.devops.mcp.model.dto.itest.request;

import lombok.Data;

import java.util.List;

@Data
public class QueryRelatedRequest {

    private List<String> workItemIds;

    private String linkRelationName;

    private Boolean visible;
}
