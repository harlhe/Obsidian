package com.zte.studio.devops.mcp.model.dto.cca;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;


@Getter
@Setter
public class CCAHttpResult<T> {
    private static final String CCA_SUCCESS_CODE = "300200";
    private static final String DEFAULT_SUCCESS_MSG = "Api request success.";
    private static final String DEFAULT_FAILED_MSG = "Api request failed.";
    private String code;
    private String message;
    private T data;

    public void msg(String msg) {
        if (StringUtils.isNotBlank(msg)) {
            this.message = msg;
        }
        if (CCA_SUCCESS_CODE.equals(this.code)) {
            this.message = DEFAULT_SUCCESS_MSG;
        } else {
            this.message = DEFAULT_FAILED_MSG;
        }
    }

    public void defaultSuccessMsg() {
        if (CCA_SUCCESS_CODE.equals(this.code)) {
            this.message = DEFAULT_SUCCESS_MSG;
        }
    }
    public void defaultFailMsg() {
        if (!CCA_SUCCESS_CODE.equals(this.code)) {
            this.message = DEFAULT_FAILED_MSG;
        }
    }

    public static CCAHttpResult<?> newInstance(){
        return new CCAHttpResult<>();
    }
    public CCAHttpResult<?> error(String msg) {
        this.setMessage(msg);
        return this;
    }

    public CCAHttpResult<T> ok(T data) {
        this.setData(data);
        this.setMessage(DEFAULT_SUCCESS_MSG);
        return this;
    }
}
