package com.zte.studio.devops.mcp.model.dto.itest.workitem;

import lombok.Data;

import java.util.Locale;

/**
 * @author YuWeiwei
 * @since 1.0.0
 * <p>Copyright: Copyright (c) 2020</p>
 */

@Data
public class WorkItemTypeDef {
    private String id;
    private String key;
    private String tenantKey;
    private String name;
    private String nameZh;
    private String nameEn;
    private Boolean nameModified;
    private String description;
    private String icon;
    private String color;
    private String workspaceKey;
    private String workspaceName;
    private String workspaceNameZh;
    private String workspaceNameEn;

    /**
     * 草稿态
     */
    private Boolean draft;
    /**
     * 哪个工作项类型的草稿
     */
    private String draftFromKey;
    /**
     * 从哪个模型继承
     */
    private String parentKey;
    /**
     * 父模型工作区
     */
    private String parentWorkspaceKey;
    /**
     * 父模型工作区
     */
    private String parentWorkspaceName;

    /**
     * 工作项类型key
     */
    private String workItemTypeRootKey;
    /**
     * 工作项类型对应的工作区
     */
    private String workItemTypeRootWorkspaceKey;
    /**
     * 工作项类型中文名称
     */
    private String workItemTypeRootNameZh;
    /**
     * 工作项类型英文名称
     */
    private String workItemTypeRootNameEn;
    /**
     * 工作项类型名称
     */
    private String workItemTypeRootName;
    /**
     * 工作项实例存储表的key
     */
    private String bizKey;
    /**
     * 模型key路径/A/B/C/D
     */
    private String keyNodePath;

    /**
     * 启用/禁用
     */
    private Boolean valid;

    /**
     * 所属应用
     */
    private String appCode;
    /**
     * 对应配置的语言环境
     */
    private Locale configurationLocale;

}