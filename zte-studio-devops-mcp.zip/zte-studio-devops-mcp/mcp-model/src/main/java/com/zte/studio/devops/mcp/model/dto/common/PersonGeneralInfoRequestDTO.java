package com.zte.studio.devops.mcp.model.dto.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * desc inone 个人信息接口的请求体
 *
 * @author 10261252
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PersonGeneralInfoRequestDTO {
    private String idType;
    private List<String> ids;
    private List<PersonGeneralInfoBlockDTO> infoBlocks;
    private String msname;
}
