package com.zte.studio.devops.mcp.model;

import lombok.Getter;

@Getter
public enum McpHeaderEnum {
    X_TENANT_ID("X-Tenant-Id", "10001"),
    X_ACCOUNT_ID("X-Account-Id",""),
    X_EMP_NO("X-Emp-No",""),
    X_AUTH_VALUE("X-Auth-Value",""),
    X_WORKSPACE_KEY("X-Workspace-Key",""),
    X_TEAM_ID("X-Team-Id",""),
    X_AREA_ID("X-Area-Id",""),
    X_CODE_TENANT("X-Code-Tenant",""),
    X_CCA_SERVER("X-Cca-Server","cca.zte.com.cn"),
    X_JFROG_SERVER("X-Jfrog-Server",""),
    X_JFROG_ACCOUNT("X-Jfrog-Account",""),
    X_JFROG_ApiKey("X-Jfrog-ApiKey","");

    private final String key;

    private final String defaultVal;

    McpHeaderEnum(String key, String defaultVal) {
        this.key = key;
        this.defaultVal = defaultVal;
    }

    public String key() {
        return this.key;
    }

    public String defaultVal() {
        return this.defaultVal;
    }


}
