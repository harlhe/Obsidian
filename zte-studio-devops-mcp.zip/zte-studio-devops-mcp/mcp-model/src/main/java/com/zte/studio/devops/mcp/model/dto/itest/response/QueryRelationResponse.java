package com.zte.studio.devops.mcp.model.dto.itest.response;

import com.zte.studio.devops.mcp.model.dto.itest.response.item.RelateItem;
import lombok.Data;

import java.util.List;

@Data
public class QueryRelationResponse {

    private List<RelateItem> items;

    private Integer pageNo;

    private Integer pageSize;
}
