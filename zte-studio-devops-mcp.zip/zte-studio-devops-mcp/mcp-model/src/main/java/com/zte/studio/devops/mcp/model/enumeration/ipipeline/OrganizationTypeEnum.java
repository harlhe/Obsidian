package com.zte.studio.devops.mcp.model.enumeration.ipipeline;

import lombok.Getter;

import java.util.Arrays;

/**
 * desc
 *
 * @author 10261252
 */
@Getter
public enum OrganizationTypeEnum {
    // 团队
    TEAM(0, "team"),
    // 领域
    AREA(1, "area"),
    WORKSPACE(2, "workspace"),
    TENANT(3, "tenant"),
    PUBLIC(4, "public")
    ;

    private int code;
    private String name;

    OrganizationTypeEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public static OrganizationTypeEnum getEnumByCode(int code) {
        return Arrays.stream(OrganizationTypeEnum.values()).filter((enumObj) -> enumObj.code == code)
                .findAny().orElse(null);
    }

    public static OrganizationTypeEnum getEnumByName(String name) {
        return Arrays.stream(OrganizationTypeEnum.values()).filter((enumObj) -> enumObj.name.equals(name))
                .findAny().orElse(null);
    }
}