package com.zte.studio.devops.mcp.model.dto.cca;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CCATaskQueryDTO {
    private String ccaServer;
    private String projectShortId;
    private String taskShortId;

}
