package com.zte.studio.devops.mcp.model.dto.itest.request.dto;

import lombok.Data;

import java.util.List;

@Data
public class QueryItem {

    private Integer pageSize;

    private Integer pageNo;

    private List<SelectItem> selectItems;
}
