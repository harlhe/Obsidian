package com.zte.studio.devops.mcp.model.enumeration.ipipeline;

import lombok.Getter;

import java.util.Arrays;

/**
 * @author 10261219@zte.intra
 */

public enum ProcessStateEnum {

    /**
     * 构建阶段状态
     */
    INIT(0,"INIT"),
    PREPARED(1,"PREPARED"),
    RUNNING(2,"RUNNING"),
    /**
     * 超时终止
     */
    STOPPING(3,"STOPPING"),
    /**
     * 暂停等待
     */
    WAITING(4,"WAITING"),
    /**
     * 构建结束
     */
    BUILD_FINISHED(5,"BUILD_FINISHED"),
    /**
     * 完全结束
     */
    FINISHED(6,"FINISHED"),
    /**
     * 人工终止
     */
    ABORTING(7,"ABORTING"),
    /**
     * 任务已入队
     */
    QUEUED(8, "QUEUED"),
    /**
     * 阻塞等待
     */
    PENDING(9, "PENDING"),
    /**
     * 强制终止
     */
    FORCE_ABORTING(10, "FORCE_ABORTING"),
    ;
    @Getter
    private final int code;
    @Getter
    private final String state;

    ProcessStateEnum(int code, String state){
        this.code = code;
        this.state = state;
    }

    public static ProcessStateEnum getEnumByCode(int code) {
        return Arrays.stream(ProcessStateEnum.values()).filter((enumObj) -> enumObj.code == code)
                .findAny().orElse(null);
    }
    public static ProcessStateEnum getEnumByState(String state) {
        return Arrays.stream(ProcessStateEnum.values()).filter((enumObj) -> enumObj.state.equals(state))
                .findAny().orElse(null);
    }
}
