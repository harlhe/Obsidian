package com.zte.studio.devops.mcp.model.dto.itest.response.item;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class TestPlanItem {

    @JsonProperty("Title")
    private String title;

    @JsonProperty("WorkItemTypeKey")
    private String workItemTypeKey;

    @JsonProperty("Id")
    private String id;
}
