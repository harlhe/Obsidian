package com.zte.studio.devops.mcp.model.dto.itest.workitem;

import lombok.Data;


@Data
public class FieldDTO {

    private String key;

    private Object value;

    public static FieldDTO buildBooleanField(String key,Boolean value){
        FieldDTO fieldDTO = new FieldDTO();
        fieldDTO.setKey(key);
        if (value){
            fieldDTO.setValue("是");
        }else {
            fieldDTO.setValue("否");
        }
        return fieldDTO;
    }

    public static FieldDTO buildAdvanceField(String key,String name,String id){
        FieldDTO fieldDTO = new FieldDTO();
        fieldDTO.setKey(key);
        AdvancedData advancedData= new AdvancedData();
        advancedData.setId(id);
        advancedData.setValue(name);
        advancedData.setName(name);
        fieldDTO.setValue(advancedData);
        return fieldDTO;
    }

    public static FieldDTO buildStringField(String key,String value){
        FieldDTO fieldDTO = new FieldDTO();
        fieldDTO.setKey(key);
        fieldDTO.setValue(value);
        return fieldDTO;
    }

    public static FieldDTO buildField(String key, Object value){
        FieldDTO fieldDTO = new FieldDTO();
        fieldDTO.setKey(key);
        fieldDTO.setValue(value);
        return fieldDTO;
    }
}
