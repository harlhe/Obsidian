package com.zte.studio.devops.mcp.model.enumeration.ipipeline;

import lombok.Getter;

import java.util.Arrays;

/**
 * @author 10261219@zte.intra
 */

public enum RunningResultEnum {

    /**
     * 构建结果状态——未执行
     */
    NOT_BUILT(0,"NOT_BUILT"),
    /**
     * 等待执行
     */
    PENDING(1,"PENDING"),
    /**
     * 队列中
     */
    QUEUED(2,"QUEUED"),
    /**
     * 暂停
     */
    PAUSED(3,"PAUSED"),
    /**
     * 终止中（包含人工终止和超时终止）
     */
    TERMINATING(4,"TERMINATING"),
    /**
     * 运行中
     */
    RUNNING(5,"RUNNING"),
    /**
     * 人工终止
     */
    ABORTED(6,"ABORTED"),
    /**
     * 失败
     */
    FAILURE(7,"FAILURE"),
    /**
     * 成功
     */
    SUCCESS(8,"SUCCESS"),
    /**
     * 不稳定
     */
    UNSTABLE(9,"UNSTABLE"),
    /**
     * 跳过
     */
    SKIPPED(10,"SKIPPED"),
    /**
     * 超时
     */
    TIMEOUT(11,"TIMEOUT")
    ;
    @Getter
    private final int code;
    @Getter
    private final String state;

    RunningResultEnum(int code, String state){
        this.code = code;
        this.state = state;
    }

    public static RunningResultEnum getEnumByCode(int code) {
        return Arrays.stream(RunningResultEnum.values()).filter((enumObj) -> enumObj.code == code)
                .findAny().orElse(null);
    }

    public static RunningResultEnum getEnumByState(String state) {
        return Arrays.stream(RunningResultEnum.values()).filter((enumObj) -> enumObj.state.equals(state))
                .findAny().orElse(null);
    }
}
