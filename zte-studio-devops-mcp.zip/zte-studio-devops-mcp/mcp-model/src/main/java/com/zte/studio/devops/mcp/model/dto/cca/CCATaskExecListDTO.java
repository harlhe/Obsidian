package com.zte.studio.devops.mcp.model.dto.cca;

import lombok.Data;

import java.util.List;

@Data
public class CCATaskExecListDTO {
    private List<CCATaskExecInfo> data;
}
