package com.zte.studio.devops.mcp.model.dto.itest.response.item;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class TestResultItem {

    @JsonProperty("TestCenterResult")
    private String testCenterResult;

    private String id;
}
