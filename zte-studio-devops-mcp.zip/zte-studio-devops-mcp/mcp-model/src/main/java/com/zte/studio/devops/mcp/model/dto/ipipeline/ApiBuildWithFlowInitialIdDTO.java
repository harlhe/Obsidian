package com.zte.studio.devops.mcp.model.dto.ipipeline;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;


/**
 * @author 10261219@zte.intra
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApiBuildWithFlowInitialIdDTO implements Serializable {
    private String flowInitialId;
    private UserInfo operationUser;
    private String triggerMode;
    private Map<String, String> runningParameter;

    @Override
    public String toString() {
        return "ApiBuildParameter2{" +
                "flowInitialId='" + flowInitialId + '\'' +
                ", operationUser=" + operationUser +
                ", triggerMode='" + triggerMode + '\'' +
                ", runningParameter=" + runningParameter +
                '}';
    }
}
