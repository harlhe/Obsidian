package com.zte.studio.devops.mcp.core.service.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "test.manager.service.url")
public class TestUrlProperties {

    private String queryWorkItemTypesUrl;

    private String queryWorkItemModelUrl;

    private String createTestcaseUrl;

    private String updateWorkItemUrl;

    private String deleteWorkItemUrl;

    private String queryWorkItemDetailUrl;

    private String queryRelateWorkItemUrl;

    private String createTestPlanUrl;

    private String queryTestPlanListUrl;

    private String createRequireSuitUrl;

    private String queryRequireRecordUrl;

    private String updateRecordResultUrl;
}
