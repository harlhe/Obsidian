package com.zte.studio.devops.mcp.core.service.common;

import com.alibaba.fastjson.TypeReference;
import com.zte.itp.msa.core.model.RetCode;
import com.zte.itp.msa.core.model.ServiceData;
import com.zte.studio.devops.mcp.common.config.InoneApiProperties;
import com.zte.studio.devops.mcp.common.utils.RestUtils;
import com.zte.studio.devops.mcp.model.dto.common.PersonGeneralInfoBlockDTO;
import com.zte.studio.devops.mcp.model.dto.common.PersonGeneralInfoRequestDTO;
import com.zte.studio.devops.mcp.model.dto.common.PersonGeneralInfoResponseDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * desc
 *
 * @author 10261252
 */
@Slf4j
@Service
public class InoneApiService {
    private final static String INONE_APP_CODE_HEADER = "APPCode";
    // 调用员工中心接口的一些关键字
    private final static String PERSON_INFO_ID_TYPE = "T0002";
    private final static String PERSON_INFO_BLOCK = "B0002";
    private final static String PERSON_INFO_BLOCK_1 = "B0001";
    private final static String PERSON_INFO_VER = "v3";
    private final static String PERSON_INFO_VER_1 = "v1";

    @Autowired
    private InoneApiProperties inoneApiProperties;

    @Value("${spring.application.name}")
    private String appName;

    public Map<String, PersonGeneralInfoResponseDTO> getPersonGeneralInfo(List<String> empNos) {
        if (CollectionUtils.isEmpty(empNos)) {
            return null;
        }
        String requestUrl = inoneApiProperties.getPersonGeneralInfo();
        Map<String, String> requestHeaders = new HashMap<>();
        requestHeaders.put(INONE_APP_CODE_HEADER, inoneApiProperties.getAppCode());
        PersonGeneralInfoRequestDTO requestDTO = new PersonGeneralInfoRequestDTO();
        requestDTO.setIds(empNos);
        requestDTO.setIdType(PERSON_INFO_ID_TYPE);
        PersonGeneralInfoBlockDTO personGeneralInfoBlockDTO = new PersonGeneralInfoBlockDTO(PERSON_INFO_BLOCK,
                PERSON_INFO_VER);
        PersonGeneralInfoBlockDTO personGeneralInfoBlockDTO1 = new PersonGeneralInfoBlockDTO(PERSON_INFO_BLOCK_1,
                PERSON_INFO_VER_1);
        List<PersonGeneralInfoBlockDTO> personGeneralInfoBlockDTOS = new ArrayList<>();
        personGeneralInfoBlockDTOS.add(personGeneralInfoBlockDTO);
        personGeneralInfoBlockDTOS.add(personGeneralInfoBlockDTO1);
        requestDTO.setInfoBlocks(personGeneralInfoBlockDTOS);
        requestDTO.setMsname(appName);
        ServiceData<Map<String, PersonGeneralInfoResponseDTO>> responseDTO = new ServiceData<>();
        try {
            responseDTO = RestUtils.post(requestUrl, requestHeaders, requestDTO,
                    new TypeReference<ServiceData<Map<String, PersonGeneralInfoResponseDTO>>>() {
                    });
        } catch (Exception e) {
            log.error("Call inone getPersonGeneralIno failed.", e);
            return null;
        }
        if (Objects.nonNull(responseDTO) && Objects.nonNull(responseDTO.getCode())
                && RetCode.SUCCESS_CODE.equals(responseDTO.getCode().getCode())) {
            return responseDTO.getBo();
        }
        return null;
    }
}

