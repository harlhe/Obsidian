/*
* Copyright 2024 - 2024 the original author or authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* https://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.zte.studio.devops.mcp.core.service.icode_ccm;

import com.alibaba.fastjson.JSON;
import com.zte.studio.devops.mcp.common.utils.RequestContextUtils;
import com.zte.studio.devops.mcp.model.dto.ccm.ChangeDTO;
import com.zte.studio.devops.mcp.model.dto.ccm.ChangeVo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@ConfigurationProperties(prefix = "gerrit.api")
@Setter
@Getter
public class CodeCCMService {

  private Map<String,String> host;

  @Autowired
  private RestTemplate restClient;

  private final String authValueKey="X-Auth-Value";
  private final String authEmpKey="X-Emp-No";
  private final String defaultTenant="ZTE";

	@Tool(description = "获取我提交的评审单列表")
	public String getMyChanges() {
    String empNo = RequestContextUtils.getAccountId();
    String authValue = RequestContextUtils.getToken();
    String hostDomain = getHostByTenant();
    Map<String,String> headers = new HashMap<>();
    headers.put(authEmpKey,empNo);
    headers.put(authValueKey,authValue);
    try{
      String res = this.get(hostDomain+"/a/changes/?q=is:open+owner:self", null,headers);
      List<ChangeDTO> resList = JSON.parseArray(res, ChangeDTO.class);
      if(CollectionUtils.isEmpty(resList)){
        return "Has No Submit Changes";
      }
      List<ChangeVo> resVoList = new ArrayList<>();
      resList.forEach(e->{
        ChangeVo changeVo = new ChangeVo();
        BeanUtils.copyProperties(e,changeVo);
        changeVo.setChangeNumber(e.get_number());
        changeVo.setChangeKey(e.getChange_id());
        resVoList.add(changeVo);
      });
      return JSON.toJSONString(resVoList);
    }catch (Exception e){
      return "Get My Submit Changes Failed";
    }
	}

  private String getHostByTenant() {
    String tenantInHeader = RequestContextUtils.getCodeTenant();
    String tenant = StringUtils.isEmpty(tenantInHeader)?defaultTenant:tenantInHeader;
    String hostDomain = this.host.get(tenant);
    if(hostDomain==null){
      throw new RuntimeException("Current Tenant not supported,support tenants" + String.join(",", host.keySet()));
    }
    return hostDomain;
  }

  @Tool(description = "获取待我评审的评审单列表")
  public String getMyReviews() {
    String empNo = RequestContextUtils.getAccountId();
    String authValue = RequestContextUtils.getToken();
    String hostDomain = getHostByTenant();
    Map<String,String> headers = new HashMap<>();
    headers.put(authEmpKey,empNo);
    headers.put(authValueKey,authValue);
    try{
      String res = this.get(hostDomain + "/a/changes/?q=is:open+reviewer:self+-owner:self+-star:ignore", null, headers);
      List<ChangeDTO> resList = JSON.parseArray(res, ChangeDTO.class);
      if(CollectionUtils.isEmpty(resList)){
        return "Has No Review Changes";
      }
      List<ChangeVo> resVoList = new ArrayList<>();
      resList.forEach(e->{
        ChangeVo changeVo = new ChangeVo();
        BeanUtils.copyProperties(e,changeVo);
        changeVo.setChangeNumber(e.get_number());
        changeVo.setChangeKey(e.getChange_id());
        resVoList.add(changeVo);
      });
      return JSON.toJSONString(resVoList);
    }catch (Exception e){
      return "Get My Review Changes Failed";
    }

  }

  @Tool(description = "评审单评论并打分")
  public String review(String changeId,@ToolParam(description = "patchset号或对应commit值,默认1",required=false)String revision,@ToolParam(description = "msg",required = false) String msg,@ToolParam(description = "打分") Integer score ) {
    String empNo = RequestContextUtils.getAccountId();
    String authValue = RequestContextUtils.getToken();
    String hostDomain = getHostByTenant();
    Map<String,String> headers = new HashMap<>();
    headers.put(authEmpKey,empNo);
    headers.put(authValueKey,authValue);
    revision=StringUtils.isEmpty(revision)?"1":revision;
    String url = hostDomain+"/a/changes/"+changeId+"/revisions/"+revision+"/review";
    Map<String,Object> params = new HashMap<>();
    Map<String,Object> review = new HashMap<>();
    review.put("Code-Review",score);
    params.put("labels",review);
    params.put("message",msg);
    try{
      this.post(url, params,headers);
      return "Score Successfully";
    }catch (Exception e){
      return "Score Failed";
    }
  }
  @Tool(description = "评审单合入")
  public String merge(String changeId,@ToolParam(description = "patchset号或对应commit值,默认1",required=false)String revision ) {
    String empNo = RequestContextUtils.getAccountId();
    String authValue = RequestContextUtils.getToken();
    String hostDomain = getHostByTenant();
    Map<String,String> headers = new HashMap<>();
    headers.put(authEmpKey,empNo);
    headers.put(authValueKey,authValue);
    revision=StringUtils.isEmpty(revision)?"1":revision;
    String url = hostDomain+"/a/changes/"+changeId+"/revisions/"+revision+"/submit";
    try{
      this.post(url, null,headers);
      return "Merge Successfully";
    }catch (Exception e){
      return "Merge Failed";
    }
  }

  public String get(String url, Map<String, String> params, Map<String, String> headers) {
    try {
      UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
      if(params !=null){
        params.forEach(builder::queryParam);
      }
      HttpHeaders httpHeaders = new HttpHeaders();
      if (headers != null) {
        headers.forEach(httpHeaders::set);
      }
      HttpEntity<?> requestEntity = new HttpEntity<>(httpHeaders);
      ResponseEntity<String> response = restClient.exchange(
          builder.build().encode().toUri(),
          HttpMethod.GET,
          requestEntity,
          String.class
      );
      String bodyString = response.getBody().replace(")]}'","").replaceAll("\n","");
      //JSONArray array = JSONArray.parseArray(bodyString);
      return bodyString;
    } catch (RestClientException e) {
      log.error("GET request failed: {},from url:{}", e.getMessage(),url);
      throw new RuntimeException("Failed to get data");
    }
  }

  public String post(String url, Object body, Map<String, String> headers) {
    try {
      UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
      HttpHeaders httpHeaders = new HttpHeaders();
      if (headers != null) {
        headers.forEach(httpHeaders::set);
      }
      HttpEntity<?> requestEntity = new HttpEntity<>(body, httpHeaders);
      ResponseEntity<String> response = restClient.exchange(
          builder.build().encode().toUri(),
          HttpMethod.POST,
          requestEntity,
          String.class
      );

      return response.getBody().replace(")]}'","").replaceAll("\n","");
    } catch (RestClientException e) {
      log.error("POST request failed: {}, from url: {}", e.getMessage(), url);
      throw new RuntimeException("Failed to post data");
    }
  }

}
