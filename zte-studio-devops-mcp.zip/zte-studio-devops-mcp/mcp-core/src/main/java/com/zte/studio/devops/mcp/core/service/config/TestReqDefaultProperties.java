package com.zte.studio.devops.mcp.core.service.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "test.manager.services.default.param")
public class TestReqDefaultProperties {

    private String testcaseType;

    private String branchId;

    private String dirId;

    private String testLayer;

    private String testcaseLevel;

    private Boolean shouldAutomated;

    private Boolean hasAutomated;

    private String workspace;

    private String presetCondition;

    private String teamName;

    private String teamId;

    private String updateType;

    private String testEnvironment;

    private String suitName;
}
