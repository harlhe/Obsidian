package com.zte.studio.devops.mcp.core.service.cca;


import com.alibaba.fastjson.TypeReference;
import com.google.common.hash.Hashing;
import com.zte.studio.devops.mcp.common.utils.RequestContextUtils;
import com.zte.studio.devops.mcp.common.utils.RestUtils;
import com.zte.studio.devops.mcp.model.McpHeaderEnum;
import com.zte.studio.devops.mcp.model.dto.cca.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CCAClient {

    @Value("${cca.appid}")
    private String ccaAppId;

    @Value("${cca.secret}")
    private String ccaSecret;
    private static final String CCATY_SERVER = "ccaty.zte.com.cn";
    private static final String CCA_SERVER = "cca.zte.com.cn";
    private static final String CCATY_KEYWORD = "ccaty";

    private static final String GET_PROJECT_TASK_BY_NAME_URL =
            "https://%s/api/v2/service/project/getProjectTaskByName?projectName=%s&taskName=%s";
    private static final String GET_PROJECT_TASK_BY_ID_URL =
            "https://%s/api/v2/projects/%s/tasks/%s?username=%s";
    private static final String GET_TASK_LAST_EXEC_INFO_URL =
            "https://%s/api/v2/project/%s/task/%s/executions?start=0&length=1&order=desc&sort=startTime&username=%s";
    private static final String GET_TASK_LAST_SUCCESS_EXEC_INFO_URL =
            "https://%s/api/v2/project/task/last-success-execution?projectShortId=%s&taskId=%s";
    private static final String START_TASK_URL = "https://%s/api/v2/projects/%s/tasks/%s/execution";
    private static final String TERMINATE_TASK_URL = "https://%s/api/v2/project/%s/task/%s/execution/%s/terminate?username=%s";

    private static final String VERSION_REPORT_LIST_URL = "https://%s/api/v2/projects/%s/getAllVersionReport?start=1&length=10&filter=&toolName=";

    public CCAHttpResult<?> getProjectTaskById(String ccaServer, String projectShortId, String taskShortId) {
        String host = parseCCAServer(ccaServer);
        String url = String.format(GET_PROJECT_TASK_BY_ID_URL, host, projectShortId, taskShortId, RequestContextUtils.getAccountId());
        Map<String, String> headers = getCCAHeaders();
        return RestUtils.get(url, headers, new TypeReference<>() {
        });
    }

    public CCAHttpResult<CCAProjectTaskDTO> getProjectTaskByName(String ccaServer, String projectName, String taskName) {
        String host = parseCCAServer(ccaServer);
        String url = String.format(GET_PROJECT_TASK_BY_NAME_URL, host, projectName, taskName);
        Map<String, String> headers = getCCAHeaders();
        return RestUtils.get(url, headers, new TypeReference<>() {
        });
    }

    public CCAHttpResult<CCATaskExecListDTO> getTaskLastExecInfo(String ccaServer, String projectShortId, String taskShortId) {
        String host = parseCCAServer(ccaServer);
        String url = String.format(GET_TASK_LAST_EXEC_INFO_URL, host, projectShortId,
                taskShortId, RequestContextUtils.getAccountId());
        Map<String, String> headers = getCCAHeaders();
        return RestUtils.get(url, headers, new TypeReference<>() {
        });
    }

    public CCAHttpResult<CCATaskExecInfo> getTaskLastSuccessExecInfo(String ccaServer, String projectShortId, String taskId) {
        String host = parseCCAServer(ccaServer);
        String url = String.format(GET_TASK_LAST_SUCCESS_EXEC_INFO_URL, host, projectShortId, taskId);
        Map<String, String> headers = getCCAHeaders();
        return RestUtils.get(url, headers, new TypeReference<>() {
        });
    }

    public CCAHttpResult<CCATaskStartRespDTO> startTask(String ccaServer, String projectShortId, String taskShortId) {
        String host = parseCCAServer(ccaServer);
        String url = String.format(START_TASK_URL, host, projectShortId, taskShortId);
        Map<String, String> headers = getCCAHeaders();
        return RestUtils.post(url, headers, null, new TypeReference<>() {
        });
    }

    public CCAHttpResult<?> terminateTask(String ccaServer, String projectShortId, String taskShortId, String executionShortId) {
        String host = parseCCAServer(ccaServer);
        String url = String.format(TERMINATE_TASK_URL, host, projectShortId, taskShortId, executionShortId,
                RequestContextUtils.getAccountId());
        Map<String, String> headers = getCCAHeaders();
        return RestUtils.put(url, headers, new TypeReference<>() {
        }, "{}");
    }

    public List<CCAVersionReportDTO> getVersionReport(String ccaServer, String projectShortId, String versionName) {
        if (StringUtils.isBlank(versionName)) {
            return null;
        }
        String host = parseCCAServer(ccaServer);
        String url = String.format(VERSION_REPORT_LIST_URL, host, projectShortId);
        Map<String, String> headers = getCCAHeaders();
        CCAHttpResult<List<CCAVersionReportDTO>> versionReportResp = RestUtils.get(url, headers, new TypeReference<>() {
        });
        if (null == versionReportResp) {
            return null;
        }
        if (CollectionUtils.isEmpty(versionReportResp.getData())) {
            return null;
        }
        return versionReportResp.getData().stream()
                .filter(el -> versionName.equalsIgnoreCase(el.getVersionName())).toList();
    }


    private Map<String, String> getCCAHeaders() {
        long timeStamp = LocalDateTime.now()
                .toInstant(ZoneOffset.ofHours(8))
                .toEpochMilli();
        String sha256hex = null;
        if (StringUtils.isNotBlank(ccaSecret)) {
            sha256hex = Hashing.hmacSha256(ccaSecret.getBytes()).
                    hashString(ccaAppId + timeStamp, StandardCharsets.UTF_8).toString();
        }
        Map<String, String> httpHeaders = new HashMap<>();
        httpHeaders.put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        httpHeaders.put("X-Tenant-Id", RequestContextUtils.getTenantId());
        httpHeaders.put("X-APP-ID", ccaAppId);
        httpHeaders.put("X-Emp-No", RequestContextUtils.getAccountId());
        httpHeaders.put("X-Auth-Value", sha256hex);
        httpHeaders.put("X-TIMESTAMP", String.valueOf(timeStamp));
        return httpHeaders;
    }

    private String parseCCAServer(String ccaServer) {
        String ccaServerStr;
        if (StringUtils.isNotBlank(ccaServer)) {
            ccaServerStr = ccaServer;
        } else if (StringUtils.isNotBlank(RequestContextUtils.getCCAServer())) {
            ccaServerStr = RequestContextUtils.getCCAServer();
        } else {
            return McpHeaderEnum.X_CCA_SERVER.defaultVal();
        }
        if (ccaServerStr.toLowerCase().contains(CCATY_KEYWORD)) {
            return CCATY_SERVER;
        }
        return CCA_SERVER;
    }

}
