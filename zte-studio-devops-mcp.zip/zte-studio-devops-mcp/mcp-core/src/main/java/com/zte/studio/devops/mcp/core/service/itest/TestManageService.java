package com.zte.studio.devops.mcp.core.service.itest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.zte.studio.devops.mcp.common.constants.CommonConstants;
import com.zte.studio.devops.mcp.common.utils.DefaultValueUtils;
import com.zte.studio.devops.mcp.common.utils.RequestContextUtils;
import com.zte.studio.devops.mcp.common.utils.RestUtils;
import com.zte.studio.devops.mcp.core.service.config.TestReqDefaultProperties;
import com.zte.studio.devops.mcp.core.service.config.TestUrlProperties;
import com.zte.studio.devops.mcp.model.dto.itest.base.Result;
import com.zte.studio.devops.mcp.model.dto.itest.request.*;
import com.zte.studio.devops.mcp.model.dto.itest.request.dto.QueryItem;
import com.zte.studio.devops.mcp.model.dto.itest.request.dto.SelectItem;
import com.zte.studio.devops.mcp.model.dto.itest.response.CreateWorkItemResponse;
import com.zte.studio.devops.mcp.model.dto.itest.response.QueryRelationResponse;
import com.zte.studio.devops.mcp.model.dto.itest.response.RequirementSuitQueryResponse;
import com.zte.studio.devops.mcp.model.dto.itest.response.item.RelateItem;
import com.zte.studio.devops.mcp.model.dto.itest.response.item.RequirementSuitQueryResult;
import com.zte.studio.devops.mcp.model.dto.itest.response.item.TestPlanItem;
import com.zte.studio.devops.mcp.model.dto.itest.response.item.TestResultItem;
import com.zte.studio.devops.mcp.model.dto.itest.step.TestStep;
import com.zte.studio.devops.mcp.model.dto.itest.step.TestSteps;
import com.zte.studio.devops.mcp.model.dto.itest.workitem.FieldDTO;
import com.zte.studio.devops.mcp.model.dto.itest.workitem.FieldUsageDefVO;
import com.zte.studio.devops.mcp.model.dto.itest.workitem.WorkItemTypeDef;
import com.zte.studio.devops.mcp.model.dto.itest.workitem.WorkItemTypeDefVO;
import io.micrometer.common.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class TestManageService {

    private static final String TESTCASE_ROOT_KEY = "TestCase";

    private static final String TEST_PLAN_ROOT_KEY = "TestPlan";

    private static final String TEST_RECORD_ROOT_KEY = "TestRecord";

    private static final String TEST_LINK_RELATION_NAME= "TestedBy";

    @Autowired
    private TestReqDefaultProperties defaultProperties;

    @Autowired
    private TestUrlProperties testUrlProperties;

    private Map<String, String> getRequestHeaders() {
        Map<String, String> httpHeaders = new HashMap<>();
        httpHeaders.put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        httpHeaders.put("X-Tenant-Id", RequestContextUtils.getTenantId());
        httpHeaders.put("X-Emp-No", RequestContextUtils.getAccountId());
        httpHeaders.put("X-Auth-Value", RequestContextUtils.getToken());
        httpHeaders.put("X-Workspace-Id", getWorkspaceKey());
        return httpHeaders;
    }

    private String getWorkspaceKey(){
        String workspaceKey = RequestContextUtils.getWorkspace();
        workspaceKey = DefaultValueUtils.ifNullOrBlank(workspaceKey,defaultProperties.getWorkspace());
        return workspaceKey;
    }

    @Tool(description = "根据工作区获取测试用例必填字段信息")
    public String getMandatoryFieldsForTestCaseByWorkspace(){
        String workspaceKey = getWorkspaceKey();
        String workItemKey = getWorkItemTypeKey(workspaceKey,TESTCASE_ROOT_KEY);
        if(StringUtils.isBlank(workItemKey)){
            return "query workItemTypeKey fail";
        }
        String modeRequestUrl = String.format(testUrlProperties.getQueryWorkItemModelUrl(),workspaceKey,workItemKey);
        Result<WorkItemTypeDefVO> modeResponseEntity = RestUtils.get(modeRequestUrl,getRequestHeaders(),new TypeReference<Result<WorkItemTypeDefVO>>() {});
        if(modeResponseEntity == null || modeResponseEntity.getCode()==null ||
                modeResponseEntity.getCode().getCode()==null || modeResponseEntity.getBo() == null){
            return "query request fail";
        }
        String modeCode = modeResponseEntity.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(modeCode)){
            return "query fail, msg:"+modeResponseEntity.getCode().getMsg();
        }
        List<String> requiredFields = new ArrayList<>();
        WorkItemTypeDefVO workItemType = modeResponseEntity.getBo();
        if(CollectionUtils.isEmpty(workItemType.getFields())){
            return "WorkItem model has no field information";
        }
        for (FieldUsageDefVO field: workItemType.getFields()){
            if (field.getRequired()){
                String nameZh =field.getNameZh();
                requiredFields.add(nameZh);
            }
        }
        return String.format("The required information for the  workspace %s use case is: %s。", workspaceKey, String.join(",", requiredFields));
    }

    @Tool(description = "新建测试用例")
    public String createTestCase(@ToolParam(description = "用例标题") String title,
                                    @ToolParam(description = "是否可自动化",required = false)Boolean shouldAutomated,
                                    @ToolParam(description = "是否已自动化",required = false)Boolean hasAutomated,
                                    @ToolParam(description = "用例等级", required = false)String testCaseLevel,
                                    @ToolParam(description = "用例类型",required = false)String testCaseType,
                                    @ToolParam(description = "所属应用名称")String pdmApplicationName,
                                    @ToolParam(description = "所属应用id")String pdmApplicationId,
                                    @ToolParam(description = "所属产品名称")String belongProductName,
                                    @ToolParam(description = "所属产品id")String belongProductId,
                                    @ToolParam(description = "预置条件",required = false)String presetCondition,
                                    @ToolParam(description = "分层层级",required = false)String testLayer,
                                    @ToolParam(description = "用例库分支id", required = false)String branchId,
                                    @ToolParam(description = "用例库目录id",required = false)String dirId
                                    ) {
        presetCondition = DefaultValueUtils.ifNullOrBlank(presetCondition,defaultProperties.getPresetCondition());
        testLayer = DefaultValueUtils.ifNullOrBlank(testLayer,defaultProperties.getTestLayer());
        branchId = DefaultValueUtils.ifNullOrBlank(branchId,defaultProperties.getBranchId());
        dirId = DefaultValueUtils.ifNullOrBlank(dirId,defaultProperties.getDirId());
        shouldAutomated = DefaultValueUtils.ifNull(shouldAutomated,defaultProperties.getShouldAutomated());
        hasAutomated = DefaultValueUtils.ifNull(hasAutomated,defaultProperties.getHasAutomated());
        testCaseLevel = DefaultValueUtils.ifNullOrBlank(testCaseLevel,defaultProperties.getTestcaseLevel());
        testCaseType = DefaultValueUtils.ifNullOrBlank(testCaseType,defaultProperties.getTestcaseType());
        String workItemTypeKey = getWorkItemTypeKey("",TESTCASE_ROOT_KEY);
        if(StringUtils.isBlank(workItemTypeKey)){
            return "query workspaceTypeKey fail";
        }
        FieldDTO belongProductField = FieldDTO.buildAdvanceField("BelongProduct",belongProductName,belongProductId);
        FieldDTO pdmApplicationField = FieldDTO.buildAdvanceField("ZTE_PDMApplication",pdmApplicationName,pdmApplicationId);
        FieldDTO presetConditionField = FieldDTO.buildStringField("PresetCondition",presetCondition);
        FieldDTO testCaseLevelField = FieldDTO.buildStringField("TestCaseLevel",testCaseLevel);
        FieldDTO testLayerField = FieldDTO.buildStringField("TestLayer",testLayer);
        FieldDTO shouldAutomatedField = FieldDTO.buildBooleanField("ShouldAutomated",shouldAutomated);
        FieldDTO hasAutomatedField = FieldDTO.buildBooleanField("HasAutomated",hasAutomated);
        FieldDTO testCaseTypeField = FieldDTO.buildStringField("TestCaseType",testCaseType);
        FieldDTO titleField = FieldDTO.buildStringField("System_Title",title);
        List<FieldDTO> fieldDTOList =new ArrayList<>();
        fieldDTOList.add(belongProductField);
        fieldDTOList.add(pdmApplicationField);
        fieldDTOList.add(presetConditionField);
        fieldDTOList.add(testCaseLevelField);
        fieldDTOList.add(testLayerField);
        fieldDTOList.add(shouldAutomatedField);
        fieldDTOList.add(hasAutomatedField);
        fieldDTOList.add(testCaseTypeField);
        fieldDTOList.add(titleField);
        CreateTestCaseRequest request = new CreateTestCaseRequest();
        request.setBranchId(branchId);
        request.setFields(fieldDTOList);
        request.setDirId(dirId);
        request.setWorkItemTypeKey(workItemTypeKey);
        Result<CreateWorkItemResponse> responseEntity = RestUtils.post(testUrlProperties.getCreateTestcaseUrl(),getRequestHeaders(),request,
                        new TypeReference<Result<CreateWorkItemResponse>>() {});
        if(responseEntity == null || responseEntity.getCode()==null ||
                responseEntity.getCode().getCode()==null || responseEntity.getBo() == null){
            return "create testcase request fail";
        }
        String code = responseEntity.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return "create testcase fail, msg:"+responseEntity.getCode().getMsg();
        }
        String workItemId = responseEntity.getBo().getWorkItem().getId();
        return "create testcase success, id:" + workItemId;
    }


    @Tool(description = "修改测试用例预置条件")
    public String updateTestCase(@ToolParam(description = "用例Id")String workItemId,
                                 @ToolParam(description = "预置条件")String presetCondition) {
        log.info("update testcase has been called!");
        if (StringUtils.isBlank(workItemId) || !workItemId.contains("-")){
            return "workItemId is wrong!";
        }
        String workspace = workItemId.substring(0, workItemId.lastIndexOf('-'));
        String workItemTypeKey = getWorkItemTypeKey(workspace,TESTCASE_ROOT_KEY);
        if(StringUtils.isBlank(workItemTypeKey)){
            return "query workspaceTypeKey fail";
        }
        FieldDTO field = new FieldDTO();
        field.setKey("PresetCondition");
        field.setValue(presetCondition);
        UpdateWorkitemRequest request = new UpdateWorkitemRequest();
        List<FieldDTO> fields = new ArrayList<>();
        fields.add(field);
        request.setFields(fields);
        request.setWorkItemTypeKey(workItemTypeKey);
        Result response = RestUtils.put(String.format(testUrlProperties.getUpdateWorkItemUrl(),workspace,workItemId),
                getRequestHeaders(),new TypeReference<Result>() {}, JSON.toJSONString(request));
        if(response == null || response.getCode()==null ||
                response.getCode().getCode()==null || response.getBo() == null){
            return "update testcase request fail";
        }
        String code = response.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return "update testcase fail, msg:"+response.getCode().getMsg();
        }else {
            return "update testcase success.";
        }
    }

    @Tool(description = "删除测试用例")
    public String deleteTestCase(@ToolParam(description = "用例id") String workItemId){
        log.info("delete testcase has been called!");
        List<String> workitemList = new ArrayList<>();
        workitemList.add(workItemId);
        String responseString = RestUtils.delete(testUrlProperties.getDeleteWorkItemUrl(),getRequestHeaders(),
                JSON.toJSONString(workitemList));
        Result response = JSON.parseObject(responseString, Result.class);
        if(response == null || response.getCode()==null ||
                response.getCode().getCode()==null || response.getBo() == null){
            return "delete testcase request fail";
        }
        String code = response.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return "delete testcase fail, msg:"+response.getCode().getMsg();
        }else {
            return "delete testcase success.";
        }
    }

    @Tool(description = "根据测试用例id查询用例信息")
    public String queryTestCaseDetail(@ToolParam(description = "用例id") String workItemId){
        if (StringUtils.isBlank(workItemId) || !workItemId.contains("-")){
            return "workItemId is wrong!";
        }
        String workspace = workItemId.substring(0, workItemId.lastIndexOf('-'));
        String workItemTypeKey = getWorkItemTypeKey(workspace,TESTCASE_ROOT_KEY);
        if(StringUtils.isBlank(workItemTypeKey)){
            return "query workspaceTypeKey fail";
        }
        QueryTestCaseRequest queryRequest = new QueryTestCaseRequest();
        queryRequest.setIds(Collections.singletonList(workItemId));
        queryRequest.setWorkItemTypeKeys(Collections.singletonList(workItemTypeKey));
        queryRequest.setSelect(Arrays.asList(new String[]{"System_Title", "PresetCondition","Steps"}));
        Result<List<Map<String,Object>>> response = RestUtils.post(String.format(testUrlProperties.getQueryWorkItemDetailUrl(),workspace),
                        getRequestHeaders(),queryRequest, new TypeReference<Result<List<Map<String,Object>>>>() {});
        if(response == null || response.getCode()==null ||
                response.getCode().getCode()==null || response.getBo() == null){
            return "query testcase request fail";
        }
        String code = response.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return "query testcase fail,msg:"+response.getCode().getMsg();
        }
        List<Map<String,Object>> fieldList = response.getBo();
        if(CollectionUtils.isEmpty(fieldList)){
            return String.format("testcase is not exist, id: %s",workItemId);
        }
        return JSON.toJSONString(fieldList);
//        List<String> results = new ArrayList<>();
//        for (Map<String, Object> field : fieldList) {
//            String title = field.get("System_Title").toString();
//            String presetCondition = Objects.isNull(field.get("PresetCondition"))?"":field.get("PresetCondition").toString();
//            String systemId = field.get("id").toString();
//            String steps = getTestcaseSteps(field.get("Steps"));
//            steps = DefaultValueUtils.ifNullOrBlank(steps,defaultProperties.getPresetCondition());
//            presetCondition = DefaultValueUtils.ifNullOrBlank(presetCondition,defaultProperties.getPresetCondition());
//            String result = String.format("TestCase %s: Title is %s、presetCondition is %s、 Steps is %s",systemId,title,presetCondition,steps);
//            results.add(result);
//        }
//        String queryResult = String.join(" \n",results);
//        return String.format("query testcase success detail: %s",queryResult);
    }

    @Tool(description = "根据需求id查询关联的用例")
    public String queryTestCaseByRequirementId(@ToolParam(description = "需求id") String requirementId){
        QueryRelatedRequest request=new QueryRelatedRequest();
        request.setVisible(Boolean.TRUE);
        request.setWorkItemIds(Collections.singletonList(requirementId));
        request.setLinkRelationName(TEST_LINK_RELATION_NAME);
        Result<QueryRelationResponse> response = RestUtils.post(testUrlProperties.getQueryRelateWorkItemUrl(),
                getRequestHeaders(),request,new TypeReference<Result<QueryRelationResponse>>() {});
        if(response == null || response.getCode()==null ||
                response.getCode().getCode()==null || response.getBo() == null){
            return "query associated testcase request fail";
        }
        String code = response.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return "query associated testcase fail,msg :"+response.getCode().getMsg();
        }
        List<RelateItem> relateItems = response.getBo().getItems();
        if (CollectionUtils.isEmpty(relateItems)){
            return "No associated test cases.";
        }
        List<String> workItemIdList = relateItems.stream().map(RelateItem::getRelatedWorkItemId).collect(Collectors.toList());
        return String.format("associated testcases is [%s]",String.join(",",workItemIdList));
    }

    @Tool(description = "新建测试计划")
    public String createTestPlan(@ToolParam(description = "标题") String title,
                                 @ToolParam(description = "团队名称",required = false)String teamName,
                                 @ToolParam(description = "团队id",required = false)String teamId,
                                 @ToolParam(description = "更新类型",required = false)String updateType,
                                 @ToolParam(description = "执行环境",required = false)List<String> testEnvironment,
                                 @ToolParam(description = "所属发布版本名称")String belongReleaseVersionName,
                                 @ToolParam(description = "所属发布版本id")String belongReleaseVersionId) {
        teamName = DefaultValueUtils.ifNullOrBlank(teamName,defaultProperties.getTeamName());
        teamId = DefaultValueUtils.ifNullOrBlank(teamId,defaultProperties.getTeamId());
        updateType = DefaultValueUtils.ifNullOrBlank(updateType,defaultProperties.getUpdateType());
        testEnvironment = CollectionUtils.isEmpty(testEnvironment) ? Collections.singletonList(defaultProperties.getTestEnvironment()) : testEnvironment;
        String workItemTypeKey = getWorkItemTypeKey("",TEST_PLAN_ROOT_KEY);
        if(StringUtils.isBlank(workItemTypeKey)){
            return "query workspaceTypeKey fail";
        }
        FieldDTO versionField = FieldDTO.buildAdvanceField("BelongReleaseVersion",belongReleaseVersionName,belongReleaseVersionId);
        FieldDTO teamField = FieldDTO.buildAdvanceField("Team",teamName,teamId);
        FieldDTO updateTypeField = FieldDTO.buildStringField("UpdateType",updateType);
        FieldDTO testEnvironmentField = FieldDTO.buildField("TestEnvironment",testEnvironment);
        FieldDTO titleField = FieldDTO.buildStringField("System_Title",title);
        List<FieldDTO> fieldDTOList =new ArrayList<>();
        fieldDTOList.add(versionField);
        fieldDTOList.add(teamField);
        fieldDTOList.add(updateTypeField);
        fieldDTOList.add(testEnvironmentField);
        fieldDTOList.add(titleField);
        CreateTestPlanRequest request = new CreateTestPlanRequest();
        request.setFields(fieldDTOList);
        request.setWorkItemTypeKey(workItemTypeKey);
        Result<CreateWorkItemResponse> responseEntity = RestUtils.post(testUrlProperties.getCreateTestPlanUrl(),
                getRequestHeaders(),request,new TypeReference<Result<CreateWorkItemResponse>>() {});
        if(responseEntity == null || responseEntity.getCode()==null ||
                responseEntity.getCode().getCode()==null || responseEntity.getBo() == null){
            return "create test plan request fail";
        }
        String code = responseEntity.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return "create test plan fail, msg:"+responseEntity.getCode().getMsg();
        }
        String workItemId = responseEntity.getBo().getWorkItem().getId();
        return "create test plan success，id:" + workItemId;
    }

    @Tool(description = "查询当前团队下的测试计划列表")
    public String queryTestPlanList(){
        String teamId = DefaultValueUtils.ifNullOrBlank(RequestContextUtils.getTeamId(),defaultProperties.getTeamId());
        Result<List<TestPlanItem>> response = RestUtils.get(String.format(testUrlProperties.getQueryTestPlanListUrl(),teamId),
                getRequestHeaders(),new TypeReference<Result<List<TestPlanItem>>>() {});
        if(response == null || response.getCode()==null ||
                response.getCode().getCode()==null || response.getBo() == null){
            return "query test plan request fail";
        }
        String code = response.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return "query test plan fail, msg:"+response.getCode().getMsg();
        }
        List<TestPlanItem> planItems = response.getBo();
        if (CollectionUtils.isEmpty(planItems)){
            return "No test plan.";
        }
//        List<String> planList = new ArrayList<>();
//        for (TestPlanItem item : planItems) {
//            String planDetail = String.format("test plan %s ,title is %s",item.getId(),item.getTitle());
//            planList.add(planDetail);
//        }
//        return String.format("Test plan list is ：%s",String.join("\n",planList));
        return JSON.toJSONString(planItems);
    }

    @Tool(description = "根据需求id创建需求套件")
    public String createRequireSuit(@ToolParam(description = "需求id") List<String> requirementIds,
                                    @ToolParam(description = "套件名称",required = false)String suitName,
                                    @ToolParam(description = "测试计划id")String testPlanId){
        suitName = DefaultValueUtils.ifNullOrBlank(suitName,defaultProperties.getSuitName());
        CreateRequirementSuitRequest request = new CreateRequirementSuitRequest();
        request.setAutoCreateParentSuit(Boolean.TRUE);
        request.setRequirementIds(requirementIds);
        request.setTestplanId(testPlanId);
        request.setParentSuitPath(String.format("/%s",suitName));
        Result response = RestUtils.post(testUrlProperties.getCreateRequireSuitUrl(),
                getRequestHeaders(),request, new TypeReference<Result>(){});
        if(response == null || response.getCode()==null ||
                response.getCode().getCode()==null || response.getBo() == null){
            return "create requirement suit request fail";
        }
        String code = response.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return "create requirement suit fail ,msg :"+response.getCode().getMsg();
        }
        return JSONObject.toJSONString(response);
    }

    @Tool(description = "根据需求id查询测试记录")
    public String queryRequirementSuitRecords(@ToolParam(description = "需求id")String requirementId,
                                              @ToolParam(description = "分页页码",required = false)Integer pageNo,
                                              @ToolParam(description = "分页大小",required = false)Integer pageSize){
        String workItemTypeKey = getWorkItemTypeKey("",TEST_RECORD_ROOT_KEY);
        if(StringUtils.isBlank(workItemTypeKey)){
            return "查询工作区用例模型key出错";
        }
        RequireSuitQueryRequest request = new RequireSuitQueryRequest();
        request.setRequirementId(requirementId);
        request.setTestrecordTemplate(workItemTypeKey);
        QueryItem queryItem = new QueryItem();
        queryItem.setPageNo(pageNo);
        queryItem.setPageSize(pageSize);
        SelectItem selectItem=new SelectItem();
        selectItem.setKey("TestCenterResult");
        queryItem.setSelectItems(Collections.singletonList(selectItem));
        request.setQueryItem(queryItem);
        Result<RequirementSuitQueryResponse> response = RestUtils.post(testUrlProperties.getQueryRequireRecordUrl(),
                        getRequestHeaders(),request,new TypeReference<Result<RequirementSuitQueryResponse>>(){});
        if(response == null || response.getCode()==null ||
                response.getCode().getCode()==null || response.getBo() == null){
            return "query testRecord request fail";
        }
        String code = response.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return "query testRecord fail，msg:"+response.getCode().getMsg();
        }
        RequirementSuitQueryResult queryResult=response.getBo().getResult();
        List<TestResultItem> resultItems = queryResult.getItems();
        if (CollectionUtils.isEmpty(resultItems)){
            return  "no records";
        }
        return  JSON.toJSONString(resultItems);
    }

    @Tool(description = "修改测试记录执行结果")
    public String updateTestRecordResult(@ToolParam(description = "测试记录id")String testRecordId,
                                         @ToolParam(description = "执行结果")String result,
                                         @ToolParam(description = "测试计划id")String planId,
                                         @ToolParam(description = "测试套件id")String suitId,
                                         @ToolParam(description = "执行人姓名")String executorName){
        UpdateRecordResultRequest recordResultRequest= new UpdateRecordResultRequest();
        recordResultRequest.setResult(result);
        recordResultRequest.setTestplanId(planId);
        recordResultRequest.setIsCollect(Boolean.FALSE);
        recordResultRequest.setCheckAll(Boolean.FALSE);
        recordResultRequest.setExecutorName(executorName);
        recordResultRequest.setTestrecordIds(Collections.singletonList(testRecordId));
        recordResultRequest.setTestsuitId(suitId);
        TypeReference<Result<List<WorkItemTypeDef>>> paramTypeRef = new TypeReference<Result<List<WorkItemTypeDef>>>() {
        };
        Result response = RestUtils.post(testUrlProperties.getUpdateRecordResultUrl(),
                        getRequestHeaders(),recordResultRequest,new TypeReference<Result>(){});
        if(response == null || response.getCode()==null ||
                response.getCode().getCode()==null || response.getBo() == null){
            return "update execute result request fail";
        }
        String code = response.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return "update execute result fail, msg:"+response.getCode().getMsg();
        }else {
            return JSONObject.toJSONString(response);
        }
    }

    /**
     * 解析测试步骤信息
     * @param stepField 测试步骤字段
     * @return 测试步骤信息
     */
    private String getTestcaseSteps(Object stepField){
        String steps = "";
        if (Objects.isNull(stepField)){
            return steps;
        }
        TestSteps testSteps = JSONObject.parseObject(stepField.toString(), TestSteps.class);
        List<TestStep> steplist = testSteps.getTable();
        if(CollectionUtils.isEmpty(steplist)){
            return steps;
        }
        List<String> stepResultList = new ArrayList<>();
        for(TestStep step:steplist){
            String result = String.format("step %d: operation %s ,expect %s",step.getIndex()+1,step.getOperation(),step.getExpect());
            stepResultList.add(result);
        }
        return String.join(" ; ",stepResultList);
    }

    /**
     * 获取工作区的工作项模型key
     * @param workspace 不传则取消息头信息
     * @param workItemRootKey 工作项类型
     * @return 工作项模型key
     */
    private String getWorkItemTypeKey(String workspace,String workItemRootKey){
        String workspaceKey = StringUtils.isBlank(workspace)?getWorkspaceKey():workspace;
        String workItemKey = "";
        TypeReference<Result<List<WorkItemTypeDef>>> paramTypeRef = new TypeReference<Result<List<WorkItemTypeDef>>>() {
        };
        String requestUrl = String.format(testUrlProperties.getQueryWorkItemTypesUrl(),workspaceKey,workItemRootKey);
        Result<List<WorkItemTypeDef>> responseEntity = RestUtils.get(requestUrl, getRequestHeaders(),paramTypeRef);
        if (responseEntity == null || responseEntity.getCode() == null || responseEntity.getCode().getCode() == null) {
            return workItemKey;
        }
        String code = responseEntity.getCode().getCode();
        if (!CommonConstants.SUCCESS_CODE.equals(code)){
            return workItemKey;
        }
        List<WorkItemTypeDef> workItemTypeDefs = responseEntity.getBo();
        for(WorkItemTypeDef workItemTypeDef:workItemTypeDefs) {
            if (workItemTypeDef.getValid() ){
                workItemKey = workItemTypeDef.getKey();
            }
        }
        return workItemKey;
    }
}
