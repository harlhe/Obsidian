/*
* Copyright 2024 - 2024 the original author or authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* https://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.zte.studio.devops.mcp.core.service.ipipeline;

import com.alibaba.fastjson.TypeReference;
import com.zte.itp.msa.core.model.ServiceData;
import com.zte.studio.devops.mcp.common.utils.RequestContextUtils;
import com.zte.studio.devops.mcp.common.utils.RestUtils;
import com.zte.studio.devops.mcp.core.service.common.InoneApiService;
import com.zte.studio.devops.mcp.model.McpHeaderEnum;
import com.zte.studio.devops.mcp.model.dto.common.PersonGeneralInfoResponseDTO;
import com.zte.studio.devops.mcp.model.dto.ipipeline.*;
import com.zte.studio.devops.mcp.model.enumeration.ipipeline.OrganizationTypeEnum;
import com.zte.studio.devops.mcp.model.enumeration.ipipeline.ProcessStateEnum;
import com.zte.studio.devops.mcp.model.enumeration.ipipeline.RunningResultEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PipelineService {

	private static final String MANUAL_TRIGGER_MODE = "manual";
	private static final String PIPELINE_BUILD_URL = "PIPELINE_BUILD_URL";
	private static final String START_TIME_SORT_ITEM_KEY = "startTime";
	private static final int PAGE_NUM = 1;
	private static final int PAGE_SIZE = 20;

	@Autowired
	private InoneApiService inoneApiService;

	@Value("${ipipeline.url}")
	private String pipelineUrl;

	private Map<String, String> getRequestHeaders() {
		Map<String, String> httpHeaders = new HashMap<>();
		httpHeaders.put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
		httpHeaders.put(McpHeaderEnum.X_TENANT_ID.getKey(), RequestContextUtils.getTenantId());
		httpHeaders.put(McpHeaderEnum.X_EMP_NO.getKey(), RequestContextUtils.getAccountId());
		httpHeaders.put(McpHeaderEnum.X_AUTH_VALUE.getKey(), RequestContextUtils.getToken());
		return httpHeaders;
	}

	@Tool(description = "通过流水线名称触发流水线")
	public String triggerWithPipelineName(@ToolParam(description = "流水线名称") String pipelineName,
										  @ToolParam(description = "流水线参数", required = false) Map<String, String> triggerParams) {
		PipelineListDTO pipelineListDTO = queryByPipelineName(pipelineName);
		return triggerPipeline(pipelineListDTO.getPipelineCode(), triggerParams);
	}


	private String triggerPipeline(String pipelineCode, Map<String, String> triggerParams) {
		if (CollectionUtils.isEmpty(triggerParams)) {
			triggerParams = new HashMap<>();
		}
		String pipelineTriggerUrl = pipelineUrl + "/flow/build";
		String empNo = RequestContextUtils.getAccountId();
		ApiBuildWithFlowInitialIdDTO apiBuildWithFlowInitialIdDTO = new ApiBuildWithFlowInitialIdDTO();
		apiBuildWithFlowInitialIdDTO.setFlowInitialId(pipelineCode);
		apiBuildWithFlowInitialIdDTO.setRunningParameter(triggerParams);
		apiBuildWithFlowInitialIdDTO.setTriggerMode(MANUAL_TRIGGER_MODE);
		Map<String, PersonGeneralInfoResponseDTO> personGeneralInfoResponseDTOMap = inoneApiService.getPersonGeneralInfo(Collections.singletonList(empNo));
		PersonGeneralInfoResponseDTO personGeneralInfo = personGeneralInfoResponseDTOMap.get(empNo);
		UserInfo userInfo = new UserInfo();
		userInfo.setUserId(empNo);
		userInfo.setStrNameNoZh(personGeneralInfo.getEmpName() + empNo);
		userInfo.setStrNameNoEn(personGeneralInfo.getEmpNameEN() + empNo);
		userInfo.setNameZh(personGeneralInfo.getEmpName());
		userInfo.setNameEn(personGeneralInfo.getEmpNameEN());
		apiBuildWithFlowInitialIdDTO.setOperationUser(userInfo);
		ResponseData<BuildResponseDTO> responseData = RestUtils.post(pipelineTriggerUrl, getRequestHeaders(),
				apiBuildWithFlowInitialIdDTO, new TypeReference<>() {});
		if (Objects.isNull(responseData) || Objects.isNull(responseData.getData())) {
			log.warn("Trigger pipeline failed: {}", responseData);
			throw new RuntimeException("Trigger pipeline failed!");
		}
		Long buildNumber = responseData.getData().getBuildNumber();
		String latestBuildUrl = responseData.getData().getPipelineUrl();
		String buildUrlPrefix = latestBuildUrl.split("\\?")[0];
		String buildUrlSuffix = latestBuildUrl.split("\\?")[1];
		String buildUrl = buildUrlPrefix.replace("latest", "histories") +
				"?buildNumber=" + buildNumber + "&" + buildUrlSuffix;
		return "Pipeline trigger success: " + buildUrl;
	}

//	@Tool(description = "通过流水线编码触发流水线")
//	public String triggerWithPipelineCode(@ToolParam(description = "流水线编码") String pipelineCode,
//										  @ToolParam(description = "流水线参数", required = false) Map<String, String> triggerParams) {
//		return triggerPipeline(pipelineCode, triggerParams);
//	}

	private PipelineListDTO queryByPipelineName(String pipelineName) {
		PipelineListDTO pipelineListDTO = queryListByPipelineName(pipelineName).get(0);
		if (Objects.isNull(pipelineListDTO) || !pipelineName.equalsIgnoreCase(pipelineListDTO.getPipelineName())) {
			throw new RuntimeException("No pipeline with the same name was found");
		}
		return pipelineListDTO;
	}

	private List<PipelineListDTO> queryListByPipelineName(String pipelineName) {
		if (!StringUtils.hasText(pipelineName)) {
			throw new RuntimeException("Pipeline name cannot be empty");
		}
		PipelineConfigQueryRequestDTO pipelineConfigQueryRequestDTO = new PipelineConfigQueryRequestDTO();
		pipelineConfigQueryRequestDTO.setPipelineName(pipelineName);
		pipelineConfigQueryRequestDTO.setWorkspace(RequestContextUtils.getWorkspace());
		if (StringUtils.hasText(RequestContextUtils.getTeamId())) {
			pipelineConfigQueryRequestDTO.setOrganizationId(RequestContextUtils.getTeamId());
			pipelineConfigQueryRequestDTO.setOrganizationType(OrganizationTypeEnum.TEAM.getCode());
		} else if (StringUtils.hasText(RequestContextUtils.getAreaId())) {
			pipelineConfigQueryRequestDTO.setOrganizationId(RequestContextUtils.getAreaId());
			pipelineConfigQueryRequestDTO.setOrganizationType(OrganizationTypeEnum.AREA.getCode());
		} else {
			throw new RuntimeException("Team and area cannot be empty at the same time");
		}
		pipelineConfigQueryRequestDTO.setCurrentUserId(RequestContextUtils.getAccountId());
		pipelineConfigQueryRequestDTO.setCurrentPage(PAGE_NUM);
		pipelineConfigQueryRequestDTO.setPageSize(PAGE_SIZE);
		return queryListByPipelineConfigQueryRequestDTO(pipelineConfigQueryRequestDTO);
	}

	private List<PipelineListDTO> queryListByPipelineConfigQueryRequestDTO(PipelineConfigQueryRequestDTO pipelineConfigQueryRequestDTO) {
		String pipelineListUrl = pipelineUrl + "/flow/list";
		ServiceData<PageResponseDTO<PipelineListDTO>> serviceData = RestUtils.post(pipelineListUrl,
				getRequestHeaders(), pipelineConfigQueryRequestDTO, new TypeReference<>() {});
		if (Objects.isNull(serviceData) || Objects.isNull(serviceData.getBo())
				|| CollectionUtils.isEmpty(serviceData.getBo().getData())) {
			throw new RuntimeException("No corresponding pipeline found");
		}
		return serviceData.getBo().getData();
	}

	@Tool(description = "获取流水线执行详情")
	public String getBuildDetail(@ToolParam(description = "流水线名称") String pipelineName,
								 @ToolParam(description = "构建号", required = false) Long buildNumber) throws Exception {
		Thread thread = Thread.currentThread();
		PipelineListDTO pipelineListDTO = queryByPipelineName(pipelineName);
		PipelineBuildDTO pipelineBuildDTO = getPipelineBuildHistory(pipelineListDTO.getPipelineCode(), buildNumber);
		RunningResultEnum runningResultEnum = RunningResultEnum.getEnumByCode(pipelineBuildDTO.getRunningResult());
		ProcessStateEnum processStateEnum = ProcessStateEnum.getEnumByCode(pipelineBuildDTO.getProcessState());
		Map<String, String> systemVariable = pipelineBuildDTO.getSystemVariable();
		String pipelineBuildUrl = systemVariable.get(PIPELINE_BUILD_URL);
		return "Get pipeline build detail success! Pipeline build detail as follow:\n" +
				"process state: " + processStateEnum.getState() + "\n" +
				"running result: " + runningResultEnum.getState() + "\n" +
				"build url: " + pipelineBuildUrl;
	}

	private PipelineBuildDTO getPipelineBuildHistory(String pipelineCode, Long buildNumber) {
		String pipelineBuildHistoryUrl;
		if (Objects.isNull(buildNumber) || buildNumber <=0) {
			pipelineBuildHistoryUrl = pipelineUrl + "/flow/pipelineCode/" + pipelineCode + "/history/latest";
		} else {
			pipelineBuildHistoryUrl = pipelineUrl + "/flow/pipelineCode/" + pipelineCode + "/history/" + buildNumber;
		}
		ServiceData<PipelineBuildDTO> serviceData = RestUtils.get(pipelineBuildHistoryUrl, getRequestHeaders(), new TypeReference<>() {});
		if (Objects.isNull(serviceData) || Objects.isNull(serviceData.getBo())) {
			throw new RuntimeException("Cannot find pipeline build history!");
		}
		return serviceData.getBo();
	}

	@Tool(description = "终止流水线")
	public String stopPipelineName(@ToolParam(description = "流水线名称") String pipelineName,
								   @ToolParam(description = "构建号", required = false) Long buildNumber) {
		PipelineListDTO pipelineListDTO = queryByPipelineName(pipelineName);
		PipelineBuildDTO pipelineBuildDTO = getPipelineBuildHistory(pipelineListDTO.getPipelineCode(), buildNumber);
		String pipelineStopUrl = pipelineUrl + "/flow/pipelineBuildId/" + pipelineBuildDTO.getPipelineBuildId() + "/stop";
		ServiceData<String> stringServiceData = RestUtils.post(pipelineStopUrl, getRequestHeaders(), new HashMap<>(), new TypeReference<>() {});
		if (Objects.isNull(stringServiceData) || !StringUtils.hasText(stringServiceData.getBo())) {
			log.warn("Stop pipeline failed: {}", stringServiceData);
			throw new RuntimeException("Stop pipeline failed!");
		}
		return stringServiceData.getBo();
	}

	@Tool(description = "流水线名称模糊查询")
	public List<String> getPipelineList(@ToolParam(description = "流水线名称") String pipelineName) {
		List<PipelineListDTO> pipelineListDTOS = queryListByPipelineName(pipelineName);
		return pipelineListDTOS.stream().map(PipelineListDTO::getPipelineName).collect(Collectors.toList());
	}


	@Tool(description = "查询我收藏的流水线名称")
	public List<String> getMyFavoritePipelineList() {
		String pipelineFavoriteUrl = pipelineUrl + "/flow/favorite/all";
		PipelineConfigQueryRequestDTO queryRequestDTO = new PipelineConfigQueryRequestDTO();
		queryRequestDTO.setCurrentPage(PAGE_NUM);
		queryRequestDTO.setPageSize(PAGE_SIZE);
		queryRequestDTO.setWorkspace(RequestContextUtils.getWorkspace());
		queryRequestDTO.setCurrentUserId(RequestContextUtils.getAccountId());
		queryRequestDTO.setPipelineName("");
		ServiceData<PageResponseDTO<PipelineListDTO>> serviceData = RestUtils.post(pipelineFavoriteUrl,
				getRequestHeaders(), queryRequestDTO, new TypeReference<>() {
				});
		if (Objects.isNull(serviceData) || Objects.isNull(serviceData.getBo())
				|| CollectionUtils.isEmpty(serviceData.getBo().getData())) {
			throw new RuntimeException("No corresponding pipeline found");
		}
		List<PipelineListDTO> pipelineListDTOS = serviceData.getBo().getData();
		return pipelineListDTOS.stream().map(PipelineListDTO::getPipelineName).collect(Collectors.toList());
	}

	@Tool(description = "查询我最近执行的流水线名称")
	public List<String> getMyRecentExecutePipelineList() {
		PipelineConfigQueryRequestDTO queryRequestDTO = new PipelineConfigQueryRequestDTO();
		queryRequestDTO.setCurrentPage(PAGE_NUM);
		queryRequestDTO.setPageSize(PAGE_SIZE);
		queryRequestDTO.setWorkspace(RequestContextUtils.getWorkspace());
		queryRequestDTO.setCurrentUserId(RequestContextUtils.getAccountId());
		queryRequestDTO.setPipelineName("");
		if (StringUtils.hasText(RequestContextUtils.getTeamId())) {
			queryRequestDTO.setOrganizationId(RequestContextUtils.getTeamId());
			queryRequestDTO.setOrganizationType(OrganizationTypeEnum.TEAM.getCode());
		} else if (StringUtils.hasText(RequestContextUtils.getAreaId())) {
			queryRequestDTO.setOrganizationId(RequestContextUtils.getAreaId());
			queryRequestDTO.setOrganizationType(OrganizationTypeEnum.AREA.getCode());
		} else {
			throw new RuntimeException("Team and area cannot be empty at the same time");
		}
		queryRequestDTO.setOperationUser(Collections.singletonList(RequestContextUtils.getAccountId()));
		SortItem sortItem = new SortItem();
		sortItem.setAscending(true);
		sortItem.setKey(START_TIME_SORT_ITEM_KEY);
		queryRequestDTO.setSortItems(Collections.singletonList(sortItem));
		List<PipelineListDTO> pipelineListDTOS = queryListByPipelineConfigQueryRequestDTO(queryRequestDTO);
		return pipelineListDTOS.stream().map(PipelineListDTO::getPipelineName).collect(Collectors.toList());
	}
}