package com.zte.studio.devops.mcp.core.service.iartifact;

import com.alibaba.fastjson.TypeReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.zte.studio.devops.mcp.common.utils.RequestContextUtils;
import com.zte.studio.devops.mcp.common.utils.RestUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class ArtifactService {

    private static final String ARTIFACTORY_SERVER = "https://%s/artifactory";

    private Map<String, String> getRequestHeaders() {
        Map<String, String> httpHeaders = new HashMap<>();
        httpHeaders.put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        httpHeaders.put("Authorization",
                "Basic " + Base64.getEncoder().encodeToString((RequestContextUtils.getJfrogAccount() + ":" + RequestContextUtils.getJfrogApiKey()).getBytes()));
        return httpHeaders;
    }


    @JsonIgnoreProperties(ignoreUnknown = true)
    public record FileList(@JsonProperty("uri") String uri, @JsonProperty("children") List<Child> children) {
        @JsonIgnoreProperties(ignoreUnknown = true)
        public record Child(@JsonProperty("uri") String uri, @JsonProperty("folder") boolean folder) {}
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record FileMetadata(
            @JsonProperty("repo") String repo,
            @JsonProperty("path") String path,
            @JsonProperty("downloadUri") String downloadUri,
            @JsonProperty("checksums") Map<String, String> checksums,
            @JsonProperty("size") String size
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CopyOperationResult(
            @JsonProperty("messages") List<Message> messages
    ) {
        @JsonIgnoreProperties(ignoreUnknown = true)
        public record Message(
                @JsonProperty("level") String level,
                @JsonProperty("message") String message
        ) {}
    }

    @Tool(description = "列出某目录下的制品")
    public String listArtifacts(@ToolParam(description = "仓库名") String repo,
                                @ToolParam(description = "目录") String path) {
        String listArtifactsUrl = String.format(ARTIFACTORY_SERVER, RequestContextUtils.getJfrogServer()) + String.format("/api/storage/%s/%s", repo, path);
        String fileList = RestUtils.get(listArtifactsUrl, getRequestHeaders(), new TypeReference<>() {});
        if (Objects.isNull(fileList)) {
            log.warn("List Artifacts failed: {}", fileList);
            throw new RuntimeException("List Artifacts failed!");
        }
        return fileList;
    }

    @Tool(description = "获取制品元数据")
    public String getMetadata(@ToolParam(description = "仓库名") String repo,
                              @ToolParam(description = "制品路径") String path) {
        String getMetadataUrl = String.format(ARTIFACTORY_SERVER, RequestContextUtils.getJfrogServer()) + String.format("/api/storage/%s/%s", repo, path);
        String fileMetadata = RestUtils.get(getMetadataUrl, getRequestHeaders(), new TypeReference<>() {});
        if (Objects.isNull(fileMetadata)) {
            log.warn("Get Metadata failed: {}", fileMetadata);
            throw new RuntimeException("Get Metadata failed!");
        }
        return fileMetadata;
    }

    @Tool(description = "复制文件或者目录")
    public String copyItem(@ToolParam(description = "仓库名") String srcRepoKey,
                           @ToolParam(description = "制品路径") String srcFilePath,
                           @ToolParam(description = "制品路径") String targetRepoKey,
                           @ToolParam(description = "制品路径") String targetFilePath) {
        String copyItemUrl = String.format(ARTIFACTORY_SERVER, RequestContextUtils.getJfrogServer()) + String.format("/api/copy/%s/%s?to=/%s/%s", srcRepoKey, srcFilePath, targetRepoKey, targetFilePath);
        String stringServiceData = RestUtils.post(copyItemUrl, getRequestHeaders(), new HashMap<>(), new TypeReference<>() {});
        if (Objects.isNull(stringServiceData)) {
            log.warn("Copy Item failed: {}", stringServiceData);
            throw new RuntimeException("Copy Item failed!");
        }
        return stringServiceData;
    }

}

