package com.zte.studio.devops.mcp.core.service.cca;

import com.zte.studio.devops.mcp.model.dto.cca.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
public class CCAService {

    private static final String CCA_URL_REGEX = "https://([^/.]+)\\.zte\\.com\\.cn/workbench/project/([^/]+)/task/([^/]+)";
    @Autowired
    private CCAClient ccaClient;

    @Tool(description = "根据CCA扫描任务链接URL，获取CCA项目短id和CCA任务短id")
    public CCATaskQueryDTO getCCATaskInfoByUrl(
            @ToolParam(description = "CCA扫描任务地址") String ccaTaskUrl
    ) {
        if (StringUtils.isBlank(ccaTaskUrl)) {
            return null;
        }
        Pattern pattern = Pattern.compile(CCA_URL_REGEX);
        Matcher matcher = pattern.matcher(ccaTaskUrl);
        if (!matcher.find()) {
            return null;
        }
        String ccaServer = matcher.group(1);
        String projectShortId = matcher.group(2);
        String taskShortId = matcher.group(3);
        if (StringUtils.isBlank(ccaServer)
                || StringUtils.isBlank(projectShortId)
                || StringUtils.isBlank(taskShortId)) {
            return null;
        }
        CCATaskQueryDTO dto = new CCATaskQueryDTO();
        dto.setCcaServer(ccaServer);
        dto.setProjectShortId(projectShortId);
        dto.setTaskShortId(taskShortId);
        return dto;
    }

    @Tool(description = "根据CCA项目名称和任务名称，查询获取CCA项目短id和CCA任务短id")
    public CCATaskQueryDTO getCCATaskInfoByName(
            @ToolParam(description = "CCA服务地址", required = false) String ccaServer,
            @ToolParam(description = "CCA项目名称") String projectName,
            @ToolParam(description = "CCA任务名称") String taskName
    ) {
        CCAHttpResult<CCAProjectTaskDTO> result = ccaClient.getProjectTaskByName(ccaServer, projectName, taskName);
        if (null == result || null == result.getData()) {
            return null;
        }
        CCATaskQueryDTO ccaTaskQueryDTO = new CCATaskQueryDTO();
        ccaTaskQueryDTO.setCcaServer(ccaServer);
        ccaTaskQueryDTO.setProjectShortId(result.getData().getProjectShortId());
        ccaTaskQueryDTO.setTaskShortId(result.getData().getTaskShortId());
        return ccaTaskQueryDTO;
    }

    @Tool(description = "根据CCA项目短id任务短id，查询获取CCA扫描任务最近的的执行结果")
    public CCATaskExecInfo getTaskLastExecInfo(
            @ToolParam(description = "CCA服务地址", required = false) String ccaServer,
            @ToolParam(description = "CCA项目短id,projectShortId") String projectShortId,
            @ToolParam(description = "CCA任务短id,taskShortId") String taskShortId
    ) {
        CCAHttpResult<CCATaskExecListDTO>  result= ccaClient.getTaskLastExecInfo(ccaServer, projectShortId, taskShortId);
        CCATaskExecListDTO listDTO = result.getData();
        if (null == listDTO || CollectionUtils.isEmpty(listDTO.getData())) {
            return null;
        }
        return listDTO.getData().get(0);
    }

//    @Tool(description = "根据CCA项目短id:projectShortId和任务id:taskId，查询CCA扫描任务最近执行成功的执行信息,该接口只取最近成功的执行记录")
//    public CCAHttpResult<CCATaskExecInfo> getTaskLastSuccessExecInfo(
//            @ToolParam(description = "CCA服务地址", required = false) String ccaServer,
//            @ToolParam(description = "CCA项目短id,projectShortId") String projectShortId,
//            @ToolParam(description = "CCA任务id,taskId") String taskId
//    ) {
//        return ccaClient.getTaskLastSuccessExecInfo(ccaServer, projectShortId, taskId);
//    }

    @Tool(description = "根据CCA项目短id和任务短id，触发CCA扫描任务执行")
    public CCAHttpResult<CCATaskStartRespDTO> startTask(
            @ToolParam(description = "CCA服务地址", required = false) String ccaServer,
            @ToolParam(description = "CCA项目短id,projectShortId") String projectShortId,
            @ToolParam(description = "CCA任务短id,taskShortId") String taskShortId
    ) {
        return ccaClient.startTask(ccaServer, projectShortId, taskShortId);
    }


    @Tool(description = "根据CCA项目短id、任务短id、执行记录短id，终止CCA扫描任务执行")
    public CCAHttpResult<?> terminateTask(
            @ToolParam(description = "CCA服务地址", required = false) String ccaServer,
            @ToolParam(description = "CCA项目短id,projectShortId") String projectShortId,
            @ToolParam(description = "CCA任务短id, taskShortId") String taskShortId,
            @ToolParam(description = "CCA执行记录短id, executionShortId") String executionShortId
    ) {
        CCAHttpResult<?> terminateResult = ccaClient.terminateTask(ccaServer, projectShortId, taskShortId, executionShortId);
        if (null != terminateResult) {
            terminateResult.defaultSuccessMsg();
        }
        return terminateResult;
    }

    @Tool(description = "根据CCA项目短id、发布版本名称versionName，获取版本4个0安全扫描工具报告")
    public List<CCAVersionReportDTO> getVersionReport(
            @ToolParam(description = "CCA服务地址", required = false) String ccaServer,
            @ToolParam(description = "CCA项目短id,projectShortId") String projectShortId,
            @ToolParam(description = "发布版本名称, versionName") String versionName
    ) {
        return ccaClient.getVersionReport(ccaServer, projectShortId, versionName);
    }



}
