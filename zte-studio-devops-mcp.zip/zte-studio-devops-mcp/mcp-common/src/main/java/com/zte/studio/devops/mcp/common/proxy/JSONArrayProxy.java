package com.zte.studio.devops.mcp.common.proxy;

import com.alibaba.fastjson.JSONArray;
import lombok.Data;

import java.io.Serializable;
import java.util.Collection;

@Data
public class JSONArrayProxy implements Serializable {
    private static final long serialVersionUID = 8715308221872170691L;
    private final JSONArray jsonArray;

    public JSONArrayProxy(JSONArray jsonArray) {
        this.jsonArray = jsonArray;
    }

    public JSONArrayProxy() {
        this.jsonArray = new JSONArray();
    }
    public int size() {
        return this.jsonArray.size();
    }

    public boolean isEmpty() {
        return this.jsonArray.isEmpty();
    }

    public JSONObjectProxy getJSONObject(int index) {
        return new JSONObjectProxy(this.jsonArray.getJSONObject(index));
    }
    public Object[] toArray() {
        return this.jsonArray.toArray();
    }

    public boolean addAll(Collection<?> c) {
        return this.jsonArray.addAll(c);
    }

    @Override
    public String toString() {
        return this.jsonArray.toJSONString();
    }
}
