package com.zte.studio.devops.mcp.common.proxy;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.io.Serializable;
import java.util.Objects;
import java.util.Set;


@Data
public class JSONObjectProxy implements Serializable {
    private static final long serialVersionUID = 424753342552449750L;
    private final JSONObject jsonObject;

    public JSONObjectProxy(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }
    public JSONObjectProxy() {
        jsonObject = new JSONObject();
    }

    public Object put(String key, Object value) {
        return jsonObject.put(key, value);
    }

    public Object get(String key) {
        return jsonObject.get(key);
    }

    public void remove(String key) {
        jsonObject.remove(key);
    }

    public boolean isEmpty() {
        return this.jsonObject.isEmpty();
    }

    public boolean containsKey(Object key) {
        if(Objects.isNull(key)){
            return false;
        }else {
            return this.jsonObject.containsKey(key);
        }
    }
    public JSONObjectProxy getJSONObject(String key) {
        if (this.jsonObject.containsKey(key)){
            return new JSONObjectProxy(this.jsonObject.getJSONObject(key));
        }
        return null;
    }

    public String getString(String key) {
        return this.jsonObject.getString(key);
    }
    public int getIntValue(String key) {
        return this.jsonObject.getIntValue(key);
    }

    public Boolean getBoolean(String key) {
        return this.jsonObject.getBoolean(key);
    }

    public JSONArrayProxy getJSONArray(String key) {
        if(this.jsonObject.containsKey(key)){
            return new JSONArrayProxy(this.jsonObject.getJSONArray(key));
        }
        return null;
    }
    public Set<String> keySet() {
        return this.jsonObject.keySet();
    }
    @Override
    public String toString() {
        return this.jsonObject.toJSONString();
    }
}
