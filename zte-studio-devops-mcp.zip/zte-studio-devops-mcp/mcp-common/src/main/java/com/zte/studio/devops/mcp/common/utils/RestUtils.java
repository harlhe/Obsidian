package com.zte.studio.devops.mcp.common.utils;

import com.alibaba.fastjson.TypeReference;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * REST请求调用封装
 *
 * @author chi.yuxing
 * @createDate 2022/8/9 16:36
 */
public class RestUtils {
    private static final Logger logger = LoggerFactory.getLogger(RestUtils.class);

    private static final okhttp3.MediaType MEDIA_TYPE_JSON = MediaType.parse("application/json; charset=utf-8");
    private static final okhttp3.MediaType MEDIA_TYPE_YAML = MediaType.parse("application/yaml; charset=utf-8");
    private static final okhttp3.MediaType MEDIA_TYPE_XML = MediaType.parse("application/xml; charset=utf-8");
    private static final okhttp3.MediaType MEDIA_TYPE_FORM_URLENCODED = MediaType.parse("application/x-www-form-urlencoded; charset=utf-8");
    private static final okhttp3.MediaType MEDIA_TYPE_FORM = MediaType.parse("multipart/form-data; charset=utf-8");

    private static OkHttpClient simpleClient;

    private static OkHttpClient sslTrustClient;

    public static <T> T get(String url, Class<T> responseType) {
        String resBody = doRequestForBody(new Request.Builder().url(url).build());
        return JsonUtils.toJavaObject(resBody, responseType);
    }

    public static <T> T get(String url, TypeReference<T> responseType) {
        String resBody = doRequestForBody(new Request.Builder().url(url).build());
        return JsonUtils.toJavaObject(resBody, responseType);
    }

    public static <T> T get(String url, Map<String, String> headerMap, TypeReference<T> responseType) {
        Request.Builder reqBuilder = new Request.Builder().url(url);
        if (!CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        String resBody = doRequestForBody(reqBuilder.build());
        return JsonUtils.toJavaObject(resBody, responseType);
    }

    public static <T> T getSSLTrust(String url, Map<String, String> headerMap, TypeReference<T> responseType) {
        Request.Builder reqBuilder = new Request.Builder().url(url);
        if (!CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        try (Response response = doRequestSSLTrust(reqBuilder.build())) {
            if (Objects.nonNull(response.body())) {
                String resBody = response.body().string();
                if (StringUtils.hasText(resBody)) {
                    return JsonUtils.toJavaObject(resBody, responseType);
                }
            } else {
                return null;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public static <REQ, RES> RES post(String url, REQ body, Class<RES> responseType) {
        String resBody = post(url, null, JsonUtils.toJsonString(body));
        if (StringUtils.hasText(resBody)) {
            return JsonUtils.toJavaObject(resBody, responseType);
        }
        return null;
    }

    public static <REQ, RES> RES post(String url, REQ body, TypeReference<RES> responseType) {
        String resBody = post(url, null, JsonUtils.toJsonString(body));
        if (StringUtils.hasText(resBody)) {
            return JsonUtils.toJavaObject(resBody, responseType);
        }
        return null;
    }

    public static <REQ, RES> RES postSSLTrust(String url, REQ body, TypeReference<RES> responseType) {
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_JSON, JsonUtils.toJsonString(body));
        Request.Builder reqBuilder = new Request.Builder().url(url).post(reqBody);
        try (Response response = doRequestSSLTrust(reqBuilder.build())) {
            if (Objects.nonNull(response.body())) {
                String resBody = response.body().string();
                if (StringUtils.hasText(resBody)) {
                    return JsonUtils.toJavaObject(resBody, responseType);
                }
            } else {
                return null;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    /* Started by AICoder, pid:p66ecr1d79fccc11426e08b1a042513a10e59c4c */
    public static String postSSLTrustWithResponse(String url, Map<String, String> headerMap, String body, int timeout) {
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_JSON, body);
        Request.Builder reqBuilder = createRequest(url, "POST", reqBody, headerMap);

        try (Response response = doRequestSSLTrust(reqBuilder.build(), timeout)) {
            return handleResponse(response);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static String getSSLTrustWithResponse(String url, Map<String, String> headerMap, int timeout) {
        Request.Builder reqBuilder = createRequest(url, "GET", null, headerMap);
        try (Response response = doRequestSSLTrust(reqBuilder.build(), timeout)) {
            return handleResponse(response);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static Request.Builder createRequest(String url, String method, RequestBody body, Map<String, String> headerMap) {
        Request.Builder reqBuilder = new Request.Builder().url(url).method(method, body);

        if (headerMap != null && !headerMap.isEmpty()) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        return reqBuilder;
    }

    private static String handleResponse(Response response) throws IOException {
        if (Objects.nonNull(response.body())) {
            return response.body().string();
        }
        return null;
    }
    /* Ended by AICoder, pid:p66ecr1d79fccc11426e08b1a042513a10e59c4c */

    public static <REQ, RES> RES postSSLTrustForYaml(String url, Map<String, String> headerMap, REQ body, TypeReference<RES> responseType) {
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_YAML, body.toString());
        Request.Builder reqBuilder = new Request.Builder().url(url).post(reqBody);
        if (headerMap != null && !CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        try (Response response = doRequestSSLTrust(reqBuilder.build())) {
            if (Objects.nonNull(response.body())) {
                String resBody = response.body().string();
                if (StringUtils.hasText(resBody)) {
                    return JsonUtils.toJavaObject(resBody, responseType);
                }
            } else {
                return null;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public static <REQ, RES> RES post(String url, Map<String, String> headerMap, REQ body, TypeReference<RES> responseType) {
        String resBody = post(url, headerMap, JsonUtils.toJsonString(body));
        if (StringUtils.hasText(resBody)) {
            return JsonUtils.toJavaObject(resBody, responseType);
        }
        return null;
    }

    private static String post(String url, Map<String, String> headerMap, String body) {
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_JSON, body);
        Request.Builder reqBuilder = new Request.Builder().url(url).post(reqBody);
        if (headerMap != null && !CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        return doRequestForBody(reqBuilder.build());
    }

    public static String delete(String url, Map<String, String> headerMap, String body) {
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_JSON, body);
        Request.Builder reqBuilder = new Request.Builder().url(url).delete(reqBody);
        if (headerMap != null && !CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        return doRequestForBody(reqBuilder.build());
    }

    private static boolean putForResponse(String url, Map<String, String> headerMap, String body) {
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_JSON, body);
        Request.Builder reqBuilder = new Request.Builder().url(url).put(reqBody);
        if (!CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        return doRequestForResponse(reqBuilder.build());
    }

    private static boolean doRequestForResponse(Request request) {
        try (Response response = doRequest(request)) {
            if (Objects.nonNull(response.body())) {
                return response.isSuccessful() || response.isRedirect();
            } else {
                return false;
            }
        } catch (Exception e) {
            logger.error("HTTP request occurred error.\n" + e);
//            throw new RuntimeException(e);
            return false;
        }
    }

    private static String doRequestForBody(Request request) {
        try (Response response = doRequest(request)) {
            if (Objects.nonNull(response.body())) {
                return response.body().string();
            } else {
                return null;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static <REQ> List<String> postBodyForHeader(String url, REQ body, String targetHeader) {
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_FORM_URLENCODED, JsonUtils.toJsonString(body));
        Request.Builder reqBuilder = new Request.Builder().url(url).post(reqBody);
        return doRequestForHeader(reqBuilder.build(), targetHeader);
    }

    public static List<String> postFormForHeader(String url, Map<String, String> body, String targetHeader) {
        MultipartBody.Builder requestBodyBuilder = new MultipartBody.Builder().setType(MEDIA_TYPE_FORM);
        for (Map.Entry<String, String> entry : body.entrySet()) {
            requestBodyBuilder.addFormDataPart(entry.getKey(), entry.getValue());
        }
        Request.Builder reqBuilder = new Request.Builder().url(url).post(requestBodyBuilder.build());
        return doRequestForHeader(reqBuilder.build(), targetHeader);
    }

    private static List<String> doRequestForHeader(Request request, String targetHeader) {
        try (Response response = doRequest(request)) {
            return response.headers(targetHeader);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static Response doRequest(Request request) throws IOException {
        if (simpleClient == null) {
            simpleClient = new OkHttpClient();
        }
        Response response = simpleClient.newCall(request).execute();
        if (response.isSuccessful()) {
            return response;
        } else {
            throw new RuntimeException("HTTP request occurred error.\n" + response);
        }
    }


    private static Response doRequestSSLTrust(Request request) throws IOException {
        if (sslTrustClient == null) {
            sslTrustClient = new OkHttpClient.Builder()
                    .sslSocketFactory(SSLSocketClient.getSSLSocketFactory(), SSLSocketClient.getX509TrustManager())
                    .hostnameVerifier(SSLSocketClient.getHostnameVerifier())
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .build();
        }
        Response response = sslTrustClient.newCall(request).execute();
        if (response.isSuccessful()) {
            return response;
        } else {
            String errorMsg = "HTTP request occurred error.\n" + response;
            if(response.body() != null){
                errorMsg = errorMsg + "\n" + response.body().string();
            }
            throw new RuntimeException(errorMsg);
        }
    }

    private static Response doRequestSSLTrust(Request request,int timeout) throws IOException {
        if (sslTrustClient == null) {
            sslTrustClient = new OkHttpClient.Builder()
                    .sslSocketFactory(SSLSocketClient.getSSLSocketFactory(), SSLSocketClient.getX509TrustManager())
                    .hostnameVerifier(SSLSocketClient.getHostnameVerifier())
                    .connectTimeout(timeout, TimeUnit.SECONDS)
                    .writeTimeout(timeout, TimeUnit.SECONDS)
                    .readTimeout(timeout, TimeUnit.SECONDS)
                    .build();
        }
        Response response = sslTrustClient.newCall(request).execute();
        if (response.isSuccessful()) {
            return response;
        } else {
            String errorMsg = "HTTP request occurred error.\n" + response;
            if(response.body() != null){
                errorMsg = errorMsg + "\n" + response.body().string();
            }
            throw new RuntimeException(errorMsg);
        }
    }

    public static String postForXml(String url, Map<String, String> headerMap, String body) {
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_XML, body);
        Request.Builder reqBuilder = new Request.Builder().url(url).post(reqBody);
        if (!CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        return doRequestForBody(reqBuilder.build());
    }

    public static <REQ, RES> boolean isPutSuccess(String url, Map<String, String> headerMap, REQ body, TypeReference<RES> responseType) {
        return putForResponse(url, headerMap, JsonUtils.toJsonString(body));
    }

    public static <RES> RES postForm(String url, Map<String, String> headerMap, Map<String, Object> form, TypeReference<RES> responseType) {
        MultipartBody.Builder requestBodyBuilder = new MultipartBody.Builder().setType(MEDIA_TYPE_FORM);
        for (Map.Entry<String, Object> entry : form.entrySet()) {
            if(Objects.nonNull(entry.getValue())){
                requestBodyBuilder.addFormDataPart(entry.getKey(), entry.getValue().toString());
            }
        }
        Request.Builder reqBuilder = new Request.Builder().url(url).post(requestBodyBuilder.build());
        if (!CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        String resBody = doRequestForBody(reqBuilder.build());
        if (StringUtils.hasText(resBody)) {
            return JsonUtils.toJavaObject(resBody, responseType);
        }
        return null;
    }

    public static <RES> RES deleteSSLTrust(String url, Map<String, String> headerMap, TypeReference<RES> responseType) {
        Request.Builder reqBuilder = new Request.Builder().url(url).delete();
        if (headerMap != null && !CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        try (Response response = doRequestSSLTrust(reqBuilder.build())) {
            if (Objects.nonNull(response.body())) {
                String resBody = response.body().string();
                if (StringUtils.hasText(resBody)) {
                    return JsonUtils.toJavaObject(resBody, responseType);
                }
            } else {
                return null;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public static <REQ, RES> RES delete(String url, REQ body, Class<RES> responseType) {
        String resBody = delete(url, null, JsonUtils.toJsonString(body));
        if (StringUtils.hasText(resBody)) {
            return JsonUtils.toJavaObject(resBody, responseType);
        }
        return null;
    }

    public static InputStream getStream(String url) throws IOException {
        try{
            //此处response不可关闭，因为上层调用会持续使用，获取结果
            Response response = doRequest(new Request.Builder().url(url).build());
            if (Objects.nonNull(response.body())) {
                return response.body().byteStream();
            } else {
                return null;
            }
        }catch (Exception e){
            return null;
        }
    }

    public static String getAsString(String url) {
        Request request = new Request.Builder().url(url).build();
        try (Response response = doRequest(request)) {
            if (Objects.nonNull(response.body())) {
                return response.body().string();
            } else {
                return null;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static <T> T put(String url, TypeReference<T> responseType, String body){
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_JSON, body);
        String resBody = doRequestForBody(new Request.Builder().url(url).put(reqBody).build());
        return JsonUtils.toJavaObject(resBody, responseType);
    }

    public static <T> T put(String url, Map<String, String> headerMap ,TypeReference<T> responseType, String body){
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_JSON, body);
        Request.Builder reqBuilder = new Request.Builder().url(url).put(reqBody);
        if (headerMap != null && !CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        String resBody = doRequestForBody(reqBuilder.build());
        return JsonUtils.toJavaObject(resBody, responseType);
    }

    public static <REQ, RES> RES postSSLTrust(String url, Map<String, String> headerMap, REQ body, TypeReference<RES> responseType) {
        String resBody = postSSLTrust(url, headerMap, JsonUtils.toJsonString(body));
        if (StringUtils.hasText(resBody)) {
            return JsonUtils.toJavaObject(resBody, responseType);
        }
        return null;
    }

    private static String postSSLTrust(String url, Map<String, String> headerMap, String body) {
        RequestBody reqBody = RequestBody.create(MEDIA_TYPE_JSON, body);
        Request.Builder reqBuilder = new Request.Builder().url(url).post(reqBody);
        if (headerMap != null && !CollectionUtils.isEmpty(headerMap)) {
            for (Map.Entry<String, String> header : headerMap.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }
        return doRequestForBodySSLTrust(reqBuilder.build());
    }

    private static String doRequestForBodySSLTrust(Request request) {
        try (Response response = doRequestSSLTrust(request)) {
            if (Objects.nonNull(response.body())) {
                return response.body().string();
            } else {
                return null;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
