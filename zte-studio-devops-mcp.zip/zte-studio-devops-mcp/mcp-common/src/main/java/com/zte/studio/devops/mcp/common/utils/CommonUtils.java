package com.zte.studio.devops.mcp.common.utils;

/**
 * desc
 *
 * @author 10261252
 */
public class CommonUtils {
}
