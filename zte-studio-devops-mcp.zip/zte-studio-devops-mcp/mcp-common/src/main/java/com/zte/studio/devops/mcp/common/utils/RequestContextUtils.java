package com.zte.studio.devops.mcp.common.utils;

/**
 * 请求上下文工具
 */
public final class RequestContextUtils {
    // MCP TOOL是另起线程池执行，使用InheritableThreadLocal来让工具执行线程获取到请求头相关信息
    private static final InheritableThreadLocal<String> TOKEN = new InheritableThreadLocal<>();
    private static final InheritableThreadLocal<String> TENANT_ID = new InheritableThreadLocal<>();
    private static final InheritableThreadLocal<String> ACCOUNT_ID = new InheritableThreadLocal<>();
    private static final InheritableThreadLocal<String> WORKSPACE = new InheritableThreadLocal<>();
    private static final InheritableThreadLocal<String> TEAM_ID = new InheritableThreadLocal<>();
    private static final InheritableThreadLocal<String> AREA_ID = new InheritableThreadLocal<>();
    private static final InheritableThreadLocal<String> X_CCA_SERVER = new InheritableThreadLocal<>();
    private static final InheritableThreadLocal<String> X_JFROG_SERVER = new InheritableThreadLocal<>();
    private static final InheritableThreadLocal<String> X_JFROG_ACCOUNT = new InheritableThreadLocal<>();
    private static final InheritableThreadLocal<String> X_JFROG_APIKEY = new InheritableThreadLocal<>();

    private static final InheritableThreadLocal<String> CODE_TENANT = new InheritableThreadLocal<>();

    public static void setToken(String token) {
        TOKEN.set(token);
    }

    /**
     * 获取当前操作用户的TOKEN
     * @return
     */
    public static String getToken() {
      return TOKEN.get();
    }

    public static void setAccountId(String employeeNO) {
        ACCOUNT_ID.set(employeeNO);
    }


    /**
     * 获取当前操作用户的租户
     * @return
     */
    public static String getTenantId() {
        return TENANT_ID.get();
    }

    public static void setTenantId(String tenantId) {
        TENANT_ID.set(tenantId);
    }

    /**
     * 获取当前操作用户的工号
     * @return
     */
    public static String getAccountId() {
        return ACCOUNT_ID.get();
    }

    /**
     * 获取当前操作的工作区
     * @return
     */
    public static String getWorkspace() { return WORKSPACE.get(); }

    public static void setWorkspace(String workspace) {
        WORKSPACE.set(workspace);
    }

    /**
     * 获取当前操作的团队
     * @return
     */
    public static String getTeamId() { return TEAM_ID.get(); }

    public static void setTeamId(String teamId) {
        TEAM_ID.set(teamId);
    }

    public static String getAreaId() { return AREA_ID.get(); }

    public static void setAreaId(String areaId) {
        AREA_ID.set(areaId);
    }

    public static void setCodeTenant(String codeTenant){
      CODE_TENANT.set(codeTenant);
    }

    public static String getCodeTenant(){
      return CODE_TENANT.get();
    }

    public static void setJfrogAccount(String jfrogAccount) {
        X_JFROG_ACCOUNT.set(jfrogAccount);
    }

    public static void setCCAServer (String ccaServer) {
        X_CCA_SERVER.set(ccaServer);
    }

    public static String getCCAServer() {
        return X_CCA_SERVER.get();
    }



    public static void setJfrogServer(String jfrogServer) {
        X_JFROG_SERVER.set(jfrogServer);
    }

    public static void setJfrogApikey(String jfrogApikey) {
        X_JFROG_APIKEY.set(jfrogApikey);
    }

    public static String getJfrogAccount() {
        return X_JFROG_ACCOUNT.get();
    }

    public static String getJfrogServer() {
        return X_JFROG_SERVER.get();
    }

    public static String getJfrogApiKey() {
        return X_JFROG_APIKEY.get();
    }

    public static void clear() {

        TOKEN.remove();

        TENANT_ID.remove();

        ACCOUNT_ID.remove();

        TEAM_ID.remove();

        WORKSPACE.remove();

        AREA_ID.remove();

        CODE_TENANT.remove();

        X_JFROG_ACCOUNT.remove();

        X_JFROG_SERVER.remove();

        X_JFROG_APIKEY.remove();

    }
}
