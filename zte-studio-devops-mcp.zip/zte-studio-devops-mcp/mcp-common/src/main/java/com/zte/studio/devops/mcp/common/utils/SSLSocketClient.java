package com.zte.studio.devops.mcp.common.utils;

import org.bouncycastle.asn1.pkcs.RSAPrivateKey;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateKeySpec;
import java.util.Arrays;
import java.util.Objects;


public class SSLSocketClient {
    private static final Logger logger = LoggerFactory.getLogger(SSLSocketClient.class);
    //获取这个SSLSocketFactory
    public static SSLSocketFactory getSSLSocketFactory() {
        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, getTrustManager(), new SecureRandom());
            return sslContext.getSocketFactory();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //获取TrustManager
    private static TrustManager[] getTrustManager() {
        return new TrustManager[]{
                new X509TrustManager() {
                    @Override
                    public void checkClientTrusted(X509Certificate[] chain, String authType) {
                    }

                    @Override
                    public void checkServerTrusted(X509Certificate[] chain, String authType) {
                    }

                    @Override
                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[]{};
                    }
                }
        };
    }

    //获取HostnameVerifier
    public static HostnameVerifier getHostnameVerifier() {
        return (s, sslSession) -> true;
    }

    public static X509TrustManager getX509TrustManager() {
        X509TrustManager trustManager = null;
        try {
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init((KeyStore) null);
            TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
            if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
                throw new IllegalStateException("Unexpected default trust managers:" + Arrays.toString(trustManagers));
            }
            trustManager = (X509TrustManager) trustManagers[0];
        } catch (Exception e) {
            e.printStackTrace();
        }

        return trustManager;
    }

    /**
     *
     * @param caCrt
     * @param clientCrt
     * @param clientKey
     * @return
     * @throws Exception
     */
    public static SSLSocketFactory getSSLSocketFactory(String caCrt, String clientCrt, String clientKey) throws Exception {
        //CA证书是用来认证服务端的，CA就是一个公认的认证证书
        String caAlias = "";
        String crtAlias = "";
        String password = "";
        CertificateFactory caCertFactory = CertificateFactory.getInstance("X.509");
        InputStream caStream = new ByteArrayInputStream(caCrt.getBytes((StandardCharsets.UTF_8)));
        Certificate ca = caCertFactory.generateCertificate(caStream);
        KeyStore caKeyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        caKeyStore.load(null, password.toCharArray());
        caKeyStore.setCertificateEntry(caAlias, ca);
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(caKeyStore);
        //关闭文件流
        caStream.close();

        //crt客户端证书，发送给服务端做双向验证
        CertificateFactory crtCertFactory = CertificateFactory.getInstance("X.509");
        InputStream crtStream =new ByteArrayInputStream(clientCrt.getBytes(StandardCharsets.UTF_8));
        Certificate crt = crtCertFactory.generateCertificate(crtStream);
        KeyStore crtKeyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        crtKeyStore.load(null, password.toCharArray());
        crtKeyStore.setCertificateEntry(crtAlias, crt);
        //客户端私钥，处理双向SSL验证中服务端用客户端证书加密的数据的解密（解析签名）工具
        //加载openssl私钥文件并返回解析对象
        PrivateKey privateKey = getPrivateKey(clientKey);
        crtKeyStore.setKeyEntry(crtAlias + ".private.key",  privateKey, password.toCharArray(), new Certificate[]{crt});

        //初始化秘钥管理器
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(crtKeyStore, password.toCharArray());
        //关闭文件流0
        crtStream.close();

        //注意，此处用TLSv1.2，需要服务端与客户端采用相同协议
        SSLContext sslContext = SSLContext.getInstance("TLSv1.3");
        // 第一个参数是授权的密钥管理器，用来授权验证。TrustManager[]第二个是被授权的证书管理器，用来验证服务器端的证书。第三个参数是一个随机数值，可以填写null
        sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), new SecureRandom());
        //跳过CA证书校验
        /*
        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }
            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }
        };
        sslContext.init(kmf.getKeyManagers(), trustAllCerts, new SecureRandom());
        */
        return sslContext.getSocketFactory();
    }

    /**
     * 将字符串key对象转化成私钥对象
     * @param keyData
     * @return
     * @throws Exception
     */
    public static PrivateKey getPrivateKey(String keyData) throws Exception {
        PrivateKey privKey = null;
        PemReader pemReader = null;
        try {
            if (Objects.isNull(keyData)){
                throw new FileNotFoundException("can not find private key：" + keyData);
            }
            pemReader = new PemReader(new StringReader(keyData));
            PemObject pemObject = pemReader.readPemObject();

            byte[] pemContent = pemObject.getContent();
            if(Objects.isNull(pemObject)){
                return privKey;
            }
            //支持从PKCS#1 PKCS#8 格式的私钥文件中提取私钥
            if (pemObject.getType().endsWith("RSA PRIVATE KEY")) {
                //从PKCS#1取得私钥, openssl genrsa 默认生成的私钥就是PKCS1的编码
                RSAPrivateKey asn1PrivKey = RSAPrivateKey.getInstance(pemContent);
                RSAPrivateKeySpec rsaPrivKeySpec = new RSAPrivateKeySpec(asn1PrivKey.getModulus(), asn1PrivKey.getPrivateExponent());
                KeyFactory keyFactory= KeyFactory.getInstance("rsa");
                privKey= keyFactory.generatePrivate(rsaPrivKeySpec);
            } else if (pemObject.getType().endsWith("PRIVATE KEY")) {
                //通过openssl pkcs8 -topk8转换为pkcs8，例如（-nocrypt不做额外加密操作）：
                //openssl pkcs8 -topk8 -in pri.key -out pri8.key -nocrypt
                //从PKCS#8取得私钥
                PKCS8EncodedKeySpec privKeySpec = new PKCS8EncodedKeySpec(pemContent);
                KeyFactory kf = KeyFactory.getInstance("rsa");
                privKey = kf.generatePrivate(privKeySpec);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            try {
                if (pemReader != null) {
                    pemReader.close();
                }
            } catch (Exception e) {
                logger.error("Read pem information error,",e);
            }
        }
        return privKey;
    }
}
