package com.zte.studio.devops.mcp.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.zte.studio.devops.mcp.common.proxy.JSONArrayProxy;
import com.zte.studio.devops.mcp.common.proxy.JSONObjectProxy;


import java.util.List;

/**
 * @author 10261219@zte.intra
 */
public class JsonUtils {

    /**
     * 对象转JSON字符串
     *
     * @param obj
     * @return
     */
    public static String toJsonString(Object obj) {
        return JSON.toJSONString(obj);
    }

    public static String toJsonStringWithNullValue(Object obj) {
        return JSON.toJSONString(obj, SerializerFeature.WriteMapNullValue);
    }

    /**
     * JSON字符串转对象
     *
     * @param jsonStr
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T toJavaObject(String jsonStr, Class<T> clazz) {
        try {
            return JSON.parseObject(jsonStr, clazz);
        } catch (Exception e) {
            throw new RuntimeException("Parse json string to java object occurred error.\nJson String:" + jsonStr, e);
        }
    }

    /**
     * JSON字符串转对象，支持泛型
     *
     * @param jsonStr
     * @param typeReference
     * @param <T>
     * @return
     */
    public static <T> T toJavaObject(String jsonStr, TypeReference<T> typeReference) {
        try {
            return JSON.parseObject(jsonStr, typeReference);
        } catch (Exception e) {
            throw new RuntimeException("Parse json string to java object occurred error.\nJson String:" + jsonStr, e);
        }
    }

    public static JSONObjectProxy toJSONObject(Object obj) {
        try {
            return new JSONObjectProxy((JSONObject) JSON.toJSON(obj));
        } catch (Exception e) {
            throw new RuntimeException("Parse object to json object occurred error.\nJson obj:" + obj, e);
        }
    }

    public static JSONArrayProxy toJSONArray(Object obj) {
        try {
            return new JSONArrayProxy(JSONArray.parseArray(JSON.toJSONString(obj)));
        } catch (Exception e) {
            throw new RuntimeException("Parse object to JSONArray occurred error.\nJson obj:" + obj, e);
        }
    }

    public static JSONArrayProxy toJSONArrayWithNullValue(Object obj) {
        try {
            return new JSONArrayProxy(JSONArray.parseArray(JSON.toJSONString(obj, SerializerFeature.WriteMapNullValue)));
        } catch (Exception e) {
            throw new RuntimeException("Parse object to JSONArray occurred error.\nJson obj:" + obj, e);
        }
    }

    public static JSONArrayProxy toJSONArray(List<Object> obj) {
        try {
            return new JSONArrayProxy(JSONArray.parseArray(JSON.toJSONString(obj)));
        } catch (Exception e) {
            throw new RuntimeException("Parse object to JSONArray occurred error.\nJson obj:" + obj, e);
        }
    }

    public static JSONArrayProxy toJSONArrayWithNullValue(List<Object> obj) {
        try {
            return new JSONArrayProxy(JSONArray.parseArray(JSON.toJSONString(obj, SerializerFeature.WriteMapNullValue)));
        } catch (Exception e) {
            throw new RuntimeException("Parse object to JSONArray occurred error.\nJson obj:" + obj, e);
        }
    }

    public static JSONObjectProxy toJSONObject(String jsonStr) {
        try {
            return new JSONObjectProxy(JSON.parseObject(jsonStr));
        } catch (Exception e) {
            throw new RuntimeException("Parse object to JSONObject occurred error.\nJson str:" + jsonStr, e);
        }
    }

    public static JSONArrayProxy toJSONArray(String jsonStr) {
        try {
            return new JSONArrayProxy(JSONArray.parseArray(jsonStr));
        } catch (Exception e) {
            throw new RuntimeException("Parse object to JSONArray occurred error.\nJson str:" + jsonStr, e);
        }
    }
}
