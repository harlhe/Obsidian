package com.zte.studio.devops.mcp.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * desc inone相关配置
 *
 * @author 10261252
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "inone-api")
public class InoneApiProperties {
    private String appCode;
    private String personGeneralInfo;
}
