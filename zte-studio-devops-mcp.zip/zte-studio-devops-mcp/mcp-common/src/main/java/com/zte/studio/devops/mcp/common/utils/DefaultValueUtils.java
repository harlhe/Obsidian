package com.zte.studio.devops.mcp.common.utils;

public class DefaultValueUtils {
    /**
     * 如果字符串为 null、空或纯空白则返回默认值
     * @param str 原始字符串
     * @param defaultValue 默认值
     * @return 非空白字符串
     */
    public static String ifNullOrBlank(String str, String defaultValue) {
        return (str != null && !str.trim().isEmpty()) ? str : defaultValue;
    }

    /**
     * 如果对象为 null 则返回默认值
     * @param value 原始值
     * @param defaultValue 默认值
     * @return 非空值
     */
    public static Boolean ifNull(Boolean value, Boolean defaultValue) {
        return value != null ? value : defaultValue;
    }

    /**
     * 如果对象为 null 则返回默认值
     * @param value 原始值
     * @param defaultValue 默认值
     * @return 非空值
     */
    public static Integer ifNull(Integer value, Integer defaultValue) {
        return value != null ? value : defaultValue;
    }
}
