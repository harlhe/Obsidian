package com.zte.studio.devops.mcp.common.constants;

/**
 * desc
 *
 * @author 10261252
 */
public class CommonConstants {

    public static final String SUCCESS_CODE = "0000";
}
