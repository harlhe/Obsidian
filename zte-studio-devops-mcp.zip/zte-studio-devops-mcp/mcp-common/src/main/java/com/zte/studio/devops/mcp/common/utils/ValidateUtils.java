package com.zte.studio.devops.mcp.common.utils;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 10261219@zte.intra
 */
public class ValidateUtils {

    private final static String STR_HTTPS = "https";
    private static final int INDEX_NOT_FOUND = -1;
    public static Pattern pattern = Pattern.compile("[0-9a-zA-Z]{1,}");

    /**
     * 验证coverity扫描url漏洞, URL manipulation (URL_MANIPULATION)
     *
     * @param params 待验证的url
     * @return
     */
    public static String validateParams(String params) {
        if (isBlank(params)) {
            return params;
        }
        if (countMatches(params, STR_HTTPS) == 1) {
            return params;
        }
        return params;
    }

    private static int countMatches(final CharSequence str, final CharSequence sub) {
        if (isEmpty(str) || isEmpty(sub)) {
            return 0;
        }
        int count = 0;
        int idx = 0;
        while ((idx = indexOf(str, sub, idx)) != INDEX_NOT_FOUND) {
            count++;
            idx += sub.length();
        }
        return count;
    }

    private static int indexOf(final CharSequence cs, final CharSequence searchChar, final int start) {
        if (cs instanceof String) {
            return ((String) cs).indexOf(searchChar.toString(), start);
        } else if (cs instanceof StringBuilder) {
            return ((StringBuilder) cs).indexOf(searchChar.toString(), start);
        } else if (cs instanceof StringBuffer) {
            return ((StringBuffer) cs).indexOf(searchChar.toString(), start);
        }
        return cs.toString().indexOf(searchChar.toString(), start);
    }

    private static boolean isBlank(final CharSequence cs) {
        final int strLen = length(cs);
        if (strLen == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if (!Character.isWhitespace(cs.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static int length(final CharSequence cs) {
        return cs == null ? 0 : cs.length();
    }

    public static boolean isAlphaNumeric(String s) {
        Matcher m = pattern.matcher(s);
        return m.matches();
    }

    /**
     * 验证coverity扫描url漏洞, URL manipulation (URL_MANIPULATION)
     *
     * @param params 待验证的url
     * @return
     */
    public static Object validateObject(Object params) {
        if (isEmpty(params)) {
            return params;
        }
        if (params instanceof Integer) {
            return params;
        }
        if (params instanceof Long) {
            return params;
        }
        if (params instanceof Boolean) {
            return params;
        }
        if (params instanceof String) {
            return validateParams((String) params);
        }
        return params;
    }

    private static boolean isEmpty(final Object object) {
        if (object == null) {
            return true;
        }
        if (object instanceof CharSequence) {
            return ((CharSequence) object).length() == 0;
        }
        if (object.getClass().isArray()) {
            return Array.getLength(object) == 0;
        }
        if (object instanceof Collection<?>) {
            return ((Collection<?>) object).isEmpty();
        }
        if (object instanceof Map<?, ?>) {
            return ((Map<?, ?>) object).isEmpty();
        }
        return false;
    }
}