package com.zte.studio.devops.mcp.starter.filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * desc
 *
 * @author 10261252
 */
@Slf4j
@Component
@jakarta.servlet.annotation.WebFilter
public class AuthFilter implements Filter {

    private static final String MCP_MESSAGE_URL = "/mcp/message";
    private static final String X_API_KEY_HEADER = "x-api-key";
    private static final String AVAILABLE_API_KEY = "23333";

//    @PostConstruct
//    public void log() {
//        log.info("Bean has bean registered.");
//    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        HttpServletResponse httpResponse = (HttpServletResponse) servletResponse;
//        if (MCP_MESSAGE_URL.equals(httpServletRequest.getRequestURI())) {
//            String xApiKey = httpServletRequest.getHeader(X_API_KEY_HEADER);
//            if (!AVAILABLE_API_KEY.equals(xApiKey)) {
//                // 设置响应状态为401，并返回错误信息
//                httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
//                httpResponse.getWriter().write("Unauthorized: Please provide a valid x-api-key header.");
//                return; // 终止过滤器链的执行
//            }
//        }
        filterChain.doFilter(servletRequest, servletResponse);
    }
}
