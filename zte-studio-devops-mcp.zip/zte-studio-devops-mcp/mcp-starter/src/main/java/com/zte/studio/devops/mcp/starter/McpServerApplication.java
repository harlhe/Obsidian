package com.zte.studio.devops.mcp.starter;

import com.zte.studio.devops.mcp.core.service.iartifact.ArtifactService;
import com.zte.studio.devops.mcp.core.service.cca.CCAService;
import com.zte.studio.devops.mcp.core.service.icode_ccm.CodeCCMService;
import com.zte.studio.devops.mcp.core.service.ipipeline.PipelineService;
import com.zte.studio.devops.mcp.core.service.itest.TestManageService;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.function.FunctionToolCallback;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.zte.studio.devops.mcp.**"})
public class McpServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(McpServerApplication.class, args);
	}

	@Bean
	public ToolCallbackProvider pipelineTools(PipelineService pipelineService) {
		return MethodToolCallbackProvider.builder().toolObjects(pipelineService).build();
	}

	@Bean
	public ToolCallbackProvider artifactTools(ArtifactService artifactService) {
		return MethodToolCallbackProvider.builder().toolObjects(artifactService).build();
	}

	@Bean
	public ToolCallbackProvider ccaTools(CCAService ccaService) {
		return MethodToolCallbackProvider.builder().toolObjects(ccaService).build();
	}

	@Bean
	public ToolCallbackProvider iCodeCCMTools(CodeCCMService codeCCMService) {
		return MethodToolCallbackProvider.builder().toolObjects(codeCCMService).build();
	}

	@Bean
	public ToolCallbackProvider testManageTools(TestManageService testManageService) {
		return MethodToolCallbackProvider.builder().toolObjects(testManageService).build();
	}

//	@Bean
//	public ToolCallbackProvider weatherTools(WeatherService weatherService) {
//		return MethodToolCallbackProvider.builder().toolObjects(weatherService).build();
//	}

//	public record TextInput(String input) {
//	}
//
//	@Bean
//	public ToolCallback toUpperCase() {
//		return FunctionToolCallback.builder("toUpperCase", (TextInput input) -> input.input().toUpperCase())
//			.inputType(TextInput.class)
//			.description("Put the text to upper case")
//			.build();
//	}

}
