package com.zte.studio.devops.mcp.starter.interceptor;

import com.zte.studio.devops.mcp.common.utils.RequestContextUtils;
import com.zte.studio.devops.mcp.model.McpHeaderEnum;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import java.util.Objects;

/**
 * 请求上下文拦截器
 */
@Slf4j
public class RequestContextInterceptor implements HandlerInterceptor {

    private static final String TOKEN_HEADER = "X-Auth-Value";
    private static final String ACCOUNT_ID_HEADER = "X-Emp-No";
    private static final String X_TENANT_ID_HEADER = "X-Tenant-Id";
    private static final String DEFAULT_HEADER = "10001";
    private static final String WORKSPACE_HEADER = "X-Workspace";
    public static final String TEAM_ID_HEADER = "X-Team-Id";
    public static final String AREA_ID_HEADER = "X-Area-Id";
    public static final String JFROG_ACCOUNT = "X-Jfrog-Account";
    public static final String JFROG_SERVER = "X-Jfrog-Server";
    public static final String JFROG_APIKEY = "X-Jfrog-ApiKey";
    public static final String CODE_TENANT_KEY = "X-Code-Tenant";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String accountID = request.getHeader(ACCOUNT_ID_HEADER);
        RequestContextUtils.setAccountId(accountID);

        String token = request.getHeader(TOKEN_HEADER);
        RequestContextUtils.setToken(token);

        String tenantId = request.getHeader(X_TENANT_ID_HEADER);
        if (Objects.isNull(tenantId)) {
            tenantId = DEFAULT_HEADER;
        }
        RequestContextUtils.setTenantId(tenantId);

        String workspace = request.getHeader(WORKSPACE_HEADER);
        RequestContextUtils.setWorkspace(workspace);

        String teamId = request.getHeader(TEAM_ID_HEADER);
        RequestContextUtils.setTeamId(teamId);

        String areaId = request.getHeader(AREA_ID_HEADER);
        RequestContextUtils.setAreaId(areaId);

        String jfrogAccount = request.getHeader(JFROG_ACCOUNT);
        RequestContextUtils.setJfrogAccount(jfrogAccount);

        String ccaServer = request.getHeader(McpHeaderEnum.X_CCA_SERVER.key());
        RequestContextUtils.setCCAServer(ccaServer);

        String jfrogServer = request.getHeader(JFROG_SERVER);
        RequestContextUtils.setJfrogServer(jfrogServer);

        String jfrogApiKey = request.getHeader(JFROG_APIKEY);
        RequestContextUtils.setJfrogApikey(jfrogApiKey);

        String codeTenant = request.getHeader(CODE_TENANT_KEY);
        RequestContextUtils.setCodeTenant(codeTenant);
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        RequestContextUtils.clear();
    }
}