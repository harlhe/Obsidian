package com.zte.studio.devops.mcp.starter.interceptor;

import com.alibaba.fastjson.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zte.itp.msa.core.model.RetCode;
import com.zte.itp.msa.core.model.ServiceData;
import com.zte.studio.devops.mcp.common.utils.JsonUtils;
import com.zte.studio.devops.mcp.common.utils.RestUtils;
import com.zte.studio.devops.mcp.model.McpHeaderEnum;
import com.zte.studio.devops.mcp.model.dto.UacTokenVerifyDTO;
import com.zte.studio.devops.mcp.model.dto.UacTokenVerifyRespBo;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.HashMap;
import java.util.Map;


@Component
@Slf4j
public class UacAuthInterceptor implements HandlerInterceptor {

    @Value("${uac.system.code}")
    private String uacSystemCode;

    @Value("${uac.token.verify}")
    private String uacVerifyUrl;

    private static final String UAC_AUTH_FAILED = "Uac Auth Failed.";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String account = request.getHeader(McpHeaderEnum.X_ACCOUNT_ID.key());
        if (StringUtils.isBlank(account)) {
            account = request.getHeader(McpHeaderEnum.X_EMP_NO.key());
        }
        String token = request.getHeader(McpHeaderEnum.X_AUTH_VALUE.key());
        String clientIp = request.getRemoteAddr();
        if (!verifyUacToken(account, clientIp, token)) {
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            response.getWriter().write(new ObjectMapper().writeValueAsString(UAC_AUTH_FAILED));
            return false;
        }
        return true;
    }

    private boolean verifyUacToken(String account, String clientIp, String token) {
        UacTokenVerifyDTO verifyDTO = new UacTokenVerifyDTO();
        verifyDTO.setAccount(account);
        verifyDTO.setToken(token);
        verifyDTO.setClientIP(clientIp);
        verifyDTO.setSystemCode(uacSystemCode);
        verifyDTO.genVerifyCode();
        try {
            ServiceData<UacTokenVerifyRespBo> respDTO = RestUtils.post(uacVerifyUrl, getUacHeaders(), verifyDTO,
                    new TypeReference<>() {
                    });
            if (null == respDTO || null == respDTO.getCode()) {
                return false;
            }
            if (!RetCode.SUCCESS_CODE.equals(respDTO.getCode().getCode())
                    || null == respDTO.getBo()
                    || !UacTokenVerifyRespBo.authSuccess(respDTO.getBo())
            ) {
                log.error("Uac uth account: {} failed with resp: {}", account, JsonUtils.toJsonString(respDTO));
                return false;
            }
            return true;
        } catch (Exception e) {
            log.error("uac auth request failed.", e);
            return false;
        }
    }

    private Map<String, String> getUacHeaders() {
        Map<String, String> httpHeaders = new HashMap<>();
        httpHeaders.put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        return httpHeaders;
    }


}