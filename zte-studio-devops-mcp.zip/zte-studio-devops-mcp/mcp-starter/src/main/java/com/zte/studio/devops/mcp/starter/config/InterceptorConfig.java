package com.zte.studio.devops.mcp.starter.config;

import com.zte.studio.devops.mcp.starter.interceptor.RequestContextInterceptor;
import com.zte.studio.devops.mcp.starter.interceptor.UacAuthInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Slf4j
@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

    @Autowired
    private UacAuthInterceptor uacAuthInterceptor;

    @Value("${uac.token.enabled}")
    private Boolean uacTokenEnabled;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        RequestContextInterceptor reqContextInterceptor = new RequestContextInterceptor();
        registry.addInterceptor(reqContextInterceptor).addPathPatterns("/mcp/message");
        if (uacTokenEnabled) {
            registry.addInterceptor(uacAuthInterceptor).addPathPatterns("/*");
        }
    }
}